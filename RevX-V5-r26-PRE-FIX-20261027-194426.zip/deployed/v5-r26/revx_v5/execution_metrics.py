"""Measurements from actual observations; never requests or submits orders."""
import math
from .execution_truth import fee_in_usd


def finite(value):
    try:
        result=float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def observation(previous, intent, order, phase, now):
    row=dict(previous or {})
    meta=intent.get('metadata') or {}
    row.update(intent_id=intent['intent_id'],symbol=intent.get('symbol'),side=intent.get('side'),phase=phase)
    row.setdefault('decision_at',meta.get('decision_at'))
    row.setdefault('decision_mid',meta.get('decision_mid'))
    if phase=='SUBMIT_REQUESTED':
        row.setdefault('submit_requested_at',now)
    else:
        row.setdefault('response_observed_at',now)
    quantity=finite(order.get('filled_quantity'))
    price=finite(order.get('average_fill_price') or order.get('average_price'))
    if quantity is not None and quantity>0:
        row.setdefault('first_fill_observed_at',now)
        if quantity != finite(row.get('filled_quantity')):
            # A previous partial's cumulative price/fee does not describe a
            # different filled quantity. Missing new evidence stays unknown.
            row['average_fill_price'] = None
            row['fee_usd'] = None
        row.update(filled_quantity=quantity)
        if price is not None:
            row['average_fill_price']=price
        price=finite(row.get('average_fill_price'))
        mid=finite(row.get('decision_mid'))
        sign=1 if str(row.get('side')).upper()=='BUY' else -1
        row['shortfall_vs_decision_mid_bps']=(sign*(price/mid-1)*10000 if price and mid and mid>0 else None)
        row['effective_spread_bps']=(2*row['shortfall_vs_decision_mid_bps'] if row['shortfall_vs_decision_mid_bps'] is not None else None)
        fee=fee_in_usd(order)
        if finite(fee) is not None:
            row['fee_usd']=finite(fee)
        else:
            row.setdefault('fee_usd',None)
    row['fill_observation_latency_sec']=(row['first_fill_observed_at']-row['submit_requested_at']
        if 'first_fill_observed_at' in row and 'submit_requested_at' in row else None)
    row['updated_at']=now
    return row


def markouts(rows, prices, now):
    changed=False
    for row in rows.values():
        fill=finite(row.get('average_fill_price'))
        started=finite(row.get('first_fill_observed_at'))
        mid=finite(prices.get(str(row.get('symbol','')).replace('/','-')))
        if not fill or not started or not mid or mid<=0:
            continue
        for horizon in (60,300):
            key=f'markout_{horizon}s'
            if key in row or now-started<horizon:
                continue
            delay=now-started-horizon
            # Record actual sampling age; overdue samples are not called 1m/5m returns.
            sign=1 if str(row.get('side')).upper()=='BUY' else -1
            row[key]={'elapsed_sec':now-started,'delay_sec':delay,
                      'reference_fill_price':fill,'filled_quantity_at_mark':row.get('filled_quantity'),
                      'signed_bps':sign*(mid/fill-1)*10000 if delay<=30 else None,
                      'status':'OBSERVED' if delay<=30 else 'MISSED_WINDOW'}
            changed=True
    return changed
