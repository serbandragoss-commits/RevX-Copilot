"""Deterministic Day/Night mode clock preserved from the validated V4 schedule."""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime, timedelta, tzinfo


@dataclass(frozen=True)
class ModeWindow:
    mode: str
    session_key: str
    entry_open: bool
    observed_at: float


class AutoModeClock:
    def __init__(self, timezone: tzinfo | None = None, clock=time.time):
        # Windows' system local zone is authoritative for the laptop runtime.
        # Avoid a hidden dependency on the optional Python tzdata package.
        self.timezone = timezone
        self.clock = clock

    def current(self) -> ModeWindow:
        observed = float(self.clock())
        local = (datetime.fromtimestamp(observed, self.timezone)
                 if self.timezone is not None
                 else datetime.fromtimestamp(observed).astimezone())
        minute = local.hour * 60 + local.minute
        if 7 * 60 <= minute < 22 * 60:
            return ModeWindow("DAY", local.date().isoformat(), minute < 21 * 60 + 55,
                              observed)
        session_date = local.date() - timedelta(days=1) if minute < 7 * 60 else local.date()
        entry_open = minute >= 22 * 60 or minute < 6 * 60 + 55
        return ModeWindow("NIGHT", session_date.isoformat(), entry_open, observed)
