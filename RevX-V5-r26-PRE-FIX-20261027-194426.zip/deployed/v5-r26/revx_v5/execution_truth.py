"""Deterministic fill/fee truth helpers used after provider reconciliation."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable


def _dec(value: Any) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("non-numeric execution value") from exc
    if not result.is_finite() or result < 0:
        raise ValueError("invalid execution value")
    return result


def reported_fee(order: dict):
    return next((order[key] for key in ('fee', 'fees', 'total_fee') if order.get(key) is not None), None)


def fee_in_usd(order: dict) -> Decimal | None:
    if order.get('fee_usd') is not None:
        return _dec(order['fee_usd'])
    raw = reported_fee(order)
    if raw is None:
        return None
    amount = _dec(raw)
    if amount == 0:
        return amount
    if str(order.get('fee_currency') or '').strip().upper() in {'USD', 'USDC', 'USDT'}:
        return amount
    rate = order.get('fee_price_usd')
    return amount * _dec(rate) if rate is not None else None


def ledger_row_complete(row: dict) -> bool:
    known = row.get('fee_truth') == 'KNOWN'
    legacy_known = (row.get('fee_truth') is None
                    and row.get('entry_fee_usd') is not None
                    and row.get('exit_fee_usd') is not None)
    return (known or legacy_known) and row.get('net_pnl_usd') is not None


def recompute_session_risk(state: dict, mode: str, key: str) -> dict:
    rows = [row for row in state.get('economic_ledger', [])
            if row.get('operating_mode') == mode and row.get('session_key') == key]
    net = Decimal(0)
    for row in rows:
        if row.get('net_pnl_usd') is not None:
            try:
                value = Decimal(str(row['net_pnl_usd']))
            except (InvalidOperation, ValueError, TypeError) as exc:
                raise ValueError('invalid economic value') from exc
            if not value.is_finite():
                raise ValueError('invalid economic value')
            net += value
    risk = state.setdefault('risk', {}).setdefault(mode, {}).setdefault('sessions', {}).setdefault(key, {})
    risk.update(realized_net_pnl_usd=format(net, 'f'), complete=all(map(ledger_row_complete, rows)))
    return risk


@dataclass(frozen=True)
class FillSummary:
    quantity: Decimal
    gross_value: Decimal
    fees: Decimal
    expected_value: Decimal

    @property
    def net_value(self) -> Decimal:
        return self.gross_value - self.fees

    @property
    def slippage_value(self) -> Decimal:
        return self.gross_value - self.expected_value


def order_fill_state(order: dict) -> dict:
    """Normalize venue order status without treating partial as complete."""
    status = str(order.get("status", "")).lower()
    if status in {'partially_filled','partial'} and str(order.get('reject_reason','')).lower() in {'cancelled','canceled'}:
        status = 'cancelled'
    filled = _dec(order.get("filled_quantity", 0))
    leaves = order.get("leaves_quantity")
    if leaves is None:
        leaves = max(Decimal("0"), _dec(order.get("quantity", 0)) - filled)
    else:
        leaves = _dec(leaves)
    if status in {"partially_filled", "partial", "open", "new", "pending"} and filled > 0:
        phase = "PARTIAL"
    elif status in {"open", "new", "pending", "accepted"} and filled == 0:
        phase = "ACTIVE"
    elif status in {"filled", "complete", "completed"} and leaves == 0:
        phase = "FILLED"
    elif status in {"cancelled", "canceled", "rejected", "expired"}:
        phase = "TERMINAL_UNFILLED" if filled == 0 else "TERMINAL_PARTIAL"
    else:
        phase = "UNKNOWN"
    return {"phase": phase, "filled_quantity": filled, "leaves_quantity": leaves,
            "venue_order_id": order.get("id") or order.get("venue_order_id")}


def summarize_fills(rows: Iterable[dict], *, expected_price: Any | None = None) -> FillSummary:
    quantity = Decimal("0")
    gross = Decimal("0")
    fees = Decimal("0")
    expected = Decimal("0")
    for row in rows:
        qty = _dec(row.get("filled_quantity", row.get("quantity", 0)))
        price = _dec(row.get("average_price", row.get("average_fill_price",
                                                       row.get("price", 0))))
        fee = fee_in_usd({'fee_currency':'USD', **row})
        if fee is None:
            raise ValueError("USD-equivalent fee truth is required")
        quantity += qty
        gross += qty * price
        fees += fee
        expected += qty * (_dec(expected_price) if expected_price is not None else price)
    return FillSummary(quantity, gross, fees, expected)


def net_pnl(entry: FillSummary, exit: FillSummary) -> Decimal:
    """Net realized PnL after both entry and exit fees."""
    return exit.net_value - entry.net_value
