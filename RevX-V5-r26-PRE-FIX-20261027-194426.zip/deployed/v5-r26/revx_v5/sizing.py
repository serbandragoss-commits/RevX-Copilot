"""Pure BUY sizing; retains the planner's risk/cash/depth bounds and venue step."""
from decimal import Decimal, ROUND_FLOOR, ROUND_CEILING


def number(value, *, positive=False):
    result = Decimal(str(value))
    if not result.is_finite() or result < 0 or (positive and result == 0):
        raise ValueError("invalid sizing input")
    return result


def size_buy(plan, rules, exposure_remaining, config):
    price = number(plan.limit_price, positive=True)
    stop = number(plan.stop, positive=True)
    step = number(rules.base_step, positive=True)
    if stop >= price:
        raise ValueError("BUY stop must be below entry")
    # These are the existing configured cost assumptions, not new thresholds.
    fee = number(config.get("taker_fee_pct", 0.09)) / 100
    entry_slip = number(config.get("expected_entry_slippage_pct", 0.05)) / 100
    exit_slip = number(config.get("expected_exit_slippage_pct", 0.05)) / 100
    risk = number(plan.requested_risk_usd, positive=True)
    available = number(plan.available_usd)
    reserve = number(plan.cash_reserve_usd)
    capital = min(number(plan.capital_limit_usd), max(Decimal(0), available - reserve))
    # Costs relative to executable entry/stop prices: spread is not added twice.
    loss_per_unit = price - stop + price * (fee + entry_slip) + stop * (fee + exit_slip)
    bounds = {
        "planner": number(plan.quantity, positive=True),
        "risk_with_costs": risk / loss_per_unit,
        "cash_with_entry_costs": capital / (price * (1 + fee + entry_slip)),
        "portfolio_headroom": number(exposure_remaining) / price,
        "venue_maximum": number(rules.max_order_size, positive=True),
    }
    if config.get('v5_order_max_usd') is not None:
        bounds['operator_order_maximum'] = number(config['v5_order_max_usd'],positive=True)/price
    binding = min(bounds, key=bounds.get)
    quantity = (bounds[binding] / step).to_integral_value(rounding=ROUND_FLOOR) * step
    minimum = max(number(rules.min_order_size), number(rules.min_order_size_quote) / price)
    if config.get('v5_order_min_usd') is not None:
        minimum=max(minimum,number(config['v5_order_min_usd'])/price)
    if quantity <= 0 or quantity < minimum:
        raise ValueError("calculated BUY is below venue minimum")
    return quantity, {
        "mode": "DYNAMIC_RISK_CASH_COSTS",
        "binding": binding,
        "planner_quantity": str(plan.quantity),
        "quantity": str(quantity),
        "notional_usd": str(quantity * price),
        "minimum_notional_usd": str((minimum / step).to_integral_value(rounding=ROUND_CEILING) * step * price),
        "risk_budget_usd": str(risk),
        "estimated_stop_loss_with_costs_usd": str(quantity * loss_per_unit),
        "entry_cost_allowance_usd": str(quantity * price * (fee + entry_slip)),
        "portfolio_headroom_usd": str(exposure_remaining),
        "usable_cash_usd": str(capital),
        "cost_assumptions_pct": {"fee_each_side": str(fee * 100),
                                 "entry_slippage": str(entry_slip * 100),
                                 "exit_slippage": str(exit_slip * 100)},
    }


def pending_buy_commitment(orders):
    total = Decimal(0)
    symbols = set()
    seen = set()
    for order in orders:
        side = str(order.get("side", "")).upper()
        if side not in {"BUY", "SELL"}:
            raise ValueError("pending order side unavailable")
        if side == "SELL":
            continue  # Holdings still count until the sell actually fills.
        identity = str(order.get("id") or order.get("venue_order_id") or "")
        if not identity or identity in seen:
            raise ValueError("pending order identity unavailable or duplicated")
        seen.add(identity)
        price = number(order.get("price"), positive=True)
        filled = number(order.get("filled_quantity"))
        quantity = number(order.get("quantity"), positive=True)
        leaves = number(order.get("leaves_quantity", quantity - filled))
        if filled + leaves != quantity:
            raise ValueError("pending order quantities inconsistent")
        symbol = str(order.get("symbol", "")).upper().replace("/", "-")
        if not symbol:
            raise ValueError("pending symbol unavailable")
        total += leaves * price
        if leaves > 0:
            symbols.add(symbol)
    return total, symbols
