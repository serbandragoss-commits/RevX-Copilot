"""Executable V5 operating policy; keep values explicit and testable."""

from dataclasses import dataclass
from decimal import Decimal
import math
import json
from pathlib import Path


def operator_settings():
    value=json.loads((Path(__file__).resolve().parents[1]/'operator-policy.json').read_text(encoding='utf-8'))
    if value.get('schema') != 'revx-v5-operator-policy-v1':
        raise ValueError('invalid operator policy')
    for field in ('exposure_usd','order_min_usd','order_max_usd','session_loss_usd','risk_usd'):
        x=Decimal(value[field])
        if not x.is_finite() or x<=0:
            raise ValueError('invalid operator limit: '+field)
    if Decimal(value['order_min_usd'])>Decimal(value['order_max_usd']):
        raise ValueError('invalid order band')
    for field in ('day_max_positions','night_max_positions'):
        if type(value[field]) is not int or value[field]<=0:
            raise ValueError('invalid position limit')
    return value


def operator_policy():
    value=operator_settings()
    return RiskPolicy(order_usd=float(value['order_max_usd']),
        exposure_usd=float(value['exposure_usd']),
        session_loss_usd=float(value['session_loss_usd']),day_max_positions=value['day_max_positions'],
        night_max_positions=value['night_max_positions'])


def operator_config(config):
    value=operator_settings()
    return {**config, **{key:float(value['risk_usd']) for key in
        ('risk_usd','standard_risk_usd','ambitious_risk_usd','ignition_risk_usd')},
        'v5_order_min_usd':value['order_min_usd'],'v5_order_max_usd':value['order_max_usd']}


@dataclass(frozen=True)
class RiskPolicy:
    order_usd: float | None = None
    exposure_usd: float = 150.0
    session_loss_usd: float = 10.0
    day_max_positions: int = 20
    night_max_positions: int = 10

    def max_positions(self, mode: str) -> int:
        if mode == "DAY":
            return self.day_max_positions
        if mode == "NIGHT":
            return self.night_max_positions
        raise ValueError("mode must be DAY or NIGHT")

    def allows(self, mode: str, open_positions: int, exposure_usd: float,
               order_usd: float, session_loss_usd: float) -> bool:
        return (self.can_open(mode, open_positions, exposure_usd, session_loss_usd)
                and math.isfinite(order_usd) and order_usd > 0
                and Decimal(str(exposure_usd)) + Decimal(str(order_usd)) <= Decimal(str(self.exposure_usd))
                and (self.order_usd is None or order_usd <= self.order_usd))

    def can_open(self, mode: str, open_positions: int, exposure_usd: float,
                 session_loss_usd: float) -> bool:
        return (mode in {"DAY", "NIGHT"}
                and 0 <= open_positions < self.max_positions(mode)
                and math.isfinite(exposure_usd) and 0 <= exposure_usd < self.exposure_usd
                and math.isfinite(session_loss_usd)
                and session_loss_usd > -self.session_loss_usd)
