"""Adapt provider calls and verify execution evidence."""

from __future__ import annotations

from typing import Any


class MutationDisabledAdapter:
    """Fail-closed mutation seam used when exact LIVE authority is absent."""

    async def submit_order(self, _body: dict, _lane: Any = None):
        raise RuntimeError("V5 mutation client is not loaded")

    async def cancel_order(self, _venue_order_id: str, _lane: Any = None):
        raise RuntimeError("V5 mutation client is not loaded")


class RevXV5ProviderAdapter:
    def __init__(self, client: Any, lane: Any = None):
        self.client = client
        self.lane = lane
        self._fill_cache = {}

    def _lane(self, lane: Any = None) -> Any:
        return self.lane if lane is None else lane

    async def balances(self, lane: Any = None):
        active = self._lane(lane)
        return await (self.client.balances() if active is None
                      else self.client.balances(active))

    async def active_orders(self, symbol: str | None = None, lane: Any = None):
        active = self._lane(lane)
        return await (self.client.active_orders(symbol) if active is None
                      else self.client.active_orders(symbol, active))

    async def historical_orders(self, symbol: str | None = None, hours: int = 24,
                                lane: Any = None):
        active = self._lane(lane)
        return await (self.client.historical_orders(symbol, hours) if active is None
                      else self.client.historical_orders(symbol, hours, active))

    async def submit_order(self, body: dict, lane: Any = None):
        active = self._lane(lane)
        if active is None:
            return await self.client.submit_order(body)
        return await self.client.submit_order(body, active)

    async def cancel_order(self, venue_order_id: str, lane: Any = None):
        active = self._lane(lane)
        if active is None:
            return await self.client.cancel_order(venue_order_id)
        return await self.client.cancel_order(venue_order_id, active)

    async def order(self, venue_order_id: str, lane: Any = None):
        active = self._lane(lane)
        value = await (self.client.order(venue_order_id) if active is None
                       else self.client.order(venue_order_id, active))
        return await self.enrich_order(value, active)

    async def enrich_order(self, order, lane=None):
        from .execution_evidence import decimal, normalize_fills
        if decimal(order.get('filled_quantity', 0)) == 0 or order.get('execution_price_source') == 'INDIVIDUAL_FILLS':
            return order
        oid = str(order.get('id') or order.get('venue_order_id') or '')
        if not oid:
            raise ValueError('FILLED_ORDER_WITHOUT_ID')
        active = self._lane(lane)
        if order.get('total_fee') is None and order.get('fee') is None:
            detail = await (self.client.order(oid) if active is None else self.client.order(oid, active))
            if str(detail.get('id') or detail.get('venue_order_id')) != oid:
                raise ValueError('FILL_ORDER_IDENTITY_MISMATCH')
            order = detail
        key = (oid, str(order.get('filled_quantity')), str(order.get('updated_date')))
        fills = self._fill_cache.get(key)
        if fills is None:
            fills = await self.client.auth_get('/api/1.0/orders/fills/' + oid, {}, active, 'order-fills')
            normalized = normalize_fills(order, fills)
            self._fill_cache[key] = fills
            if len(self._fill_cache)>256:
                self._fill_cache.pop(next(iter(self._fill_cache)))
            return normalized
        return normalize_fills(order, fills)

    async def pair_configurations(self, lane: Any = None):
        active = self._lane(lane)
        return await (self.client.pair_configurations() if active is None
                      else self.client.pair_configurations(active))

    async def order_book(self, symbol: str, limit: int = 50, lane: Any = None):
        active = self._lane(lane)
        return await (self.client.order_book(symbol, limit) if active is None
                      else self.client.order_book(symbol, limit, active))

    async def tickers(self, lane: Any = None):
        active = self._lane(lane)
        return await (self.client.tickers() if active is None
                      else self.client.tickers(active))

    async def candles(self, symbol: str, interval: int = 15, hours: int = 24,
                      lane: Any = None):
        # Canonical v3.5.8 selects the ENTRY lane internally for candles.
        return await self.client.candles(symbol, interval, hours)
