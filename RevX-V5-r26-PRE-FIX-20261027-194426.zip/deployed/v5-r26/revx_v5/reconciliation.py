"""Authenticated read/reconciliation boundary for the V5 runtime.

The reconciler is deliberately injected with a client. Tests use a fake client;
the live adapter will be wired to the verified v3.5.8 client only after its
preflight contract passes.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Protocol


class ReadClient(Protocol):
    async def balances(self, lane: Any = None) -> Any: ...
    async def active_orders(self, symbol: str | None = None, lane: Any = None) -> Any: ...


class ReconciliationBlocked(RuntimeError):
    """Observed unresolved state: refuse new execution without claiming a crash."""
    def __init__(self, state):
        super().__init__('V5 startup blocked by ambiguous external order state')
        self.active_orders = len(state.active_orders)
        self.ambiguous_orders = sum(
            str(row.get('status', '')).upper() in {'UNKNOWN', 'PENDING', 'PARTIALLY_FILLED'}
            or not str(row.get('id') or row.get('venue_order_id') or '')
            for row in state.active_orders)
        self.order_management_only = False
        self.active_order_states = [dict(row) for row in state.active_orders]


class ManagedPartialOrder(ReconciliationBlocked):
    def __init__(self, state):
        super().__init__(state)
        self.ambiguous_orders = 0
        self.order_management_only = True


def owned_open_order(row, records):
    """Strict durable identity and quantity proof; never adopt a foreign order."""
    cid = str(row.get('client_order_id') or '')
    local = records.get(cid)
    if not cid or not isinstance(local, dict):
        return False
    normalize = lambda s: str(s or '').upper().replace('/', '-')
    if (not local.get('venue_order_id') or str(row.get('id') or row.get('venue_order_id')) != str(local['venue_order_id'])
            or normalize(row.get('symbol')) != normalize(local.get('symbol'))
            or str(row.get('side', '')).upper() != str(local.get('side', '')).upper()):
        return False
    if str(row.get('status', '')).lower() not in {'open', 'new', 'accepted', 'partially_filled', 'partial'}:
        return False
    try:
        quantity = Decimal(str(row['quantity']))
        filled = Decimal(str(row['filled_quantity']))
        leaves = Decimal(str(row['leaves_quantity']))
        intended = Decimal(str(local['body']['order_configuration']['limit']['base_size']))
        return (all(x.is_finite() for x in (quantity, filled, leaves, intended))
                and quantity == intended and quantity > 0 and 0 <= filled < quantity
                and leaves > 0 and filled + leaves == quantity
                and (str(row.get('status')).lower() not in {'partially_filled','partial'} or filled > 0))
    except (KeyError, TypeError, ValueError, InvalidOperation):
        return False


@dataclass(frozen=True)
class ReconciledState:
    balances: Any
    active_orders: tuple[dict, ...]
    positions: tuple[dict, ...]
    ambiguous: bool
    balances_valid: bool


def _rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [x for x in value if isinstance(x, dict)]
    if isinstance(value, dict):
        for key in ("data", "items", "orders", "results"):
            if isinstance(value.get(key), list):
                return [x for x in value[key] if isinstance(x, dict)]
    return []


def parse_balances(value: Any) -> tuple[tuple[dict, ...], bool]:
    """Normalize Revolut X balance list/wrapper/map shapes; fail closed on gaps."""
    raw_rows: list[tuple[str | None, Any]] = []
    if isinstance(value, list):
        raw_rows = [(None, row) for row in value]
    elif isinstance(value, dict):
        wrapped = next((value[key] for key in ("data", "balances", "items", "results")
                        if isinstance(value.get(key), list)), None)
        if wrapped is not None:
            raw_rows = [(None, row) for row in wrapped]
        elif "currency" in value:
            raw_rows = [(None, value)]
        elif value and all(isinstance(row, dict) for row in value.values()):
            raw_rows = [(str(currency), row) for currency, row in value.items()]
        else:
            return (), False
    else:
        return (), False

    normalized: list[dict] = []
    valid = bool(raw_rows)
    for keyed_currency, row in raw_rows:
        if not isinstance(row, dict):
            valid = False
            continue
        currency = str(row.get("currency") or keyed_currency or "").strip().upper()
        raw_total = row.get("total")
        if not currency or raw_total is None:
            valid = False
            continue
        try:
            total = Decimal(str(raw_total))
        except (InvalidOperation, ValueError):
            valid = False
            continue
        if not total.is_finite() or total < 0:
            valid = False
            continue
        normalized.append({**row, "currency": currency, "total": total})
    return tuple(normalized), valid and len(normalized) == len(raw_rows)


async def reconcile(client: ReadClient, lane: Any = None) -> ReconciledState:
    """Read authoritative balances/orders; never mutates venue state."""
    balances = await client.balances(lane)
    active = tuple(_rows(await client.active_orders(None, lane)))
    ambiguous = any(
        str(row.get("status", "")).upper() in {"UNKNOWN", "PENDING", "PARTIALLY_FILLED"}
        or not str(row.get("id") or row.get("venue_order_id") or "")
        for row in active
    )
    balance_rows, balances_valid = parse_balances(balances)
    positions = tuple(
        {"symbol": row["currency"], **row}
        for row in balance_rows
        if row["currency"] != "USD" and row["total"] > 0
    )
    return ReconciledState(balances, active, positions, ambiguous, balances_valid)
