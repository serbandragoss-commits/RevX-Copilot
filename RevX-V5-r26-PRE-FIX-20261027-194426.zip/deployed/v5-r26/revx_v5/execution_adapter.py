"""V5 execution boundary with explicit idempotency and ambiguity gates."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


class MutationClient(Protocol):
    async def active_orders(self, symbol: str | None = None, lane: Any = None) -> Any: ...
    async def historical_orders(self, symbol: str | None = None, hours: int = 24, lane: Any = None) -> Any: ...
    async def submit_order(self, body_obj: dict, lane: Any = None) -> Any: ...
    async def cancel_order(self, venue_order_id: str, lane: Any = None) -> Any: ...


class ExecutionBlocked(RuntimeError):
    pass


@dataclass(frozen=True)
class Intent:
    intent_id: str
    symbol: str
    side: str
    body: dict
    metadata: dict | None = None


def _rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [x for x in value if isinstance(x, dict)]
    if isinstance(value, dict):
        for key in ("data", "items", "orders", "results"):
            if isinstance(value.get(key), list):
                return [x for x in value[key] if isinstance(x, dict)]
    return []


async def submit_once(client: MutationClient, intent: Intent, lane: Any = None) -> dict:
    """Submit at most once; ambiguous responses never trigger an automatic retry."""
    if intent.side.upper() not in {"BUY", "SELL"}:
        raise ExecutionBlocked("invalid side")
    existing = _rows(await client.active_orders(intent.symbol, lane))
    existing += _rows(await client.historical_orders(intent.symbol, 24, lane))
    matches = [row for row in existing if str(row.get("client_order_id", "")) == intent.intent_id]
    if len(matches) > 1:
        raise ExecutionBlocked("duplicate intent identity")
    if matches:
        return matches[0]
    result = await client.submit_order(intent.body, lane)
    rows = _rows(result)
    order = rows[0] if rows else (result if isinstance(result, dict) else {})
    if not order.get("id") and not order.get("venue_order_id"):
        raise ExecutionBlocked("ambiguous submit response; no retry")
    return order
