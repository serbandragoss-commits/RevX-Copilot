"""Operator-started one-shot gate; counterpart HOLD is procedural, not fencing."""
import os
import json
import time
from contextlib import nullcontext
from pathlib import Path
from .authority_config import load_runtime_authority
from .serialized_session import MAX_LIVE_DURATION_SECONDS, digest

INSTALL_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = INSTALL_ROOT.parents[1]
STATE_ROOT = PROJECT_ROOT / "state/v5"
AUTHORITY = STATE_ROOT / "authority-v5.json"
LEASE = STATE_ROOT / "runtime-v5.lock"
SOURCE_ROOT = INSTALL_ROOT / "canonical-base-v3.5.8"
_SESSION = None


def bind_session(result, lease, authority_hash):
    global _SESSION
    if _SESSION is not None or lease.handle is None or lease.path.resolve() != LEASE.resolve():
        raise RuntimeError('SESSION_ALREADY_BOUND_OR_NO_LEASE')
    consumed_path = STATE_ROOT / ('consumed-' + result['permit_id'] + '.json')
    consumed = json.loads(consumed_path.read_text(encoding='utf-8'))
    if (consumed.get('pid') != os.getpid()
            or any(consumed.get(k) != value for k, value in result.items())):
        raise RuntimeError('SESSION_CONSUMPTION_MISMATCH')
    remaining = result['deadline_epoch'] - time.time()
    if not 0 < remaining <= MAX_LIVE_DURATION_SECONDS:
        raise RuntimeError('SESSION_DEADLINE_INVALID')
    _SESSION = {**result, 'pid': os.getpid(), 'lease': lease, 'authority_hash': authority_hash,
                'monotonic_deadline': time.monotonic() + remaining}


def service_lease(path):
    from .process_lease import ProcessLease
    if (_SESSION and _SESSION['pid'] == os.getpid()
            and _SESSION['lease'].handle is not None and Path(path).resolve() == LEASE.resolve()):
        return nullcontext()
    return ProcessLease(path)


def validate_paths(state_root, authority, lease, source_root):
    for supplied, canonical in ((state_root, STATE_ROOT), (authority, AUTHORITY),
                                (lease, LEASE), (source_root, SOURCE_ROOT)):
        if Path(supplied).resolve() != canonical.resolve():
            raise RuntimeError("NONCANONICAL_V5_LAUNCH_PATH")


def require_global_live():
    if not _SESSION:
        raise RuntimeError("GLOBAL_SINGLE_LIVE_COORDINATOR_UNAVAILABLE")
    if (_SESSION['pid'] != os.getpid() or _SESSION['lease'].handle is None
            or time.time() >= _SESSION['deadline_epoch']
            or time.monotonic() >= _SESSION['monotonic_deadline']):
        raise RuntimeError('SESSION_NOT_OWNED_OR_EXPIRED')
    if digest(AUTHORITY.read_bytes()) != _SESSION['authority_hash']:
        raise RuntimeError('SESSION_AUTHORITY_DRIFT')
    for filename, expected in _SESSION['installed_hashes'].items():
        if digest(Path(filename).read_bytes()) != expected:
            raise RuntimeError('INSTALLED_HASH_DRIFT')


def require_live_mutation():
    if not load_runtime_authority(AUTHORITY).permits_mutation:
        raise RuntimeError("V5_PERSISTENTLY_DISARMED_OR_EXPIRED")
    if (STATE_ROOT / "v5.kill").exists():
        raise RuntimeError("V5_KILL_SWITCH")
    require_global_live()
