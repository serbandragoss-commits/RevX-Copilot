"""Persistent, fail-closed service loop for the V5 runner."""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .notification_outbox import deliver_pending


MATERIAL_STATUSES = {"ACTION_READY", "ACTION_SUBMITTED", "BLOCKED", "DEGRADED", "FAILED", "PAUSED"}


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="health-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, sort_keys=True, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@dataclass
class V5Service:
    runner: Any
    health_path: str | os.PathLike[str]
    interval_sec: float = 15.0
    failure_limit: int = 3
    state_store: Any = None
    telegram_send: Callable[[str], None] | None = None
    startup_message: str | None = None
    clock: Callable[[], float] = time.time
    sleeper: Callable[[float], Any] = asyncio.sleep
    _stop: asyncio.Event = field(default_factory=asyncio.Event, init=False)

    def request_stop(self) -> None:
        self._stop.set()

    def _queue_transition(self, result: dict[str, Any], previous: str | None) -> None:
        if self.state_store is None:
            return
        status = str(result.get("status", "UNKNOWN"))
        if status not in MATERIAL_STATUSES or status == previous:
            if status == "HEALTHY_SILENCE" and previous in {"DEGRADED", "FAILED", "BLOCKED"}:
                self.state_store.append_notification({
                    "notification_id": "v5-recovered-{0}".format(int(self.clock())),
                    "message": "RevX V5 | RECOVERED | HEALTHY_SILENCE",
                })
            return
        reason = result.get("reason")
        if not reason and status == "ACTION_SUBMITTED":
            action = result.get("action") or result.get("side") or "ACTION"
            symbol = result.get("symbol") or "UNKNOWN_SYMBOL"
            intent_id = result.get("intent_id")
            reason = "{0} {1}{2}".format(
                action, symbol,
                (" | intent=" + str(intent_id)[:12]) if intent_id else "",
            )
        if status == "BLOCKED" and reason == "unresolved_intent_reconciliation":
            details = result.get("unresolved_intents_detail") or []
            if details:
                first = details[0]
                reason = "{status} {symbol} {side} {intent}".format(
                    status=str(first.get("status", "UNRESOLVED")),
                    symbol=str(first.get("symbol") or "UNKNOWN_SYMBOL"),
                    side=str(first.get("side") or "ACTION"),
                    intent=("intent=" + str(first.get("intent_id", ""))[:12]),
                )
        message = "RevX V5 | {status} | {reason}".format(
            status=status, reason=reason or "unspecified"
        )
        self.state_store.append_notification({
            "notification_id": "v5-state-{0}-{1}".format(status, int(self.clock())),
            "message": message,
        })

    def _deliver_notifications(self) -> dict[str, int]:
        if self.state_store is None or self.telegram_send is None:
            return {"sent": 0, "failed": 0, "deferred": 0}
        return deliver_pending(self.state_store, self.telegram_send)

    def _deliver_required_start(self) -> None:
        """Deliver START before the first runner cycle or refuse the run."""
        if not self.startup_message:
            return
        if self.telegram_send is None:
            raise RuntimeError("required START Telegram transport is unavailable")
        self.telegram_send(self.startup_message)

    @staticmethod
    def _final_message(final: dict[str, Any]) -> str:
        pnl = final.get("net_pnl_usd")
        return "\n".join((
            "RevX V5 LIVE — FINAL Run",
            "Status: {0}".format(final.get("status", "UNKNOWN")),
            "Stop reason: {0}".format(final.get("service_stop_reason", "UNKNOWN")),
            "Actions submitted: {0}".format(final.get("actions_executed", 0)),
            "Fills: {0}".format(final.get("fills", "UNKNOWN")),
            "Net PnL: {0}".format(pnl if pnl is not None else "UNKNOWN"),
            "Session PnL: {0}".format(final.get("session_loss_usd", "UNKNOWN")),
        ))

    def _deliver_required_final(self, final: dict[str, Any]) -> dict[str, Any]:
        """Attempt FINAL directly; retain delivery evidence even on transport loss."""
        result = {"sent": 0, "failed": 0}
        # A bounded/offline service instance has no LIVE START contract. The
        # paired START/FINAL lifecycle applies only to a run that supplied it.
        if not self.startup_message:
            result["not_applicable"] = True
            return result
        if self.telegram_send is None:
            result["failed"] = 1
            result["error_type"] = "TelegramUnavailable"
            return result
        try:
            self.telegram_send(self._final_message(final))
        except Exception as exc:
            result["failed"] = 1
            result["error_type"] = type(exc).__name__
        else:
            result["sent"] = 1
        return result

    async def run(self, *, max_cycles: int | None = None) -> dict[str, Any]:
        if self.interval_sec < 0 or self.failure_limit < 1:
            raise ValueError("invalid service limits")
        if max_cycles is not None and max_cycles < 1:
            raise ValueError("max_cycles must be positive")
        cycles = failures = actions = mutations = 0
        previous_status: str | None = None
        first_failure = None
        last_progress = float(self.clock())
        terminal_reason = "stop_requested"
        health: dict[str, Any] = {
            "schema": "revx-v5-runtime-health-v1",
            "status": "PAUSED",
            "reason": "stop_requested",
            "runtime_mode": "UNKNOWN",
            "entry_enabled": False,
            "cycles": 0,
            "consecutive_failures": 0,
            "actions_executed": 0,
            "broker_mutated": 0,
            "last_cycle_at": float(self.clock()),
            "last_progress_at": last_progress,
            "notification": {"sent": 0, "failed": 0, "deferred": 0},
        }

        try:
            self._deliver_required_start()
        except Exception as exc:
            final = {
                **health,
                "status": "FAILED",
                "reason": "telegram_start_delivery_failed",
                "error_type": type(exc).__name__,
                "service_stopped": True,
                "service_stop_reason": "telegram_start_delivery_failed",
                "stopped_at": float(self.clock()),
            }
            final["final_notification"] = self._deliver_required_final(final)
            _atomic_json(Path(self.health_path), final)
            return final

        while not self._stop.is_set() and (max_cycles is None or cycles < max_cycles):
            result = await self.runner.cycle()
            if result.get('exception_trace'):
                evidence = {k: result.get(k) for k in ('reason','phase','error_type','error_detail',
                            'exception_trace','intent_id','symbol')}
                evidence.update(event='RUNTIME_EXCEPTION', observed_at=float(self.clock()))
                if first_failure is None:
                    first_failure = evidence
                if self.state_store is not None:
                    try:
                        self.state_store.append_decision_snapshot(evidence)
                    except Exception as journal_error:
                        evidence['journal_write_error'] = type(journal_error).__name__
            cycles += 1
            status = str(result.get("status", "UNKNOWN"))
            if status in {"FAILED", "DEGRADED"}:
                failures += 1
            else:
                failures = 0
                last_progress = float(self.clock())
            actions += int(result.get("actions_executed", 0) or 0)
            mutations += int(result.get("broker_mutated", 0) or 0)
            self._queue_transition(result, previous_status)
            notification = self._deliver_notifications()
            previous_status = status
            health = {
                "schema": "revx-v5-runtime-health-v1",
                "status": status,
                "reason": result.get("reason"),
                "error_type": result.get("error_type"),
                "error_detail": result.get("error_detail"),
                "exception_trace": result.get('exception_trace'),
                "first_failure": first_failure,
                "order_management_only": result.get('order_management_only', False),
                "active_order_states": result.get('active_order_states', []),
                "runtime_mode": result.get("runtime_mode", "UNKNOWN"),
                "entry_enabled": bool(result.get("entry_enabled", False)),
                "cycles": cycles,
                "consecutive_failures": failures,
                "actions_executed": actions,
                "broker_mutated": mutations,
                "last_cycle_at": float(self.clock()),
                "last_progress_at": last_progress,
                "notification": notification,
                "operating_mode": result.get("operating_mode"),
                "session_key": result.get("session_key"),
                "open_positions": int(result.get("open_positions", 0) or 0),
                "exposure_usd": result.get("exposure_usd"),
                "session_loss_usd": result.get("session_loss_usd"),
                "active_orders": int(result.get("active_orders", 0) or 0),
                "ambiguous_orders": int(result.get("ambiguous_orders", 0) or 0),
                "external_inventory_count": int(
                    result.get("external_inventory_count", 0) or 0
                ),
                "owned_position_count": int(
                    result.get("owned_position_count", 0) or 0
                ),
            }
            _atomic_json(Path(self.health_path), health)
            if failures >= self.failure_limit:
                terminal_reason = "failure_threshold"
                break
            if status == "PAUSED":
                terminal_reason = str(result.get("reason", "paused"))
                break
            if self._stop.is_set() or (max_cycles is not None and cycles >= max_cycles):
                break
            if self.sleeper is asyncio.sleep and self.interval_sec > 0:
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=self.interval_sec)
                except asyncio.TimeoutError:
                    pass
            else:
                await self.sleeper(self.interval_sec)

        final = {
            **health,
            "service_stopped": True,
            "entry_enabled": False,
            "service_stop_reason": terminal_reason if failures >= self.failure_limit or self._stop.is_set()
            else ('kill_switch' if health.get('reason') == 'kill_switch' else "bounded_rehearsal_complete"),
            "stopped_at": float(self.clock()),
        }
        final["final_notification"] = self._deliver_required_final(final)
        _atomic_json(Path(self.health_path), final)
        return final
