"""Deterministic scenario allocation, not an expected-return or Kelly forecast."""
from decimal import Decimal
from .sizing import number


def allocate_targets(candidates, capital):
    """Distribute available capital by positive net-target/stop-loss scenario ratio."""
    capital = number(capital)
    scores = {}
    capacities = {}
    minimums = {}
    for intent in candidates:
        meta = intent.metadata
        sizing = meta.get('sizing') or {}
        q = number(meta['quantity'], positive=True)
        entry = number(meta['entry'], positive=True)
        target = number(meta['target'], positive=True)
        costs = sizing.get('cost_assumptions_pct') or {}
        fee = number(costs.get('fee_each_side', '0.09')) / 100
        slip = number(costs.get('exit_slippage', '0.05')) / 100
        reward = q * (target-entry) - number(sizing.get('entry_cost_allowance_usd', 0)) - q*target*(fee+slip)
        risk = number(sizing.get('estimated_stop_loss_with_costs_usd'), positive=True)
        scores[intent.symbol] = max(Decimal(0), reward / risk)
        capacities[intent.symbol] = q*entry
        minimums[intent.symbol] = number(sizing.get('minimum_notional_usd', 0))
    eligible = {symbol for symbol,score in scores.items()
                if score>0 and minimums[symbol]<=capacities[symbol]}
    # Weighted water filling: redistribute capital a risk/cash bounded plan
    # cannot use, without increasing that plan's validated quantity.
    while True:
        amounts = {symbol:Decimal(0) for symbol in scores}
        active = set(eligible)
        remaining = capital
        while active and remaining>0:
            total=sum((scores[symbol] for symbol in sorted(active)),Decimal(0))
            shares={symbol:remaining*scores[symbol]/total for symbol in sorted(active)}
            capped={symbol for symbol in active if shares[symbol]>=capacities[symbol]}
            if not capped:
                for symbol in sorted(active):
                    amounts[symbol]=shares[symbol]
                break
            for symbol in sorted(capped):
                amounts[symbol]=capacities[symbol]
                remaining-=capacities[symbol]
            active-=capped
        infeasible = {s for s in eligible if amounts[s] < minimums[s]}
        if not infeasible:
            break
        # Drop one lowest-ranked unfillable share, then redistribute. Dropping
        # every small share together could discard all otherwise valid buys.
        rejected = sorted(infeasible, key=lambda s: (-scores[s], s))[-1]
        eligible.remove(rejected)
    return {symbol: {'scenario_score': str(score),
                     'allocation_usd': str(amounts[symbol]),
                     'basis': 'NET_TARGET_TO_STOP_SCENARIOS_NOT_EXPECTED_RETURN'}
            for symbol, score in scores.items()}
