"""Fail-closed startup supervisor for the V5 runtime boundary."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any
from .sizing import pending_buy_commitment


@dataclass
class V5Supervisor:
    boundary: Any
    operating_mode: str | None = None
    mode_clock: Any = None

    @staticmethod
    def _external_exposure(records: list[dict]) -> Decimal:
        total = Decimal("0")
        for row in records:
            try:
                quantity = Decimal(str(row.get("quantity")))
                price = Decimal(str(row.get("mark_price")))
            except (InvalidOperation, ValueError, TypeError):
                raise RuntimeError("reconciled external inventory lacks mark price")
            if quantity <= 0 or price <= 0:
                raise RuntimeError("reconciled external inventory has invalid mark price")
            total += quantity * price
        return total

    async def prepare(self) -> dict:
        """Recover intent truth first, then establish the venue-backed mode."""
        recovered = await self.boundary.recover_pending()
        terminal = {"FILLED", "TERMINAL_UNFILLED", "TERMINAL_PARTIAL", "TERMINAL_UNPRICED"}
        unresolved = [row for row in recovered if row.get("status") not in terminal]
        known_open = [row for row in unresolved
                      if row.get("status") in {"ACTIVE", "PARTIAL"}]
        hard_blocked = [row for row in unresolved if row not in known_open]
        if hard_blocked:
            active_orders = sum(1 for row in unresolved
                                if row.get("status") in {"ACTIVE", "PARTIAL"})
            ambiguous_orders = sum(1 for row in hard_blocked)
            details = []
            for row in hard_blocked:
                order = row.get("order") if isinstance(row.get("order"), dict) else {}
                details.append({
                    "intent_id": str(row.get("intent_id", "")),
                    "status": str(row.get("status", "UNKNOWN")),
                    "symbol": str(order.get("symbol") or row.get("symbol") or ""),
                    "side": str(order.get("side") or row.get("side") or ""),
                    "venue_order_id": str(order.get("id") or row.get("venue_order_id") or ""),
                })
            return {
                "status": "BLOCKED",
                "reason": "unresolved_intent_reconciliation",
                "runtime_mode": "UNKNOWN",
                "entry_enabled": False,
                "unresolved_intents": len(unresolved),
                "active_orders": active_orders,
                "ambiguous_orders": ambiguous_orders,
                "unresolved_intents_detail": details,
                "process_started": 0,
                "broker_mutated": 0,
            }
        prepared = await self.boundary.prepare_startup()
        result = {
            "status": "PASS",
            "runtime_mode": prepared["runtime_mode"],
            "entry_enabled": prepared["entry_enabled"],
            "external_inventory_count": prepared["inventory"]["count"],
            "external_inventory_reconciled": prepared["inventory"]["reconciled"],
            "external_inventory_symbols": sorted(
                row["symbol"] for row in prepared["inventory"]["records"]
            ),
            "owned_positions": prepared.get("owned_positions", []),
            "external_positions": list(prepared["inventory"].get("records", [])),
            "managed_positions": list(prepared.get("owned_positions", [])) + list(
                prepared["inventory"].get("records", [])
            ),
            "managed_symbols": sorted({
                str(row.get("symbol", "")).upper().replace("/", "-")
                for row in (list(prepared.get("owned_positions", [])) + list(
                    prepared["inventory"].get("records", [])
                )) if row.get("symbol")
            }),
            "pending_intent_symbols": sorted({
                str((row.get("order") or {}).get("symbol") or row.get("symbol") or "")
                .upper().replace("/", "-")
                for row in known_open
                if str((row.get("order") or {}).get("symbol") or row.get("symbol") or "").strip()
            }),
            "owned_symbols": sorted(
                str(row.get("symbol", "")) for row in prepared.get("owned_positions", [])
                if row.get("symbol")
            ),
            "owned_position_count": len(prepared.get("owned_positions", [])),
            "active_orders": len(prepared["state"].active_orders),
            "ambiguous_orders": int(prepared["state"].ambiguous),
            "recovered_intents": len(recovered),
            "process_started": 0,
            "broker_mutated": 0,
        }
        window = self.mode_clock.current() if self.mode_clock is not None else None
        operating_mode = window.mode if window is not None else self.operating_mode
        session_key = window.session_key if window is not None else "REHEARSAL"
        entry_open = bool(window.entry_open) if window is not None else True
        store = getattr(self.boundary, "state_store", None)
        if operating_mode in {"DAY", "NIGHT"} and store is not None:
            result.update(store.admission_snapshot(operating_mode, session_key))
            external_records = list(prepared["inventory"].get("records", []))
            external_exposure = self._external_exposure(external_records)
            result["external_position_count"] = len(external_records)
            result["external_exposure_usd"] = format(external_exposure, "f")
            result["open_positions"] += len(external_records)
            result["exposure_usd"] = format(
                Decimal(str(result["exposure_usd"])) + external_exposure, "f"
            )
            pending_exposure, pending_symbols = pending_buy_commitment(prepared["state"].active_orders)
            result["pending_buy_exposure_usd"] = format(pending_exposure, "f")
            result["exposure_usd"] = format(Decimal(result["exposure_usd"]) + pending_exposure, "f")
            result["open_positions"] += len(pending_symbols - set(result["managed_symbols"]))
            result["entry_enabled"] = bool(result["entry_enabled"] and entry_open)
            result["entry_window_open"] = entry_open
        else:
            result.update({"operating_mode": None, "open_positions": 0,
                           "session_key": None, "entry_window_open": False,
                           "exposure_usd": None, "session_loss_usd": None,
                           "risk_truth_complete": False,
                           "external_position_count": len(prepared["inventory"].get("records", [])),
                           "external_exposure_usd": None})
        return result
