"""Prepare a V5 launch with durable operator reporting; never starts a process."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .notification_outbox import deliver_pending
from .state_store import DurableState


@dataclass
class V5LaunchCoordinator:
    supervisor: Any
    store: DurableState
    reporter: Any

    async def prepare(self, notification_id: str) -> dict:
        result = await self.supervisor.prepare()
        if result["status"] != "PASS":
            return {**result, "launch_status": "BLOCKED", "telegram": "NOT_SENT"}
        mode = result["runtime_mode"]
        message = (
            "RevX V5 STARTUP GATE — PASS\n"
            f"Mode: {mode}\n"
            f"External inventory: {result['external_inventory_count']}\n"
            f"New BUY enabled: {'YES' if result['entry_enabled'] else 'NO'}\n"
            "Orders submitted: 0. Runtime started: NO."
        )
        self.store.append_notification({"notification_id": notification_id,
                                        "message": message})
        if not self.reporter.available():
            return {**result, "launch_status": "BLOCKED_TELEGRAM",
                    "telegram": "UNAVAILABLE"}
        delivery = deliver_pending(self.store, self.reporter.send)
        if delivery["failed"] or delivery["deferred"] or delivery["sent"] != 1:
            return {**result, "launch_status": "BLOCKED_TELEGRAM",
                    "telegram": "DELIVERY_FAILED", "delivery": delivery}
        return {**result, "launch_status": "GATE_PASS_RUNNER_REQUIRED",
                "telegram": "PASS", "delivery": delivery,
                "process_started": 0, "broker_mutated": 0}
