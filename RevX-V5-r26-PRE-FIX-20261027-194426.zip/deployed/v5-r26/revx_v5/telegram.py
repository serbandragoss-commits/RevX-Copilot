"""V5 Telegram boundary; credential import is intentionally external."""

from __future__ import annotations

import base64
import ctypes
import platform
from ctypes import wintypes
from pathlib import Path
from typing import Callable


class TelegramUnavailable(RuntimeError):
    pass


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD),
                ("pbData", ctypes.POINTER(ctypes.c_byte))]


def load_dpapi_token(path: str | Path) -> str:
    """Decrypt a ConvertFrom-SecureString token for the current Windows user."""
    if platform.system() != "Windows":
        raise TelegramUnavailable("V5 DPAPI token requires Windows user context")
    # Windows PowerShell 5 writes UTF-8 with a BOM.  The BOM is serialization
    # metadata, not part of the DPAPI blob.
    encoded = Path(path).read_text(encoding="utf-8-sig").strip()
    try:
        raw = bytes.fromhex(encoded)
    except ValueError:
        raw = base64.b64decode(encoded, validate=True)
    source = ctypes.create_string_buffer(raw, len(raw))
    incoming = _DATA_BLOB(len(raw), ctypes.cast(source, ctypes.POINTER(ctypes.c_byte)))
    output = _DATA_BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(incoming), None, None, None, None, 0, ctypes.byref(output)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData).decode("utf-16-le").rstrip("\x00")
    finally:
        ctypes.windll.kernel32.LocalFree(output.pbData)


class TelegramReporter:
    def __init__(self, token_path: str | Path, chat_id: str,
                 sender: Callable[[str, str, str], None] | None = None,
                 token_loader: Callable[[Path], str] | None = None):
        self.token_path = Path(token_path)
        self.chat_id = chat_id
        self.sender = sender
        self.token_loader = token_loader or load_dpapi_token

    def available(self) -> bool:
        return bool(self.chat_id and self.token_path.is_file())

    def send(self, message: str) -> None:
        if not self.available():
            raise TelegramUnavailable("V5 Telegram credential is not imported")
        if self.sender is None:
            raise TelegramUnavailable("no Telegram transport configured")
        self.sender(self.token_loader(self.token_path),
                    self.chat_id, message)
