"""Canonical V5 LIVE contract: limits already enforced by V5's own policy."""
from __future__ import annotations

from .policy import operator_policy, operator_settings

LIVE_CONTRACT_SCHEMA = "revx-v5-live-contract-v1"
VALIDATION_LIMIT = 10

def live_contract() -> dict:
    policy = operator_policy()
    return {
        "schema": LIVE_CONTRACT_SCHEMA, "status": "PASS",
        "operator_settings": operator_settings(),
        "order_usd": policy.order_usd, "sizing": "DYNAMIC_RISK_CASH_COSTS",
        "allocation": "NET_TARGET_TO_STOP_SCENARIOS_NOT_EXPECTED_RETURN",
        "target_exits": True,
        "exposure_usd": policy.exposure_usd,
        "session_loss_usd": policy.session_loss_usd,
        "day_max_positions": policy.day_max_positions,
        "night_max_positions": policy.night_max_positions,
        "validation_limit": VALIDATION_LIMIT, "execution": "V5_NATIVE_POLICY",
    }
