"""Account-wide terminal GET reconciliation; never submits/cancels orders."""
import time
from decimal import Decimal
from .reconciliation import parse_balances
from .live_runtime import V5LiveBoundary
from .provider_adapter import MutationDisabledAdapter
from .execution_truth import order_fill_state, fee_in_usd


def rows(value):
    if isinstance(value, dict):
        value = next((value[k] for k in ('data', 'items', 'orders', 'results')
                      if isinstance(value.get(k), list)), None)
    if not isinstance(value, list) or any(not isinstance(x, dict) for x in value):
        raise ValueError('INVALID_ORDER_RESPONSE')
    return value


async def reconcile_terminal(client, store, before_ids, stop_reason, authority_off):
    result = {'schema': 'revx-v5-terminal-account-v1', 'status': 'INCOMPLETE',
              'stop_reason': stop_reason, 'authority_off': authority_off,
              'realized_net_pnl_usd': None, 'unrealized_net_pnl_usd': None,
              'fees_usd': None, 'slippage_usd': None}
    try:
        if not authority_off:
            raise ValueError('AUTHORITY_NOT_OFF')
        boundary = V5LiveBoundary(client, MutationDisabledAdapter(), state_store=store)
        result['intent_recovery'] = await boundary.recover_pending()
        balance_rows, valid = parse_balances(await client.balances())
        if not valid:
            raise ValueError('BALANCE_SCHEMA')
        active = rows(await client.active_orders(None))
        history = rows(await client.historical_orders(None, 24))
        ids = set(store.intent_records()) - set(before_ids)
        relevant_ids = ids | {str(r.get('intent_id')) for r in store.pending_intents()}
        by_id = {}
        for r in history + active:
            if str(r.get('client_order_id') or '') in relevant_ids:
                oid = str(r.get('id') or r.get('venue_order_id') or '')
                if not oid:
                    raise ValueError('MATCHED_ORDER_WITHOUT_ID')
                by_id[oid] = r
        for oid in list(by_id):
            if hasattr(client, 'order'):
                detail = await client.order(oid)
                if not isinstance(detail, dict) or str(detail.get('id') or detail.get('venue_order_id')) != oid:
                    raise ValueError('ORDER_DETAIL_IDENTITY_MISMATCH')
                if detail.get('client_order_id') != by_id[oid].get('client_order_id'):
                    raise ValueError('ORDER_DETAIL_INTENT_MISMATCH')
                by_id[oid] = detail
        matched = list(by_id.values())
        result['submitted_intents'] = sorted(ids)
        result['active_orders'] = [{k: r.get(k) for k in ('id', 'client_order_id', 'symbol', 'status',
                                   'filled_quantity','leaves_quantity','quantity')}
                                   for r in active]
        result['ambiguous_orders'] = sum(order_fill_state(r)['phase'] == 'UNKNOWN' for r in active)
        result['pending_intents'] = [{k: r.get(k) for k in ('intent_id', 'symbol', 'status')}
                                     for r in store.pending_intents()]
        result['fills'] = [{k: r.get(k) for k in ('id', 'client_order_id', 'symbol', 'side',
                            'filled_quantity','leaves_quantity','average_price','average_fill_price',
                            'fee','total_fee','fee_currency','fee_usd')}
                           for r in matched if Decimal(str(r.get('filled_quantity') or 0)) > 0]
        result['positions'] = [{'currency': r['currency'], 'quantity': str(r['total'])}
                               for r in balance_rows if r['currency'] != 'USD' and r['total'] > 0]
        saved = store.load()
        result['execution_metrics'] = {key:value for key,value in saved.get('execution_metrics',{}).items()
                                       if key in relevant_ids}
        venue_quantities = {r['currency']: r['total'] for r in balance_rows}
        owned_quantities = {}
        for symbol, pos in saved.get('positions', {}).items():
            asset = symbol.replace('/', '-').split('-')[0]
            owned_quantities[asset] = owned_quantities.get(asset, Decimal(0)) + Decimal(str(pos['quantity']))
        result['quantity_mismatches'] = [asset for asset, qty in owned_quantities.items()
                                        if qty > venue_quantities.get(asset, Decimal(0))]
        ledger = [r for r in saved.get('economic_ledger', []) if r.get('sell_intent_id') in ids]
        result['realized_ledger'] = ledger
        external_ledger = [r for r in saved.get('external_exit_ledger', []) if r.get('sell_intent_id') in ids]
        result['external_exit_ledger'] = external_ledger
        if not external_ledger and ledger and all(r.get('net_pnl_usd') is not None and r.get('fee_truth') == 'KNOWN' for r in ledger):
            result['realized_net_pnl_usd'] = str(sum(Decimal(str(r['net_pnl_usd'])) for r in ledger))
        def usd_fee(row):
            currency = str(row.get('fee_currency') or '').upper()
            base = str(row.get('symbol','')).upper().replace('/','-').split('-')[0]
            if currency == base and row.get('execution_price_source') == 'INDIVIDUAL_FILLS':
                row = {**row, 'fee_price_usd':row['average_fill_price']}
            return fee_in_usd(row)
        fees = [usd_fee(r) for r in matched]
        if not relevant_ids and not active and not result['pending_intents']:
            result['realized_net_pnl_usd'] = '0'
            result['fees_usd'] = '0'
        elif matched and all(f is not None for f in fees):
            result['fees_usd'] = str(sum(fees))
        result['fee_completeness'] = 'KNOWN' if result['fees_usd'] is not None else 'UNKNOWN'
        result['execution_inconsistencies'] = []
        for r in matched:
            average = r.get('max_fill_price', r.get('average_fill_price', r.get('average_price')))
            if (r.get('type') == 'limit' and str(r.get('side')).lower() == 'buy'
                    and average is not None and r.get('price') is not None
                    and Decimal(str(average)) > Decimal(str(r['price']))):
                result['execution_inconsistencies'].append('BUY_FILL_ABOVE_LIMIT:' + str(r.get('id')))
            if (r.get('type') == 'limit' and str(r.get('side')).lower() == 'sell'
                    and r.get('min_fill_price') is not None and r.get('price') is not None
                    and Decimal(str(r['min_fill_price'])) < Decimal(str(r['price']))):
                result['execution_inconsistencies'].append('SELL_FILL_BELOW_LIMIT:' + str(r.get('id')))
        if not result['positions'] and not result['quantity_mismatches'] and not active and not result['pending_intents']:
            result['unrealized_net_pnl_usd'] = '0'
        if result['quantity_mismatches'] or result['execution_inconsistencies']:
            result['realized_net_pnl_usd'] = None
            result['unrealized_net_pnl_usd'] = None
        result['economic_status'] = ('KNOWN' if result['realized_net_pnl_usd'] is not None
                                    and result['unrealized_net_pnl_usd'] is not None
                                    and result['fees_usd'] is not None else 'UNKNOWN')
        missing = ids - {str(r.get('client_order_id')) for r in history + active}
        result['unmatched_submitted_intents'] = sorted(missing)
        result['status'] = ('PASS' if not active and not result['pending_intents'] and not missing
                            and not result['quantity_mismatches']
                            and not result['execution_inconsistencies']
                            else 'INCOMPLETE')
        result['limitations'] = ['Open-position cost basis/markout and slippage remain UNKNOWN without complete evidence.',
                                'No flattening or cancellation is performed after the deadline.']
    except Exception as exc:
        result.update(status='INCOMPLETE', error_type=type(exc).__name__)
    result['observed_at'] = time.time()
    return result
