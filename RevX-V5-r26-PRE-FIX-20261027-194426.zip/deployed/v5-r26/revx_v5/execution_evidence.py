"""Individual execution prices and settled cash are distinct venue facts."""
from decimal import Decimal


def decimal(value):
    result = Decimal(str(value))
    if not result.is_finite() or result < 0:
        raise ValueError('INVALID_EXECUTION_EVIDENCE')
    return result


def normalize_fills(order, payload):
    fills = payload.get('data') if isinstance(payload, dict) else payload
    if not isinstance(fills, list) or not fills:
        raise ValueError('FILL_EVIDENCE_MISSING')
    quantity = Decimal(0)
    gross = Decimal(0)
    seen = set()
    prices = []
    normalize = lambda value: str(value).upper().replace('/', '-')
    for fill in fills:
        identity = fill.get('id') or fill.get('tid')
        if not identity or identity in seen:
            raise ValueError('FILL_ID_MISSING_OR_DUPLICATED')
        seen.add(identity)
        symbol = fill.get('symbol') or (str(fill.get('qc')) + '/' + str(fill.get('pc')))
        if (normalize(symbol) != normalize(order.get('symbol'))
                or (fill.get('side') is not None and str(fill['side']).lower() != str(order.get('side')).lower())):
            raise ValueError('FILL_IDENTITY_MISMATCH')
        q, p = decimal(fill.get('quantity',fill.get('q'))), decimal(fill.get('price',fill.get('p')))
        if not q or not p:
            raise ValueError('FILL_PRICE_OR_QUANTITY_ZERO')
        quantity += q
        gross += q*p
        prices.append(p)
    if quantity != decimal(order['filled_quantity']):
        raise ValueError('FILL_QUANTITY_NOT_RECONCILED')
    result = dict(order)
    result['reported_average_fill_price'] = order.get('average_fill_price')
    result['average_price'] = result['average_fill_price'] = str(gross/quantity)
    amount = decimal(order['filled_amount']) if order.get('filled_amount') is not None else gross
    if not amount:
        raise ValueError('SETTLED_QUOTE_AMOUNT_ZERO')
    result.update(executed_quote_amount=str(amount), fill_gross_quote=str(gross),
                  execution_price_source='INDIVIDUAL_FILLS',
                  max_fill_price=str(max(prices)), min_fill_price=str(min(prices)))
    return result
