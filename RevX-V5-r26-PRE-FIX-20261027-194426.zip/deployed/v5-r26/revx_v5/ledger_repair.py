"""Pure replay of one flat-to-flat run. Never changes the supplied state."""
import copy
from decimal import Decimal
from .state_store import DurableState
from .execution_truth import ledger_row_complete, recompute_session_risk


def replay_flat_run(state, intents, orders):
    memory = {}
    store = object.__new__(DurableState)
    store.load = lambda: copy.deepcopy(memory)
    def save(value):
        memory.clear()
        memory.update(copy.deepcopy(value))
    store.save = save
    selected = [o for o in orders if Decimal(str(o.get('filled_quantity',0)))>0]
    for order in sorted(selected,key=lambda o:(int(o['created_date']),str(o['id']))):
        key=order['client_order_id']
        if key not in intents or order.get('execution_price_source') != 'INDIVIDUAL_FILLS':
            raise ValueError('verified intent and fill evidence required')
        if order.get('total_fee') is None or not order.get('fee_currency'):
            raise ValueError('fee evidence missing')
        store.apply_execution_fill(intents[key],order)
    if memory.get('positions'):
        raise ValueError('run is not flat-to-flat')
    ledger=memory.get('economic_ledger',[])
    if not ledger or not all(map(ledger_row_complete, ledger)):
        raise ValueError('replay economics incomplete')
    result=copy.deepcopy(state)
    keys={r['sell_intent_id'] for r in ledger}
    old=[r for r in state.get('economic_ledger',[]) if r.get('sell_intent_id') in keys]
    if len(old)!=len(ledger):
        raise ValueError('existing ledger identity mismatch')
    replacements={r['sell_intent_id']:r for r in ledger}
    for row in old:
        new=replacements[row['sell_intent_id']]
        if (row['buy_intent_id']!=new['buy_intent_id'] or row['symbol']!=new['symbol']
                or Decimal(row['quantity'])!=Decimal(new['quantity'])):
            raise ValueError('replay changes position or trade identity')
        # Keep original observation timestamps; replay time is not fill time.
        for field in ('entry_filled_at','exit_filled_at'):
            new[field]=row.get(field)
    result['economic_ledger']=[replacements.get(r.get('sell_intent_id'),r)
                               for r in result['economic_ledger']]
    for key, corrected in memory.get('intents',{}).items():
        current=result.setdefault('intents',{}).get(key,{})
        if current and Decimal(current.get('adopted_quantity','0'))!=Decimal(corrected['adopted_quantity']):
            raise ValueError('replay changes adopted quantity')
        # Preserve the original observation time and unrelated intent metadata.
        result['intents'][key]={**current,**{k:v for k,v in corrected.items() if k!='last_fill_at'}}
    for mode,key in {(r['operating_mode'],r['session_key']) for r in ledger}:
        recompute_session_risk(result, mode, key)
    return result, {'trades':len(ledger),'realized_net_pnl_usd':str(sum((Decimal(r['net_pnl_usd']) for r in ledger),Decimal(0))),
                    'ledger':ledger,'positions_unchanged':result.get('positions')==state.get('positions')}
