"""One-shot, operator-started serialized session. No distributed-fencing claim.

Imports and validation never arm authority. Consumption is exclusive/durable.
The operator must provide the independently reported binding digest.
"""
import hashlib
import json
import math
import os
import time
from datetime import datetime
from pathlib import Path
from uuid import UUID

MAX_LIVE_DURATION_SECONDS = 86_400


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def stamp(value):
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        raise ValueError('TIMEZONE_REQUIRED')
    return parsed.timestamp()


def validate_bundle(root, expected_digest, now):
    root = Path(root)
    raw = (root / 'binding.json').read_bytes()
    if digest(raw) != expected_digest:
        raise ValueError('BINDING_TAMPER')
    binding = json.loads(raw)
    docs = {}
    for name in ('permit', 'counterpart', 'authority_candidate'):
        content = (root / (name + '.json')).read_bytes()
        if digest(content) != binding[name + '_sha256']:
            raise ValueError(name.upper() + '_TAMPER')
        docs[name] = json.loads(content)
    p, c, a = (docs[k] for k in ('permit', 'counterpart', 'authority_candidate'))
    UUID(p['permit_id'])
    if (p.get('schema') != 'revx-coo-serialized-live-permit-v1'
            or p.get('agent') != 'V5/Dell' or p.get('authorized_action') != 'one_live_run'
            or p.get('one_time') is not True or p.get('max_duration_seconds') != MAX_LIVE_DURATION_SECONDS
            or p.get('strict_sequence') != ['V5/Dell', 'V6/iMac']):
        raise ValueError('PERMIT_SCOPE')
    required = ('existing_strategy_and_limits_only', 'no_restart_or_extension',
                'telegram_start_final_required', 'terminal_account_wide_reconciliation_required')
    if (any(p.get('constraints', {}).get(k) is not True for k in required)
            or p['constraints'].get('v6_permit_before_v5_terminal') is not False):
        raise ValueError('PERMIT_CONSTRAINTS')
    cp = p.get('counterpart', {})
    if (cp.get('agent') != 'V6/iMac' or cp.get('required_state') != 'STOPPED_AND_DISARMED'
            or cp.get('orders_allowed') is not False or cp.get('post_attempted') is not False):
        raise ValueError('COUNTERPART_POLICY')
    end = stamp(p['expires_at_utc'])
    if (not math.isfinite(now) or not stamp(p['not_before_utc']) <= now
            or not 0 < end - now <= MAX_LIVE_DURATION_SECONDS):
        raise ValueError('EXPIRED_OR_INSUFFICIENT_WINDOW')
    if (c.get('permit_id') != p['permit_id'] or c.get('agent') != 'V6/iMac'
            or c.get('process_absent') is not True or c.get('launchagent_stopped') is not True
            or c.get('alternate_autostarts_disabled') is not True
            or c.get('authority_expired') is not True or c.get('no_v6_permit') is not True
            or c.get('hold_until_v5_terminal') is not True
            or not stamp(c['observed_at_utc']) <= now < stamp(c['valid_until_utc'])
            or stamp(c['valid_until_utc']) < end):
        raise ValueError('COUNTERPART_HOLD_INVALID')
    if (a != {'schema': 'revx-v5-runtime-authority-v1', 'execution_enabled': False,
              'order_placement': 'OFF', 'acknowledgement': ''}):
        raise ValueError('CANDIDATE_MUST_BE_OFF')
    if not binding.get('installed_hashes'):
        raise ValueError('EMPTY_SOURCE_BINDING')
    for filename, expected in binding['installed_hashes'].items():
        if digest(Path(filename).read_bytes()) != expected:
            raise ValueError('INSTALLED_HASH_DRIFT')
    return {'permit_id': p['permit_id'], 'deadline_epoch': end,
            'binding_sha256': expected_digest, 'installed_hashes': binding['installed_hashes']}


def validate_preflight(report, now):
    if (report.get('schema') != 'revx-v5-authenticated-get-only-v1'
            or report.get('status') != 'PASS' or report.get('authenticated_get') != 'PASS'
            or report.get('order_placement') != 'OFF'
            or report.get('active_orders') != 0 or report.get('ambiguous_orders') != 0
            or report.get('balance_schema_valid') is not True
            or report.get('external_inventory_reconciled') is not True
            or report.get('pair_count', 0) <= 0):
        raise ValueError('PREFLIGHT_NOT_PASS')
    observed = report.get('observed_at')
    if isinstance(observed, bool) or not isinstance(observed, (int, float)) or not 0 <= now - observed <= 30:
        raise ValueError('PREFLIGHT_STALE')


def consume(result, path):
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as out:
        json.dump({**result, 'pid': os.getpid(), 'consumed_at': time.time()}, out, sort_keys=True)
        out.flush()
        os.fsync(out.fileno())
