"""Deterministic, fail-closed V5 autonomous runner state machine.

The runner owns orchestration only.  Signal generation and venue-specific order
construction are injected through ``action_source``.  Real mutation requires
both an enabled execution boundary and an exact, explicit authority object.
"""

from __future__ import annotations

from dataclasses import dataclass
import traceback
from typing import Any, Protocol

from .execution_adapter import Intent
from .reconciliation import ReconciliationBlocked


LIVE_ACKNOWLEDGEMENT = "REVX_V5_LIVE_EXECUTION_AUTHORIZED"


class ActionSource(Protocol):
    async def next_exit(self, context: dict) -> Intent | None: ...
    async def next_entry(self, context: dict) -> Intent | None: ...


@dataclass(frozen=True)
class RuntimeAuthority:
    execution_enabled: bool = False
    order_placement: str = "OFF"
    acknowledgement: str = ""

    @property
    def permits_mutation(self) -> bool:
        return (
            self.execution_enabled
            and self.order_placement == "ON"
            and self.acknowledgement == LIVE_ACKNOWLEDGEMENT
        )


class NullActionSource:
    """Safe source used by authenticated rehearsal: it proposes no action."""

    async def next_exit(self, context: dict) -> Intent | None:
        return None

    async def next_entry(self, context: dict) -> Intent | None:
        return None


def _safe_error_detail(exc: Exception) -> str:
    """Bounded diagnostic detail; never persist unbounded exception text."""
    detail = " ".join(str(exc).split())
    return detail[:240] if detail else type(exc).__name__


def _is_transient_transport(exc: Exception) -> bool:
    """Classify provider/network failures as retryable, never as trade failure."""
    name = type(exc).__name__
    detail = str(exc).lower()
    if name in {"TimeoutError", "ConnectionError", "ConnectionResetError", "ConnectionAbortedError"}:
        return True
    return any(marker in detail for marker in (
        "transport error", "timed out", "timeout", "connection reset",
        "connection aborted", "connection refused", "temporarily unavailable",
    ))


def _failure_result(prepared: dict, *, stage: str, exc: Exception) -> dict:
    if isinstance(exc, ReconciliationBlocked):
        return V5Runner._result('BLOCKED', prepared, reason='reconciliation_state_changed',
            entry_enabled=False, active_orders=exc.active_orders, ambiguous_orders=exc.ambiguous_orders,
            error_type=type(exc).__name__, error_detail=_safe_error_detail(exc), phase=stage,
            order_management_only=exc.order_management_only,
            active_order_states=exc.active_order_states)
    if _is_transient_transport(exc):
        return V5Runner._result(
            "DEGRADED", prepared, reason=f"{stage}_transport_degraded",
            error_type=type(exc).__name__, error_detail=_safe_error_detail(exc),
        )
    return V5Runner._result(
        "FAILED", prepared, reason=f"{stage}_exception",
        error_type=type(exc).__name__, error_detail=_safe_error_detail(exc),
        exception_trace=[{'file': f.filename, 'line': f.lineno, 'function': f.name}
                         for f in traceback.extract_tb(exc.__traceback__)[-16:]], phase=stage,
    )


@dataclass
class V5Runner:
    supervisor: Any
    boundary: Any
    action_source: ActionSource
    authority: RuntimeAuthority = RuntimeAuthority()
    kill_switch: Any = None

    def _killed(self) -> bool:
        if self.kill_switch is None:
            return False
        return bool(self.kill_switch())

    @staticmethod
    def _result(status: str, prepared: dict, **extra: Any) -> dict:
        return {
            "status": status,
            "runtime_mode": prepared.get("runtime_mode", "UNKNOWN"),
            "entry_enabled": bool(prepared.get("entry_enabled", False)),
            "operating_mode": prepared.get("operating_mode"),
            "session_key": prepared.get("session_key"),
            "open_positions": int(prepared.get("open_positions", 0) or 0),
            "owned_position_count": int(
                prepared.get("owned_position_count", 0) or 0
            ),
            "exposure_usd": prepared.get("exposure_usd"),
            "session_loss_usd": prepared.get("session_loss_usd"),
            "active_orders": int(prepared.get("active_orders", 0) or 0),
            "ambiguous_orders": int(prepared.get("ambiguous_orders", 0) or 0),
            "unresolved_intents_detail": list(
                prepared.get("unresolved_intents_detail", []) or []
            ),
            "pending_intent_symbols": list(
                prepared.get("pending_intent_symbols", []) or []
            ),
            "external_inventory_count": int(
                prepared.get("external_inventory_count", 0) or 0
            ),
            "order_management_only": bool(prepared.get('order_management_only', False)),
            "active_order_states": list(prepared.get('active_order_states', [])),
            "broker_mutated": 0,
            "actions_executed": 0,
            **extra,
        }

    async def cycle(self) -> dict:
        """Run one bounded cycle and execute at most one reconciled action."""
        if self._killed():
            return self._result("PAUSED", {}, reason="kill_switch")

        try:
            prepared = await self.supervisor.prepare()
        except Exception as exc:
            prepared = _failure_result({}, stage="supervisor", exc=exc)
            if not prepared.get('order_management_only'):
                return prepared
        if prepared.get("status") != "PASS" and not prepared.get('order_management_only'):
            return self._result("BLOCKED", prepared,
                                reason=prepared.get("reason", "startup_gate"))
        if self._killed():
            return self._result("PAUSED", prepared, reason="kill_switch")

        # Expired entry orders must be handled before discovery. Otherwise a
        # quiet cycle could leave a stale post-only BUY working indefinitely.
        if self.authority.permits_mutation:
            cancel_stale = getattr(self.boundary, "cancel_stale_entry_orders", None)
            try:
                cancelled = await cancel_stale() if cancel_stale is not None else []
            except Exception as exc:
                return self._result("FAILED", prepared, reason="stale_entry_cancel_exception",
                                    error_type=type(exc).__name__,
                                    error_detail=_safe_error_detail(exc))
            if cancelled:
                if any(row.get("outcome") == "RACE_RECONCILIATION_REQUIRED" for row in cancelled):
                    return self._result("BLOCKED", prepared,
                        reason="stale_entry_cancel_race_reconciliation_pending")
                return self._result("ACTION_SUBMITTED", prepared,
                                    broker_mutated=1, actions_executed=1,
                                    action="CANCEL", symbol=cancelled[0].get("symbol"),
                                    cancelled_entry_orders=cancelled)

        if prepared.get('order_management_only'):
            return prepared

        context = dict(prepared)
        mode = prepared["runtime_mode"]
        try:
            intent = await self.action_source.next_exit(context)
        except Exception as exc:
            return _failure_result(prepared, stage="exit_source", exc=exc)

        exit_state = getattr(self.action_source, 'last_scan', {}).get('last_exit', {})
        if intent is None and exit_state.get('status') == 'BLOCKED_URGENT_EXIT':
            return self._result('BLOCKED', prepared, entry_enabled=False,
                                reason='urgent_exit_not_executable', exit_details=exit_state)

        if intent is not None:
            if intent.side.upper() != "SELL":
                return self._result("BLOCKED", prepared,
                                    reason="exit_source_returned_non_sell")
        elif prepared.get("entry_enabled"):
            try:
                intent = await self.action_source.next_entry(context)
            except Exception as exc:
                return _failure_result(prepared, stage="entry_source", exc=exc)
            if intent is not None and intent.side.upper() != "BUY":
                return self._result("BLOCKED", prepared,
                                    reason="entry_source_returned_non_buy")

        if intent is None:
            admission = getattr(self.action_source, 'last_scan', {})
            if admission.get('admission') == 'BLOCKED':
                return self._result('BLOCKED', prepared, entry_enabled=False,
                                    reason=admission.get('reason', 'entry_admission_blocked'))
            return self._result("HEALTHY_SILENCE", prepared,
                                reason="no_qualifying_action")

        if self._killed():
            return self._result("PAUSED", prepared, reason="kill_switch")
        if not self.authority.permits_mutation:
            return self._result("ACTION_READY", prepared,
                                reason="mutation_authority_off",
                                intent_id=intent.intent_id,
                                action=intent.side.upper(),
                                symbol=intent.symbol)

        try:
            result = await self.boundary.execute_intent(intent)
        except ReconciliationBlocked as exc:
            return _failure_result(prepared, stage='execution', exc=exc)
        except Exception as exc:
            return self._result("FAILED", prepared, reason="execution_exception",
                                error_type=type(exc).__name__,
                                error_detail=_safe_error_detail(exc),
                                intent_id=intent.intent_id,
                                action=intent.side.upper(), symbol=intent.symbol,
                                phase='execution', exception_trace=[
                                    {'file':f.filename,'line':f.lineno,'function':f.name}
                                    for f in traceback.extract_tb(exc.__traceback__)[-16:]])
        return self._result("ACTION_SUBMITTED", prepared,
                            broker_mutated=1, actions_executed=1,
                            intent_id=intent.intent_id,
                            action=intent.side.upper(), symbol=intent.symbol,
                            venue_order_id=result.get("id") or result.get("venue_order_id"))
