"""Fail-closed loading of the operator-controlled V5 mutation boundary."""

from __future__ import annotations

import json
import math
import os
import tempfile
import time
from pathlib import Path

from .runner import LIVE_ACKNOWLEDGEMENT, RuntimeAuthority


AUTHORITY_SCHEMA = "revx-v5-runtime-authority-v1"


def disarm(path: str | Path) -> None:
    path = Path(path)
    value = {"schema": AUTHORITY_SCHEMA, "execution_enabled": False,
             "order_placement": "OFF", "acknowledgement": ""}
    fd, name = tempfile.mkstemp(prefix="disarm-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump(value, out)
            out.flush()
            os.fsync(out.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def load_runtime_authority(path: str | Path) -> RuntimeAuthority:
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict) or value.get("schema") != AUTHORITY_SCHEMA:
        raise ValueError("invalid V5 authority schema")
    allowed = {"schema", "execution_enabled", "order_placement", "acknowledgement", "expires_at_epoch"}
    if set(value) - allowed:
        raise ValueError("unknown V5 authority fields")
    authority = RuntimeAuthority(
        execution_enabled=value.get("execution_enabled") is True,
        order_placement=str(value.get("order_placement", "OFF")),
        acknowledgement=str(value.get("acknowledgement", "")),
    )
    if authority.execution_enabled and not authority.permits_mutation:
        raise ValueError("incomplete V5 mutation authority")
    if authority.order_placement not in {"OFF", "ON"}:
        raise ValueError("invalid V5 order placement boundary")
    if authority.acknowledgement and authority.acknowledgement != LIVE_ACKNOWLEDGEMENT:
        raise ValueError("invalid V5 live acknowledgement")
    if authority.permits_mutation:
        expiry = value.get("expires_at_epoch")
        if (isinstance(expiry, bool) or not isinstance(expiry, (int, float))
                or not math.isfinite(expiry) or expiry <= time.time()):
            disarm(path)
            return RuntimeAuthority()
    return authority
