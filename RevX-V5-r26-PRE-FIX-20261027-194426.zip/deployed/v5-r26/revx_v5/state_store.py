"""Durable positions, economic ledger and intent outbox."""

from __future__ import annotations

import json
import os
import tempfile
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
from .execution_truth import order_fill_state, recompute_session_risk, reported_fee, fee_in_usd


def replace_state_file(source, destination):
    """Bounded retry for Windows sharing/access races; persistent failures propagate."""
    for attempt in range(6):
        try:
            os.replace(source, destination)
            return
        except PermissionError as exc:
            if os.name != 'nt' or getattr(exc, 'winerror', None) not in {5, 32, 33} or attempt == 5:
                raise
            time.sleep(0.01 * (2 ** attempt))


class DurableState:
    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.state_path = self.root / "state.json"
        self.outbox_path = self.root / "outbox.jsonl"
        self.notifications_path = self.root / "notifications.jsonl"
        self.decision_journal_path = self.root / "decision-journal.jsonl"

    def load(self) -> dict[str, Any]:
        if not self.state_path.exists():
            return {"schema": "revx-v5-state-v1", "positions": {}, "mode": None,
                    "intents": {}, "external_inventory": {},
                    "risk": {"DAY": {"sessions": {}}, "NIGHT": {"sessions": {}}}}
        data = json.loads(self.state_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("schema") != "revx-v5-state-v1":
            raise RuntimeError("invalid V5 state schema")
        return data

    def save(self, data: dict[str, Any]) -> None:
        if data.get("schema") != "revx-v5-state-v1":
            raise ValueError("invalid V5 state schema")
        fd, tmp = tempfile.mkstemp(prefix="state-", suffix=".json", dir=self.root)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, sort_keys=True, separators=(",", ":"))
                handle.flush()
                os.fsync(handle.fileno())
            replace_state_file(tmp, self.state_path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    def append_intent(self, intent: dict[str, Any]) -> None:
        if not intent.get("intent_id"):
            raise ValueError("intent_id required")
        with self.outbox_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(intent, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def record_external_inventory(self, records: list[dict], mode: str) -> None:
        """Persist venue inventory separately without claiming V5 ownership."""
        if mode not in {"NORMAL", "MANAGE_EXISTING_ONLY"}:
            raise ValueError("invalid runtime mode")
        if any(row.get("classification") != "EXTERNAL_INVENTORY" for row in records):
            raise ValueError("unknown external inventory cannot be persisted")
        state = self.load()
        state["runtime_mode"] = mode
        state["external_inventory"] = {
            str(row["symbol"]): {
                "symbol": str(row["symbol"]),
                "currency": str(row["currency"]),
                "quantity": str(row["quantity"]),
                "classification": "EXTERNAL_INVENTORY",
                "mark_price": row.get("mark_price"),
                "cost_basis_status": str(row.get("cost_basis_status") or "UNKNOWN"),
                "pnl_status": str(row.get("pnl_status") or "UNKNOWN"),
                "exit_eligible": row.get("exit_eligible") is True,
                "exit_evaluation_status": str(
                    row.get("exit_evaluation_status") or "UNKNOWN"
                ),
            }
            for row in records
        }
        self.save(state)

    def terminalize_absent_owned_position(self, symbol: str, order: dict[str, Any]) -> None:
        """Remove local ownership only after venue truth proves its full SELL fill."""
        normalized = str(symbol).upper().replace("/", "-")
        venue_symbol = str(order.get("symbol") or "").upper().replace("/", "-")
        side = str(order.get("side") or "").upper()
        status = str(order.get("status") or "").upper()
        filled = self._decimal(order.get("filled_quantity", 0))
        leaves = self._decimal(order.get("leaves_quantity", 0))
        if venue_symbol != normalized or side != "SELL" or status not in {"FILLED", "COMPLETE", "COMPLETED"}:
            raise ValueError("venue order does not prove terminal owned-position exit")
        if filled <= 0 or leaves != 0:
            raise ValueError("venue order is not a complete fill")
        state = self.load()
        positions = state.setdefault("positions", {})
        position = positions.get(normalized)
        if not isinstance(position, dict):
            raise ValueError("owned position is absent from durable state")
        owned = self._decimal(position.get("quantity", 0))
        if filled < owned:
            raise ValueError("venue fill is below durable owned quantity")
        positions.pop(normalized)
        events = state.setdefault("reconciliation_events", [])
        if not isinstance(events, list):
            raise ValueError("invalid reconciliation event state")
        events.append({
            "event": "VENUE_CONFIRMED_OWNED_EXIT",
            "symbol": normalized,
            "venue_order_id": str(order.get("id") or order.get("venue_order_id") or ""),
            "filled_quantity": str(filled),
            "observed_at": time.time(),
        })
        state["reconciliation_events"] = events[-256:]
        self.save(state)

    def terminalize_absent_owned_position_by_venue_balance(self, symbol: str) -> None:
        """Accept a valid zero venue balance without inventing a closing order or PnL."""
        normalized = str(symbol).upper().replace("/", "-")
        state = self.load()
        positions = state.setdefault("positions", {})
        position = positions.get(normalized)
        if not isinstance(position, dict):
            raise ValueError("owned position is absent from durable state")
        owned = self._decimal(position.get("quantity", 0))
        if owned <= 0:
            raise ValueError("owned position quantity is invalid")
        positions.pop(normalized)
        events = state.setdefault("reconciliation_events", [])
        if not isinstance(events, list):
            raise ValueError("invalid reconciliation event state")
        events.append({
            "event": "VENUE_BALANCE_CONFIRMED_ZERO",
            "symbol": normalized,
            "quantity": format(owned, "f"),
            "economic_truth": "UNKNOWN",
            "observed_at": time.time(),
        })
        state["reconciliation_events"] = events[-256:]
        self.save(state)

    def reconcile_owned_quantity_to_venue(
        self, symbol: str, venue_quantity: Any, order: dict[str, Any]
    ) -> dict[str, str]:
        """Adopt an account-wide venue balance when a proven fill omits fee data.

        The venue balance is authoritative for the currently received quantity.
        This path is deliberately economic-unknown: it never invents a fee or
        a conversion, and only runs for a matching terminal BUY with no
        terminal SELL for the same position (checked by the caller).
        """
        normalized = str(symbol).upper().replace("/", "-")
        venue_symbol = str(order.get("symbol") or "").upper().replace("/", "-")
        side = str(order.get("side") or "").upper()
        phase = order_fill_state(order)["phase"] if isinstance(order, dict) else ""
        venue_qty = self._decimal(venue_quantity)
        filled = self._decimal(order.get("filled_quantity", 0))
        if (venue_symbol != normalized or side != "BUY"
                or phase not in {"PARTIAL", "FILLED", "TERMINAL_PARTIAL"}
                or venue_qty <= 0 or filled <= 0 or venue_qty > filled):
            raise ValueError("venue data does not prove owned quantity reconciliation")
        state = self.load()
        position = state.setdefault("positions", {}).get(normalized)
        if not isinstance(position, dict):
            raise ValueError("owned position is absent from durable state")
        gross = self._decimal(position.get("gross_filled_quantity", position.get("quantity", 0)))
        if gross <= 0 or venue_qty > gross:
            raise ValueError("venue quantity exceeds proven gross fill")
        position["quantity"] = format(venue_qty, "f")
        position["gross_filled_quantity"] = format(gross, "f")
        position["quantity_reconciliation_truth"] = "VENUE_BALANCE"
        position["quantity_reconciliation_status"] = "FEE_UNKNOWN"
        position["entry_fee_truth"] = "UNKNOWN"
        intent_id = str(position.get("entry_intent_id") or "")
        if intent_id:
            intent_state = state.setdefault("intents", {}).setdefault(intent_id, {})
            intent_state["quantity_reconciled_to_venue"] = True
            intent_state["quantity_reconciliation_truth"] = "VENUE_BALANCE"
            intent_state["fee_truth"] = "UNKNOWN"
            intent_state.pop("adopted_fee_usd", None)
        events = state.setdefault("reconciliation_events", [])
        events.append({
            "event": "VENUE_BALANCE_QUANTITY_RECONCILED",
            "symbol": normalized,
            "venue_quantity": format(venue_qty, "f"),
            "gross_filled_quantity": format(gross, "f"),
            "fee_truth": "UNKNOWN",
            "venue_order_id": str(order.get("id") or order.get("venue_order_id") or ""),
            "observed_at": time.time(),
        })
        state["reconciliation_events"] = events[-256:]
        self.save(state)
        return {"symbol": normalized, "quantity": format(venue_qty, "f"),
                "fee_truth": "UNKNOWN"}

    def market_health(self) -> dict[str, dict[str, int]]:
        value = self.load().get("market_health", {})
        return value if isinstance(value, dict) else {}

    def record_market_health(self, symbol: str, *, coverage_misses: int,
                             negative_momentum: int,
                             last_negative_observed_at: float = 0.0,
                             last_coverage_miss_observed_at: float = 0.0) -> None:
        state = self.load()
        state.setdefault("market_health", {})[str(symbol).upper()] = {
            "coverage_misses": max(0, int(coverage_misses)),
            "negative_momentum": max(0, int(negative_momentum)),
            "last_negative_observed_at": max(0.0, float(last_negative_observed_at)),
            "last_coverage_miss_observed_at": max(
                0.0, float(last_coverage_miss_observed_at)
            ),
        }
        self.save(state)

    def market_tape(self) -> dict[str, list[list[float]]]:
        value = self.load().get("market_tape", {})
        return value if isinstance(value, dict) else {}

    def record_market_tape(self, snapshot: dict[str, list[list[float]]]) -> None:
        state = self.load()
        bounded: dict[str, list[list[float]]] = {}
        for symbol in sorted(snapshot)[:512]:
            values = snapshot.get(symbol)
            if isinstance(values, list):
                bounded[str(symbol).upper()] = values[-64:]
        state["market_tape"] = bounded
        self.save(state)

    def deep_validation_times(self) -> dict[str, float]:
        value = self.load().get("deep_validation_times", {})
        if not isinstance(value, dict):
            return {}
        return {str(key).upper(): float(timestamp) for key, timestamp in value.items()}

    def record_deep_validation(self, asset: str, observed_at: float) -> None:
        values = self.deep_validation_times()
        values[str(asset).upper()] = float(observed_at)
        self.record_deep_validation_times(values)

    def record_deep_validation_times(self, values: dict[str, float]) -> None:
        state = self.load()
        normalized = {
            str(asset).upper(): float(observed_at)
            for asset, observed_at in values.items()
        }
        if len(normalized) > 512:
            keep = sorted(normalized.items(), key=lambda item: item[1], reverse=True)[:512]
            normalized = dict(keep)
        state["deep_validation_times"] = normalized
        self.save(state)

    def append_decision_snapshot(self, snapshot: dict[str, Any],
                                 limit: int = 256) -> None:
        """Persist a bounded, secret-free discovery/decision audit trail."""
        if not isinstance(snapshot, dict) or not snapshot.get("observed_at"):
            raise ValueError("decision snapshot requires observed_at")
        bound = max(16, min(int(limit), 2048))
        rows: list[str] = []
        if self.decision_journal_path.exists():
            rows = [line for line in self.decision_journal_path.read_text(
                encoding="utf-8"
            ).splitlines() if line.strip()]
        rows.append(json.dumps(snapshot, sort_keys=True, separators=(",", ":")))
        rows = rows[-bound:]
        fd, tmp = tempfile.mkstemp(
            prefix="decision-journal-", suffix=".jsonl", dir=self.root
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write("\n".join(rows) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            replace_state_file(tmp, self.decision_journal_path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    def pending_intents(self) -> list[dict[str, Any]]:
        latest = self.intent_records()
        unresolved = {"PENDING", "SUBMITTED", "ACTIVE", "PARTIAL",
                      "UNCONFIRMED", "AMBIGUOUS", "RECONCILIATION_BLOCKED"}
        return [row for row in latest.values()
                if row.get("status", "PENDING") in unresolved]

    def record_execution_observation(self, intent, order, phase):
        from .execution_metrics import observation
        state=self.load()
        rows=state.setdefault('execution_metrics',{})
        old=rows.get(intent['intent_id'],{})
        row=observation(old,intent,order,phase,time.time())
        if all(old.get(k)==v for k,v in row.items() if k!='updated_at'):
            return
        rows[intent['intent_id']]=row
        self.save(state)

    def observe_execution_markouts(self, prices, now):
        from .execution_metrics import markouts
        state=self.load()
        if markouts(state.get('execution_metrics',{}),prices,now):
            self.save(state)

    def intent_records(self) -> dict[str, dict[str, Any]]:
        """Merge append-only intent events without losing original metadata."""
        if not self.outbox_path.exists():
            return {}
        latest: dict[str, dict[str, Any]] = {}
        for line in self.outbox_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                row = json.loads(line)
                if row.get("intent_id"):
                    latest.setdefault(row["intent_id"], {}).update(row)
        return latest

    @staticmethod
    def _decimal(value: Any) -> Decimal:
        try:
            result = Decimal(str(value))
        except (InvalidOperation, ValueError, TypeError) as exc:
            raise ValueError("invalid fill value") from exc
        if not result.is_finite() or result < 0:
            raise ValueError("invalid fill value")
        return result

    @staticmethod
    def _signed_decimal(value: Any) -> Decimal:
        """Validate economic PnL fields without treating a loss as malformed."""
        try:
            result = Decimal(str(value))
        except (InvalidOperation, ValueError, TypeError) as exc:
            raise ValueError("invalid economic value") from exc
        if not result.is_finite():
            raise ValueError("invalid economic value")
        return result

    def apply_execution_fill(self, intent: dict[str, Any], order: dict[str, Any]) -> dict:
        """Idempotently adopt newly observed BUY/SELL fill quantity."""
        intent_id = str(intent.get("intent_id") or "")
        metadata = intent.get("metadata") if isinstance(intent.get("metadata"), dict) else {}
        if metadata.get("inventory_origin") == "EXTERNAL_INVENTORY":
            return self.apply_external_exit_fill(intent, order)
        symbol = str(intent.get("symbol") or metadata.get("symbol") or "").upper().replace("/", "-")
        side = str(intent.get("side") or "").upper()
        if not intent_id or not symbol or side not in {"BUY", "SELL"}:
            raise ValueError("complete intent identity required")
        filled = self._decimal(order.get("filled_quantity", 0))
        if filled <= 0:
            return {"adopted_delta": "0", "position_changed": False}
        price = self._decimal(order.get("average_price") or order.get(
            "average_fill_price") or order.get("price", 0))
        if price <= 0:
            raise ValueError("positive average fill price required")
        raw_fee = reported_fee(order)
        raw_fee_amount = self._decimal(raw_fee) if raw_fee is not None else None
        fee_currency = str(order.get("fee_currency") or "").upper().strip()
        if raw_fee_amount is not None and raw_fee_amount > 0 and not fee_currency:
            raise ValueError("positive fee requires currency")
        fee_currency = fee_currency or "USD"
        base_asset = symbol.split("-", 1)[0]
        base_fee_total = (
            raw_fee_amount
            if fee_currency == base_asset and raw_fee_amount is not None
            else Decimal("0")
        )
        base_buy_fee = side == 'BUY' and fee_currency == base_asset and raw_fee_amount is not None
        # A positive BUY base fee is already embedded in net unit cost.
        total_fee = Decimal(0) if base_buy_fee else fee_in_usd(order)
        fee_truth = 'KNOWN' if total_fee is not None else 'UNKNOWN'

        state = self.load()
        intent_state = state.setdefault("intents", {}).setdefault(intent_id, {})
        adopted = self._decimal(intent_state.get("adopted_quantity", 0))
        adopted_fee = self._decimal(intent_state.get("adopted_fee_usd", 0))
        adopted_base_fee = self._decimal(intent_state.get("adopted_base_fee_quantity", 0))
        positions = state.setdefault("positions", {})
        current = positions.get(symbol, {})
        current_qty = self._decimal(current.get("quantity", 0))
        current_entry = self._decimal(current.get("average_entry_price", 0))
        cumulative_quote = self._decimal(order.get('executed_quote_amount', filled * price))
        adopted_quote = self._decimal(intent_state.get('adopted_quote_amount',
                                      adopted * self._decimal(intent_state.get('last_fill_price', 0))))
        migrate_quote = (adopted > 0 and 'adopted_quote_amount' not in intent_state
                         and order.get('execution_price_source') == 'INDIVIDUAL_FILLS'
                         and order.get('executed_quote_amount') is not None and total_fee is not None)
        if migrate_quote:
            # The old basis can contain a rounded average. Reconcile it once
            # against the verified cumulative cash, without adopting units twice.
            if side == 'BUY':
                sold = any(row.get('buy_intent_id') == intent_id for row in state.get('economic_ledger', []))
                if (current.get('entry_intent_id') != intent_id or sold or current_qty <= 0
                        or current_qty != adopted - adopted_base_fee):
                    raise ValueError('legacy BUY basis is not uniquely owned')
                adopted_quote = current_qty * current_entry
            else:
                rows = [row for row in state.get('economic_ledger', []) if row.get('sell_intent_id') == intent_id]
                if (len(rows) != 1 or rows[0].get('symbol') != symbol
                        or self._decimal(rows[0]['quantity']) != adopted):
                    raise ValueError('legacy SELL basis is not uniquely recorded')
                adopted_quote = self._signed_decimal(rows[0]['gross_pnl_usd']) + self._decimal(rows[0]['entry_price']) * adopted
        quote_delta = cumulative_quote - adopted_quote
        if not migrate_quote and (quote_delta < 0 or (filled > adopted and quote_delta <= 0)):
            raise ValueError('venue executed quote regressed')
        if filled < adopted:
            raise ValueError("venue filled quantity regressed")
        if total_fee is not None and total_fee < adopted_fee:
            raise ValueError("venue fee regressed")
        if base_fee_total < adopted_base_fee:
            raise ValueError("venue base fee regressed")
        delta = filled - adopted
        base_fee_delta = base_fee_total - adopted_base_fee
        fee_delta = total_fee - adopted_fee if total_fee is not None else None

        if delta == 0 and base_fee_delta == 0:
            if quote_delta != 0 and not migrate_quote:
                raise ValueError('same-quantity price correction requires reconciliation')
            fee_became_known = (
                total_fee is not None and (intent_state.get("fee_truth") != "KNOWN" or migrate_quote)
            )
            if not fee_became_known:
                return {"adopted_delta": "0", "position_changed": False}
            if side == "BUY":
                same_intent = str(current.get("entry_intent_id") or "") == intent_id
                if not current or not same_intent:
                    raise ValueError("cannot apply late BUY fee without matching open position")
                if migrate_quote:
                    current['average_entry_price'] = format((current_qty * current_entry + quote_delta) / current_qty, 'f')
                current["entry_fee_usd"] = format(
                    self._decimal(current.get("entry_fee_usd", 0))
                    + (total_fee - adopted_fee), "f"
                )
                current["entry_fee_truth"] = "KNOWN"
            else:
                ledger = state.setdefault("economic_ledger", [])
                matches = [row for row in ledger if row.get("sell_intent_id") == intent_id]
                if len(matches) != 1:
                    raise ValueError("cannot apply late SELL fee without one ledger row")
                row = matches[0]
                if migrate_quote:
                    row['gross_pnl_usd'] = format(self._signed_decimal(row['gross_pnl_usd']) + quote_delta, 'f')
                    row['exit_price'] = format(price, 'f')
                row["exit_fee_usd"] = format(total_fee, "f")
                if row.get("entry_fee_usd") is not None:
                    realized = (
                        self._signed_decimal(row["gross_pnl_usd"])
                        - self._decimal(row["entry_fee_usd"])
                        - total_fee
                    )
                    row["fee_truth"] = "KNOWN"
                    row["net_pnl_usd"] = format(realized, "f")
                recompute_session_risk(state, str(row["operating_mode"]), str(row["session_key"]))
            intent_state.update({
                "adopted_fee_usd": format(total_fee, "f"),
                "adopted_quote_amount": format(cumulative_quote, 'f'),
                "fee_truth": "KNOWN",
                "fill_provenance": "VENUE",
                "last_fill_price": format(price, "f"),
                "last_fill_at": float(time.time()),
            })
            self.save(state)
            return {"adopted_delta": "0", "position_changed": False,
                    "economic_correction": True}
        if side == "BUY":
            same_intent_history = (
                bool(current)
                and str(current.get("entry_intent_id") or intent_id) == intent_id
            )
            net_delta = delta - base_fee_delta
            # A late base fee may reduce only this intent's existing position.
            late_base_fee_correction = (
                delta == 0 and base_fee_delta > 0 and same_intent_history
            )
            if net_delta < 0 and not late_base_fee_correction:
                raise ValueError("base fee exceeds incremental fill")
            if net_delta == 0 and current_qty == 0:
                raise ValueError("base fee leaves no received quantity")
            new_qty = current_qty + net_delta
            if new_qty <= 0:
                raise ValueError("received quantity must remain positive")
            # Quote cost / net units embeds the base fee exactly once.
            average = ((current_qty * current_entry) + quote_delta) / new_qty
            entry_fee_truth = (
                "KNOWN" if total_fee is not None
                and (str(current.get("entry_fee_truth", "KNOWN")) == "KNOWN"
                     or same_intent_history)
                else "UNKNOWN"
            )
            positions[symbol] = {
                **current,
                "symbol": symbol,
                "quantity": format(new_qty, "f"),
                "average_entry_price": format(average, "f"),
                "stop": metadata.get("stop"),
                "target": metadata.get("target"),
                "lane": metadata.get("lane"),
                "operating_mode": metadata.get("operating_mode"),
                "session_key": metadata.get("session_key"),
                "entry_fee_usd": format(
                    self._decimal(current.get("entry_fee_usd", 0))
                    + (fee_delta or Decimal("0")), "f"
                ),
                "entry_fee_truth": entry_fee_truth,
                "gross_filled_quantity": format(
                    self._decimal(current.get("gross_filled_quantity", current_qty)) + delta, "f"
                ),
                "entry_base_fee_quantity": format(
                    self._decimal(current.get("entry_base_fee_quantity", 0)) + base_fee_delta, "f"
                ),
                "entry_base_fee_currency": base_asset if base_fee_total > 0 else current.get(
                    "entry_base_fee_currency"
                ),
                "source": "V5_OWNED",
                "entry_base_fee_in_cost_basis": base_buy_fee or current.get('entry_base_fee_in_cost_basis', False),
                "entry_intent_id": intent_id,
                "entry_filled_at": float(time.time()),
            }
        else:
            if delta > current_qty:
                raise ValueError("SELL fill exceeds V5-owned quantity")
            operating_mode = str(current.get("operating_mode") or "")
            if operating_mode not in {"DAY", "NIGHT"}:
                raise ValueError("V5 position operating mode is unknown")
            session_key = str(current.get("session_key") or "")
            if not session_key:
                raise ValueError("V5 position session is unknown")
            entry_fee = self._decimal(current.get("entry_fee_usd", 0))
            entry_fee_truth = str(current.get("entry_fee_truth", "UNKNOWN"))
            entry_fee_share = entry_fee * (delta / current_qty)
            gross = quote_delta - current_entry * delta
            ledger = state.setdefault("economic_ledger", [])
            matches = [row for row in ledger if row.get("sell_intent_id") == intent_id]
            if len(matches) > 1:
                raise ValueError("duplicate SELL ledger rows")
            row = matches[0] if matches else {
                "trade_id": f"{symbol}:{intent_id}", "symbol": symbol,
                "quantity": "0", "entry_price": format(current_entry, "f"),
                "gross_pnl_usd": "0", "entry_fee_usd": "0",
                "buy_intent_id": str(current.get("entry_intent_id", "")),
                "sell_intent_id": intent_id, "operating_mode": operating_mode,
                "session_key": session_key, "entry_filled_at": current.get("entry_filled_at"),
                "fill_provenance": "VENUE",
            }
            if not matches:
                ledger.append(row)
            row["quantity"] = format(self._decimal(row["quantity"]) + delta, "f")
            row["exit_price"] = format(price, "f")
            row["gross_pnl_usd"] = format(
                self._signed_decimal(row["gross_pnl_usd"]) + gross, "f"
            )
            if entry_fee_truth == "KNOWN" and row.get("entry_fee_usd") is not None:
                row["entry_fee_usd"] = format(
                    self._decimal(row["entry_fee_usd"]) + entry_fee_share, "f"
                )
            else:
                row["entry_fee_usd"] = None
            row["exit_fee_usd"] = format(total_fee, "f") if total_fee is not None else None
            economics_complete = row["entry_fee_usd"] is not None and total_fee is not None
            row["fee_truth"] = "KNOWN" if economics_complete else "UNKNOWN"
            row["net_pnl_usd"] = (
                format(self._signed_decimal(row["gross_pnl_usd"])
                       - self._decimal(row["entry_fee_usd"]) - total_fee, "f")
                if economics_complete else None
            )
            row["exit_filled_at"] = float(time.time())
            if len(ledger) > 1024:
                del ledger[:-1024]
            recompute_session_risk(state, operating_mode, session_key)
            new_qty = current_qty - delta
            if new_qty == 0:
                positions.pop(symbol, None)
            else:
                positions[symbol] = {
                    **current,
                    "quantity": format(new_qty, "f"),
                    "entry_fee_usd": format(entry_fee - entry_fee_share, "f"),
                }

        intent_state.update({"adopted_quantity": format(filled, "f"),
                             "adopted_quote_amount": format(cumulative_quote, 'f'),
                             "fee_truth": fee_truth,
                             "fill_provenance": "VENUE",
                             "last_fill_price": format(price, "f"),
                             "last_fill_at": float(time.time())})
        if total_fee is not None:
            intent_state["adopted_fee_usd"] = format(total_fee, "f")
        else:
            intent_state.pop("adopted_fee_usd", None)
        if base_fee_total > 0:
            intent_state["adopted_base_fee_quantity"] = format(base_fee_total, "f")
            intent_state["base_fee_currency"] = base_asset
        self.save(state)
        return {"adopted_delta": format(delta, "f"),
                "position_changed": True, "symbol": symbol, "side": side}

    def apply_external_exit_fill(self, intent: dict, order: dict) -> dict:
        """Track external-lot SELL fills without inventing entry cost or owned PnL."""
        symbol = str(intent.get("symbol") or "").upper().replace("/", "-")
        intent_id = str(intent.get("intent_id") or "")
        if not symbol or not intent_id or str(intent.get("side")).upper() != "SELL":
            raise ValueError("external exit identity required")
        filled = self._decimal(order.get("filled_quantity", 0))
        state = self.load()
        adopted = state.setdefault("intents", {}).setdefault(intent_id, {})
        previous = self._decimal(adopted.get("adopted_quantity", 0))
        if filled < previous:
            raise ValueError("external fill quantity regressed")
        delta = filled - previous
        if not delta:
            return {"adopted_delta": "0", "position_changed": False}
        external = state.setdefault("external_inventory", {})
        lot = external.get(symbol)
        if not isinstance(lot, dict):
            raise ValueError("external lot missing for SELL fill")
        available = self._decimal(lot.get("quantity", 0))
        if delta > available:
            raise ValueError("SELL fill exceeds reconciled external lot")
        remaining = available - delta
        if remaining:
            lot["quantity"] = format(remaining, "f")
        else:
            external.pop(symbol)
        ledger = state.setdefault("external_exit_ledger", [])
        matches = [row for row in ledger if row.get("sell_intent_id") == intent_id]
        if len(matches) > 1:
            raise ValueError("duplicate external exit ledger")
        row = matches[0] if matches else {"sell_intent_id": intent_id, "symbol": symbol}
        if not matches:
            ledger.append(row)
        raw_price = order.get("average_fill_price") or order.get("average_price") or order.get("price")
        price = self._decimal(raw_price) if raw_price is not None else None
        if price is not None and price <= 0:
            raise ValueError("invalid external fill price")
        row.update(quantity=format(filled, "f"),
                   exit_price=format(price, "f") if price is not None else None,
                   entry_price=None, net_pnl_usd=None, cost_basis_status="UNKNOWN",
                   venue_order_id=str(order.get("id") or order.get("venue_order_id") or ""),
                   observed_at=time.time())
        adopted.update(adopted_quantity=format(filled, "f"),
                       inventory_origin="EXTERNAL_INVENTORY", fill_provenance="VENUE")
        self.save(state)
        return {"adopted_delta": format(delta, "f"), "position_changed": True,
                "symbol": symbol, "side": "SELL", "economic_truth": "UNKNOWN"}

    def admission_snapshot(self, mode: str, session_key: str) -> dict[str, Any]:
        if mode not in {"DAY", "NIGHT"}:
            raise ValueError("mode must be DAY or NIGHT")
        if not session_key:
            raise ValueError("session_key required")
        state = self.load()
        # Exposure belongs to the account, including holdings inherited at a
        # DAY/NIGHT transition. Realized loss remains scoped to its session.
        positions = [row for row in state.get("positions", {}).values()
                     if isinstance(row, dict)]
        exposure = sum(
            self._decimal(row.get("quantity", 0))
            * self._decimal(row.get("average_entry_price", 0))
            for row in positions
        )
        sessions = state.setdefault("risk", {}).setdefault(
            mode, {"sessions": {}}
        ).setdefault("sessions", {})
        risk = sessions.setdefault(
            session_key, {"realized_net_pnl_usd": "0", "complete": True}
        )
        self.save(state)
        complete = bool(risk.get("complete", False))
        pnl = Decimal(str(risk.get("realized_net_pnl_usd", "0"))) if complete else None
        return {"operating_mode": mode, "session_key": session_key,
                "open_positions": len(positions),
                "exposure_usd": format(exposure, "f"),
                "session_loss_usd": format(pnl, "f") if pnl is not None else None,
                "risk_truth_complete": complete}

    def append_notification(self, notification: dict[str, Any]) -> None:
        if not notification.get("notification_id") or not notification.get("message"):
            raise ValueError("notification_id and message required")
        latest = {row.get("notification_id"): row
                  for row in self._notification_rows() if row.get("notification_id")}
        if notification["notification_id"] in latest:
            return
        with self.notifications_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({**notification, "status": "PENDING",
                                     "attempts": int(notification.get("attempts", 0))},
                                    sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def _notification_rows(self) -> list[dict[str, Any]]:
        if not self.notifications_path.exists():
            return []
        return [json.loads(line) for line in
                self.notifications_path.read_text(encoding="utf-8").splitlines()
                if line.strip()]

    def pending_notifications(self, limit: int = 20) -> list[dict[str, Any]]:
        rows = self._notification_rows()
        latest: dict[str, dict[str, Any]] = {}
        for row in rows:
            notification_id = row.get("notification_id")
            if not notification_id:
                continue
            latest.setdefault(notification_id, {}).update(row)
        return [row for row in latest.values() if row.get("status") == "PENDING"][:limit]

    def mark_notification(self, notification_id: str, status: str, attempts: int) -> None:
        self._append_notification_status(notification_id, status, attempts)

    def _append_notification_status(self, notification_id: str, status: str, attempts: int) -> None:
        with self.notifications_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"notification_id": notification_id,
                                     "status": status, "attempts": attempts},
                                    sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
