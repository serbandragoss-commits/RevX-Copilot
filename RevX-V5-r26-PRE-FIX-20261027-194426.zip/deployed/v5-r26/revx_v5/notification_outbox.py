"""Bounded Telegram notification delivery with durable deduplication."""

from __future__ import annotations

from typing import Any, Callable

from .state_store import DurableState


def deliver_pending(store: DurableState, send: Callable[[str], None], *, max_attempts: int = 3) -> dict[str, int]:
    sent = failed = deferred = 0
    for row in store.pending_notifications():
        attempts = int(row.get("attempts", 0))
        if attempts >= max_attempts:
            deferred += 1
            continue
        try:
            send(row["message"])
        except Exception:
            store.mark_notification(row["notification_id"], "PENDING", attempts + 1)
            failed += 1
        else:
            store.mark_notification(row["notification_id"], "SENT", attempts + 1)
            sent += 1
    return {"sent": sent, "failed": failed, "deferred": deferred}
