"""Reconcile venue state, execute one intent, and recover pending orders."""

from __future__ import annotations

from dataclasses import dataclass
import datetime as _datetime
import time
import logging
from typing import Any
from .state_store import DurableState

from .execution_adapter import Intent, submit_once
from .execution_truth import order_fill_state
from .external_inventory import classify_external_inventory, fetch_inventory_books
from .reconciliation import ReconciledState, ReconciliationBlocked, ManagedPartialOrder, owned_open_order, reconcile
from .recovery import resolve_intent

MAX_OWNED_POSITION_HISTORY_HOURS = 31 * 24


def _rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        for key in ("data", "items", "orders", "results"):
            if isinstance(value.get(key), list):
                return [row for row in value[key] if isinstance(row, dict)]
    return []


def _timestamp(value: Any) -> float | None:
    """Normalize common venue timestamps without guessing unknown age."""
    if value is None or value == "":
        return None
    try:
        numeric = float(value)
        if numeric > 10_000_000_000:
            numeric /= 1000.0
        return numeric if numeric > 0 else None
    except (TypeError, ValueError):
        pass
    try:
        text = str(value).replace("Z", "+00:00")
        return _datetime.datetime.fromisoformat(text).timestamp()
    except (TypeError, ValueError, OverflowError):
        return None


def _owned_position_history_hours(position: dict[str, Any], now: float | None = None) -> int:
    """Cover a recorded owned entry plus one day, with a bounded GET-only lookback."""
    observed = _timestamp(position.get("entry_filled_at"))
    if observed is None:
        return 24
    age = max(0.0, (time.time() if now is None else now) - observed)
    age_hours = int((age + 3599) // 3600)
    return min(MAX_OWNED_POSITION_HISTORY_HOURS, max(24, age_hours + 24))


@dataclass
class V5LiveBoundary:
    read_client: Any
    mutation_client: Any
    lane: Any = None
    state_store: DurableState | None = None
    runtime_mode: str = "UNKNOWN"
    entry_order_ttl_sec: float = 45.0
    risk_policy: Any = None

    def _observe_execution(self, intent, order, phase):
        """Optional measurements must not interrupt durable order recovery."""
        if self.state_store is None:
            return
        try:
            self.state_store.record_execution_observation(intent, order, phase)
        except Exception as exc:
            logging.getLogger(__name__).warning(
                'EXECUTION_TELEMETRY_UNAVAILABLE phase=%s error_type=%s',
                phase, type(exc).__name__)

    async def startup_reconcile(self) -> ReconciledState:
        state = await reconcile(self.read_client, self.lane)
        if not state.balances_valid:
            raise RuntimeError("V5 startup blocked by unreadable external balance state")
        if state.ambiguous:
            records = self.state_store.intent_records() if self.state_store is not None else {}
            if state.active_orders and all(owned_open_order(row, records) for row in state.active_orders):
                raise ManagedPartialOrder(state)
            raise ReconciliationBlocked(state)
        return state

    async def prepare_startup(self) -> dict:
        """Build and persist a venue-backed startup mode without mutation."""
        state = await self.startup_reconcile()
        pairs = await self.read_client.pair_configurations()
        books = await fetch_inventory_books(self.read_client, state.positions, pairs)
        inventory = classify_external_inventory(state.positions, pairs, books)
        if state.positions and not inventory["reconciled"]:
            raise RuntimeError("V5 startup blocked by unknown external inventory")
        owned_records: list[dict] = []
        external_records = list(inventory["records"])
        if self.state_store is not None:
            saved = self.state_store.load()
            owned = saved.get("positions", {}) if isinstance(saved.get("positions"), dict) else {}
            by_symbol = {str(row["symbol"]).upper(): row for row in external_records}
            for symbol, position in owned.items():
                row = by_symbol.get(str(symbol).upper())
                if row is None:
                    owned_qty = self.state_store._decimal(position.get("quantity", 0))
                    normalized = str(symbol).upper().replace("/", "-")
                    records = self.state_store.intent_records()
                    exit_intent_ids = {
                        str(intent_id) for intent_id, intent in records.items()
                        if str(intent.get("symbol") or "").upper().replace("/", "-") == normalized
                        and str(intent.get("side") or "").upper() == "SELL"
                    }
                    proven_exit = None
                    if exit_intent_ids:
                        history_hours = _owned_position_history_hours(position)
                        history = _rows(await self.read_client.historical_orders(
                            str(symbol), history_hours, self.lane
                        ))
                        # Some provider adapters do not accept the local
                        # BASE-QUOTE spelling for historical filtering.  Fall
                        # back once to account-wide history, but accept only a
                        # V5-owned exit intent; same-symbol manual trades are
                        # never treated as proof for this position.
                        if not history:
                            history = _rows(await self.read_client.historical_orders(
                                None, history_hours, self.lane
                            ))
                        proven_exit = next((order for order in history
                                            if str(order.get("symbol") or "").upper().replace("/", "-") == normalized
                                            and str(order.get("side") or "").upper() == "SELL"
                                            and str(order.get("client_order_id") or "") in exit_intent_ids
                                            and order_fill_state(order)["phase"] == "FILLED"
                                            and order_fill_state(order)["filled_quantity"] >= owned_qty), None)
                    if proven_exit is not None:
                        self.state_store.terminalize_absent_owned_position(str(symbol), proven_exit)
                    else:
                        self.state_store.terminalize_absent_owned_position_by_venue_balance(str(symbol))
                    continue
                venue_qty = self.state_store._decimal(row["quantity"])
                owned_qty = self.state_store._decimal(position.get("quantity", 0))
                if owned_qty <= 0 or venue_qty < owned_qty:
                    # Reconcile every owned symbol against its terminal BUY
                    # fill before declaring a mismatch.  This covers venue
                    # fees paid in the base asset (and any future equivalent)
                    # without naming or special-casing a ticker.
                    entry_intent_id = str(position.get("entry_intent_id") or "")
                    history = _rows(await self.read_client.historical_orders(
                        str(symbol), 24, self.lane
                    ))
                    if not history:
                        history = _rows(await self.read_client.historical_orders(
                            None, 24, self.lane
                        ))
                    proven_buy = next((order for order in history
                                       if str(order.get("symbol") or "").upper().replace("/", "-")
                                       == str(symbol).upper().replace("/", "-")
                                       and str(order.get("side") or "").upper() == "BUY"
                                       and entry_intent_id
                                       and str(order.get("client_order_id") or "") == entry_intent_id
                                       and order_fill_state(order)["phase"] in {
                                           "PARTIAL", "FILLED", "TERMINAL_PARTIAL"
                                       }), None)
                    if proven_buy is not None:
                        proven_sells = [order for order in history
                                        if str(order.get("symbol") or "").upper().replace("/", "-")
                                        == str(symbol).upper().replace("/", "-")
                                        and str(order.get("side") or "").upper() == "SELL"
                                        and order_fill_state(order)["phase"] in {
                                            "PARTIAL", "FILLED", "TERMINAL_PARTIAL"
                                        }]
                        raw_fee = proven_buy.get("fee", proven_buy.get(
                            "fees", proven_buy.get("total_fee")))
                        fee_currency = str(proven_buy.get("fee_currency") or "").strip()
                        if proven_sells:
                            raise RuntimeError(f"V5-owned quantity mismatch: {symbol}")
                        if raw_fee is None and not fee_currency:
                            self.state_store.reconcile_owned_quantity_to_venue(
                                str(symbol), venue_qty, proven_buy
                            )
                        else:
                            self.state_store.apply_execution_fill(
                                {"intent_id": entry_intent_id, "symbol": str(symbol),
                                 "side": "BUY", "metadata": position},
                                proven_buy,
                            )
                        saved = self.state_store.load()
                        position = saved.get("positions", {}).get(symbol, position)
                        owned_qty = self.state_store._decimal(position.get("quantity", 0))
                        # The venue fill is now represented in durable state;
                        # continue through the common account-wide comparison.
                        if venue_qty >= owned_qty:
                            pass
                        else:
                            raise RuntimeError(f"V5-owned quantity mismatch: {symbol}")
                    else:
                        raise RuntimeError(f"V5-owned quantity mismatch: {symbol}")
                owned_records.append(dict(position))
                residual = venue_qty - owned_qty
                if residual == 0:
                    external_records.remove(row)
                else:
                    row["quantity"] = format(residual, "f")
        self.runtime_mode = "NORMAL"
        if self.state_store is not None:
            self.state_store.record_external_inventory(external_records, self.runtime_mode)
        visible_inventory = {**inventory, "records": external_records,
                             "count": len(external_records)}
        return {"state": state, "inventory": visible_inventory,
                "owned_positions": owned_records, "runtime_mode": self.runtime_mode,
                "entry_enabled": True}

    async def execute_intent(self, intent: Intent) -> dict:
        prepared = await self.prepare_startup()
        state = prepared["state"]
        if state.ambiguous:
            raise RuntimeError("V5 execution blocked by ambiguous reconciliation")
        if self.state_store is not None and intent.side.upper() == 'BUY' and (intent.metadata or {}).get('sizing'):
            # Alternative plans may be stale by the time one is selected.
            from .policy import RiskPolicy
            from .sizing import pending_buy_commitment, number
            from .reconciliation import parse_balances
            meta=intent.metadata
            view=self.state_store.admission_snapshot(meta['operating_mode'],meta['session_key'])
            pending,pending_symbols=pending_buy_commitment(state.active_orders)
            external=prepared['inventory']['records']
            exposure=number(view['exposure_usd'])+pending+sum(
                (number(row['quantity'])*number(row['mark_price']) for row in external),number(0))
            occupied={str(row['symbol']) for row in prepared.get('owned_positions',[])+external}
            count=view['open_positions']+len(external)+len(pending_symbols-occupied)
            limit=intent.body['order_configuration']['limit']
            notional=number(limit['base_size'],positive=True)*number(limit['price'],positive=True)
            if not view['risk_truth_complete'] or not (self.risk_policy or RiskPolicy()).allows(meta['operating_mode'],count,
                    float(exposure),float(notional),float(view['session_loss_usd'])):
                raise RuntimeError('BUY_ACCOUNT_CHANGED_BEFORE_SUBMIT')
            balances,valid=parse_balances(state.balances)
            cash=next((number(row.get('available')) for row in balances if row['currency']=='USD'),number(0))
            if not valid or notional+number(meta['sizing']['entry_cost_allowance_usd'])>cash:
                raise RuntimeError('BUY_CASH_CHANGED_BEFORE_SUBMIT')
        if self.state_store is not None:
            self.state_store.append_intent({"intent_id": intent.intent_id,
                                            "symbol": intent.symbol,
                                            "side": intent.side,
                                            "body": intent.body,
                                            "metadata": intent.metadata or {},
                                            "submitted_at": time.time(),
                                            "status": "PENDING"})
        measured_intent={'intent_id':intent.intent_id,'symbol':intent.symbol,
                         'side':intent.side,'metadata':intent.metadata or {}}
        self._observe_execution(measured_intent,{},'SUBMIT_REQUESTED')
        result = await submit_once(self.mutation_client, intent, self.lane)
        if self.state_store is not None:
            # Persist the broker acknowledgement before any additional GET.
            # If fill evidence is temporarily unavailable, restart recovery
            # still has the authoritative venue ID and must never resubmit.
            self.state_store.append_intent({'intent_id':intent.intent_id,
                'venue_order_id':result.get('id') or result.get('venue_order_id'),
                'status':'SUBMITTED'})
        if hasattr(self.read_client, 'enrich_order'):
            result = await self.read_client.enrich_order(result, self.lane)
        fill = order_fill_state(result)
        terminal_status = "SUBMITTED"
        if self.state_store is not None and fill["phase"] in {
            "PARTIAL", "FILLED", "TERMINAL_PARTIAL"
        }:
            self.state_store.apply_execution_fill({
                "intent_id": intent.intent_id, "symbol": intent.symbol,
                "side": intent.side, "metadata": intent.metadata or {},
            }, result)
            terminal_status = fill["phase"]
        elif fill["phase"] == "TERMINAL_UNFILLED":
            terminal_status = "TERMINAL_UNFILLED"
        if self.state_store is not None:
            self.state_store.append_intent({"intent_id": intent.intent_id,
                                            "symbol": intent.symbol,
                                            "side": intent.side,
                                            "venue_order_id": result.get("id") or result.get("venue_order_id"),
                                            "submitted_at": time.time(),
                                            "status": terminal_status})
        self._observe_execution(measured_intent,result,'RESPONSE_OBSERVED')
        return result

    async def cancel_stale_entry_orders(self) -> list[dict]:
        """Cancel only aged BUY orders durably proven to belong to V5."""
        ttl = max(5.0, float(self.entry_order_ttl_sec))
        now = time.time()
        active = _rows(await self.mutation_client.active_orders(None, self.lane))
        records = self.state_store.intent_records() if self.state_store is not None else {}
        by_intent_id = {
            str(intent_id): row
            for intent_id, row in records.items()
            if intent_id
        }
        by_order_id = {
            str(row.get("venue_order_id")): row
            for row in records.values()
            if row.get("venue_order_id")
        }
        cancelled: list[dict] = []
        for row in active:
            if str(row.get("side", "")).lower() != "buy":
                continue
            venue_id = str(row.get("id") or row.get("venue_order_id") or "")
            if not venue_id:
                continue
            client_order_id = str(row.get("client_order_id") or "")
            local = by_order_id.get(venue_id) or by_intent_id.get(client_order_id)
            # Active orders are account-wide.  Unknown ownership is therefore
            # fail-closed for mutation: manual and other-system orders must not
            # be adopted merely because they are old BUYs.
            if not local:
                continue
            local_intent_id = str(local.get("intent_id") or client_order_id)
            if not local_intent_id or str(local.get("side", "")).upper() != "BUY":
                continue
            local_venue_id = str(local.get("venue_order_id") or "")
            if local_venue_id and venue_id != local_venue_id:
                continue
            if client_order_id and client_order_id != local_intent_id:
                continue
            venue_symbol = str(row.get("symbol") or "").upper().replace("/", "-")
            local_symbol = str(local.get("symbol") or "").upper().replace("/", "-")
            if venue_symbol and local_symbol and venue_symbol != local_symbol:
                continue
            submitted = None
            for key in ("created_at", "createdAt", "created_time", "createdTime",
                        "created_date", "createdDate", "order_created_at",
                        "submitted_at", "submittedAt"):
                submitted = _timestamp(row.get(key))
                if submitted is not None:
                    break
            if submitted is None:
                submitted = _timestamp(local.get("submitted_at"))
            # Unknown age is fail-closed: do not cancel an order without proof.
            if submitted is None or now - submitted < ttl:
                continue
            attempted = _timestamp(local.get("cancel_requested_at"))
            if attempted is not None and now - attempted < ttl:
                continue
            event = {
                "intent_id": local_intent_id,
                "venue_order_id": venue_id,
                "symbol": str(row.get("symbol") or ""),
                "side": "BUY",
                "cancel_requested_at": now,
                "age_sec": round(max(0.0, now - submitted), 3),
                "reason": "ENTRY_ORDER_TTL",
            }
            try:
                await self.mutation_client.cancel_order(venue_id, self.lane)
            except RuntimeError as exc:
                # The venue may have terminalized the order between the active
                # GET and this cancel attempt.  Preserve the ambiguity for
                # recovery; never retry a mutation from this path.
                if "inactive" not in str(exc).lower():
                    raise
                event["outcome"] = "RACE_RECONCILIATION_REQUIRED"
                if self.state_store is not None and event["intent_id"]:
                    self.state_store.append_intent({**event, "status": "SUBMITTED"})
                cancelled.append(event)
                continue
            if self.state_store is not None and event["intent_id"]:
                self.state_store.append_intent({**event, "status": "ACTIVE"})
            cancelled.append(event)
        return cancelled

    async def recover_pending(self) -> list[dict]:
        """Reconcile durable pending intents after restart; never resubmit."""
        if self.state_store is None:
            return []
        recovered = []
        for intent in self.state_store.pending_intents():
            outcome = await resolve_intent(
                self.read_client,
                intent["intent_id"],
                intent.get("venue_order_id"),
                self.lane,
            )
            status = outcome["status"]
            order = outcome.get("order")
            if status == "CONFIRMED" and isinstance(order, dict):
                if hasattr(self.read_client, 'enrich_order'):
                    order = await self.read_client.enrich_order(order, self.lane)
                fill = order_fill_state(order)
                status = fill["phase"]
                if status in {"PARTIAL", "FILLED", "TERMINAL_PARTIAL"}:
                    try:
                        self.state_store.apply_execution_fill(intent, order)
                    except ValueError:
                        # A venue can prove a complete SELL quantity while
                        # omitting its average fill price.  Quantity truth is
                        # sufficient to make the intent terminal; the next
                        # fresh-balance startup pass removes the owned
                        # position only if that absence is independently
                        # confirmed.  Never invent price/PnL and never retry
                        # the already-terminal order.
                        raw_price = (order.get("average_price") or order.get("average_fill_price")
                                     or order.get("price"))
                        missing_price = raw_price is None or not str(raw_price).strip()
                        if (missing_price and str(intent.get("side") or "").upper() == "SELL"
                                and status == "FILLED"):
                            status = "TERMINAL_UNPRICED"
                        else:
                            status = "RECONCILIATION_BLOCKED"
            self.state_store.append_intent({"intent_id": intent["intent_id"],
                                            "status": status,
                                            "recovery": True,
                                            "matches": outcome.get("matches", [])})
            if outcome['status'] == 'CONFIRMED' and isinstance(order, dict):
                self._observe_execution(intent,order,'RECOVERY_OBSERVED')
            # Return the normalized fill phase, not the intermediate lookup
            # status (CONFIRMED).  Startup supervision must distinguish an
            # active venue order from a terminally reconciled intent.
            recovered.append({"intent_id": intent["intent_id"],
                              **outcome, "status": status})
        return recovered
