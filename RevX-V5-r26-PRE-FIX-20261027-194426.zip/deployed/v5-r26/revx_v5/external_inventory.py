"""Pure classification of venue balances that pre-date the V5 runtime."""

from __future__ import annotations

import asyncio
from decimal import Decimal, InvalidOperation
from typing import Any


def _positive(value: Any) -> bool:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return False
    return number.is_finite() and number > 0


def _pair_rows(payload: Any) -> list[tuple[str, dict]]:
    if not isinstance(payload, dict):
        return []
    nested = next((payload[key] for key in ("data", "items", "pairs", "results")
                   if isinstance(payload.get(key), dict)), None)
    source = nested if nested is not None else payload
    rows: list[tuple[str, dict]] = []
    for key, value in source.items():
        if not isinstance(value, dict):
            continue
        symbol = str(value.get("symbol") or key).strip().upper().replace("/", "-")
        rows.append((symbol, value))
    return rows


def active_usd_pairs(payload: Any) -> set[str]:
    """Return active USD spot symbols with usable venue increments."""
    result: set[str] = set()
    for symbol, row in _pair_rows(payload):
        base = str(row.get("base") or symbol.removesuffix("-USD")).upper()
        quote = str(row.get("quote") or ("USD" if symbol.endswith("-USD") else "")).upper()
        status = str(row.get("status") or "").lower()
        if (symbol == f"{base}-USD" and quote == "USD" and status == "active"
                and _positive(row.get("base_step")) and _positive(row.get("quote_step"))):
            result.add(symbol)
    return result


def executable_book(payload: Any) -> bool:
    """Require a non-crossed, positive two-sided public order book."""
    if not isinstance(payload, dict):
        return False

    def best(side: str, *, highest: bool) -> Decimal | None:
        prices: list[Decimal] = []
        for row in payload.get(side) or []:
            raw = row.get("price") if isinstance(row, dict) else (
                row[0] if isinstance(row, (list, tuple)) and row else None
            )
            try:
                value = Decimal(str(raw))
            except (InvalidOperation, ValueError):
                continue
            if value.is_finite() and value > 0:
                prices.append(value)
        return (max(prices) if highest else min(prices)) if prices else None

    bid = best("bids", highest=True)
    ask = best("asks", highest=False)
    return bid is not None and ask is not None and ask >= bid


def best_bid(payload: Any) -> Decimal | None:
    values = [price for price, _ in book_levels(payload, "bids")]
    return max(values) if values else None


def book_levels(payload: Any, side: str) -> list[tuple[Decimal, Decimal | None]]:
    """Parse price/quantity levels without inventing missing depth."""
    result = []
    if not isinstance(payload, dict):
        return result
    for row in payload.get(side) or []:
        if isinstance(row, dict):
            price = next((Decimal(str(row[key])) for key in ("price",)
                          if _positive(row.get(key))), None)
            quantity = next((Decimal(str(row[key])) for key in
                             ("quantity", "size", "amount", "base_quantity")
                             if _positive(row.get(key))), None)
        elif isinstance(row, (list, tuple)) and row:
            price = Decimal(str(row[0])) if _positive(row[0]) else None
            quantity = (Decimal(str(row[1])) if len(row) > 1 and _positive(row[1])
                        else None)
        else:
            continue
        if price is not None:
            result.append((price, quantity))
    return result


def executable_bid_value(quantity: Decimal,
                         bids: list[tuple[Decimal, Decimal | None]]) -> tuple[Decimal | None, bool]:
    """Return depth-weighted proceeds only when every consumed size is known."""
    if not bids or any(size is None for _, size in bids):
        return None, False
    remaining = quantity
    proceeds = Decimal("0")
    for price, size in sorted(bids, key=lambda row: row[0], reverse=True):
        take = min(remaining, size or Decimal("0"))
        proceeds += take * price
        remaining -= take
        if remaining <= 0:
            return proceeds, True
    return proceeds, False


def classify_external_inventory(positions: list[dict] | tuple[dict, ...],
                                pairs: Any,
                                books: dict[str, Any]) -> dict[str, Any]:
    """Classify every non-USD balance; all rows must be tradable and observable."""
    allowed = active_usd_pairs(pairs)
    records = []
    for row in positions:
        currency = str(row.get("currency") or row.get("symbol") or "").upper()
        symbol = f"{currency}-USD" if currency else ""
        pair_active = symbol in allowed
        book_executable = pair_active and executable_book(books.get(symbol))
        bid = best_bid(books.get(symbol)) if book_executable else None
        records.append({
            "currency": currency,
            "symbol": symbol,
            "quantity": str(row.get("total") or "0"),
            "classification": "EXTERNAL_INVENTORY" if book_executable else "UNKNOWN",
            "pair_active": pair_active,
            "executable_book": book_executable,
            "mark_price": str(bid) if bid is not None else None,
            # Venue confirms quantity and executable mark, but not the
            # original acquisition cost.  Keep that uncertainty explicit
            # while making every observable non-stable balance available to
            # the shared exit evaluator; there is no ownership whitelist.
            "cost_basis_status": "UNKNOWN",
            "pnl_status": "UNKNOWN",
            "exit_eligible": bool(book_executable),
            "exit_evaluation_status": (
                "READY_COST_UNKNOWN" if book_executable else "BLOCKED_NO_EXECUTABLE_BOOK"
            ),
        })
    unknown = [row["currency"] for row in records if row["classification"] == "UNKNOWN"]
    return {
        "records": records,
        "count": len(records),
        "reconciled": not unknown,
        "unknown_currencies": sorted(unknown),
    }


async def fetch_inventory_books(client: Any,
                                positions: list[dict] | tuple[dict, ...],
                                pairs: Any, lane: Any = None,
                                attempts: int = 3) -> dict[str, Any]:
    """Bounded retries; unavailable books remain unknown and fail closed."""
    allowed = active_usd_pairs(pairs)
    books: dict[str, Any] = {}
    for row in positions:
        currency = str(row.get("currency") or row.get("symbol") or "").upper()
        symbol = f"{currency}-USD" if currency else ""
        if symbol in allowed:
            for attempt in range(max(1, int(attempts))):
                try:
                    books[symbol] = await client.order_book(symbol, 50, lane)
                    break
                except Exception:
                    if attempt + 1 >= max(1, int(attempts)):
                        break
                    await asyncio.sleep(0.25 * (2 ** attempt))
    return books
