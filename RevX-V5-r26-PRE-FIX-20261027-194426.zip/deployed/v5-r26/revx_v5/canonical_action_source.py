"""Build V5 BUY/SELL intents from market data and reconciled inventory."""

from __future__ import annotations

import copy
import hashlib
import time
from decimal import Decimal, ROUND_FLOOR
from typing import Any

from .execution_adapter import Intent
from .policy import RiskPolicy
from .sizing import size_buy
from .allocation import allocate_targets


class V5ExitPlanner:
    """V5-owned second gate for strategy-specific exit reasons."""

    def __init__(self, delegate: Any, config: dict, clock: Any = time.time):
        self.delegate = delegate
        self.config = config
        self.clock = clock

    def __getattr__(self, name: str) -> Any:
        return getattr(self.delegate, name)

    async def build_sell_plan(self, exit_id: str, position: dict, reason: str,
                              scope: str = "MANAGED", external: bool = False):
        normalized_reason = str(reason).upper()
        if normalized_reason in {"CONFIRMED_DOWNTREND", "CONFIRMED_DOWNTREND_UNPROFITABLE"}:
            required = int(self.config.get("confirmed_downtrend_confirmations", 2))
            observed_at = float(position.get("fast_momentum_last_observed_at") or 0)
            max_age = float(self.config.get("confirmed_downtrend_max_age_sec", 75.0))
            age = float(self.clock()) - observed_at
            if (
                str(position.get("fast_momentum_state", "")).upper() != "NEGATIVE"
                or int(position.get("fast_momentum_negative_confirmations", 0)) < required
                or observed_at <= 0
                or age < -5.0
                or age > max_age
            ):
                raise ValueError("CONFIRMED_DOWNTREND is not fresh and confirmed")
        if normalized_reason == "DEGRADED_POSITION":
            required = int(self.config.get("degraded_position_confirmations", 3))
            observed_at = float(position.get("coverage_last_missing_at") or 0)
            max_age = float(self.config.get("degraded_position_max_age_sec", 75.0))
            age = float(self.clock()) - observed_at
            if (
                int(position.get("coverage_missing_confirmations", 0)) < required
                or observed_at <= 0
                or age < -5.0
                or age > max_age
            ):
                raise ValueError("DEGRADED_POSITION is not fresh and confirmed")
        # Reconciled external lots are bounded to their recorded quantity. The
        # legacy external=True path requires ALL_AVAILABLE and would sweep an
        # owned lot of the same asset as well. Use its quantity-bounded path.
        if external and scope == "MANAGED":
            if position.get("inventory_origin") != "EXTERNAL_INVENTORY":
                raise ValueError("external SELL requires reconciled lot identity")
            external = False
        plan = await self.delegate.build_sell_plan(
            exit_id, position, reason, scope, external=external
        )
        if normalized_reason == 'CONFIRMED_DOWNTREND_UNPROFITABLE':
            entry=float(position.get('average_entry_price') or position.get('entry') or 0)
            if entry<=0 or float(plan.trigger_bid)>entry:
                raise ValueError('downtrend exit recovered above cost basis on fresh book')
        return plan


def _rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        if isinstance(value.get("data"), list):
            return [row for row in value["data"] if isinstance(row, dict)]
        if value and all(isinstance(row, dict) for row in value.values()):
            return list(value.values())
    return []


def _floor(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError("invalid venue base step")
    return (value / step).to_integral_value(rounding=ROUND_FLOOR) * step


def _text(value: Decimal) -> str:
    return format(value, "f")


class CanonicalSpeculativeActionSource:
    def __init__(self, client: Any, planner: Any, tape: Any, *,
                 rank_candidates: Any, quote_from_ticker: Any,
                 policies: tuple[Any, ...], priority: Any,
                 order_cap_usd: float | None = None, validation_limit: int = 7,
                 degraded_strikes: int = 3, health_store: Any = None,
                 risk_policy: RiskPolicy | None = None,
                 allocation_mode: bool = False, target_exits: bool = False,
                 negative_min_interval_sec: float = 10.0,
                 negative_max_gap_sec: float = 75.0,
                 degraded_min_interval_sec: float = 10.0,
                 degraded_max_gap_sec: float = 75.0,
                 clock: Any = time.time):
        self.client = client
        self.planner = planner
        self.tape = tape
        self.rank_candidates = rank_candidates
        self.quote_from_ticker = quote_from_ticker
        self.policies = policies
        self.priority = priority
        self.order_cap_usd = Decimal(str(order_cap_usd)) if order_cap_usd is not None else None
        self.validation_limit = max(1, min(int(validation_limit), 10))
        self.degraded_strikes = max(2, int(degraded_strikes))
        self.negative_min_interval_sec = max(1.0, float(negative_min_interval_sec))
        self.negative_max_gap_sec = max(
            self.negative_min_interval_sec, float(negative_max_gap_sec)
        )
        self.degraded_min_interval_sec = max(1.0, float(degraded_min_interval_sec))
        self.degraded_max_gap_sec = max(
            self.degraded_min_interval_sec, float(degraded_max_gap_sec)
        )
        self.clock = clock
        self.health_store = health_store
        self.risk_policy = risk_policy or RiskPolicy()
        self.allocation_mode = allocation_mode
        self.target_exits = target_exits
        self.last_scan: dict = {}
        self._last_tape_persisted_at = 0.0
        self._deep_validation_times: dict[str, float] = {}
        self._coverage_misses: dict[str, int] = {}
        self._last_coverage_miss_observed_at: dict[str, float] = {}
        self._negative_momentum: dict[str, int] = {}
        self._last_negative_observed_at: dict[str, float] = {}
        if health_store is not None:
            self._deep_validation_times = health_store.deep_validation_times()
            for symbol, row in health_store.market_health().items():
                if isinstance(row, dict):
                    self._coverage_misses[str(symbol).upper()] = int(
                        row.get("coverage_misses", 0)
                    )
                    self._negative_momentum[str(symbol).upper()] = int(
                        row.get("negative_momentum", 0)
                    )
                    self._last_negative_observed_at[str(symbol).upper()] = float(
                        row.get("last_negative_observed_at", 0) or 0
                    )
                    self._last_coverage_miss_observed_at[str(symbol).upper()] = float(
                        row.get("last_coverage_miss_observed_at", 0) or 0
                    )

    @classmethod
    def from_canonical(cls, client: Any, config: dict, **kwargs: Any):
        """Bind only to the verified v3.5.8 package present on sys.path."""
        from revx_v3.execution import ExecutionService
        from revx_v3.models import Priority
        from revx_v3.momentum import MomentumTape
        from revx_v3.strategy import (
            AMBITIOUS,
            IGNITION,
            STANDARD,
            quote_from_ticker,
            rank_candidates,
        )

        policies = (IGNITION, STANDARD, AMBITIOUS)
        health_store = kwargs.get("health_store")
        saved_tape = health_store.market_tape() if health_store is not None else None
        planner = V5ExitPlanner(
            ExecutionService(client, config), config,
            clock=kwargs.get("clock", time.time),
        )
        return cls(client, planner, MomentumTape(saved_tape),
                   rank_candidates=rank_candidates,
                   quote_from_ticker=quote_from_ticker,
                   policies=policies, priority=Priority, **kwargs)

    async def next_exit(self, context: dict) -> Intent | None:
        self.last_scan.pop('last_exit', None)
        positions = [row for row in context.get("managed_positions", context.get("owned_positions", []))
                     if isinstance(row, dict) and row.get("symbol")]
        external_positions = [row for row in context.get("external_positions", [])
                              if isinstance(row, dict)]
        if not positions:
            return None
        raw = await self.client.tickers(self.priority.EXIT_WATCH)
        ticker_rows = _rows(raw)
        now = float(self.clock())
        prices: dict[str, float] = {}
        for row in ticker_rows:
            quote = self.quote_from_ticker(row)
            if quote is not None:
                prices[quote.symbol] = quote.mid
        momentum = self.tape.observe(prices, now)
        for metrics in momentum.values():
            metrics["observed_at"] = now

        if self.health_store is not None and hasattr(self.health_store,'observe_execution_markouts'):
            self.health_store.observe_execution_markouts(prices,now)
        triggered: list[tuple[int, dict, str, float]] = []
        for original in positions:
            position = dict(original)
            position["inventory_origin"] = (
                "EXTERNAL_INVENTORY" if original in external_positions else "V5_OWNED"
            )
            symbol = str(position["symbol"]).upper().replace("/", "-")
            if symbol not in prices:
                last_missing = self._last_coverage_miss_observed_at.get(symbol, 0.0)
                missing_gap = now - last_missing
                if last_missing <= 0 or missing_gap > self.degraded_max_gap_sec:
                    self._coverage_misses[symbol] = 1
                    self._last_coverage_miss_observed_at[symbol] = now
                elif missing_gap >= self.degraded_min_interval_sec:
                    self._coverage_misses[symbol] = self._coverage_misses.get(symbol, 0) + 1
                    self._last_coverage_miss_observed_at[symbol] = now
            else:
                self._coverage_misses[symbol] = 0
                self._last_coverage_miss_observed_at[symbol] = 0.0
            metrics = momentum.get(symbol, {})
            negative = self._momentum_negative(metrics)
            if negative:
                last_negative = self._last_negative_observed_at.get(symbol, 0.0)
                negative_gap = now - last_negative
                if last_negative <= 0 or negative_gap > self.negative_max_gap_sec:
                    self._negative_momentum[symbol] = 1
                    self._last_negative_observed_at[symbol] = now
                elif negative_gap >= self.negative_min_interval_sec:
                    self._negative_momentum[symbol] = self._negative_momentum.get(symbol, 0) + 1
                    self._last_negative_observed_at[symbol] = now
            else:
                self._negative_momentum[symbol] = 0
                self._last_negative_observed_at[symbol] = 0.0
            if self.health_store is not None:
                self.health_store.record_market_health(
                    symbol, coverage_misses=self._coverage_misses[symbol],
                    negative_momentum=self._negative_momentum[symbol],
                    last_negative_observed_at=self._last_negative_observed_at.get(symbol, 0.0),
                    last_coverage_miss_observed_at=(
                        self._last_coverage_miss_observed_at.get(symbol, 0.0)
                    ),
                )
            try:
                book = await self.client.order_book(symbol, 50, self.priority.EXIT_CRITICAL)
                bid = self._best_price(book, "bids", highest=True)
            except Exception:
                bid = None
            if bid is None:
                # No executable truth means no blind SELL.
                continue

            reason = None
            stop = float(position.get("stop") or 0)
            target = float(position.get("target") or 0)
            if stop > 0 and bid <= stop:
                reason = "STOP_HIT"
            elif self._coverage_misses.get(symbol, 0) >= self.degraded_strikes:
                reason = "DEGRADED_POSITION"
                position.update({
                    "coverage_missing_confirmations": self._coverage_misses[symbol],
                    "coverage_last_missing_at": self._last_coverage_miss_observed_at.get(
                        symbol, 0.0
                    ),
                })
            elif self.target_exits and target > 0 and bid >= target:
                reason = "TARGET_HIT"
            elif self._negative_momentum.get(symbol, 0) >= 2:
                entry_price = float(
                    position.get("average_entry_price")
                    or position.get("entry")
                    or 0
                )
                # A confirmed downtrend protects capital only after the
                # position is no longer profitable.  Never turn a winner into
                # an automatic SELL on this signal alone.  For external
                # inventory without cost-basis truth, hold rather than infer.
                if entry_price > 0 and bid > entry_price:
                    self.last_scan["last_exit"] = {
                        "observed_at": now, "status": "HOLD_PROFITABLE_DOWNTREND",
                        "symbol": symbol,
                        "reason": "CONFIRMED_DOWNTREND_PROFIT_PROTECTED",
                        "bid": bid, "entry": entry_price,
                    }
                    continue
                if entry_price <= 0:
                    self.last_scan["last_exit"] = {
                        "observed_at": now, "status": "HOLD_PROFITABILITY_UNKNOWN",
                        "symbol": symbol,
                        "reason": "CONFIRMED_DOWNTREND_COST_BASIS_UNKNOWN",
                    }
                    continue
                reason = "CONFIRMED_DOWNTREND_UNPROFITABLE"
                position.update({
                    "fast_momentum_state": "NEGATIVE",
                    "fast_momentum_negative_confirmations": self._negative_momentum[symbol],
                    "fast_momentum_last_observed_at": self._last_negative_observed_at.get(
                        symbol, 0.0
                    ),
                })
            if reason is None:
                continue
            severity = {"STOP_HIT": 0, "DEGRADED_POSITION": 1,
                        "TARGET_HIT": 2, "CONFIRMED_DOWNTREND_UNPROFITABLE": 3}[reason]
            triggered.append((severity, position, reason, bid))

        self._persist_tape(now)
        if not triggered:
            return None
        highest_severity = min(row[0] for row in triggered)
        blocked: list[dict[str, str]] = []
        for _severity, position, reason, bid in sorted(triggered, key=lambda row: row[0]):
            if _severity != highest_severity:
                continue
            symbol = str(position["symbol"]).upper().replace("/", "-")
            exit_seed = f"{symbol}|{position['inventory_origin']}|{reason}|{int(now // 60)}"
            exit_id = "v5-exit-" + hashlib.sha256(
                exit_seed.encode("utf-8")
            ).hexdigest()[:20]
            try:
                plan = await self.planner.build_sell_plan(
                    exit_id, position, reason, "MANAGED",
                    external=position["inventory_origin"] == "EXTERNAL_INVENTORY"
                )
            except Exception as exc:
                blocked.append({"symbol": symbol, "reason": reason,
                                "error_type": type(exc).__name__,
                                "error": str(exc)[:240]})
                continue
            self.last_scan["last_exit"] = {
                "observed_at": now, "status": "INTENT_READY",
                "symbol": symbol, "reason": reason,
            }
            self._journal({"observed_at": now, "event": "EXIT_DECISION",
                           **self.last_scan["last_exit"]})
            return Intent(plan.client_order_id, symbol, "SELL", copy.deepcopy(plan.body), {
                "decision_at": now,
                "decision_mid": prices.get(symbol),
                "source": "V5_DEGRADED_EXIT_BRIDGE",
                "inventory_origin": position["inventory_origin"],
                "reason": reason,
                "quantity": float(plan.quantity),
                "trigger_bid": float(plan.trigger_bid),
            })
        self.last_scan["last_exit"] = {
            "observed_at": now, "status": "BLOCKED_URGENT_EXIT",
            "severity": highest_severity, "blocked": blocked,
        }
        self._journal({"observed_at": now, "event": "EXIT_DECISION",
                       **self.last_scan["last_exit"]})
        return None

    @staticmethod
    def _momentum_negative(momentum: dict) -> bool:
        if not isinstance(momentum, dict):
            return False
        m1 = float(momentum.get("m1", 0) or 0)
        s20 = float(momentum.get("s20", 0) or 0)
        accel = float(momentum.get("accel_5_vs_15", 0) or 0)
        return bool(m1 <= -0.12 or (s20 <= -0.08 and m1 <= 0)
                    or (m1 <= 0 and accel <= -0.10))

    @staticmethod
    def _best_price(book: Any, side: str, *, highest: bool) -> float | None:
        if not isinstance(book, dict):
            return None
        values = []
        for row in book.get(side) or []:
            raw = row.get("price") if isinstance(row, dict) else (
                row[0] if isinstance(row, (list, tuple)) and row else None
            )
            try:
                price = float(raw)
            except (TypeError, ValueError):
                continue
            if price > 0:
                values.append(price)
        return (max(values) if highest else min(values)) if values else None

    async def scan(self, owned: set[str] | None = None) -> list[tuple[Any, Any]]:
        raw = await self.client.tickers(self.priority.DISCOVERY)
        rows = _rows(raw)
        now = float(self.clock())
        prices: dict[str, float] = {}
        for row in rows:
            quote = self.quote_from_ticker(row)
            if quote is not None:
                prices[quote.symbol] = quote.mid
        momentum = self.tape.observe(prices, now)
        for metrics in momentum.values():
            metrics["observed_at"] = now
        self._persist_tape(now)
        context_spans = [
            float(metrics.get("context_span_sec", 0) or 0)
            for metrics in momentum.values()
            if isinstance(metrics, dict)
        ]
        context_ready = sum(
            bool(metrics.get("five_minute_context_ready", False))
            for metrics in momentum.values()
            if isinstance(metrics, dict)
        )
        context_with_m5 = sum(
            "m5" in metrics
            for metrics in momentum.values()
            if isinstance(metrics, dict)
        )

        by_symbol: dict[str, tuple[Any, Any]] = {}
        for policy in self.policies:
            ranked = self.rank_candidates(rows, owned or set(), policy, None, momentum)
            for candidate in ranked:
                if str(policy.name).upper() == "IGNITION" and not bool(
                    getattr(candidate, "momentum", {}).get("ignition", False)
                ):
                    continue
                current = by_symbol.get(candidate.symbol)
                if current is None or float(getattr(candidate, "score", 0) or 0) > float(
                    getattr(current[0], "score", 0) or 0
                ):
                    by_symbol[candidate.symbol] = (candidate, policy)
        owned_assets = {self._asset_key(symbol) for symbol in (owned or set())}
        eligible = sorted(
            (item for item in by_symbol.values()
             if self._asset_key(item[0].symbol) not in owned_assets),
            key=lambda item: (
                -float(getattr(item[0], "score", 0) or 0),
                str(item[0].symbol),
            ),
        )
        merged, selection = self._allocate_validation_slots(eligible)
        if self.health_store is not None and hasattr(self.health_store,'observe_execution_markouts'):
            self.health_store.observe_execution_markouts(prices,now)
        self.last_scan = {
            "observed_at": now,
            "ticker_rows": len(rows),
            "priced_symbols": len(prices),
            "strategy_eligible": len(eligible),
            "validation_limit": self.validation_limit,
            "selection_policy": (
                "5_COMPOSITE_1_RAW_MOVER_1_FRESH_EXPLORATION_PLUS_RANKED_BACKFILL"
                if self.validation_limit > 7
                else "5_COMPOSITE_1_RAW_MOVER_1_FRESH_EXPLORATION"
            ),
            "market_context": {
                "history_source": "REST_TICKERS_EXISTING_FETCH",
                "symbols_recorded": len(momentum),
                "symbols_span_ge_240": context_ready,
                "symbols_with_m5": context_with_m5,
                "max_context_span_sec": max(context_spans, default=0.0),
            },
            "selected": selection,
            "top": [self._candidate_view(item, "RANKED") for item in eligible[:12]],
        }
        return merged

    @staticmethod
    def _asset_key(symbol: str) -> str:
        normalized = str(symbol or "").upper().replace("/", "-")
        parts = normalized.rsplit("-", 1)
        if len(parts) == 2 and parts[1] in {"USD", "EUR"}:
            return parts[0]
        return normalized

    @staticmethod
    def _candidate_view(item: tuple[Any, Any], slot: str) -> dict[str, Any]:
        candidate, policy = item
        momentum = dict(getattr(candidate, "momentum", {}) or {})
        quote = getattr(candidate, "quote", None)
        return {
            "symbol": str(candidate.symbol),
            "asset": CanonicalSpeculativeActionSource._asset_key(candidate.symbol),
            "lane": str(policy.name).upper(),
            "slot": slot,
            "score": float(getattr(candidate, "score", 0) or 0),
            "change_24h_pct": float(getattr(candidate, "change_24h_pct", 0) or 0),
            "m1": float(momentum.get("m1", 0) or 0),
            "m5": float(momentum.get("m5", 0) or 0),
            "m5_available": "m5" in momentum,
            "m15_available": "m15" in momentum,
            "accel_5_vs_15": float(momentum.get("accel_5_vs_15", 0) or 0),
            "context_observations": int(momentum.get("context_observations", 0) or 0),
            "context_span_sec": float(momentum.get("context_span_sec", 0) or 0),
            "bid": (
                float(getattr(quote, "bid", 0) or 0)
                if quote is not None and getattr(quote, "bid", None) is not None
                else None
            ),
            "ask": (
                float(getattr(quote, "ask", 0) or 0)
                if quote is not None and getattr(quote, "ask", None) is not None
                else None
            ),
            "spread_pct": (
                float(getattr(quote, "spread_pct", 0) or 0)
                if quote is not None and getattr(quote, "spread_pct", None) is not None
                else None
            ),
            "five_minute_context_ready": bool(
                momentum.get("five_minute_context_ready", False)
            ),
        }

    def _allocate_validation_slots(
        self, eligible: list[tuple[Any, Any]]
    ) -> tuple[list[tuple[Any, Any]], list[dict[str, Any]]]:
        selected: list[tuple[Any, Any]] = []
        labels: list[str] = []
        assets: set[str] = set()

        def add(item: tuple[Any, Any], label: str) -> bool:
            asset = self._asset_key(item[0].symbol)
            if asset in assets or len(selected) >= self.validation_limit:
                return False
            selected.append(item)
            labels.append(label)
            assets.add(asset)
            return True

        for item in eligible:
            if len(selected) >= min(5, self.validation_limit):
                break
            add(item, "COMPOSITE")

        if len(selected) < self.validation_limit:
            raw_ranked = sorted(
                eligible,
                key=lambda item: (
                    -float(getattr(item[0], "change_24h_pct", 0) or 0),
                    str(item[0].symbol),
                ),
            )
            for item in raw_ranked:
                if add(item, "RAW_MOVER"):
                    break

        if len(selected) < self.validation_limit:
            fresh = [item for item in eligible if float(
                getattr(item[0], "momentum", {}).get("accel_5_vs_15", 0) or 0
            ) > 0]
            fresh_ranked = sorted(
                fresh,
                key=lambda item: (
                    -float(getattr(item[0], "momentum", {}).get("accel_5_vs_15", 0) or 0),
                    -float(getattr(item[0], "momentum", {}).get("m1", 0) or 0),
                    -float(getattr(item[0], "momentum", {}).get("m5", 0) or 0),
                    str(item[0].symbol),
                ),
            )
            for item in fresh_ranked:
                if add(item, "FRESH_ACCELERATION"):
                    break

        if len(selected) < self.validation_limit:
            exploration = sorted(
                eligible,
                key=lambda item: self._deep_validation_times.get(
                    self._asset_key(item[0].symbol), 0.0
                ),
            )
            for item in exploration:
                if add(item, "EXPLORATION_ROTATION"):
                    break

        # Duplicate or absent specialty slots fall through to the next best
        # eligible composite candidate without increasing the validation cap.
        for item in eligible:
            if len(selected) >= self.validation_limit:
                break
            add(item, "COMPOSITE_FALLTHROUGH")
        return selected, [
            self._candidate_view(item, label)
            for item, label in zip(selected, labels)
        ]

    def _journal(self, snapshot: dict[str, Any]) -> None:
        if self.health_store is not None and hasattr(
            self.health_store, "append_decision_snapshot"
        ):
            self.health_store.append_decision_snapshot(snapshot)

    def _persist_tape(self, now: float) -> None:
        if (
            self.health_store is not None
            and hasattr(self.health_store, "record_market_tape")
            and hasattr(self.tape, "snapshot")
            and now - self._last_tape_persisted_at >= 60.0
        ):
            self.health_store.record_market_tape(self.tape.snapshot())
            self._last_tape_persisted_at = now

    async def next_entry(self, context: dict) -> Intent | None:
        self.last_scan = {}
        if context.get("runtime_mode") != "NORMAL" or not context.get("entry_enabled"):
            return None
        mode = context.get("operating_mode")
        if mode not in {"DAY", "NIGHT"} or not context.get("risk_truth_complete"):
            self.last_scan = {"admission": "BLOCKED", "reason": "risk_truth_unavailable"}
            self._journal({**self.last_scan, 'event':'ENTRY_ADMISSION', 'observed_at':float(self.clock())})
            return None
        if context.get("session_loss_usd") is None or context.get("exposure_usd") is None:
            self.last_scan = {"admission": "BLOCKED", "reason": "risk_truth_unavailable"}
            self._journal({**self.last_scan, 'event':'ENTRY_ADMISSION', 'observed_at':float(self.clock())})
            return None
        if not self.risk_policy.can_open(
            mode,
            int(context.get("open_positions", 0)),
            float(context["exposure_usd"]),
            float(context["session_loss_usd"]),
        ):
            self.last_scan = {"admission": "BLOCKED", "reason": "mode_limit"}
            self._journal({**self.last_scan, 'event':'ENTRY_ADMISSION', 'observed_at':float(self.clock())})
            return None
        # Exclude held and pending assets from new BUYs.
        owned = set(context.get("managed_symbols", context.get("owned_symbols", [])))
        owned.update(str(symbol).upper().replace("/", "-")
                     for symbol in context.get("pending_intent_symbols", []) or [])
        candidates = await self.scan(owned)
        slot_by_symbol = {
            str(row.get("symbol", "")).upper(): str(row.get("slot", ""))
            for row in self.last_scan.get("selected", [])
            if isinstance(row, dict)
        }
        rejections: list[dict[str, str]] = []
        alternatives = []
        refresh_args = {}
        for candidate, policy in candidates[:self.validation_limit]:
            lane = str(policy.name).upper()
            slot = slot_by_symbol.get(str(candidate.symbol).upper(), "")
            # A headline mover can rank inside the five composite slots.  Do
            # not let that accidentally fall back to STANDARD; promote any
            # selected >=15% 24h mover (or the dedicated raw slot) to the
            # bounded MOVER rescue lane.  IGNITION keeps its stronger lane.
            change_24h = float(getattr(candidate, "change_24h_pct", 0) or 0)
            if lane != "IGNITION" and (slot == "RAW_MOVER" or change_24h >= 15.0):
                lane = "MOVER"
            elif slot == "FRESH_ACCELERATION":
                lane = "SPECULATIVE"
            momentum = dict(getattr(candidate, "momentum", {}) or {})
            momentum["v5_short_trend_policy"] = True
            asset = self._asset_key(candidate.symbol)
            self._deep_validation_times[asset] = float(self.clock())
            signal_seed = f"{candidate.symbol}|{lane}|{int(self.clock() // 60)}"
            signal_id = "v5-" + hashlib.sha256(signal_seed.encode("utf-8")).hexdigest()[:20]
            try:
                risk_fraction = 25 if lane == "IGNITION" else 100
                plan = await self.planner.build_buy_plan(
                    signal_id, candidate.symbol, lane, risk_fraction, momentum
                )
                rules = await self.planner.pair_rules(candidate.symbol)
                remaining = Decimal(str(self.risk_policy.exposure_usd)) - Decimal(str(context["exposure_usd"]))
                sizing = None
                if self.order_cap_usd is None:
                    quantity, sizing = size_buy(plan, rules, remaining, self.planner.config)
                    body = copy.deepcopy(plan.body)
                    body["order_configuration"]["limit"]["base_size"] = _text(quantity)
                    notional = quantity * Decimal(str(plan.limit_price))
                else:
                    body, quantity, notional = self._cap_buy(plan, rules, remaining)
                if not self.risk_policy.allows(mode, int(context.get("open_positions", 0)),
                                               float(context["exposure_usd"]), float(notional),
                                               float(context["session_loss_usd"])):
                    raise ValueError("calculated BUY exceeds portfolio authority")
            except Exception as exc:
                rejections.append({"symbol": candidate.symbol, "lane": lane,
                                   "type": type(exc).__name__,
                                   "reason": str(exc)[:240]})
                continue
            metadata = {
                "decision_at": float(self.last_scan.get('observed_at',self.clock())),
                "decision_mid": getattr(getattr(candidate,'quote',None),'mid',None),
                "sizing": sizing,
                "source": "CANONICAL_V358_HYBRID",
                "lane": lane,
                "operating_mode": mode,
                "session_key": context.get("session_key"),
                "signal_id": signal_id,
                "quantity": float(quantity),
                "notional_usd": float(notional),
                "entry": float(plan.limit_price),
                "stop": float(plan.stop),
                "target": float(plan.target),
                "risk_pct": float(plan.risk_pct),
                "structural_rr": float(plan.structural_rr),
                "quality": float(plan.quality),
                "spread_pct": float(plan.spread_pct),
                "estimated_slippage_pct": float(plan.estimated_slippage_pct),
                "coverage_pct": float(plan.coverage_pct),
            }
            self.last_scan["planning_rejections"] = rejections
            if self.allocation_mode and self.order_cap_usd is None:
                alternatives.append(Intent(plan.client_order_id,candidate.symbol,'BUY',body,metadata))
                refresh_args[candidate.symbol]=(signal_id,lane,risk_fraction)
                continue
            self.last_scan["entry_decision"] = {
                "status": "INTENT_READY", "symbol": candidate.symbol, "lane": lane
            }
            self._persist_deep_validation_times()
            self._journal({**self.last_scan, "event": "ENTRY_DECISION"})
            return Intent(plan.client_order_id, candidate.symbol, "BUY", body, metadata)
        if alternatives:
            allocations=allocate_targets(alternatives,remaining)
            self.last_scan['allocation_scenarios']=allocations
            self.last_scan['planning_rejections']=rejections
            for chosen in sorted(alternatives,key=lambda item:(-Decimal(allocations[item.symbol]['scenario_score']),item.symbol)):
                if Decimal(allocations[chosen.symbol]['allocation_usd']) <= 0:
                    continue
                try:
                    # Rebuild the chosen plan with newly observed momentum after
                    # comparing alternatives; never relabel an old quote as fresh.
                    raw=await self.client.tickers(self.priority.DISCOVERY)
                    prices={}
                    for row in _rows(raw):
                        quote=self.quote_from_ticker(row)
                        if quote is not None:
                            prices[quote.symbol]=quote.mid
                    observed=float(self.clock())
                    momentum=self.tape.observe(prices,observed).get(chosen.symbol)
                    if momentum is None:
                        raise ValueError('chosen candidate quote unavailable')
                    momentum.update(observed_at=observed,v5_short_trend_policy=True)
                    signal_id,lane,risk_fraction=refresh_args[chosen.symbol]
                    plan=await self.planner.build_buy_plan(signal_id,chosen.symbol,lane,risk_fraction,momentum)
                    rules=await self.planner.pair_rules(chosen.symbol)
                    budget=min(remaining,Decimal(allocations[chosen.symbol]['allocation_usd']))
                    quantity,sizing=size_buy(plan,rules,budget,self.planner.config)
                    notional=quantity*Decimal(str(plan.limit_price))
                    if not self.risk_policy.allows(mode,int(context.get('open_positions',0)),
                                                  float(context['exposure_usd']),float(notional),float(context['session_loss_usd'])):
                        raise ValueError('allocated order exceeds authority')
                    body=copy.deepcopy(plan.body)
                    body['order_configuration']['limit']['base_size']=_text(quantity)
                    metadata={**chosen.metadata,'sizing':sizing,'allocation':allocations[chosen.symbol],
                              'decision_at':observed,'decision_mid':prices[chosen.symbol],
                              'quantity':float(quantity),'notional_usd':float(notional),
                              'entry':float(plan.limit_price),'stop':float(plan.stop),'target':float(plan.target)}
                    metadata.update({name:float(getattr(plan,name)) for name in
                                     ('risk_pct','structural_rr','quality','spread_pct','estimated_slippage_pct','coverage_pct')})
                    self.last_scan['entry_decision']={'status':'INTENT_READY','symbol':chosen.symbol,'lane':lane}
                    self._persist_deep_validation_times()
                    self._journal({**self.last_scan,'event':'ENTRY_DECISION'})
                    return Intent(plan.client_order_id,chosen.symbol,'BUY',body,metadata)
                except Exception as exc:
                    rejections.append({'symbol':chosen.symbol,'type':type(exc).__name__,'reason':str(exc)[:240]})
        self.last_scan["planning_rejections"] = rejections
        self.last_scan["entry_decision"] = {"status": "NO_QUALIFYING_ACTION"}
        self._persist_deep_validation_times()
        self._journal({**self.last_scan, "event": "ENTRY_DECISION"})
        return None

    def _persist_deep_validation_times(self) -> None:
        if self.health_store is not None and hasattr(
            self.health_store, "record_deep_validation_times"
        ):
            self.health_store.record_deep_validation_times(self._deep_validation_times)

    def _cap_buy(self, plan: Any, rules: Any, remaining: Decimal | None = None) -> tuple[dict, Decimal, Decimal]:
        price = Decimal(str(plan.limit_price))
        original = Decimal(str(plan.quantity))
        step = Decimal(str(rules.base_step))
        if price <= 0 or original <= 0 or self.order_cap_usd <= 0:
            raise ValueError("invalid BUY plan")
        cap = self.order_cap_usd if remaining is None else min(self.order_cap_usd, remaining)
        quantity = min(original, _floor(cap / price, step))
        minimum = max(Decimal(str(rules.min_order_size)),
                      Decimal(str(rules.min_order_size_quote)) / price)
        if quantity < minimum:
            raise ValueError("20 USD cap is below venue minimum")
        notional = quantity * price
        if notional > self.order_cap_usd:
            raise ValueError("BUY plan exceeds V5 order cap")
        body = copy.deepcopy(plan.body)
        limit = body.get("order_configuration", {}).get("limit")
        if not isinstance(limit, dict):
            raise ValueError("BUY plan is not a limit order")
        limit["base_size"] = _text(quantity)
        return body, quantity, notional
