"""Minimal Telegram HTTPS transport; injected in tests, no polling or commands."""

from __future__ import annotations

import json
import urllib.parse
import urllib.request


def send_telegram(token: str, chat_id: str, message: str, *, timeout: float = 10.0) -> None:
    if not token or not chat_id or not message:
        raise ValueError("Telegram token, chat_id, and message are required")
    url = "https://api.telegram.org/bot" + token + "/sendMessage"
    body = urllib.parse.urlencode({"chat_id": chat_id, "text": message}).encode()
    request = urllib.request.Request(url, data=body, method="POST",
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if payload.get("ok") is not True:
        raise RuntimeError("Telegram transport rejected message")
