"""Final launch decision gate; it never starts a process or contacts a venue."""

from __future__ import annotations

from typing import Any


class LaunchBlocked(RuntimeError):
    pass


def validate_launch(report: dict[str, Any], *, operator_ack: bool,
                    rollback_ready: bool) -> dict[str, Any]:
    failures = []
    if report.get("status") != "PASS":
        failures.append("preflight_not_pass")
    if report.get("recovery_status") != "PASS":
        failures.append("fresh_recovery_not_pass")
    if report.get("live_contract_status") != "PASS":
        failures.append("live_contract_not_pass")
    if int(report.get("active_orders", 0)) != 0:
        failures.append("active_orders")
    if int(report.get("ambiguous_orders", 0)) != 0:
        failures.append("ambiguous_orders")
    positions = int(report.get("positions_nonzero", 0))
    external_count = int(report.get("external_inventory_count", 0))
    external_reconciled = report.get("external_inventory_reconciled") is True
    if positions and not external_reconciled:
        failures.append("external_inventory_unknown")
    if positions and external_count != positions:
        failures.append("external_inventory_count_mismatch")
    if not operator_ack:
        failures.append("operator_ack_missing")
    if not rollback_ready:
        failures.append("rollback_not_ready")
    if failures:
        raise LaunchBlocked(",".join(failures))
    # Reconciled inventory is a symbol-scoped exclusion, not a global
    # manage-only mode. Discovery remains enabled for unrelated symbols.
    mode = "NORMAL"
    return {"status": "READY_TO_LAUNCH", "runtime_mode": mode,
            "entry_enabled": 1, "process_started": 0,
            "broker_mutated": 0, "failures": []}
