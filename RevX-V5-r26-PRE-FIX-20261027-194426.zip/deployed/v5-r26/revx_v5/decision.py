"""Pure, side-effect-free V5 hybrid decision kernel.

This module deliberately has no broker, Telegram, filesystem, or model access.
It converts reconciled inputs into one deterministic decision and is therefore
safe to test before integrating an execution adapter.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import FrozenSet, Optional

from .policy import RiskPolicy


@dataclass(frozen=True)
class Quote:
    bid: Optional[float]
    ask: Optional[float]
    spread_pct: Optional[float]
    age_s: Optional[float]
    executable: bool
    depth_usd: Optional[float] = None
    volume_usd: Optional[float] = None


@dataclass(frozen=True)
class Candidate:
    symbol: str
    quote: Quote
    episode_age_s: Optional[float]
    geometry_ok: bool
    reversal: bool
    signal_families: FrozenSet[str]
    already_seen: bool = False


@dataclass(frozen=True)
class Position:
    symbol: str
    entry: float
    stop: float
    target: float
    quantity: float
    external: bool = False
    degraded: bool = False
    thesis_decay: bool = False
    failed_breakout: bool = False
    trailing_exit: bool = False
    target_momentum_lost: bool = False
    external_exit_requested: bool = False


@dataclass(frozen=True)
class Decision:
    action: str
    reason: str
    intent_id: str


def _fresh_executable(quote: Quote) -> bool:
    return (
        quote.executable
        and quote.bid is not None
        and quote.ask is not None
        and quote.age_s is not None
        and quote.age_s <= 15.0
        and quote.spread_pct is not None
        and quote.spread_pct <= 0.50
    )


def evaluate_entry(candidate: Candidate, *, mode: str, open_positions: int,
                   max_positions: int, exposure_usd: float,
                   max_exposure_usd: float, order_usd: float,
                   max_order_usd: float) -> Decision:
    """Return BUY or NO_ACTION; discovery never bypasses admission."""
    prefix = f"entry:{candidate.symbol}"
    q = candidate.quote
    if mode not in {"DAY", "NIGHT"}:
        return Decision("NO_ACTION", "mode_invalid", prefix + ":mode")
    if not _fresh_executable(q):
        return Decision("NO_ACTION", "fresh_executable_quote_required", prefix + ":quote")
    if candidate.already_seen:
        return Decision("NO_ACTION", "dedup_or_cooldown", prefix + ":dedup")
    if open_positions >= max_positions or exposure_usd + order_usd > max_exposure_usd:
        return Decision("NO_ACTION", "mode_limit", prefix + ":limits")
    if order_usd <= 0 or order_usd > max_order_usd:
        return Decision("NO_ACTION", "order_cap", prefix + ":sizing")
    if q.volume_usd is None or q.volume_usd < 250_000:
        return Decision("NO_ACTION", "volume_gate", prefix + ":volume")
    if q.depth_usd is None or q.depth_usd < 50:
        return Decision("NO_ACTION", "depth_gate", prefix + ":depth")
    if candidate.episode_age_s is None or not 6 <= candidate.episode_age_s <= 30:
        return Decision("NO_ACTION", "episode_gate", prefix + ":episode")
    if not candidate.geometry_ok or candidate.reversal:
        return Decision("NO_ACTION", "geometry_or_reversal_gate", prefix + ":geometry")
    required = {"price_momentum", "flow_liquidity", "context_regime"}
    families = candidate.signal_families & required
    if len(families) < 2 or not (families & {"price_momentum", "flow_liquidity"}):
        return Decision("NO_ACTION", "two_independent_signal_families_required", prefix + ":quorum")
    return Decision("BUY", "economic_admission_pass", prefix + ":buy")


def evaluate_entry_with_policy(candidate: Candidate, *, mode: str,
                               open_positions: int, exposure_usd: float,
                               session_loss_usd: float,
                               order_usd: float | None = None,
                               policy: RiskPolicy | None = None) -> Decision:
    """Admission wrapper that binds the executable Day/Night policy."""
    active = policy or RiskPolicy()
    if not active.can_open(mode, open_positions, exposure_usd, session_loss_usd):
        return Decision("NO_ACTION", "mode_limit", f"entry:{candidate.symbol}:limits")
    if order_usd is None:
        return Decision("NO_ACTION", "calculated_size_required", f"entry:{candidate.symbol}:sizing")
    if not active.allows(mode, open_positions, exposure_usd,
                         order_usd, session_loss_usd):
        return Decision("NO_ACTION", "mode_limit", f"entry:{candidate.symbol}:limits")
    return evaluate_entry(candidate, mode=mode, open_positions=open_positions,
                          max_positions=active.max_positions(mode),
                          exposure_usd=exposure_usd,
                          max_exposure_usd=active.exposure_usd,
                          order_usd=order_usd,
                          max_order_usd=active.order_usd if active.order_usd is not None else active.exposure_usd)


def evaluate_exit(position: Position, quote: Quote, *, reconciled: bool,
                  ambiguous_order: bool, extension_valid: bool = True) -> Decision:
    """Return one deduplicated exit decision in the approved precedence order."""
    prefix = f"exit:{position.symbol}"
    if not reconciled or ambiguous_order:
        return Decision("UNKNOWN", "reconciliation_or_ambiguity_gate", prefix + ":gate")
    if quote.bid is not None and quote.bid <= position.stop:
        return Decision("SELL", "hard_stop", prefix + ":hard_stop")
    if position.degraded:
        if _fresh_executable(quote):
            return Decision("SELL", "degraded_position_executable_truth", prefix + ":degraded")
        return Decision("DEGRADED", "await_executable_truth", prefix + ":degraded")
    if position.failed_breakout:
        return Decision("SELL", "failed_breakout_or_early_failure", prefix + ":fast_failure")
    if position.thesis_decay:
        return Decision("SELL", "thesis_decay", prefix + ":thesis")
    if position.trailing_exit or position.target_momentum_lost:
        return Decision("SELL", "trailing_or_target_momentum_loss", prefix + ":trail")
    if position.external and position.external_exit_requested:
        return Decision("SELL", "scoped_external_inventory_exit", prefix + ":external")
    if quote.bid is not None and quote.bid >= position.target and not extension_valid:
        return Decision("SELL", "target_reached_extension_invalid", prefix + ":target")
    return Decision("HOLD", "continuation_valid", prefix + ":hold")
