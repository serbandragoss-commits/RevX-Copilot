"""Restart recovery decisions; no automatic retry of ambiguous actions."""

from __future__ import annotations

from typing import Any


def _rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        for key in ("data", "items", "orders", "results"):
            if isinstance(value.get(key), list):
                return [row for row in value[key] if isinstance(row, dict)]
    return []


async def resolve_intent(client: Any, intent_id: str, venue_order_id: str | None = None,
                        lane: Any = None) -> dict:
    # A submitted intent already has the venue's authoritative identifier.
    # Resolve it first; list endpoints may omit a freshly submitted order or
    # normalize its client id differently.  A direct lookup is read-only and
    # never implies a retry or a mutation.
    if venue_order_id and hasattr(client, "order"):
        try:
            direct = await client.order(venue_order_id, lane)
            rows = _rows(direct)
            order = rows[0] if rows else (direct if isinstance(direct, dict) else {})
            observed_id = str(order.get("id") or order.get("venue_order_id") or "")
            if observed_id == str(venue_order_id):
                return {"status": "CONFIRMED", "order": order,
                        "resolution": "VENUE_ORDER_ID"}
        except Exception:
            # Fall back to the existing list-based lookup.  If both paths
            # cannot prove truth, recovery remains fail-closed.
            pass
    active = _rows(await client.active_orders(None, lane))
    historical = _rows(await client.historical_orders(None, 24, lane))
    matches = [row for row in active + historical
               if str(row.get("client_order_id", "")) == intent_id]
    if len(matches) > 1:
        return {"status": "AMBIGUOUS", "matches": matches}
    if matches:
        return {"status": "CONFIRMED", "order": matches[0],
                "resolution": "CLIENT_ORDER_ID"}
    return {"status": "UNCONFIRMED", "matches": []}
