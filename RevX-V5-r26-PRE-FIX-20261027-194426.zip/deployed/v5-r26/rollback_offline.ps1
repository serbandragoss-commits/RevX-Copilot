[CmdletBinding(SupportsShouldProcess, ConfirmImpact='High')]
param(
    [Parameter(Mandatory=$true)][string]$BackupRoot,
    [Parameter(Mandatory=$true)][string]$TargetRoot,
    [switch]$OfflineOnly
)
$ErrorActionPreference = 'Stop'
if (-not $OfflineOnly) { throw 'Refusing rollback without -OfflineOnly.' }

$source = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$workspace = [IO.Path]::GetFullPath((Join-Path $source '..\..'))
$target = [IO.Path]::GetFullPath($TargetRoot).TrimEnd('\')
$allowedTarget = [IO.Path]::GetFullPath(
    (Join-Path $workspace 'deployed\v5-r25')
).TrimEnd('\')
if (-not [string]::Equals($target, $allowedTarget, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing target outside exact r25 deployment path: $target"
}

$backup = [IO.Path]::GetFullPath($BackupRoot).TrimEnd('\')
$allowedBackupPrefix = [IO.Path]::GetFullPath(
    (Join-Path $workspace 'rollback')
).TrimEnd('\') + '\'
if (-not $backup.StartsWith($allowedBackupPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing backup outside rollback root: $backup"
}
$receiptPath = Join-Path $backup 'INSTALL_RECEIPT.json'
if (-not (Test-Path -LiteralPath $receiptPath -PathType Leaf)) {
    throw 'Bound install receipt is missing.'
}
$receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
if ($receipt.schema -ne 'revx-v5-r25-install-receipt-v1' -or
    -not [string]::Equals([string]$receipt.target, $target, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Rollback receipt does not match target.'
}
$savedManifest = Join-Path $backup 'SOURCE_MANIFEST.json'
if (-not (Test-Path -LiteralPath $savedManifest -PathType Leaf) -or
    (Get-FileHash -LiteralPath $savedManifest -Algorithm SHA256).Hash -ne
        [string]$receipt.source_manifest_sha256) {
    throw 'Rollback receipt manifest binding failed.'
}

if (-not $PSCmdlet.ShouldProcess($target, 'Remove exact RevX V5 r25 deployment')) {
    return
}
if (Test-Path -LiteralPath $target) {
    Remove-Item -LiteralPath $target -Recurse -Force
}
if ([bool]$receipt.target_preexisted) {
    New-Item -ItemType Directory -Force -Path $target | Out-Null
}
Write-Output "OFFLINE_ROLLBACK_PASS target=$target receipt=$receiptPath"
