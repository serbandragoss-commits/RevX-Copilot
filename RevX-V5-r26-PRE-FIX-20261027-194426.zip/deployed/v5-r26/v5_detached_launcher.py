"""Manually authorized detached V5 host. No retry, rearm, or automatic restart."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from revx_v5.authority_config import disarm
from revx_v5.process_lease import ProcessLease
from v5_operator_session import write_json


def detached_process(command, stdout, stderr):
    options = dict(stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                   close_fds=True)
    if os.name == 'nt':
        options['creationflags'] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        options['start_new_session'] = True
    return subprocess.Popen(command, **options)


def startup_result(output, state_root, permit_id):
    """Accept a healthy first cycle only from this launch's consumed permit."""
    receipt = Path(output) / 'launch.json'
    final = Path(output) / 'FINAL.json'
    if final.exists():
        return json.loads(final.read_text(encoding='utf-8'))
    if not receipt.exists():
        return None
    launch = json.loads(receipt.read_text(encoding='utf-8'))
    if launch.get('status') != 'CHILD_STARTED':
        return launch
    consumed = Path(state_root) / ('consumed-' + permit_id + '.json')
    health_path = Path(state_root) / 'runtime-health-v5.json'
    if not consumed.exists() or not health_path.exists():
        return None
    owner = json.loads(consumed.read_text(encoding='utf-8'))
    health = json.loads(health_path.read_text(encoding='utf-8'))
    if (owner.get('pid') != launch.get('runtime_pid')
            or health.get('last_cycle_at',0) < launch['started_at'] or health.get('cycles',0) < 1):
        return None
    if health.get('status') in {'HEALTHY_SILENCE','ACTION_SUBMITTED'}:
        return {**launch, 'status':'RUNNING', 'health_status':health['status'], 'cycles':health['cycles']}
    return {**launch, 'status':'STARTUP_NOT_HEALTHY', 'health_status':health.get('status'),
            'reason':health.get('reason'), 'do_not_repeat_launch':True}


def supervise(command, state_root, output, terminal_path):
    """Own a separate launcher lease; only disarm while holding the runtime lease."""
    state_root, output, terminal_path = map(Path, (state_root, output, terminal_path))
    receipt = output / 'launch.json'
    authority = state_root / 'authority-v5.json'
    runtime_lease = state_root / 'runtime-v5.lock'
    result = {'status': 'FAILED', 'supervisor_pid': os.getpid(), 'restart_attempted': False}
    try:
        with ProcessLease(state_root / 'supervisor-v5.lock'):
            # A stale ON file is cleared only after proof no runtime owns the
            # OS lock. A competing launcher cannot disarm the active owner.
            with ProcessLease(runtime_lease):
                disarm(authority)
            with (output / 'runtime.stdout.log').open('ab', buffering=0) as out, \
                    (output / 'runtime.stderr.log').open('ab', buffering=0) as err:
                child = detached_process(command, out, err)
                started = {**result, 'status': 'CHILD_STARTED', 'runtime_pid': child.pid,
                           'started_at': time.time(), 'logs': str(output)}
                # Once launched, always wait and clean up even if receipt writing
                # fails. Never leave a child unobserved due to telemetry failure.
                try:
                    write_json(receipt, started)
                except OSError as exc:
                    print('RECEIPT_WRITE_FAILED ' + type(exc).__name__, file=sys.stderr, flush=True)
                code = child.wait()
            result.update(runtime_pid=child.pid, exit_code=code,
                          exit_hex=hex(code & 0xffffffff), stopped_at=time.time())
            with ProcessLease(runtime_lease):
                disarm(authority)
                result['authority_off'] = True
            if terminal_path.is_file():
                terminal = json.loads(terminal_path.read_text(encoding='utf-8'))
                result['runtime_terminal_status'] = terminal.get('status')
                result['status'] = 'PASS' if code == 0 and terminal.get('status') == 'PASS' else 'FAIL'
                result['reason'] = 'RUNTIME_TERMINAL_RECORDED'
            else:
                result.update(status='FAIL', reason='RUNTIME_EXITED_WITHOUT_FINAL')
            write_json(output / 'FINAL.json', result)
            return result
    except Exception as exc:
        result.update(error_type=type(exc).__name__, reason=str(exc), stopped_at=time.time())
        write_json(output / 'FINAL.json', result)
        if not receipt.exists():
            write_json(receipt, result)
        return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--binding-sha256', required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--telegram-token', type=Path, required=True)
    parser.add_argument('--operator-confirmed', action='store_true', required=True)
    parser.add_argument('--supervise', action='store_true')
    args = parser.parse_args()
    from revx_v5 import live_gate
    from revx_v5.serialized_session import validate_bundle
    package = args.package.resolve()
    if package.parent != live_gate.STATE_ROOT.resolve():
        raise ValueError('package must be in canonical state root')
    bundle = validate_bundle(package, args.binding_sha256, time.time())
    if (live_gate.STATE_ROOT / ('consumed-' + bundle['permit_id'] + '.json')).exists():
        raise RuntimeError('PERMIT_ALREADY_CONSUMED')
    output = live_gate.STATE_ROOT / ('launch-' + bundle['permit_id'])
    root = Path(__file__).resolve().parent
    if args.supervise:
        command = [sys.executable, '-u', '-B', str(root / 'v5_operator_session.py'),
                   '--package', str(package), '--binding-sha256', args.binding_sha256,
                   '--config', str(args.config.resolve()), '--telegram-token', str(args.telegram_token.resolve()),
                   '--activate', '--reset-manual-stop']
        terminal = live_gate.STATE_ROOT / ('session-' + bundle['permit_id']) / 'FINAL.json'
        result = supervise(command, live_gate.STATE_ROOT, output, terminal)
        # The runtime sends its own FINAL. Alert only when that artifact is absent.
        if result.get('reason') == 'RUNTIME_EXITED_WITHOUT_FINAL':
            try:
                from revx_v5.telegram import TelegramReporter
                from revx_v5.telegram_http import send_telegram
                config = json.loads(args.config.read_text(encoding='utf-8-sig'))
                TelegramReporter(args.telegram_token, str(config.get('telegram_chat_id') or ''),
                    sender=send_telegram).send('RevX V5 — FAIL\nRuntime exited without FINAL.'
                    '\nAuthority OFF; no restart.\nExit: ' + result['exit_hex'])
            except Exception as exc:
                print('ALERT_DELIVERY_FAILED ' + type(exc).__name__, file=sys.stderr, flush=True)
        return 0 if result['status'] == 'PASS' else 2
    output.mkdir(exist_ok=False)
    command = [sys.executable, '-u', '-B', str(Path(__file__).resolve()), *sys.argv[1:], '--supervise']
    with (output / 'supervisor.stdout.log').open('ab', buffering=0) as out, \
            (output / 'supervisor.stderr.log').open('ab', buffering=0) as err:
        process = detached_process(command, out, err)
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        result = startup_result(output, live_gate.STATE_ROOT, bundle['permit_id'])
        if result is not None:
            print(json.dumps(result))
            return 0 if result['status'] == 'RUNNING' else 2
        if process.poll() is not None:
            break
        time.sleep(.1)
    print(json.dumps({'status': 'START_NOT_CONFIRMED', 'supervisor_pid': process.pid,
                      'logs': str(output), 'do_not_repeat_launch': True}))
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
