# RevX Ultimate V5 — r25 Mover Discovery and Fast Confirmed Exit

## Authority and scope

Operator-approved strategy patch for the stopped, flat RevX Ultimate V5 r24
runtime. The public product name remains V5. r24 is preserved unchanged as the
rollback target. No credential, Telegram token, broker state, risk limit, order
size, exposure, session-loss limit, Day/Night position cap, or execution
authority is included or changed by this package.

## Discovery

- one complete ticker batch per discovery scan;
- maximum seven deep validations;
- five global composite leaders;
- one distinct eligible raw 24h mover;
- one distinct positive-acceleration candidate, otherwise oldest eligible
  exploration candidate;
- duplicate slots backfill from the composite ranking;
- underlying deduplication before deep validation;
- existing eligibility, liquidity, spread, structural and anti-chase gates stay
  authoritative;
- EUR aliases may be deduplicated but are not made executable by this patch;
- one bounded 256-record decision journal snapshot per completed discovery
  cycle, with top, slot provenance and planning rejection evidence;
- bounded momentum and exploration state survive restart.

## Exit

- exit evaluation precedes entry evaluation;
- global trigger priority is `STOP_HIT`, `DEGRADED_POSITION`, then
  `CONFIRMED_DOWNTREND`, independent of position list order;
- hard stop triggers on the first confirmed executable cycle;
- degraded/missing ticker requires three consecutive cycles and an executable
  book;
- confirmed downtrend requires two consecutive negative cycles and has no
  profit/loss floor;
- a positive observation resets the negative streak;
- maximum one reconciled action per cycle remains unchanged;
- active/ambiguous order blocking, available-balance truth, full visible bid
  coverage, slippage cap, deterministic identity, marketable-limit SELL and
  no-blind-retry remain unchanged.

## Expected economic trade-off

The approved behavior accepts greater turnover and fee/whipsaw risk in exchange
for faster capital release from weakening positions and wider representation of
raw/fresh movers. It does not promise profit and does not weaken entry quality
or execution-integrity gates.

## Rollback

Operational rollback is the intact `deployed/v5-r24` package plus the exported
pre-r25 Scheduled Task definition. Rollback requires a stopped/flat broker
preflight, restoring the exact r24 task action, starting r24, and verifying one
r24 process, fresh health and reconciled broker truth. The offline rollback
script only restores/removes an offline package target and is not a substitute
for the Scheduled Task pointer rollback.
