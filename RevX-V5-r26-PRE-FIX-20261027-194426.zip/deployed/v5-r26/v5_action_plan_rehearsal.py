"""Build at most one real-data V5 action plan; never submit it."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path


async def run(config_path: Path, source_root: Path) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v5.canonical_action_source import CanonicalSpeculativeActionSource
    from revx_v5.operating_mode import AutoModeClock

    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    started = time.time()
    try:
        source = CanonicalSpeculativeActionSource.from_canonical(
            client, config, order_cap_usd=20.0, validation_limit=7
        )
        window = AutoModeClock().current()
        intent = await source.next_entry({"runtime_mode": "NORMAL",
                                          "entry_enabled": window.entry_open,
                                          "owned_symbols": [],
                                          "operating_mode": window.mode,
                                          "session_key": window.session_key,
                                          "risk_truth_complete": True,
                                          "open_positions": 0,
                                          "exposure_usd": "0",
                                          "session_loss_usd": "0"})
    finally:
        await broker.close()
    result = {
        "schema": "revx-v5-action-plan-rehearsal-v1",
        "status": "ACTION_READY" if intent else "HEALTHY_SILENCE",
        **source.last_scan,
        "action": intent.side if intent else None,
        "symbol": intent.symbol if intent else None,
        "notional_usd": (intent.metadata or {}).get("notional_usd") if intent else None,
        "lane": (intent.metadata or {}).get("lane") if intent else None,
        "planning_rejections": source.last_scan.get("planning_rejections", []),
        "order_cap_usd": 20.0,
        "broker_accessed": 1,
        "live_accessed": 0,
        "order_placement": "OFF",
        "mutation_client_loaded": 0,
        "actions_executed": 0,
        "duration_sec": round(time.time() - started, 6),
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = asyncio.run(run(args.config, args.source_root))
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
