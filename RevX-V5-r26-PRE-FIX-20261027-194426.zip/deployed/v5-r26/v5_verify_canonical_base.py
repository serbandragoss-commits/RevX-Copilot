"""Verify the exact canonical v3.5.8 audit archive and every manifested file."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


ARCHIVE_BYTES = 39_513_479
ARCHIVE_SHA256 = "EC42995020E579DAA6B7DBE4BF0FC6091BCFF62C5A5BC279F2A38C7EE655AD22"
MANIFEST_BYTES = 10_092
MANIFEST_SHA256 = "D0CA9CE3B251689C21953229C2E2090D0030D0C6E223102C5883C3FC9A4E25D6"
MANIFESTED_FILES = 41


def digest_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest().upper()


def digest_file(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest().upper()


def verify(path: Path) -> dict:
    failures: list[str] = []
    if not path.is_file():
        return {"status": "FAIL", "failures": ["archive_missing"]}
    if path.stat().st_size != ARCHIVE_BYTES:
        failures.append("archive_bytes")
    if digest_file(path) != ARCHIVE_SHA256:
        failures.append("archive_sha256")
    with zipfile.ZipFile(path) as archive:
        entries = {item.filename.replace("\\", "/"): item for item in archive.infolist()}
        manifest_bytes = archive.read("audit-manifest.json")
        if len(manifest_bytes) != MANIFEST_BYTES:
            failures.append("manifest_bytes")
        if digest_bytes(manifest_bytes) != MANIFEST_SHA256:
            failures.append("manifest_sha256")
        manifest = json.loads(manifest_bytes.decode("utf-8-sig"))
        files = manifest.get("files", [])
        if len(files) != MANIFESTED_FILES:
            failures.append("manifest_file_count")
        for item in files:
            name = str(item["path"])
            entry = entries.get(name.replace("\\", "/"))
            if entry is None:
                failures.append(f"missing:{name}")
                continue
            payload = archive.read(entry)
            if len(payload) != int(item["bytes"]):
                failures.append(f"bytes:{name}")
            if digest_bytes(payload) != str(item["sha256"]).upper():
                failures.append(f"sha256:{name}")
    return {
        "schema": "revx-v5-canonical-base-verification-v1",
        "status": "PASS" if not failures else "FAIL",
        "archive_bytes": path.stat().st_size,
        "archive_sha256": digest_file(path),
        "manifest_bytes": len(manifest_bytes),
        "manifest_sha256": digest_bytes(manifest_bytes),
        "manifested_files": len(files),
        "file_failures": len([item for item in failures if ":" in item]),
        "failures": failures,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = verify(args.archive)
    if args.report is not None:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n",
                               encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
