"""V5 startup reconciliation, authenticated GET-only and fail-closed."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path


async def run(config_path: Path, source_root: Path) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.external_inventory import classify_external_inventory, fetch_inventory_books
    from revx_v5.reconciliation import parse_balances

    config = json.loads(config_path.read_text(encoding="utf-8"))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    started = time.time()
    try:
        balances = await client.balances(Priority.EXIT_CRITICAL)
        active_orders = await client.active_orders(None, Priority.EXIT_CRITICAL)
        pairs = await client.pair_configurations(Priority.EXIT_CRITICAL)
        balance_rows, balances_valid = parse_balances(balances)
        positions = [row for row in balance_rows
                     if row["currency"] != "USD" and row["total"] > 0]
        books = await fetch_inventory_books(client, positions, pairs, Priority.EXIT_CRITICAL)
    finally:
        await broker.close()

    if isinstance(active_orders, list):
        orders = [x for x in active_orders if isinstance(x, dict)]
    elif isinstance(active_orders, dict):
        orders = [x for x in active_orders.get("data", []) if isinstance(x, dict)]
    else:
        orders = []

    inventory = classify_external_inventory(positions, pairs, books)

    ambiguous = [
        row for row in orders
        if str(row.get("status", "")).upper() in {"UNKNOWN", "PENDING", "PARTIALLY_FILLED"}
        or not str(row.get("id") or row.get("venue_order_id") or "")
    ]
    status = (
        "BLOCKED_BALANCE_SCHEMA" if not balances_valid else
        "BLOCKED_AMBIGUOUS" if ambiguous else
        "BLOCKED_ACTIVE_ORDERS" if orders else
        "BLOCKED_EXTERNAL_INVENTORY" if positions and not inventory["reconciled"] else
        "PASS"
    )
    return {
        "schema": "revx-v5-startup-reconcile-v1",
        "status": status,
        "observed_at": time.time(),
        "duration_sec": round(time.time() - started, 6),
        "authenticated_get": "PASS",
        "positions_nonzero": len(positions),
        "position_currencies": sorted({row["currency"] for row in positions}),
        "external_inventory_count": inventory["count"],
        "external_inventory_reconciled": inventory["reconciled"],
        "external_inventory_unknown": inventory["unknown_currencies"],
        "external_inventory_symbols": sorted(row["symbol"] for row in inventory["records"]),
        "runtime_mode": "NORMAL",
        "entry_enabled": 1,
        "balance_rows": len(balance_rows),
        "balance_schema_valid": balances_valid,
        "active_orders": len(orders),
        "ambiguous_orders": len(ambiguous),
        "order_placement": "OFF",
        "mutation_client_loaded": 0,
        "live_accessed": 0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(asyncio.run(run(args.config, args.source_root)), indent=2, sort_keys=True))


if __name__ == "__main__":
    raise SystemExit(main())
