[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$V6Attestation,
    [string]$Config = 'C:\Users\serba\Documents\RevX\config-v3.live.json',
    [string]$TelegramToken = "$env:LOCALAPPDATA\RevX\V5\telegram-token.dpapi"
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot)
$stateRoot = 'C:\Users\serba\Documents\RevX\state\v5'
$python = (Get-Command python -ErrorAction Stop).Source
$confirmation = Read-Host 'V6 ramane oprit/dezarmat pe durata sesiunii. Confirmi START V5 LIVE (maxim 24h), inclusiv reluarea dupa STOP manual? Scrie DA'
if ($confirmation -cne 'DA') { throw 'Operator start not confirmed; authority unchanged' }
$preparedRaw = & $python (Join-Path $root 'v5_prepare_one_shot.py') --deployment $root --state-root $stateRoot --attestation $V6Attestation --operator-confirmed-counterpart
if ($LASTEXITCODE -ne 0) { throw "V5 one-shot preparation failed with exit code $LASTEXITCODE" }
$prepared = $preparedRaw | ConvertFrom-Json
if (-not $prepared.bundle -or -not $prepared.binding_sha256) { throw 'V5 one-shot preparation returned an incomplete bundle' }
& $python (Join-Path $root 'v5_detached_launcher.py') --package $prepared.bundle --binding-sha256 $prepared.binding_sha256 --config $Config --telegram-token $TelegramToken --operator-confirmed
$launchExit = $LASTEXITCODE
if ($launchExit -eq 0) {
    Write-Output 'V5 separat: preflight si primul ciclu sanatos confirmate. Fereastra se inchide automat. Oprire: Stop-V5-r26.cmd'
}
exit $launchExit
