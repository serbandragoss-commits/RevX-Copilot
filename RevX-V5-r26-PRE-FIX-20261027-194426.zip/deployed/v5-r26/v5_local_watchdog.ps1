[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$HealthPath,
    [Parameter(Mandatory=$true)][string]$StateRoot,
    [int]$IntervalSec = 60,
    [int]$MaxAgeSec = 90,
    [int]$StartupGraceSec = 120,
    [int]$ParentPid = 0
)
$ErrorActionPreference = 'Stop'
$alert = Join-Path ([IO.Path]::GetFullPath($StateRoot)) 'watchdog-alert.json'
$heartbeat = Join-Path ([IO.Path]::GetFullPath($StateRoot)) 'watchdog-heartbeat.json'
$started = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

function Write-AtomicJson([string]$Path, [object]$Value) {
    $dir = Split-Path -Parent $Path
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $tmp = Join-Path $dir ('.' + [IO.Path]::GetFileName($Path) + '.tmp')
    [IO.File]::WriteAllText($tmp, ($Value | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}

while ($true) {
    try {
        if ($ParentPid -gt 0 -and -not (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue)) {
            Write-AtomicJson (Join-Path ([IO.Path]::GetFullPath($StateRoot)) 'watchdog-terminal.json') ([ordered]@{
                schema='revx-v5-local-watchdog-terminal-v1'; status='STOPPED'; reason='parent_exit'; observed_at=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            })
            return
        }
        if (-not (Test-Path -LiteralPath $HealthPath -PathType Leaf)) {
            if (([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $started) -lt $StartupGraceSec) {
                Start-Sleep -Seconds ([Math]::Max(10,$IntervalSec)); continue
            }
            throw 'health_missing'
        }
        $health = Get-Content -LiteralPath $HealthPath -Raw | ConvertFrom-Json
        # Do not evaluate a previous run's terminal snapshot during startup.
        # Wait until the agent has emitted its first cycle after this watchdog
        # was launched, then evaluate the fresh runtime state normally.
        if ([double]$health.last_cycle_at -lt $started) {
            Write-AtomicJson $heartbeat ([ordered]@{
                schema='revx-v5-local-watchdog-heartbeat-v1'; status='STARTING'; observed_at=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); health_age_sec=$null
            })
            Start-Sleep -Seconds ([Math]::Max(1,$IntervalSec)); continue
        }
        $age = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [double]$health.last_cycle_at
        if ($age -gt $MaxAgeSec -and ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $started) -lt $StartupGraceSec) {
            Write-AtomicJson $heartbeat ([ordered]@{
                schema='revx-v5-local-watchdog-heartbeat-v1'; status='STARTING'; observed_at=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); health_age_sec=$age
            })
            Start-Sleep -Seconds ([Math]::Max(1,$IntervalSec)); continue
        }
        $bad = @()
        if ($age -gt $MaxAgeSec) { $bad += 'health_stale' }
        if ([string]$health.runtime_mode -notin @('NORMAL','MANAGE_EXISTING_ONLY')) { $bad += 'runtime_mode' }
        if ([string]$health.status -notin @('HEALTHY_SILENCE','ACTION_SUBMITTED')) { $bad += ('status_' + [string]$health.status) }
        if ([int]$health.consecutive_failures -gt 0) { $bad += 'consecutive_failures' }
        if ([int]$health.ambiguous_orders -gt 0) { $bad += 'ambiguous_orders' }
        if ([string]$health.runtime_mode -notin @('NORMAL','MANAGE_EXISTING_ONLY') -and
            [string]$health.status -ne 'ACTION_SUBMITTED' -and [int]$health.active_orders -gt 0) { $bad += 'active_orders' }
        if ($bad.Count -gt 0) {
            Write-AtomicJson $alert ([ordered]@{
                schema='revx-v5-local-watchdog-alert-v1'; status='ALERT'; observed_at=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); reasons=$bad; health=$health
            })
            return
        }
        Write-AtomicJson $heartbeat ([ordered]@{
            schema='revx-v5-local-watchdog-heartbeat-v1'; status='HEALTHY'; observed_at=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); health_age_sec=$age
        })
        if (Test-Path -LiteralPath $alert) { Remove-Item -LiteralPath $alert -Force }
    } catch {
        Write-AtomicJson $alert ([ordered]@{
            schema='revx-v5-local-watchdog-alert-v1'; status='ALERT'; observed_at=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); reasons=@('watchdog_exception'); error_type=$_.Exception.GetType().Name
        })
        return
    }
    Start-Sleep -Seconds ([Math]::Max(1,$IntervalSec))
}
