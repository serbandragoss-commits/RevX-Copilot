"""Create a V5 one-shot bundle from a current V6 stop/disarm attestation."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path

from revx_v5.serialized_session import MAX_LIVE_DURATION_SECONDS

MAX_ATTESTATION_AGE_SECONDS = 300
MAX_ATTESTATION_VALIDITY_SECONDS = MAX_LIVE_DURATION_SECONDS + 3600

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def parse_time(value: str) -> float:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timezone required")
    return parsed.timestamp()


def prepare(deployment: Path, state_root: Path, attestation_path: Path, now: float | None = None) -> dict:
    now = time.time() if now is None else now
    attestation = json.loads(attestation_path.read_text(encoding="utf-8"))
    observed_at = attestation.get("observed_at_epoch")
    valid_until = attestation.get("valid_until_epoch")
    try:
        observed_at = float(observed_at)
        valid_until = float(valid_until)
    except (TypeError, ValueError):
        raise ValueError("V6_STOPPED_DISARMED attestation timestamps are invalid") from None
    required = (attestation.get("schema") == "revx-v6-stop-attestation-v1"
                and attestation.get("status") == "V6_STOPPED_DISARMED"
                and attestation.get("process_absent") is True
                and attestation.get("autostart_disabled") is True
                and attestation.get("authority_off") is True
                and attestation.get("lease_free") is True)
    if (not required or not math.isfinite(observed_at) or not math.isfinite(valid_until)
            or observed_at > now or now - observed_at > MAX_ATTESTATION_AGE_SECONDS
            or valid_until < now + MAX_LIVE_DURATION_SECONDS
            or valid_until > observed_at + MAX_ATTESTATION_VALIDITY_SECONDS):
        raise ValueError("V6_STOPPED_DISARMED attestation is missing or too short")
    manifest = json.loads((deployment / "RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
    installed: dict[str, str] = {}
    for item in manifest["files"]:
        relative = Path(str(item["path"]))
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("unsafe manifest path")
        target = (deployment / relative).resolve()
        if deployment not in target.parents or not target.is_file() or sha256(target) != item["sha256"]:
            raise ValueError("installed hash drift: " + str(relative))
        installed[str(target)] = item["sha256"]
    permit_id = str(uuid.uuid4())
    deadline = now + MAX_LIVE_DURATION_SECONDS
    stamp = lambda epoch: datetime.fromtimestamp(epoch, UTC).isoformat().replace("+00:00", "Z")
    bundle = state_root / ("v5-r26-one-shot-" + permit_id)
    bundle.mkdir(parents=True, exist_ok=False)
    permit = {"schema":"revx-coo-serialized-live-permit-v1","permit_id":permit_id,"agent":"V5/Dell","authorized_action":"one_live_run","one_time":True,"max_duration_seconds":MAX_LIVE_DURATION_SECONDS,"not_before_utc":stamp(now),"expires_at_utc":stamp(deadline),"strict_sequence":["V5/Dell","V6/iMac"],"constraints":{"existing_strategy_and_limits_only":True,"no_restart_or_extension":True,"telegram_start_final_required":True,"terminal_account_wide_reconciliation_required":True,"v6_permit_before_v5_terminal":False},"counterpart":{"agent":"V6/iMac","required_state":"STOPPED_AND_DISARMED","orders_allowed":False,"post_attempted":False}}
    counterpart = {"permit_id":permit_id,"agent":"V6/iMac","process_absent":True,"launchagent_stopped":True,"alternate_autostarts_disabled":True,"authority_expired":True,"no_v6_permit":True,"hold_until_v5_terminal":True,"observed_at_utc":stamp(observed_at),"valid_until_utc":stamp(valid_until),"source_attestation_sha256":sha256(attestation_path),"source_attestation":str(attestation_path),"source":attestation.get("source","")}
    authority = {"schema":"revx-v5-runtime-authority-v1","execution_enabled":False,"order_placement":"OFF","acknowledgement":""}
    for name, value in (("permit.json", permit), ("counterpart.json", counterpart), ("authority_candidate.json", authority)):
        atomic_json(bundle / name, value)
    binding = {"permit_sha256":sha256(bundle / "permit.json"),"counterpart_sha256":sha256(bundle / "counterpart.json"),"authority_candidate_sha256":sha256(bundle / "authority_candidate.json"),"installed_hashes":installed}
    atomic_json(bundle / "binding.json", binding)
    return {"bundle":str(bundle),"binding_sha256":sha256(bundle / "binding.json"),"deadline_epoch":deadline,"authority":"OFF_UNTIL_ACTIVATE"}


def operator_attestation(state_root: Path) -> Path:
    """Record a fresh declaration only after explicit confirmation at manual start."""
    now = time.time()
    state_root.mkdir(parents=True, exist_ok=True)
    path = state_root / ("operator-counterpart-" + str(uuid.uuid4()) + ".json")
    atomic_json(path, {"schema": "revx-v6-stop-attestation-v1",
        "status": "V6_STOPPED_DISARMED", "process_absent": True,
        "autostart_disabled": True, "authority_off": True, "lease_free": True,
        "observed_at_epoch": now, "valid_until_epoch": now + MAX_ATTESTATION_VALIDITY_SECONDS,
        "source": "operator_confirmation_at_manual_start"})
    return path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--attestation", type=Path, required=True)
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--deployment", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--operator-confirmed-counterpart", action="store_true")
    args = parser.parse_args()
    if args.operator_confirmed_counterpart:
        args.attestation = operator_attestation(args.state_root.resolve())
    print(json.dumps(prepare(args.deployment.resolve(), args.state_root.resolve(), args.attestation.resolve()), sort_keys=True))
