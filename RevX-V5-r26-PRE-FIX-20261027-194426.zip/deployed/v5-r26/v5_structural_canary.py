"""One-shot offline lifecycle canary; no broker, network, Telegram, or LIVE access."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from revx_v5.execution_adapter import Intent
from revx_v5.live_runtime import V5LiveBoundary
from revx_v5.state_store import DurableState


class FakeClient:
    def __init__(self):
        self.submits = 0
        self.holding = False

    async def balances(self, lane=None):
        rows = [{"currency": "USD", "total": "150"}]
        if self.holding:
            rows.append({"currency": "ABC", "total": "1"})
        return rows

    async def active_orders(self, symbol=None, lane=None):
        return []

    async def historical_orders(self, symbol=None, hours=24, lane=None):
        return []

    async def pair_configurations(self, lane=None):
        return {"ABC/USD": {"base": "ABC", "quote": "USD", "status": "active",
                            "base_step": "0.01", "quote_step": "0.001"}}

    async def order_book(self, symbol, limit=50, lane=None):
        return {"bids": [["10.9", "10"]], "asks": [["11", "10"]]}

    async def submit_order(self, body, lane=None):
        self.submits += 1
        self.holding = self.submits == 1
        price = "10" if self.submits == 1 else "11"
        fee = "0.10" if self.submits == 1 else "0.11"
        return {"id": f"offline-{self.submits}", "client_order_id": body["client_order_id"],
                "status": "filled", "quantity": "1", "filled_quantity": "1",
                "leaves_quantity": "0", "average_price": price,
                "fee": fee, "fee_currency": "USD"}


async def run(root: Path) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    store = DurableState(root)
    client = FakeClient()
    boundary = V5LiveBoundary(client, client, state_store=store)
    buy = await boundary.execute_intent(
        Intent("canary-1", "ABC-USD", "BUY", {"client_order_id": "canary-1"},
               {"stop": 9, "target": 12, "lane": "STANDARD",
                "operating_mode": "DAY", "session_key": "offline-canary"})
    )
    sell = await boundary.execute_intent(
        Intent("canary-2", "ABC-USD", "SELL", {"client_order_id": "canary-2"},
               {"reason": "STRUCTURAL_CANARY"})
    )
    reloaded = DurableState(root)
    admission = reloaded.admission_snapshot("DAY", "offline-canary")
    return {"schema": "revx-v5-structural-canary-v1", "status": "PASS",
            "broker_accessed": 0, "live_accessed": 0, "order_placement": "OFF",
            "submits_simulated": client.submits,
            "pending_after_restart": len(reloaded.pending_intents()),
            "positions_after_exit": admission["open_positions"],
            "realized_net_pnl_usd": admission["session_loss_usd"],
            "buy_order_id": buy["id"], "sell_order_id": sell["id"]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    report = asyncio.run(run(Path(args.output)))
    Path(args.output, "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
