# Ultimate V5 design contract

## 1. Decision ownership

There is one decision graph. Discovery may produce candidates, but only the
economic admission gate can authorize a BUY. Every position has one owner,
one exit state machine and one durable action identity.

## 2. Entry precedence

1. Provider truth and freshness.
2. Universe/product eligibility.
3. Symbol deduplication and cooldown.
4. Signal quorum: at least two independent families (price/momentum,
   flow/liquidity, context/regime), including price/momentum or flow/liquidity.
5. V5 deterministic economic admission (spread, volume, depth, episode age,
   geometry, anti-chase and reversal gates).
6. V2/V2.11 and V4 signals become features/challengers, never bypasses.
7. Mode/session limits and sizing ledger.
8. Idempotent order intent and execution reconciliation.

If any higher layer is unknown, the candidate is rejected or deferred.

## 3. Exit precedence

The exit decision evaluates in this order, with execution gates separated from exit reasons:

1. venue/state reconciliation and ambiguous-order gate;
2. hard stop / emergency risk boundary;
3. position-health classification;
4. executable degraded-position bridge;
5. failed breakout / early momentum failure;
6. thesis decay with required confirmations;
7. trailing or target-momentum loss;
8. scoped external-inventory policy exit, only after separate explicit
   financial authorization and an adopted cost/risk basis;
9. hard target as a baseline, with target extension allowed while momentum,
   liquidity and execution geometry remain valid;
10. continuation/hold only while the position remains priced and coherent.

Each position receives one deduplicated exit identity. A later reason may
upgrade severity but may not create a second concurrent SELL.

Ambiguous execution, lot/quantity truth and fee truth are gates on every exit,
not exit reasons. If those gates fail, the action is `UNKNOWN/DEGRADED` and no
blind retry is allowed.

## 4. Degraded-position bridge

- If authenticated venue-native price/order-book data is fresh and executable,
  create an emergency exit intent and route it through the normal SELL truth
  path.
- If only public or last-good data exists, mark `EXIT_DATA_DEGRADED`; do not
  submit an unpriced order.
- External/unmanaged inventory is reconciled and blocks new entry, but is not
  silently adopted or sold. Autonomous `ALL_AVAILABLE` exit requires separate
  explicit financial authorization plus a durable adopted cost/risk basis.
- Once degradation is confirmed, exit is immediate on the first executable
  venue truth; it is never a blind order from an unpriced state.
- Every submit, partial fill, timeout and ambiguous response is reconciled
  before a retry.

## 5. Autonomy boundary

Telegram is reporting/alerting in autonomous mode, not per-trade approval.
Autonomy still requires current mode authorization, kill-switch validity,
limits, venue truth, idempotency and reconciliation. No AI/model output is an
execution authority.

## 6. Operator-approved policy

- target policy: `EXTEND_WHILE_VALID`;
- external inventory: `RECONCILE_AND_BLOCK_ENTRY`; no autonomous sale without
  separate explicit financial authorization;
- degraded position: `INSTANT_EXIT_ON_EXECUTABLE_TRUTH`;
- time expiry: none; degradation is the primary emergency exit trigger;
- BUY quorum: at least two independent signal families.
- target extension terminates on thesis decay, target-momentum loss, degraded
  data, risk boundary or loss of minimum net remaining R/R;
- `ALL_AVAILABLE` means all reconciled quantity in the explicitly identified
  symbol/position scope, never the whole account.

## 7. Candidate validation

The first canary is a one-hour structural smoke test: lifecycle, state
transitions, duplicate protection, stale data, kill switch, restart recovery
and terminal reconciliation. It is not an economic profitability proof.

Before any LIVE activation, the candidate needs explicit financial authority,
a clean authenticated preflight, zero ambiguous positions/orders, frozen
source hashes, rollback and verified post-start health.
