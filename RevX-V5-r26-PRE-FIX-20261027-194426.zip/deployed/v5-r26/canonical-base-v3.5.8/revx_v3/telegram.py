from __future__ import annotations

import asyncio
import json
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from .client import _dpapi_unprotect


class TelegramError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        retry_after: float | None = None,
        transient: bool = False,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.retry_after = retry_after
        self.transient = transient


class TelegramTransport:
    def __init__(
        self,
        token_file: Path,
        chat_id: str,
        timeout_sec: float = 20.0,
        poll_timeout_sec: int = 15,
    ):
        self.chat_id = str(chat_id).strip()
        encrypted = token_file.read_text(encoding="ascii").strip()
        self.token = _dpapi_unprotect(encrypted)
        self.timeout_sec = timeout_sec
        self.poll_timeout_sec = max(1, min(int(poll_timeout_sec), 18))
        if not self.token or not self.chat_id:
            raise TelegramError("Telegram token/chat_id missing")

    def _api(self, method: str, payload: dict[str, Any] | None = None):
        url = f"https://api.telegram.org/bot{self.token}/{method}"
        data = urllib.parse.urlencode(payload or {}).encode("utf-8")
        request = urllib.request.Request(url, data=data, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_sec) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read(1000).decode("utf-8", "replace")
            retry_after = None
            try:
                parsed = json.loads(detail)
                retry_after = float((parsed.get("parameters") or {}).get("retry_after"))
            except (TypeError, ValueError, json.JSONDecodeError):
                pass
            raise TelegramError(
                f"Telegram HTTP {exc.code}: {detail}",
                status_code=int(exc.code),
                retry_after=retry_after,
                transient=int(exc.code) == 429 or int(exc.code) >= 500,
            ) from exc
        except urllib.error.URLError as exc:
            raise TelegramError(
                f"Telegram transport error: {exc.reason}", transient=True
            ) from exc
        if not body.get("ok"):
            raise TelegramError(f"Telegram API error: {body}")
        return body.get("result")

    def send_sync(self, text: str, buttons: list | None = None) -> str:
        payload: dict[str, Any] = {
            "chat_id": self.chat_id,
            "text": text,
            "disable_web_page_preview": "true",
        }
        if buttons:
            payload["reply_markup"] = json.dumps({"inline_keyboard": buttons})
        result = self._api("sendMessage", payload) or {}
        return str(result.get("message_id", ""))

    async def poll(self, offset: int) -> tuple[list[dict], int]:
        result = await asyncio.to_thread(
            self._api,
            "getUpdates",
            {
                "offset": int(offset),
                "timeout": self.poll_timeout_sec,
                "allowed_updates": json.dumps(["callback_query"]),
            },
        )
        callbacks: list[dict] = []
        next_offset = int(offset)
        for update in result or []:
            next_offset = max(next_offset, int(update.get("update_id", 0)) + 1)
            callback = update.get("callback_query")
            if not isinstance(callback, dict):
                continue
            message = callback.get("message") or {}
            chat = message.get("chat") or {}
            if str(chat.get("id", "")) == self.chat_id:
                callback["_update_id"] = int(update.get("update_id", 0))
                callbacks.append(callback)
        return callbacks, next_offset

    async def answer(self, callback_id: str, text: str) -> None:
        try:
            await asyncio.to_thread(
                self._api,
                "answerCallbackQuery",
                {"callback_query_id": callback_id, "text": text[:180]},
            )
        except TelegramError as exc:
            detail = str(exc).lower()
            if not any(marker in detail for marker in (
                "query is too old", "query id is invalid", "response timeout expired"
            )):
                raise
