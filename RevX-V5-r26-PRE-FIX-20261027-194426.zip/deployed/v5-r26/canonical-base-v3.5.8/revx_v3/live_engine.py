from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import secrets
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Awaitable, Callable

from .broker import LaneCoolingDown, RateLimited
from .engine import ShadowEngine
from .execution import (
    BuyPlan,
    DustUntradable,
    ExecutionRefused,
    ExecutionService,
    ExecutionUnknown,
    SellPlan,
    order_id,
    order_status,
)
from .inventory import owned_order_ids, unique_buy_lot_match
from .momentum import MomentumTape
from .models import Priority
from .outbox import DurableOutbox
from .state import StateOwner
from .strategy import quote_from_ticker
from .telegram import TelegramTransport


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _rows(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        return [payload]
    return []


def _ticker_notional(row: dict, quote) -> float:
    """Use the same liquidity floor as ranked discovery for pulse WATCHes."""
    raw = row.get("quote_volume_24h")
    if raw is not None:
        return max(0.0, _f(raw))
    return max(0.0, _f(row.get("volume_24h", row.get("volume", 0.0)))) * quote.mid


def _tape_watch_score(momentum: dict) -> float:
    """Rank stateful fast-watch records without restricting tape coverage."""
    return (
        max(0.0, _f(momentum.get("s20"))) * 20.0
        + max(0.0, _f(momentum.get("m1"))) * 12.0
        + max(0.0, _f(momentum.get("m5"))) * 8.0
        + max(0.0, _f(momentum.get("accel_5_vs_15"))) * 10.0
    )


def _bounded_tape_watches(
    candidates: list[tuple[str, Any, dict]], limit: int, epoch: int
) -> list[tuple[str, Any, dict]]:
    """Bound state writes, rotating equal-momentum symbols each pulse epoch."""
    bounded = max(1, int(limit))
    return sorted(
        candidates,
        key=lambda item: (
            -_tape_watch_score(item[2]),
            hashlib.sha256(f"tape:{epoch}:{item[0]}".encode("utf-8")).hexdigest(),
        ),
    )[:bounded]


PROFIT_RESET_REASONS = {"TARGET_HIT", "TARGET_MOMENTUM_LOSS", "TRAIL_PROFIT"}
ACTIVE_REENTRY_RESET = {"AWAITING_PULLBACK", "AWAITING_RECLAIM"}


def _fast_momentum_state(momentum: dict) -> str:
    """Classify only short-horizon continuation; 1h/6h are deliberately absent."""
    if not isinstance(momentum, dict):
        return "UNKNOWN"
    if bool(momentum.get("ignition", False)):
        return "POSITIVE"
    has_m1 = momentum.get("m1") is not None
    has_m5 = momentum.get("m5") is not None
    has_s20 = momentum.get("s20") is not None
    has_accel = momentum.get("accel_5_vs_15") is not None
    m1 = _f(momentum.get("m1"))
    m5 = _f(momentum.get("m5"))
    s20 = _f(momentum.get("s20"))
    accel = _f(momentum.get("accel_5_vs_15"))
    if (
        has_m1 and has_m5
        and m1 > 0.0 and m5 > 0.0
        and (not has_s20 or s20 >= -0.05)
        and (not has_accel or accel >= -0.10)
    ):
        return "POSITIVE"
    if (
        (has_m1 and m1 <= -0.12)
        or (has_s20 and has_m1 and s20 <= -0.08 and m1 <= 0.0)
        or (has_m1 and has_accel and m1 <= 0.0 and accel <= -0.10)
    ):
        return "NEGATIVE"
    return "NEUTRAL"


def _lease_ignition_signal(
    row: dict, current: dict, config: dict, now: float | None = None
) -> dict:
    """Carry a recent two-pulse validation while current tape stays positive."""
    result = dict(current or {})
    if str(row.get("lane", "")).upper() != "IGNITION":
        return result
    decision = row.get("decision") if isinstance(row.get("decision"), dict) else {}
    validated = decision.get("momentum") if isinstance(decision.get("momentum"), dict) else {}
    if (
        str(decision.get("verdict", "")).upper() != "CANDIDATE"
        or decision.get("blockers")
        or not bool(validated.get("ignition", False))
        or _fast_momentum_state(result) != "POSITIVE"
    ):
        return result
    stamp = time.time() if now is None else float(now)
    origin = _f(row.get("created_at"), _f(decision.get("observed_at")))
    age = stamp - origin
    lease_sec = float(config.get("ignition_signal_lease_sec", 90.0))
    if origin <= 0 or age < -5.0 or age > lease_sec:
        return result
    result.update({
        "ignition_signal_lease": True,
        "ignition_signal_age_sec": age,
        "ignition_signal_entry": _f(decision.get("entry")),
        "ignition_signal_quality": _f(decision.get("quality")),
        "ignition_signal_max_entry_drift_pct": float(
            config.get("ignition_signal_max_entry_drift_pct", 0.75)
        ),
        "ignition_validated_s20": _f(validated.get("s20")),
        "ignition_validated_m1": _f(validated.get("m1")),
        "ignition_validated_m5": _f(validated.get("m5")),
        "ignition_validated_accel": _f(validated.get("accel_5_vs_15")),
    })
    return result


def _buy_refusal_fingerprint(message: str) -> str:
    text = str(message or "").strip()
    if text.startswith("net R/R "):
        return "net_rr"
    marker = "fresh strategy decision is not CANDIDATE: "
    if text.startswith(marker):
        blockers = sorted(
            item.strip() for item in text[len(marker):].split(",") if item.strip()
        )
        return "strategy:" + ",".join(blockers)
    return text


def _reentry_reclaim_positive(momentum: dict, config: dict) -> bool:
    if not isinstance(momentum, dict):
        return False
    return bool(momentum.get("ignition", False)) or (
        momentum.get("m1") is not None
        and momentum.get("m5") is not None
        and _f(momentum.get("m1")) >= float(config.get("post_profit_reentry_min_m1_pct", 0.15))
        and _f(momentum.get("m5")) >= float(config.get("post_profit_reentry_min_m5_pct", 0.35))
        and _f(momentum.get("accel_5_vs_15")) >= float(
            config.get("post_profit_reentry_min_accel_pct", -0.05)
        )
    )


def _advance_reentry_reset(
    reset: dict, executable_price: float, momentum: dict, config: dict, now: float
) -> dict:
    """Advance a persisted post-profit reset without using an arbitrary timer."""
    updated = dict(reset)
    status = str(updated.get("status", ""))
    if status not in ACTIVE_REENTRY_RESET or executable_price <= 0:
        return updated
    peak = max(
        executable_price,
        _f(updated.get("peak_price")),
        _f(updated.get("exit_price")),
    )
    changed = peak != _f(updated.get("peak_price"))
    updated["peak_price"] = peak
    pullback_pct = max(0.01, float(config.get("post_profit_reentry_pullback_pct", 1.50)))
    reclaim_pct = max(0.01, float(config.get("post_profit_reentry_reclaim_pct", 0.50)))
    if status == "AWAITING_PULLBACK":
        pullback_level = peak * (1.0 - pullback_pct / 100.0)
        updated["pullback_level"] = pullback_level
        if executable_price <= pullback_level:
            updated.update(
                status="AWAITING_RECLAIM",
                pullback_low=executable_price,
                pullback_seen_at=now,
                reclaim_level=executable_price * (1.0 + reclaim_pct / 100.0),
            )
            changed = True
    elif status == "AWAITING_RECLAIM":
        previous_low = _f(updated.get("pullback_low"), executable_price)
        low = min(previous_low, executable_price)
        reclaim_level = low * (1.0 + reclaim_pct / 100.0)
        if low != previous_low or reclaim_level != _f(updated.get("reclaim_level")):
            changed = True
        updated["pullback_low"] = low
        updated["reclaim_level"] = reclaim_level
        if executable_price >= reclaim_level and _reentry_reclaim_positive(momentum, config):
            updated.update(
                status="RELEASED",
                released_at=now,
                release_price=executable_price,
                release_momentum=dict(momentum),
            )
            changed = True
    if changed:
        updated["updated_at"] = now
    return updated


class GuardedEngine(ShadowEngine):
    ACTIVE_SIGNAL = {"PENDING", "AWAITING_CONFIRM", "BUY_EXECUTING", "ORDER_SUBMITTED", "BUY_PARTIAL", "EXECUTION_UNKNOWN"}
    ACTIVE_EXIT = {"PENDING", "SELL_EXECUTING", "ORDER_SUBMITTED", "SELL_PARTIAL", "EXECUTION_UNKNOWN"}
    ACTIVE_EXTERNAL_EXIT = {"PENDING", "SELL_EXECUTING", "ORDER_SUBMITTED", "SELL_PARTIAL", "EXECUTION_UNKNOWN"}

    def __init__(
        self,
        config: dict,
        client,
        state: StateOwner,
        logger: logging.Logger,
        telegram: TelegramTransport,
        outbox: DurableOutbox,
        trade_ledger: Path,
    ):
        super().__init__(config, client, state, logger)
        self.label = "LIVE"
        self.telegram = telegram
        self.outbox = outbox
        self.execution = ExecutionService(client, config)
        self.trade_ledger = trade_ledger
        runtime_root = trade_ledger.parent.parent if trade_ledger.parent.name == "logs" else trade_ledger.parent
        self.research_dir = runtime_root / "data"
        self._execution_lock = asyncio.Lock()
        self._transport_state: dict[str, dict[str, float]] = {}
        self._last_outbox_health_log = 0.0
        self._last_evidence_error_log = 0.0
        self._continuation_hits: dict[str, dict[str, float]] = {}
        self._continuation_last_attempt: dict[str, float] = {}
        self._continuation_last_global_attempt = 0.0
        self._latest_momentum: dict[str, dict[str, float | bool]] = {}

    async def run(self, once: bool = False) -> None:
        self.state.load()
        self._momentum_tape = MomentumTape(self.state.state.get("momentum_tape"))
        self._restore_entry_admission(self.state.state.get("entry_admission"))
        saved = self.state.state.get("validation_last_seen", {})
        if isinstance(saved, dict):
            self._validation_last_seen = {
                str(k): float(v) for k, v in saved.items() if isinstance(v, (int, float))
            }
        self._validation_rotation_epoch = max(
            0, int(self.state.state.get("validation_rotation_epoch", 0))
        )
        await self.state.start()

        def boot(state):
            state["mode"] = "LIVE_GUARDED"
            state.setdefault("signals", {})
            state.setdefault("positions", {})
            state.setdefault("exits", {})
            state.setdefault("external_exits", {})
            state.setdefault("inventory_reviews", {})
            state.setdefault("portfolio_inventory", {})
            state.setdefault("watches", {})
            state.setdefault("candidate_outcomes", {})
            state.setdefault("universe_audit", {})
            state.setdefault("metrics", {})
            state.setdefault("reentry_resets", {})
            state.setdefault("entry_admission", self._entry_admission_snapshot())
            state.setdefault("telegram_offset", 0)
            state["runtime"] = {
                "version": "3.5.8",
                "started_at": time.time(),
                "execution_enabled": bool(self.config.get("execution_enabled", False)),
                "two_step_confirmation": True,
            }

        await self.state.apply("LIVE_BOOT", boot)
        await self._startup_gate()
        self.log.info(
            "RevX Agent v3.5.8 LIVE_GUARDED starting | full-universe tape + fair validation rotation + strong IGNITION gate | no auto-order",
            bool(self.config.get("execution_enabled", False)),
        )
        self.log.info(
            "ENTRY POLICY standard quality>=55 risk<=10% rr>=1.85 spread<=0.50% netRR>=2.00 | "
            "ambitious quality>=55 risk<=15% rr>=2.75 spread<=0.70% | "
            "1h+3h positive, 6h..24h regime vote + closed-candle reclaim"
        )
        self.log.info("TELEGRAM longPoll=15s | HTTP 429/5xx retry_after aware | durable outbox health=300s")
        self.log.info(
            "INVENTORY MANAGER fullPortfolio=60s | manual BUY=EXACT_LOT+TELEGRAM_ADOPT | "
            "nonconforming external inventory=SELL_ALL_APPROVAL | no auto-order"
        )
        self.log.info(
            "DISCOVERY COVERAGE full eligible pool=ON validations=%d | surge priority + score-band rotation",
            self._validation_limit(),
        )
        self.log.info(
            "MOMENTUM TAPE 20s/1m/5m/15m/1h | IGNITION LIVE 25%% starter netRR>=1.5 | "
            "1h+3h positive, 6h..24h consensus>=60%%, 1h cap=6%%"
        )
        self.log.info(
            "FAST TICKER PULSE=%ss | pre-target negative momentum uses distinct observations; Telegram SELL remains mandatory",
            float(self.config.get("fast_ticker_interval_sec", 20)),
        )
        self.log.info(
            "POSITION GUARD trailingArm=%.2f%% drawdown=%.2f%% confirmations=%d heartbeat=%ss",
            float(self.config.get("trailing_arm_profit_pct", 5.0)),
            float(self.config.get("trailing_drawdown_pct", 2.5)),
            int(self.config.get("trailing_confirmations", 2)),
            int(self.config.get("position_heartbeat_sec", 300)),
        )
        self._notify(
            "v3.5.8-live-online",
            "RevX v3.5.8 LIVE_GUARDED ONLINE\n"
            "Orders require size selection plus final Telegram confirmation.\n"
            "Manual inventory that fails both entry policies receives a scoped SELL ALL approval.\n"
            "Hard stops remain first priority. Targets with positive continuation become protected milestones.\n"
            "Two fresh negative momentum observations can create an early scoped SELL approval before target.\n"
            "No automatic SELL is submitted.\n"
            "Every size choice also caps cash usage at that percentage.\n"
            "IGNITION is live as a 25% starter at net R/R >=1.5; a recent alert has a short lease only while fresh tape remains strongly confirmed.\n"
            "Post-profit re-entry requires a new pullback plus momentum reclaim.\n"
            "STANDARD requires positive 1h+3h, a 6h..24h regime vote and closed-candle reclaim; every order still needs Telegram confirmation.",
        )
        self._append_evidence({
            "type": "RUNTIME_START",
            "ts": time.time(),
            "version": "3.5.8",
            "pricing": "ASK_ENTRY_BID_EXIT",
            "fee_model": "CONFIG_TAKER_EACH_SIDE",
            "fee_pct_each_side": float(self.config.get("evidence_fee_pct_each_side", self.config.get("taker_fee_pct", 0.09))),
        })
        if once:
            await self._discovery_once()
            await self._deliver_outbox()
            await self.state.close()
            self.outbox.close()
            return

        tasks = [
            asyncio.create_task(self._periodic("DISCOVERY", float(self.config.get("scan_interval_sec", 60)), self._discovery_once, 0), name="v3-discovery"),
            asyncio.create_task(
                self._periodic(
                    "TICKER_PULSE",
                    float(self.config.get("fast_ticker_interval_sec", 20)),
                    self._ticker_pulse_once,
                    5,
                ),
                name="v3-ticker-pulse",
            ),
            asyncio.create_task(self._periodic("TELEGRAM", 2.0, self._telegram_once, 0), name="v3-telegram"),
            asyncio.create_task(self._periodic("OUTBOX", 2.0, self._deliver_outbox, 0), name="v3-outbox"),
            asyncio.create_task(self._periodic("EXIT_WATCH", float(self.config.get("exit_watch_interval_sec", 15)), self._exit_watch_once, 3), name="v3-exit-watch"),
            asyncio.create_task(self._periodic("ORDER_WATCH", float(self.config.get("order_watch_interval_sec", 15)), self._order_watch_once, 8), name="v3-order-watch"),
            asyncio.create_task(self._periodic("INVENTORY", float(self.config.get("inventory_interval_sec", 60)), self._inventory_once, 12), name="v3-inventory"),
        ]
        try:
            await self._stop.wait()
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            await self.state.close()
            self.outbox.close()

    async def _startup_gate(self) -> None:
        active = _rows(await self.client.active_orders(None, Priority.EXIT_CRITICAL))
        if active:
            detail = ", ".join(
                f"{row.get('symbol')}:{row.get('side')}:{order_id(row)}" for row in active[:10]
            )
            raise RuntimeError(
                "LIVE_GUARDED startup refused because venue has active orders. "
                f"Resolve/reconcile them first: {detail}"
            )
        positions = [
            row for row in self.state.view().get("positions", {}).values()
            if row.get("status") == "OPEN"
        ]
        self.log.info("LIVE STARTUP GATE passed activeOrders=0 managedPositions=%d", len(positions))

    async def _periodic(
        self, name: str, interval: float, func: Callable[[], Awaitable[None]], initial_delay: float
    ) -> None:
        if initial_delay:
            await asyncio.sleep(initial_delay)
        deadline = time.monotonic()
        while not self._stop.is_set():
            try:
                await func()
            except asyncio.CancelledError:
                raise
            except LaneCoolingDown as exc:
                self.log.warning("%s DEFERRED lane=%s remaining=%.1fs", name, exc.lane.name, exc.remaining)
            except RateLimited as exc:
                self.log.warning("%s RATE LIMIT retry_after=%s", name, exc.retry_after)
            except Exception as exc:
                if self._is_transport_error(exc):
                    status = self._transport_state.setdefault(name, {"strikes": 0.0, "last_log": 0.0})
                    status["strikes"] += 1
                    now = time.monotonic()
                    reminder = float(self.config.get("transport_error_reminder_sec", 300))
                    if status["strikes"] == 1 or now - status["last_log"] >= reminder:
                        self.log.warning(
                            "%s TRANSPORT DEGRADED strike=%d type=%s detail=%s | scheduled retry only",
                            name,
                            int(status["strikes"]),
                            type(exc).__name__,
                            str(exc).replace("\n", " ")[:240],
                        )
                        status["last_log"] = now
                    if name == "TELEGRAM":
                        exponential = min(30.0, 2.0 ** min(int(status["strikes"]), 5))
                        delay = max(exponential, _f(getattr(exc, "retry_after", None)))
                        deadline = max(deadline, time.monotonic() + delay - interval)
                else:
                    self.log.exception("%s ERROR", name)
            else:
                status = self._transport_state.get(name)
                if status and status.get("strikes", 0) > 0:
                    self.log.info("%s TRANSPORT RECOVERED after=%d", name, int(status["strikes"]))
                    status.update(strikes=0.0, last_log=0.0)
            now = time.monotonic()
            # A normal worker action can legitimately outlast a short cadence:
            # Telegram long-polling waits up to 15 seconds while its scheduler
            # interval is 2 seconds. Only a material runtime stall belongs in
            # the gap journal; ordinary action duration keeps normal cadence.
            grace = max(
                float(self.config.get("scheduler_resync_min_gap_sec", 120.0)),
                interval * 2.0,
            )
            deadline, lag, missed = self._next_periodic_deadline(
                deadline, interval, now, grace
            )
            report_gap = missed and self._should_report_scheduler_gap(
                name,
                lag,
                float(self.config.get("telegram_scheduler_resync_min_gap_sec", 600.0)),
            )
            if report_gap:
                self.log.warning(
                    "%s SCHEDULER RESYNC lag=%.1fs missed~%d | backlog skipped",
                    name,
                    lag,
                    missed,
                )
                self._append_evidence({
                    "type": "RUNTIME_GAP",
                    "ts": time.time(),
                    "worker": name,
                    "lag_sec": round(lag, 3),
                    "missed_intervals_estimate": missed,
                    "outcome_status": "INCOMPLETE",
                })
            await asyncio.sleep(max(0.05, deadline - time.monotonic()))

    @staticmethod
    def _next_periodic_deadline(
        previous_deadline: float,
        interval: float,
        now: float,
        grace: float,
    ) -> tuple[float, float, int]:
        """Return the next deadline without replaying stale periodic work."""
        scheduled = previous_deadline + interval
        lag = now - scheduled
        if lag <= grace:
            return scheduled, 0.0, 0
        missed = max(1, int(lag // interval) + 1)
        return now + interval, lag, missed

    @staticmethod
    def _should_report_scheduler_gap(name: str, lag: float, telegram_min_gap: float) -> bool:
        """Do not classify a normal Telegram long-poll as a machine stall."""
        return name != "TELEGRAM" or lag >= max(telegram_min_gap, 0.0)

    def _record_discovery_evidence(
        self,
        rows: list[dict],
        merged: list,
        selected: list,
        decisions: list[dict],
        live_momentum: dict[str, dict[str, float | bool]],
        requests_this_cycle: int,
    ) -> None:
        observed_at = time.time()
        for symbol, momentum in live_momentum.items():
            latest = dict(momentum or {})
            latest["observed_at"] = _f(
                self._latest_quotes.get(symbol, {}).get("observed_at"), observed_at
            )
            self._latest_momentum[str(symbol).upper()] = latest
        if not bool(self.config.get("evidence_enabled", True)):
            return
        selected_symbols = {str(item.symbol) for item in selected}
        ranked_symbols = {str(item.symbol) for item in merged}
        snapshots = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            quote = quote_from_ticker(row)
            if quote is None:
                continue
            volume = max(0.0, _f(row.get("quote_volume_24h")))
            if volume <= 0:
                volume = max(0.0, _f(row.get("volume_24h", row.get("volume")))) * ((quote.bid + quote.ask) / 2.0)
            snapshots.append({
                "symbol": quote.symbol,
                "bid": quote.bid,
                "ask": quote.ask,
                "mid": quote.mid,
                "spread_pct": quote.spread_pct,
                "change_24h_pct": self._ticker_change_24h_pct(row, quote.bid, quote.ask),
                "quote_volume_24h": volume,
                "api_time": quote.api_time,
                "momentum": dict(live_momentum.get(quote.symbol) or {}),
                "price_source": quote.source,
            })
        control_size = max(1, int(self.config.get("evidence_control_size", 8)))
        control_symbols = {
            row["symbol"]
            for row in sorted(
                (row for row in snapshots if row["symbol"] not in selected_symbols),
                key=lambda value: (value["change_24h_pct"], value["quote_volume_24h"]),
                reverse=True,
            )[:control_size]
        }
        for row in snapshots:
            if row["symbol"] in selected_symbols:
                row["cohort"] = "STRATEGY_SELECTED"
            elif row["symbol"] in control_symbols:
                row["cohort"] = "RAW_TOP_GAINER_CONTROL"
            elif row["symbol"] in ranked_symbols:
                row["cohort"] = "RANKED_NOT_SELECTED"
            else:
                row["cohort"] = "MARKET"
        snapshots = [row for row in snapshots if row["cohort"] != "MARKET"]
        self._append_evidence({
            "type": "MARKET_CYCLE",
            "ts": time.time(),
            "complete": True,
            "pricing": "BID_ASK_OUTCOMES_MID_CONTEXT_ONLY",
            "fee_pct_each_side": float(self.config.get("evidence_fee_pct_each_side", self.config.get("taker_fee_pct", 0.09))),
            "requests_this_cycle": requests_this_cycle,
            "validation_admission": self._entry_admission_snapshot(),
            "strategy_selected_symbols": sorted(selected_symbols),
            "raw_control_symbols": sorted(control_symbols),
            "decisions": decisions,
            "quotes": snapshots,
        })

    @staticmethod
    def _ticker_change_24h_pct(row: dict, bid: float, ask: float) -> float:
        executable_mark = (bid + ask) / 2.0
        if row.get("price_change_24h") is not None and row.get("last_price") is not None:
            last = _f(row.get("last_price"))
            previous = last - _f(row.get("price_change_24h"))
            return (executable_mark / previous - 1.0) * 100.0 if previous > 0 else 0.0
        for name in ("change_24h_pct", "price_change_percentage_24h", "change_24h"):
            if row.get(name) is None:
                continue
            value = _f(row.get(name))
            if abs(value) <= 1.0 and name == "change_24h":
                value *= 100.0
            return value
        return 0.0

    def _append_evidence(self, record: dict) -> None:
        if not bool(self.config.get("evidence_enabled", True)):
            return
        try:
            stamp = _f(record.get("ts"), time.time())
            day = time.strftime("%Y%m%d", time.gmtime(stamp))
            journal = self.research_dir / f"research-v3.live-{day}.jsonl"
            journal.parent.mkdir(parents=True, exist_ok=True)
            with journal.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(json.dumps(record, separators=(",", ":"), ensure_ascii=False) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            if self._last_evidence_error_log:
                self.log.info("RESEARCH JOURNAL RECOVERED path=%s", journal)
                self._last_evidence_error_log = 0.0
        except Exception as exc:
            now = time.monotonic()
            reminder = float(self.config.get("evidence_error_reminder_sec", 300))
            if not self._last_evidence_error_log or now - self._last_evidence_error_log >= reminder:
                self.log.error("RESEARCH JOURNAL DEGRADED type=%s: %s | live agent continues", record.get("type"), exc)
                self._last_evidence_error_log = now

    @staticmethod
    def _is_transport_error(exc: Exception) -> bool:
        current: BaseException | None = exc
        for _ in range(5):
            if current is None:
                break
            if bool(getattr(current, "transient", False)):
                return True
            if isinstance(current, (ConnectionError, TimeoutError)):
                return True
            if isinstance(current, OSError):
                network_codes = {
                    51, 54, 60, 61, 101, 104, 110, 111, 113,
                    10051, 10052, 10053, 10054, 10060, 10061, 11001,
                }
                code = getattr(current, "winerror", None) or getattr(current, "errno", None)
                if code in network_codes:
                    return True
            text = str(current).lower()
            if any(marker in text for marker in (
                "transport error", "connection reset", "connection aborted",
                "timed out", "getaddrinfo failed", "remote host",
            )):
                return True
            current = current.__cause__ or current.__context__
        return False

    async def _discovery_once(self) -> None:
        decisions = await self.discovery_cycle()
        by_symbol: dict[str, dict] = {}
        watch_by_symbol: dict[str, dict] = {}
        for decision in decisions:
            symbol = str(decision.get("symbol"))
            if decision.get("verdict") == "CANDIDATE":
                current = by_symbol.get(symbol)
                if current is None or str(decision.get("lane")) == "STANDARD":
                    by_symbol[symbol] = decision
            elif decision.get("verdict") == "WATCH" and symbol not in by_symbol:
                current = watch_by_symbol.get(symbol)
                if current is None or str(decision.get("lane")) == "STANDARD":
                    watch_by_symbol[symbol] = decision
        for decision in by_symbol.values():
            await self._register_candidate(decision)
        for symbol, decision in watch_by_symbol.items():
            if symbol not in by_symbol:
                await self._register_watch(decision)
        await self._update_candidate_outcomes()
        await self._expire_signals()

    async def _ticker_pulse_once(self) -> None:
        """Fast market observation with bounded continuation promotion.

        The full ticker batch is public and already part of discovery. Sampling
        it at a short cadence gives the momentum tape a chance to see a surge
        before the next discovery cycle. Two consecutive, liquid observations
        may spend one normal deep-validation request set. In v3.5.8 every
        valid USD quote reaches the tape before liquidity/spread admission;
        qualifying continuations can
        create a 25% IGNITION approval lifecycle after the closed-candle trend
        ladder and anti-overextension guard pass.
        """
        rows = await self.client.tickers(Priority.DISCOVERY)
        if isinstance(rows, dict):
            rows = list(rows.values())
        prices: dict[str, float] = {}
        quotes = {}
        ticker_rows = {}
        observed_at = time.time()
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            quote = quote_from_ticker(row)
            if quote is None:
                continue
            prices[quote.symbol] = quote.mid
            quotes[quote.symbol] = quote
            ticker_rows[quote.symbol] = row
            self._latest_quotes[quote.symbol] = {
                "bid": quote.bid,
                "ask": quote.ask,
                "spread_pct": quote.spread_pct,
                "observed_at": observed_at,
            }
        metrics = self._momentum_tape.observe(prices)
        for symbol, momentum in metrics.items():
            latest = dict(momentum)
            latest["observed_at"] = observed_at
            self._latest_momentum[symbol] = latest
        self._latest_mids.update(prices)
        await self._update_reentry_resets(quotes, observed_at)
        view = self.state.view()
        blocked = {
            str(symbol).upper()
            for symbol, position in view.get("positions", {}).items()
            if position.get("status") == "OPEN"
        }
        blocked.update(
            str(row.get("symbol", "")).upper()
            for row in view.get("signals", {}).values()
            if row.get("status") in self.ACTIVE_SIGNAL
        )
        blocked.update(
            str(symbol).upper()
            for symbol, reset in view.get("reentry_resets", {}).items()
            if str(reset.get("status", "")) in ACTIVE_REENTRY_RESET
        )
        for asset, balance in view.get("portfolio_inventory", {}).items():
            if _f(balance) > 0:
                blocked.add(f"{str(asset).upper()}-USD")
        promotion_ready: list[tuple[float, str, Any, dict, float]] = []
        tape_watch_ready: list[tuple[str, Any, dict]] = []
        confirmation_window = float(self.config.get("continuation_confirmation_window_sec", 70.0))
        confirmations = max(2, int(self.config.get("continuation_confirmations", 2)))
        max_pullback_pct = float(self.config.get("continuation_confirmation_max_pullback_pct", 0.50))
        self._continuation_hits = {
            symbol: hit for symbol, hit in self._continuation_hits.items()
            if observed_at - _f(hit.get("ts")) <= confirmation_window * 2.0
        }
        for symbol, metric in metrics.items():
            if symbol in blocked or not bool(metric.get("early_continuation", False)):
                continue
            quote = quotes.get(symbol)
            if quote is not None:
                tape_watch_ready.append((symbol, quote, dict(metric)))
                notional = _ticker_notional(ticker_rows.get(symbol) or {}, quote)
                if self._continuation_promotion_eligible(metric, quote.spread_pct, notional):
                    previous = self._continuation_hits.get(symbol) or {}
                    recent = observed_at - _f(previous.get("ts")) <= confirmation_window
                    held = quote.ask >= _f(previous.get("ask"), quote.ask) * (1.0 - max_pullback_pct / 100.0)
                    count = int(_f(previous.get("count"))) + 1 if recent and held else 1
                    self._continuation_hits[symbol] = {
                        "count": float(count), "ts": observed_at, "ask": quote.ask,
                    }
                    cooldown = float(self.config.get("continuation_promotion_cooldown_sec", 300.0))
                    global_cooldown = float(self.config.get("continuation_global_cooldown_sec", 45.0))
                    if (
                        count >= confirmations
                        and observed_at - self._continuation_last_attempt.get(symbol, 0.0) >= cooldown
                        and observed_at - self._continuation_last_global_attempt >= global_cooldown
                    ):
                        score = (
                            max(0.0, _f(metric.get("s20"))) * 30.0
                            + max(0.0, _f(metric.get("m1"))) * 15.0
                            + max(0.0, _f(metric.get("m5"))) * 8.0
                            + max(0.0, _f(metric.get("accel_5_vs_15"))) * 12.0
                            - quote.spread_pct * 12.0
                        )
                        promotion_ready.append((score, symbol, quote, dict(metric), notional))
                else:
                    self._continuation_hits.pop(symbol, None)
        watch_limit = max(1, int(self.config.get("fast_watch_persist_limit", 6)))
        persisted_watches = _bounded_tape_watches(
            tape_watch_ready, watch_limit, self._validation_rotation_epoch
        )
        for symbol, quote, metric in persisted_watches:
            await self._register_tape_watch(symbol, quote.ask, metric)
        promotion_eligible_count = len(self._continuation_hits)
        self._record_pulse_evidence(ticker_rows, quotes, metrics, {
            "venue_ticker_rows": len(rows or []),
            "valid_usd_quotes": len(quotes),
            "tape_observed": len(metrics),
            "promotion_eligible": promotion_eligible_count,
            "promotion_ready": len(promotion_ready),
            "promotion_deferred": max(0, len(promotion_ready) - 1),
            "early_continuation_total": len(tape_watch_ready),
            "fast_watch_persisted": len(persisted_watches),
            "fast_watch_deferred": max(0, len(tape_watch_ready) - len(persisted_watches)),
        })
        if promotion_ready:
            epoch = self._validation_rotation_epoch
            _, symbol, quote, metric, notional = max(
                promotion_ready,
                key=lambda item: (
                    int(item[0] // max(0.25, float(self.config.get("coverage_score_band_points", 3.0)))),
                    hashlib.sha256(f"pulse:{epoch}:{item[1]}".encode("utf-8")).hexdigest(),
                ),
            )
            await self._promote_continuation(symbol, quote, metric, notional)
        await self._update_candidate_outcomes()
        await self._expire_signals()

    def _continuation_promotion_eligible(
        self, momentum: dict, spread_pct: float, quote_notional_24h: float
    ) -> bool:
        return (
            bool(momentum.get("ignition", False))
            and 0.15 <= _f(momentum.get("m1")) <= float(self.config.get("continuation_max_m1_pct", 3.0))
            and 0.45 <= _f(momentum.get("m5")) <= float(self.config.get("continuation_max_m5_pct", 12.0))
            and _f(momentum.get("accel_5_vs_15")) >= -0.05
            and spread_pct <= float(self.config.get("continuation_max_spread_pct", 0.75))
            and quote_notional_24h >= float(self.config.get("continuation_min_quote_volume_24h", 150_000.0))
        )

    async def _update_reentry_resets(self, quotes: dict, observed_at: float) -> None:
        view = self.state.view()
        resets = view.get("reentry_resets", {})
        updates: dict[str, dict] = {}
        transitions: list[tuple[str, str, str]] = []
        for symbol, reset in resets.items():
            before = str(reset.get("status", ""))
            if before not in ACTIVE_REENTRY_RESET:
                continue
            quote = quotes.get(symbol)
            if quote is None:
                continue
            updated = _advance_reentry_reset(
                reset,
                quote.ask,
                self._latest_momentum.get(symbol, {}),
                self.config,
                observed_at,
            )
            if updated != reset:
                updates[symbol] = updated
                after = str(updated.get("status", ""))
                if after != before:
                    transitions.append((symbol, before, after))
        if not updates:
            return

        def commit(state):
            target = state.setdefault("reentry_resets", {})
            for symbol, updated in updates.items():
                current = target.get(symbol, {})
                if str(current.get("status", "")) in ACTIVE_REENTRY_RESET:
                    target[symbol] = updated

        await self.state.apply("POST_PROFIT_REENTRY_RESET_PROGRESS", commit)
        for symbol, before, after in transitions:
            current = updates[symbol]
            self.log.info(
                "POST-PROFIT REENTRY RESET %s %s -> %s price=%s peak=%s low=%s reclaim=%s",
                symbol,
                before,
                after,
                current.get("release_price", quotes[symbol].ask),
                current.get("peak_price"),
                current.get("pullback_low"),
                current.get("reclaim_level"),
            )
            self._append_evidence({
                "type": "POST_PROFIT_REENTRY_RESET",
                "ts": observed_at,
                "symbol": symbol,
                "from": before,
                "to": after,
                "state": current,
            })

    async def _promote_continuation(self, symbol: str, quote, momentum: dict, notional: float) -> None:
        """Spend at most one deep validation and never submit an order."""
        self._continuation_last_attempt[symbol] = time.time()
        self._continuation_last_global_attempt = time.time()
        try:
            decision = await self.execution.fresh_decision(symbol, "IGNITION", momentum)
        except (LaneCoolingDown, RateLimited) as exc:
            if isinstance(exc, RateLimited):
                self._on_entry_rate_limit()
            self.log.warning("CONTINUATION PROMOTION DEFERRED %s | %s", symbol, exc)
            return
        except Exception as exc:
            self.log.warning("CONTINUATION PROMOTION FAILED %s | %s", symbol, exc)
            return
        payload = asdict(decision)
        payload["momentum"] = dict(momentum)
        payload["promotion_source"] = "TWO_PULSE_CONTINUATION"
        payload["quote_volume_24h"] = notional
        self._append_evidence({
            "type": "CONTINUATION_PROMOTION",
            "ts": time.time(),
            "symbol": symbol,
            "entry_ask": quote.ask,
            "quote_volume_24h": notional,
            "decision": payload,
        })
        if decision.verdict == "CANDIDATE":
            await self._register_candidate(payload)
            if bool(self.config.get("ignition_live_enabled", False)):
                self.log.info("CONTINUATION PROMOTED %s | 25%% starter approval", symbol)
            else:
                self.log.info("CONTINUATION PROMOTED %s | IGNITION config-disabled shadow evidence", symbol)
        else:
            self.log.info(
                "CONTINUATION VALIDATED WAIT %s | %s",
                symbol,
                ",".join(decision.blockers),
            )

    def _record_pulse_evidence(
        self, ticker_rows: dict, quotes: dict, metrics: dict, coverage: dict | None = None
    ) -> None:
        if not bool(self.config.get("evidence_enabled", True)):
            return
        view = self.state.view()
        forced = {
            str(row.get("symbol", ""))
            for row in view.get("signals", {}).values()
            if row.get("status") in self.ACTIVE_SIGNAL
        }
        forced.update(
            str(symbol) for symbol, row in view.get("watches", {}).items()
            if row.get("status") in {"WATCHING", "TAPE_WATCHING"}
        )

        def fresh_score(symbol: str) -> tuple[float, float, str]:
            metric = metrics.get(symbol) or {}
            score = (
                max(0.0, _f(metric.get("s20"))) * 20.0
                + max(0.0, _f(metric.get("m1"))) * 12.0
                + max(0.0, _f(metric.get("m5"))) * 8.0
                + max(0.0, _f(metric.get("accel_5_vs_15"))) * 10.0
            )
            change = self._ticker_change_24h_pct(
                ticker_rows.get(symbol) or {}, quotes[symbol].bid, quotes[symbol].ask
            )
            return score, change, symbol

        top_count = max(1, int(self.config.get("evidence_pulse_top_count", 12)))
        ranked = sorted(quotes, key=fresh_score, reverse=True)
        control = set(ranked[:top_count])
        selected = control | {symbol for symbol in forced if symbol in quotes}
        snapshots = []
        for symbol in sorted(selected):
            quote = quotes[symbol]
            row = ticker_rows.get(symbol) or {}
            snapshots.append({
                "symbol": symbol,
                "bid": quote.bid,
                "ask": quote.ask,
                "mid": quote.mid,
                "spread_pct": quote.spread_pct,
                "change_24h_pct": self._ticker_change_24h_pct(row, quote.bid, quote.ask),
                "quote_volume_24h": _ticker_notional(row, quote),
                "momentum": dict(metrics.get(symbol) or {}),
                "cohort": (
                    "WATCH_OR_CANDIDATE" if symbol in forced
                    else "RAW_FRESH_MOMENTUM_CONTROL"
                ),
                "price_source": quote.source,
            })
        self._append_evidence({
            "type": "PULSE_COHORT",
            "ts": time.time(),
            "complete": True,
            "pricing": "BID_ASK_CONTEXT_MID_ONLY",
            "fee_pct_each_side": float(self.config.get("evidence_fee_pct_each_side", self.config.get("taker_fee_pct", 0.09))),
            "fresh_momentum_symbols": sorted(control),
            "universe_coverage": dict(coverage or {}),
            "observations": snapshots,
        })

    async def _register_tape_watch(self, symbol: str, entry: float, momentum: dict[str, float | bool]) -> None:
        """Record one early-continuation WATCH per cooldown window, silently."""
        now = time.time()
        existing = self.state.view().get("watches", {}).get(symbol, {})
        cooldown = float(self.config.get("watch_alert_cooldown_sec", 900))
        if now - _f(existing.get("notified_at")) < cooldown:
            return
        decision = {
            "symbol": symbol,
            "lane": "TAPE",
            "verdict": "WATCH",
            "entry": round(entry, 12),
            "trend_1h_pct": _f(momentum.get("m60")),
            "trend_6h_pct": 0.0,
            "momentum": dict(momentum),
            "target_basis": "FAST_TICKER_EARLY_CONTINUATION",
        }

        def commit(state):
            state.setdefault("watches", {})[symbol] = {
                "symbol": symbol,
                "status": "TAPE_WATCHING",
                "source": "FAST_TICKER_PULSE",
                "created_at": existing.get("created_at", now),
                "notified_at": now,
                "expires_at": now + float(self.config.get("watch_ttl_sec", 1800)),
                "decision": decision,
            }

        await self.state.apply("FAST_TICKER_WATCH", commit)
        await self._start_candidate_outcome(symbol, decision, "FAST_WATCH")
        self.log.info("FAST WATCH %s | internal only; no order", symbol)

    async def _register_watch(self, decision: dict) -> None:
        """A fresh impulse is observable before it becomes executable geometry."""
        symbol = str(decision["symbol"])
        now = time.time()
        view = self.state.view()
        existing = view.get("watches", {}).get(symbol, {})
        cooldown = float(self.config.get("watch_alert_cooldown_sec", 900))
        if now - _f(existing.get("notified_at")) < cooldown:
            return

        def commit(state):
            state.setdefault("watches", {})[symbol] = {
                "symbol": symbol,
                "status": "WATCHING",
                "created_at": existing.get("created_at", now),
                "notified_at": now,
                "expires_at": now + float(self.config.get("watch_ttl_sec", 1800)),
                "decision": decision,
            }

        await self.state.apply("EARLY_CONTINUATION_WATCH", commit)
        await self._start_candidate_outcome(symbol, decision, "WATCH")
        self._notify(
            f"watch:{symbol}:{int(now // cooldown)}",
            f"REVX WATCH\n{symbol} | early continuation detected\n"
            f"1h {decision['trend_1h_pct']}% | 6h {decision['trend_6h_pct']}%\n"
            "No BUY: waiting for controlled pullback/reclaim and executable structure.",
        )
        self.log.info("EARLY WATCH %s | no order", symbol)

    async def _start_candidate_outcome(self, symbol: str, decision: dict, kind: str) -> None:
        """Record rejected/accepted signal quality independently from fills and P&L."""
        now = time.time()
        key = f"ev-{secrets.token_hex(12)}"
        entry_ask = _f(decision.get("entry"))
        if entry_ask <= 0:
            return
        fee_pct = float(self.config.get("evidence_fee_pct_each_side", self.config.get("taker_fee_pct", 0.09)))

        def commit(state):
            records = state.setdefault("candidate_outcomes", {})
            records[key] = {
                "id": key,
                "symbol": symbol,
                "kind": kind,
                "created_at": now,
                "entry": entry_ask,
                "entry_ask": entry_ask,
                "pricing": "ASK_ENTRY_BID_EXIT",
                "fee_pct_each_side": fee_pct,
                "passive_status": "FILL_UNKNOWN",
                "mfe_pct": 0.0,
                "mae_pct": 0.0,
                "milestones": {},
                "decision": decision,
            }
            if len(records) > 500:
                oldest = sorted(records, key=lambda item: _f(records[item].get("created_at")))[:len(records) - 500]
                for stale in oldest:
                    records.pop(stale, None)

        await self.state.apply("CANDIDATE_OUTCOME_OPEN", commit)
        self._append_evidence({
            "type": "OUTCOME_OPEN",
            "ts": now,
            "id": key,
            "symbol": symbol,
            "kind": kind,
            "entry_ask": entry_ask,
            "fee_pct_each_side": fee_pct,
            "conservative_status": "OPEN",
            "passive_status": "FILL_UNKNOWN",
            "decision": decision,
        })

    async def _update_candidate_outcomes(self) -> None:
        now = time.time()
        records = self.state.view().get("candidate_outcomes", {})
        updates = []
        horizons = (("5m", 300), ("15m", 900), ("1h", 3600), ("4h", 14_400))
        tolerance = float(self.config.get("evidence_horizon_tolerance_sec", 120))
        for key, record in records.items():
            symbol = str(record.get("symbol", ""))
            entry_ask = _f(record.get("entry_ask"), _f(record.get("entry")))
            if entry_ask <= 0:
                continue
            quote = self._latest_quotes.get(symbol) or {}
            exit_bid = _f(quote.get("bid"))
            exit_ask = _f(quote.get("ask"))
            quote_at = _f(quote.get("observed_at"))
            fee_pct = _f(record.get("fee_pct_each_side"), _f(self.config.get("evidence_fee_pct_each_side", self.config.get("taker_fee_pct", 0.09))))
            gross_pnl = (exit_bid / entry_ask - 1.0) * 100.0 if exit_bid > 0 else None
            net_pnl = self._net_executable_return_pct(entry_ask, exit_bid, fee_pct) if exit_bid > 0 else None
            milestones = dict(record.get("milestones") or {})
            milestone_quotes = dict(record.get("milestone_quotes") or {})
            age = now - _f(record.get("created_at"))
            new_milestones = []
            for label, seconds in horizons:
                if age >= seconds and label not in milestones:
                    late = age - seconds > tolerance
                    stale = quote_at <= 0 or now - quote_at > tolerance
                    if late or stale or net_pnl is None:
                        milestones[label] = None
                        milestone_quotes[label] = {
                            "status": "INCOMPLETE_GAP",
                            "observed_at": quote_at or None,
                            "lateness_sec": round(max(0.0, age - seconds), 3),
                        }
                        new_milestones.append((label, "INCOMPLETE_GAP"))
                    else:
                        milestones[label] = round(net_pnl, 6)
                        milestone_quotes[label] = {
                            "status": "COMPLETE",
                            "bid": exit_bid,
                            "ask": exit_ask,
                            "gross_pnl_pct": round(gross_pnl, 6),
                            "net_pnl_pct": round(net_pnl, 6),
                            "fee_pct_each_side": fee_pct,
                        }
                        new_milestones.append((label, "COMPLETE"))
            if net_pnl is not None or new_milestones:
                updates.append({
                    "key": key,
                    "gross_pnl": gross_pnl,
                    "net_pnl": net_pnl,
                    "exit_bid": exit_bid,
                    "exit_ask": exit_ask,
                    "milestones": milestones,
                    "milestone_quotes": milestone_quotes,
                    "new_milestones": new_milestones,
                    "stamp": now,
                })
        if not updates:
            return

        def commit(state):
            records = state.setdefault("candidate_outcomes", {})
            for update in updates:
                record = records.get(update["key"])
                if not record:
                    continue
                if update["net_pnl"] is not None:
                    record["mfe_pct"] = max(_f(record.get("mfe_pct")), update["net_pnl"])
                    record["mae_pct"] = min(_f(record.get("mae_pct")), update["net_pnl"])
                    record["last_pnl_pct"] = round(update["net_pnl"], 6)
                    record["last_gross_pnl_pct"] = round(update["gross_pnl"], 6)
                    record["last_bid"] = update["exit_bid"]
                    record["last_ask"] = update["exit_ask"]
                record["last_seen_at"] = update["stamp"]
                record["milestones"] = update["milestones"]
                record["milestone_quotes"] = update["milestone_quotes"]

        await self.state.apply("CANDIDATE_OUTCOME_MARK", commit)
        for update in updates:
            for label, status in update["new_milestones"]:
                self._append_evidence({
                    "type": "OUTCOME_MILESTONE",
                    "ts": update["stamp"],
                    "id": update["key"],
                    "horizon": label,
                    "status": status,
                    "exit_bid": update["exit_bid"] if status == "COMPLETE" else None,
                    "exit_ask": update["exit_ask"] if status == "COMPLETE" else None,
                    "gross_pnl_pct": round(update["gross_pnl"], 6) if status == "COMPLETE" else None,
                    "net_pnl_pct": round(update["net_pnl"], 6) if status == "COMPLETE" else None,
                    "passive_status": "FILL_UNKNOWN",
                })

    @staticmethod
    def _net_executable_return_pct(entry_ask: float, exit_bid: float, fee_pct_each_side: float) -> float:
        fee = max(0.0, fee_pct_each_side) / 100.0
        if entry_ask <= 0 or exit_bid <= 0:
            return 0.0
        return ((exit_bid * (1.0 - fee)) / (entry_ask * (1.0 + fee)) - 1.0) * 100.0

    def _fresh_entry_momentum(self, symbol: str) -> dict:
        """Return current tape truth for size selection/final POST or refuse."""
        momentum = dict(self._latest_momentum.get(str(symbol).upper(), {}) or {})
        observed_at = _f(momentum.get("observed_at"))
        max_age = float(self.config.get("entry_momentum_max_age_sec", 45.0))
        age = time.time() - observed_at
        if observed_at <= 0 or age < -5.0 or age > max_age:
            raise ExecutionRefused(
                f"fresh entry momentum is stale or unavailable (age={age:.1f}s max={max_age:.1f}s)"
            )
        if _fast_momentum_state(momentum) == "NEGATIVE":
            raise ExecutionRefused("fresh entry momentum is negative")
        return momentum

    def _entry_momentum_for_signal(self, row: dict) -> dict:
        current = self._fresh_entry_momentum(str(row.get("symbol", "")))
        return _lease_ignition_signal(row, current, self.config)

    async def _notify_size_refusal(self, signal_id: str, row: dict, exc: Exception) -> None:
        """Persist every refusal but suppress repeated Telegram copies."""
        now = time.time()
        message = str(exc)
        fingerprint = _buy_refusal_fingerprint(message)
        previous_fingerprint = str(row.get("last_size_refusal_fingerprint", ""))
        previous_at = _f(row.get("last_size_refusal_at"))
        dedupe_sec = float(self.config.get("buy_refusal_dedupe_sec", 30.0))
        duplicate = fingerprint == previous_fingerprint and now - previous_at < dedupe_sec

        def commit(state):
            current = state.get("signals", {}).get(signal_id)
            if current is not None:
                current.update(
                    last_size_refusal_at=now,
                    last_size_refusal=message,
                    last_size_refusal_fingerprint=fingerprint,
                    size_refusal_count=int(_f(current.get("size_refusal_count"))) + 1,
                )

        await self.state.apply("BUY_SIZE_REFUSED", commit)
        if not duplicate:
            self._notify(
                f"size-refused:{signal_id}:{time.time_ns()}",
                f"BUY SIZE REFUSED - NO ORDER\n{row['symbol']} [{signal_id}]\n{message}",
            )
        self.log.warning(
            "BUY SIZE REFUSED%s %s [%s]: %s",
            " (TELEGRAM DEDUPED)" if duplicate else "",
            row["symbol"], signal_id, message,
        )

    async def _register_candidate(self, decision: dict) -> None:
        symbol = str(decision["symbol"])
        view = self.state.view()
        if symbol in view.get("positions", {}) and view["positions"][symbol].get("status") == "OPEN":
            return
        reset = view.get("reentry_resets", {}).get(symbol, {})
        if str(reset.get("status", "")) in ACTIVE_REENTRY_RESET:
            self.log.info(
                "ENTRY BLOCKED %s | post-profit reset=%s peak=%s low=%s reclaim=%s",
                symbol,
                reset.get("status"),
                reset.get("peak_price"),
                reset.get("pullback_low"),
                reset.get("reclaim_level"),
            )
            self._append_evidence({
                "type": "POST_PROFIT_REENTRY_BLOCK",
                "ts": time.time(),
                "symbol": symbol,
                "reset": reset,
                "decision": decision,
            })
            return
        incoming_lane = str(decision.get("lane", "STANDARD")).upper()
        if incoming_lane == "IGNITION" and not bool(
            self.config.get("ignition_live_enabled", False)
        ):
            await self._start_candidate_outcome(symbol, decision, "IGNITION_SHADOW")
            self._append_evidence({
                "type": "IGNITION_SHADOW_CANDIDATE",
                "ts": time.time(),
                "symbol": symbol,
                "decision": decision,
            })
            self.log.info(
                "IGNITION SHADOW %s quality=%s spread=%s trend=%s | config-disabled, no Telegram BUY",
                symbol,
                decision.get("quality"),
                decision.get("spread_pct"),
                decision.get("trend_ladder", {}),
            )
            return
        superseded: list[str] = []
        for existing_id, row in view.get("signals", {}).items():
            if row.get("symbol") != symbol or row.get("status") not in self.ACTIVE_SIGNAL:
                continue
            existing_lane = str(row.get("lane", "STANDARD")).upper()
            # A mature full-policy candidate is an upgrade over an unexecuted
            # 25% starter.  Invalidate the old Telegram token and surface the
            # stronger plan instead of letting the starter block it for 5m.
            if (
                incoming_lane != "IGNITION"
                and existing_lane == "IGNITION"
                and row.get("status") in {"PENDING", "AWAITING_CONFIRM"}
            ):
                superseded.append(existing_id)
                continue
            return
        signal_id = secrets.token_hex(5)
        now = time.time()

        def commit(state):
            for existing_id in superseded:
                existing = state["signals"].get(existing_id)
                if existing and existing.get("status") in {"PENDING", "AWAITING_CONFIRM"}:
                    existing.update(
                        status="SUPERSEDED_BY_MATURE_ENTRY",
                        confirmation_token=None,
                        superseded_at=now,
                        superseded_by=signal_id,
                    )
            state["signals"][signal_id] = {
                "id": signal_id,
                "symbol": symbol,
                "lane": decision["lane"],
                "status": "PENDING",
                "created_at": now,
                "decision": decision,
            }

        await self.state.apply("ENTRY_CANDIDATE", commit)
        if superseded:
            self.log.info(
                "ENTRY UPGRADE %s | starter=%s mature=%s",
                symbol,
                ",".join(superseded),
                signal_id,
            )
        await self._start_candidate_outcome(symbol, decision, "CANDIDATE")
        lane = str(decision.get("lane", "STANDARD")).upper()
        buttons = (
            [[{"text": "STARTER - 25% RISK", "callback_data": f"V3SIZE:{signal_id}:25"}],
             [{"text": "PASS", "callback_data": f"V3PASS:{signal_id}"}]]
            if lane == "IGNITION" else
            [[
                {"text": "25%", "callback_data": f"V3SIZE:{signal_id}:25"},
                {"text": "50%", "callback_data": f"V3SIZE:{signal_id}:50"},
                {"text": "75%", "callback_data": f"V3SIZE:{signal_id}:75"},
                {"text": "100%", "callback_data": f"V3SIZE:{signal_id}:100"},
            ], [{"text": "PASS", "callback_data": f"V3PASS:{signal_id}"}]]
        )
        note = (
            "IGNITION starter: 25% risk budget and <=25% cash; depth is revalidated before each step."
            if lane == "IGNITION" else
            "Choose a risk fraction; cash use cannot exceed the same percentage. No order yet."
        )
        trend_ladder = decision.get("trend_ladder", {})
        trend_line = " | ".join(
            f"{label} {float(value):+.2f}%"
            for label, value in trend_ladder.items()
        ) or (
            f"1h {float(decision.get('trend_1h_pct', 0)):+.2f}% | "
            f"6h {float(decision.get('trend_6h_pct', 0)):+.2f}%"
        )
        rr_label = "Defined R/R" if lane == "IGNITION" else "Structural R/R"
        self._notify(
            f"candidate:{signal_id}",
            f"REVX v3 BUY CANDIDATE [{signal_id}]\n"
            f"{symbol} | {lane} | quality {decision['quality']}\n"
            f"Entry {decision['entry']} | Stop {decision['stop']} | Target {decision['target']}\n"
            f"Risk {decision['risk_pct']}% | {rr_label} {decision['structural_rr']}\n"
            f"Closed trend: {trend_line}\n"
            + note,
            buttons,
        )
        self.log.info("LIVE BUY CANDIDATE %s [%s] lane=%s | approval required", symbol, signal_id, decision["lane"])

    async def _expire_signals(self) -> None:
        now = time.time()
        ttl = float(self.config.get("signal_ttl_sec", 300))
        confirm_ttl = float(self.config.get("confirm_ttl_sec", 120))
        view = self.state.view()
        expired = []
        for sid, row in view.get("signals", {}).items():
            if row.get("status") == "PENDING" and now - _f(row.get("created_at")) > ttl:
                expired.append(sid)
            elif row.get("status") == "AWAITING_CONFIRM" and now - _f(row.get("selected_at")) > confirm_ttl:
                expired.append(sid)
        stale_watches = [
            symbol for symbol, row in self.state.view().get("watches", {}).items()
            if now >= _f(row.get("expires_at"))
        ]
        if not expired and not stale_watches:
            return

        def commit(state):
            for sid in expired:
                if sid in state["signals"]:
                    state["signals"][sid].update(status="EXPIRED")
            for symbol in stale_watches:
                if symbol in state.get("watches", {}):
                    state["watches"][symbol].update(status="EXPIRED", expired_at=now)

        await self.state.apply("ENTRY_APPROVAL_EXPIRED", commit)

    async def _telegram_once(self) -> None:
        offset = int(self.state.view().get("telegram_offset", 0))
        callbacks, next_offset = await self.telegram.poll(offset)
        for callback in callbacks:
            await self._handle_callback(callback)
            handled_offset = int(callback.get("_update_id", -1)) + 1
            if handled_offset > offset:
                offset = handled_offset
                await self.state.apply(
                    "TELEGRAM_OFFSET",
                    lambda state, value=offset: state.update(telegram_offset=value),
                )
        if next_offset > offset:
            await self.state.apply(
                "TELEGRAM_OFFSET",
                lambda state, value=next_offset: state.update(telegram_offset=value),
            )

    async def _handle_callback(self, callback: dict) -> None:
        data = str(callback.get("data", ""))
        callback_id = str(callback.get("id", ""))
        parts = data.split(":")
        if len(parts) < 2:
            await self.telegram.answer(callback_id, "Unknown v3 command")
            return
        action, item_id = parts[0], parts[1]
        if action == "V3SIZE" and len(parts) == 3:
            await self._select_size(callback_id, item_id, int(parts[2]))
        elif action == "V3CONFIRM" and len(parts) == 3:
            await self._confirm_buy(callback_id, item_id, parts[2])
        elif action == "V3PASS":
            await self._terminal_signal(callback_id, item_id, "PASSED", "Passed")
        elif action == "V3CANCEL" and len(parts) == 3:
            await self._cancel_buy(callback_id, item_id, parts[2])
        elif action in {"V3SELL", "V3SELLM"}:
            await self._confirm_sell(callback_id, item_id, "MANAGED")
        elif action == "V3SELLA":
            await self._confirm_sell(callback_id, item_id, "ALL_AVAILABLE")
        elif action == "V3HOLD":
            await self._hold_exit(callback_id, item_id)
        elif action == "V3ADOPT":
            await self._adopt_inventory(callback_id, item_id)
        elif action == "V3OBSERVE":
            await self._observe_inventory(callback_id, item_id)
        elif action == "V3XSELL":
            await self._confirm_external_sell(callback_id, item_id)
        elif action == "V3XHOLD":
            await self._hold_external_exit(callback_id, item_id)
        else:
            await self.telegram.answer(callback_id, "Unknown/old v3 command")

    async def _select_size(self, callback_id: str, signal_id: str, fraction: int) -> None:
        async with self._execution_lock:
            row = self.state.view().get("signals", {}).get(signal_id)
            if not row or row.get("status") not in {"PENDING", "AWAITING_CONFIRM"}:
                await self.telegram.answer(callback_id, "Signal unavailable")
                return
            reset = self.state.view().get("reentry_resets", {}).get(row["symbol"], {})
            if str(reset.get("status", "")) in ACTIVE_REENTRY_RESET:
                await self._terminal_signal(
                    callback_id, signal_id, "REENTRY_RESET_BLOCKED", "Pullback + reclaim not complete"
                )
                self._notify(
                    f"reentry-reset-block:{signal_id}:{time.time_ns()}",
                    f"BUY BLOCKED - NO ORDER\n{row['symbol']} [{signal_id}]\n"
                    f"Post-profit reset is {reset.get('status')}; a new pullback plus momentum reclaim is required.",
                )
                return
            unresolved = self._unresolved_buy_symbols(signal_id)
            if unresolved:
                symbols = ",".join(unresolved)
                await self.telegram.answer(callback_id, "Another BUY is unresolved")
                self._notify(
                    f"buy-size-capital-reserved:{signal_id}:{time.time_ns()}",
                    f"BUY DEFERRED - NO ORDER\n{row['symbol']} [{signal_id}]\n"
                    f"Capital is reserved by unresolved BUY: {symbols}. Retry after venue reconciliation.",
                )
                return
            await self.telegram.answer(callback_id, "Building fresh plan")
            try:
                plan = await self.execution.build_buy_plan(
                    signal_id, row["symbol"], row["lane"], fraction,
                    self._entry_momentum_for_signal(row),
                )
            except Exception as exc:
                await self._notify_size_refusal(signal_id, row, exc)
                return
            token = secrets.token_hex(4)
            await self.state.apply(
                "BUY_SIZE_SELECTED",
                lambda state: state["signals"][signal_id].update(
                    status="AWAITING_CONFIRM",
                    selected_at=time.time(),
                    confirmation_token=token,
                    approved_plan=asdict(plan),
                ),
            )
            execution_line = self._buy_execution_line(plan)
            self._notify(
                f"confirm:{signal_id}:{token}",
                f"REVX v3 FINAL BUY CONFIRMATION [{signal_id}]\n"
                f"{plan.symbol} | {plan.lane} | {fraction}% risk\n"
                f"Limit {plan.limit_price} | Qty {plan.quantity} | Notional ${plan.notional_usd:.2f}\n"
                f"Capital use {plan.capital_usage_pct:.1f}% | Cap ${plan.capital_limit_usd:.2f}\n"
                f"{execution_line}\n"
                f"Actual risk ${plan.actual_risk_usd:.2f} | Stop {plan.stop} | Target {plan.target}\n"
                f"Net R/R {plan.net_rr:.2f} | {plan.sizing_mode}\n"
                f"Confirm within {int(self.config.get('confirm_ttl_sec', 120))}s. A fresh plan is rebuilt before POST.",
                [[{"text": "CONFIRM BUY", "callback_data": f"V3CONFIRM:{signal_id}:{token}"}],
                 [{"text": "CANCEL", "callback_data": f"V3CANCEL:{signal_id}:{token}"}]],
            )

    async def _confirm_buy(self, callback_id: str, signal_id: str, token: str) -> None:
        async with self._execution_lock:
            row = self.state.view().get("signals", {}).get(signal_id)
            if not row or row.get("status") != "AWAITING_CONFIRM" or token != row.get("confirmation_token"):
                await self.telegram.answer(callback_id, "Confirmation unavailable")
                return
            reset = self.state.view().get("reentry_resets", {}).get(row["symbol"], {})
            if str(reset.get("status", "")) in ACTIVE_REENTRY_RESET:
                await self._terminal_signal(
                    callback_id, signal_id, "REENTRY_RESET_BLOCKED", "Pullback + reclaim not complete"
                )
                self._notify(
                    f"reentry-reset-confirm-block:{signal_id}:{time.time_ns()}",
                    f"BUY BLOCKED - NO ORDER\n{row['symbol']} [{signal_id}]\n"
                    "The post-profit structural reset became active before execution.",
                )
                return
            age = time.time() - _f(row.get("selected_at"))
            if age > float(self.config.get("confirm_ttl_sec", 120)):
                await self._terminal_signal(callback_id, signal_id, "EXPIRED", "Fresh size required")
                return
            if not bool(self.config.get("execution_enabled", False)):
                await self.telegram.answer(callback_id, "Execution is not armed")
                self._notify(f"not-armed:{signal_id}", f"BUY BLOCKED - NO ORDER\n{row['symbol']} [{signal_id}]\nv3 execution is not armed.")
                return
            unresolved = self._unresolved_buy_symbols(signal_id)
            if unresolved:
                symbols = ",".join(unresolved)
                await self.telegram.answer(callback_id, "Another BUY is unresolved")
                self._notify(
                    f"buy-capital-reserved:{signal_id}:{time.time_ns()}",
                    f"BUY DEFERRED - NO ORDER\n{row['symbol']} [{signal_id}]\n"
                    f"Capital is reserved by unresolved BUY: {symbols}. Retry after venue reconciliation.",
                )
                return
            await self.telegram.answer(callback_id, "Final venue revalidation")
            approved = BuyPlan(**row["approved_plan"])
            try:
                fresh = await self.execution.build_buy_plan(
                    signal_id, row["symbol"], row["lane"], approved.risk_fraction_pct,
                    self._entry_momentum_for_signal(row),
                )
                breaches = self.execution.plan_drift(approved, fresh, self.config)
                if breaches:
                    await self._replace_buy_confirmation(signal_id, row, fresh, breaches)
                    return
                await self.state.apply(
                    "BUY_EXECUTING",
                    lambda state: state["signals"][signal_id].update(
                        status="BUY_EXECUTING", executing_at=time.time(), execution_plan=asdict(fresh)
                    ),
                )
                order = await self.execution.submit_buy(fresh)
                await self._apply_buy_truth(signal_id, fresh, order)
            except ExecutionRefused as exc:
                # No order was attempted.  Keep the original candidate alive
                # so a transient spread/geometry change can be sized again.
                await self.state.apply(
                    "BUY_DEFERRED",
                    lambda state: state["signals"][signal_id].update(
                        status="PENDING",
                        confirmation_token=None,
                        approved_plan=None,
                        deferred_at=time.time(),
                        error=str(exc),
                    ),
                )
                self._notify(
                    f"buy-deferred:{signal_id}:{time.time_ns()}",
                    f"BUY DEFERRED - NO ORDER\n{row['symbol']} [{signal_id}]\n{exc}\n"
                    "The candidate remains open until its normal expiry; choose size again only if desired.",
                )
            except ExecutionUnknown as exc:
                await self.state.apply(
                    "BUY_EXECUTION_UNKNOWN",
                    lambda state: state["signals"][signal_id].update(status="EXECUTION_UNKNOWN", error=str(exc)),
                )
                self._notify(f"buy-unknown:{signal_id}", f"BUY STATUS UNKNOWN\n{row['symbol']} [{signal_id}]\n{exc}\nNo retry will occur before venue reconciliation.")
            except Exception as exc:
                executing = self.state.view().get("signals", {}).get(signal_id, {}).get("status") == "BUY_EXECUTING"
                status = "EXECUTION_UNKNOWN" if executing else "BUY_REFUSED"
                await self.state.apply(
                    "BUY_EXECUTION_UNKNOWN" if executing else "BUY_REFUSED",
                    lambda state: state["signals"][signal_id].update(status=status, error=str(exc)),
                )
                if executing:
                    self._notify(f"buy-unknown:{signal_id}", f"BUY STATUS UNKNOWN\n{row['symbol']} [{signal_id}]\n{exc}\nExecution had started; no retry before venue reconciliation.")
                else:
                    self._notify(f"buy-refused:{signal_id}:{time.time_ns()}", f"BUY REFUSED - NO ORDER\n{row['symbol']} [{signal_id}]\n{exc}")

    async def _replace_buy_confirmation(
        self, signal_id: str, row: dict, fresh: BuyPlan, breaches: list[str]
    ) -> None:
        token = secrets.token_hex(4)

        def commit(state):
            signal = state["signals"][signal_id]
            history = list(signal.get("plan_updates") or [])
            history.append({"ts": time.time(), "breaches": list(breaches)})
            signal.update(
                status="AWAITING_CONFIRM",
                selected_at=time.time(),
                confirmation_token=token,
                approved_plan=asdict(fresh),
                plan_updates=history[-10:],
            )

        await self.state.apply("BUY_PLAN_RECONFIRM", commit)
        execution_line = self._buy_execution_line(fresh)
        self._notify(
            f"reconfirm:{signal_id}:{token}",
            f"REVX v3 BUY PLAN UPDATED - RECONFIRM [{signal_id}]\n"
            f"{fresh.symbol} | {fresh.lane} | {fresh.risk_fraction_pct}% risk\n"
            f"Limit {fresh.limit_price} | Qty {fresh.quantity} | Notional ${fresh.notional_usd:.2f}\n"
            f"Capital use {fresh.capital_usage_pct:.1f}% | Cap ${fresh.capital_limit_usd:.2f}\n"
            f"{execution_line}\n"
            f"Actual risk ${fresh.actual_risk_usd:.2f} | Stop {fresh.stop} | Target {fresh.target}\n"
            f"Net R/R {fresh.net_rr:.2f}\nChanged: {', '.join(breaches)}\n"
            "No order was submitted. Confirm this updated plan.",
            [[{"text": "CONFIRM UPDATED BUY", "callback_data": f"V3CONFIRM:{signal_id}:{token}"}],
             [{"text": "CANCEL", "callback_data": f"V3CANCEL:{signal_id}:{token}"}]],
        )

    def _unresolved_buy_symbols(self, exclude_signal_id: str = "") -> list[str]:
        return sorted({
            str(row.get("symbol", "?"))
            for other_id, row in self.state.view().get("signals", {}).items()
            if other_id != exclude_signal_id
            and row.get("status") in {"BUY_EXECUTING", "ORDER_SUBMITTED", "BUY_PARTIAL", "EXECUTION_UNKNOWN"}
        })

    @staticmethod
    def _buy_execution_line(plan: BuyPlan) -> str:
        if plan.execution_style == "MARKETABLE_LIMIT_DEPTH_CAPPED":
            depth_line = (
                f" | depth-scaled {plan.quantity}/{plan.requested_quantity} ({plan.depth_scale_pct:.1f}%)"
                if plan.depth_scale_pct < 99.999 else ""
            )
            return (
                f"Execution {plan.execution_style} | est VWAP {plan.estimated_vwap} | "
                f"slip {plan.estimated_slippage_pct:.4f}% | visible cover {plan.coverage_pct:.1f}%"
                + depth_line
            )
        return "Execution POST_ONLY_MAKER | passive fill is not guaranteed"

    async def _apply_buy_truth(self, signal_id: str, plan: BuyPlan, order: dict) -> None:
        venue_id = order_id(order)
        filled = _f(order.get("filled_quantity"))
        leaves = _f(order.get("leaves_quantity"), max(0.0, plan.quantity - filled))
        avg = _f(order.get("average_fill_price"), plan.limit_price)
        venue_status = order_status(order)
        terminal = venue_status in {"cancelled", "canceled", "rejected", "expired"}
        if filled > 0 and (leaves <= 0 or venue_status == "filled"):
            status = "BUY_FILLED"
        elif filled > 0 and terminal:
            status = "BUY_PARTIAL_FINAL"
        elif filled > 0:
            status = "BUY_PARTIAL"
        elif terminal:
            status = "BUY_CANCELLED"
        else:
            status = "ORDER_SUBMITTED"
        managed_qty = filled

        def commit(state):
            signal = state["signals"][signal_id]
            signal.update(
                status=status,
                venue_order_id=venue_id,
                client_order_id=plan.client_order_id,
                order=order,
                submitted_at=signal.get("submitted_at", time.time()),
                filled_quantity=filled,
                leaves_quantity=leaves,
                average_fill_price=avg,
            )
            if managed_qty > 0:
                state.setdefault("reentry_resets", {}).pop(plan.symbol, None)
                state["positions"][plan.symbol] = {
                    "status": "OPEN",
                    "symbol": plan.symbol,
                    "quantity": managed_qty,
                    "original_filled_quantity": filled,
                    "average_entry_price": avg,
                    "stop": plan.stop,
                    "target": plan.target,
                    "entry_signal_id": signal_id,
                    "entry_lane": plan.lane,
                    "entry_order_id": venue_id,
                    "opened_at": signal.get("submitted_at", time.time()),
                    "last_exit_alert_at": 0,
                }

        await self.state.apply("BUY_VENUE_TRUTH", commit)
        if filled > 0:
            try:
                balances = await self.execution.balances_map(Priority.EXIT_WATCH)
                asset = plan.symbol.removesuffix("-USD")
                venue_qty = _f(balances.get(asset, {}).get("total"), filled)
                aligned = min(filled, venue_qty)
                if aligned != managed_qty:
                    managed_qty = aligned
                    await self.state.apply(
                        "BUY_INVENTORY_RECONCILED",
                        lambda state: state["positions"][plan.symbol].update(quantity=aligned, venue_quantity=venue_qty),
                    )
            except Exception as exc:
                self.log.warning("BUY INVENTORY RECONCILE DEFERRED %s [%s]: %s", plan.symbol, signal_id, exc)
        self._notify(
            f"buy-accepted:{signal_id}:{status}",
            f"ORDER ACCEPTED\n{plan.symbol} [{signal_id}]\nOrder {venue_id}\n"
            f"Status {status} | Filled {filled} | Leaves {leaves} | Avg {avg}\n"
            f"Managed {managed_qty} | Stop {plan.stop} | Target {plan.target}",
        )
        self.log.info("BUY ACCEPTED %s [%s] order=%s status=%s filled=%s leaves=%s", plan.symbol, signal_id, venue_id, status, filled, leaves)

    async def _exit_watch_once(self) -> None:
        now = time.time()
        await self._expire_pending_exits(now)
        view = self.state.view()
        positions = [row for row in view.get("positions", {}).values() if row.get("status") == "OPEN" and _f(row.get("quantity")) > 0]
        if not positions:
            return
        payload = await self.client.tickers(Priority.EXIT_WATCH)
        rows = payload.values() if isinstance(payload, dict) else (payload or [])
        quotes = {}
        for row in rows:
            if isinstance(row, dict):
                quote = quote_from_ticker(row)
                if quote:
                    quotes[quote.symbol] = quote
        for position in positions:
            symbol = position["symbol"]
            quote = quotes.get(symbol)
            if not quote:
                misses = int(position.get("quote_missing_confirmations", 0)) + 1
                threshold = int(self.config.get("position_quote_missing_confirmations", 3))
                degraded = bool(position.get("quote_degraded")) or misses >= threshold
                await self.state.apply(
                    "POSITION_QUOTE_MISSING",
                    lambda state, s=symbol, m=misses, d=degraded: state["positions"][s].update(
                        quote_missing_confirmations=m,
                        quote_degraded=d,
                    ),
                )
                if misses == threshold:
                    self.log.warning("POSITION QUOTE DEGRADED %s missing=%d | no SELL plan", symbol, misses)
                    self._notify(
                        f"position-quote-degraded:{symbol}:{int(now // 3600)}",
                        f"REVX v3 POSITION DATA DEGRADED\n{symbol}\n"
                        f"Public quote missing for {misses} consecutive exit checks.\n"
                        "Fail-closed: no SELL approval until a fresh quote recovers.",
                    )
                continue

            recovered = bool(position.get("quote_degraded"))
            entry = _f(position.get("average_entry_price"))
            pnl_pct = (quote.bid - entry) / entry * 100 if entry > 0 else 0.0
            previous_high = max(entry, _f(position.get("high_watermark_bid"), entry))
            high = max(previous_high, quote.bid)
            target = _f(position.get("target"))
            target_reached = target > 0 and quote.bid >= target
            extension_was_active = bool(position.get("target_extension_active"))
            extension_active = extension_was_active or target_reached
            target_new = extension_active and not extension_was_active
            arm_pct = float(self.config.get("trailing_arm_profit_pct", 5.0))
            drawdown_pct = float(self.config.get("trailing_drawdown_pct", 2.5))
            armed = (
                bool(position.get("trail_armed"))
                or pnl_pct >= arm_pct
                or extension_active
            )
            trail_trigger = high * (1.0 - drawdown_pct / 100.0) if armed else 0.0
            profit_floor = 0.0
            if extension_active and entry > 0:
                fee_lock = float(self.config.get("taker_fee_pct", 0.09)) * 2.0 + 0.02
                lock_pct = max(
                    fee_lock,
                    float(self.config.get("target_extension_min_locked_profit_pct", 0.25)),
                )
                profit_floor = entry * (1.0 + lock_pct / 100.0)
                trail_trigger = max(trail_trigger, profit_floor)
            trailing_breach = armed and quote.bid <= trail_trigger
            confirmations = (
                int(position.get("trail_breach_confirmations", 0)) + 1
                if trailing_breach else 0
            )
            momentum_state = str(position.get("target_momentum_state", "UNKNOWN"))
            momentum_loss_confirmations = int(
                position.get("target_momentum_loss_confirmations", 0)
            )
            last_momentum_at = _f(position.get("target_extension_last_momentum_at"))
            latest_momentum = self._latest_momentum.get(symbol, {})
            latest_momentum_at = _f(latest_momentum.get("observed_at"))
            momentum_max_age = float(
                self.config.get("target_extension_momentum_max_age_sec", 75.0)
            )
            if (
                extension_active
                and latest_momentum_at > last_momentum_at
                and now - latest_momentum_at <= momentum_max_age
            ):
                momentum_state = _fast_momentum_state(latest_momentum)
                momentum_loss_confirmations = (
                    momentum_loss_confirmations + 1
                    if momentum_state == "NEGATIVE" else 0
                )
                last_momentum_at = latest_momentum_at
            # v3.5.2 only classified momentum after target.  v3.5.3 consumes
            # every distinct fresh tape observation for every open position,
            # so a failed entry thesis can be surfaced before the hard stop.
            fast_momentum_state = str(position.get("fast_momentum_state", "UNKNOWN"))
            fast_negative_confirmations = int(
                position.get("fast_momentum_negative_confirmations", 0)
            )
            fast_last_observed_at = _f(
                position.get("fast_momentum_last_observed_at")
            )
            early_momentum_max_age = float(
                self.config.get("early_momentum_max_age_sec", 75.0)
            )
            if (
                latest_momentum_at > fast_last_observed_at
                and now - latest_momentum_at <= early_momentum_max_age
            ):
                fast_momentum_state = _fast_momentum_state(latest_momentum)
                fast_negative_confirmations = (
                    fast_negative_confirmations + 1
                    if fast_momentum_state == "NEGATIVE" else 0
                )
                fast_last_observed_at = latest_momentum_at
            fast_negative_fresh = bool(
                fast_momentum_state == "NEGATIVE"
                and fast_last_observed_at > 0
                and now - fast_last_observed_at <= early_momentum_max_age
            )
            early_required = int(self.config.get("early_momentum_confirmations", 2))
            fee_loss_floor = (
                2.0 * float(self.config.get("taker_fee_pct", 0.09))
                + float(self.config.get("early_momentum_fee_buffer_pct", 0.10))
            )
            early_loss_floor = max(
                fee_loss_floor,
                float(self.config.get("early_momentum_min_loss_pct", 0.30)),
            )
            mfe_pct = (high / entry - 1.0) * 100.0 if entry > 0 else 0.0
            giveback_pct = (high / quote.bid - 1.0) * 100.0 if quote.bid > 0 else 0.0
            early_momentum_failure = bool(
                not extension_active
                and fast_negative_fresh
                and fast_negative_confirmations >= early_required
                and pnl_pct <= -early_loss_floor
            )
            failed_breakout = bool(
                not extension_active
                and fast_negative_fresh
                and fast_negative_confirmations >= early_required
                and mfe_pct >= float(self.config.get("failed_breakout_min_mfe_pct", 0.75))
                and giveback_pct >= float(
                    self.config.get("failed_breakout_min_giveback_pct", 0.60)
                )
                and pnl_pct <= float(self.config.get("failed_breakout_max_pnl_pct", 0.75))
            )
            # A starter that never follows through should not consume capital
            # merely because it has not yet reached the hard stop.  This is
            # deliberately limited to IGNITION positions and still produces a
            # normal Telegram SELL approval, never an automatic order.
            opened_age = now - _f(position.get("opened_at"), now)
            followthrough_after = float(self.config.get("ignition_followthrough_sec", 900))
            required_high = entry * (1.0 + float(self.config.get("ignition_min_followthrough_pct", 0.60)) / 100.0)
            no_followthrough = (
                str(position.get("entry_lane", "")).upper() == "IGNITION"
                and opened_age >= followthrough_after
                and high < required_high
                and pnl_pct <= -float(self.config.get("ignition_exit_loss_pct", 0.75))
            )
            no_followthrough_confirmations = (
                int(position.get("no_followthrough_confirmations", 0)) + 1
                if no_followthrough else 0
            )
            heartbeat_due = now - _f(position.get("last_position_heartbeat_at")) >= float(
                self.config.get("position_heartbeat_sec", 300)
            )
            await self.state.apply(
                "POSITION_WATCH",
                lambda state, s=symbol: state["positions"][s].update(
                    last_quote_bid=quote.bid,
                    last_quote_ask=quote.ask,
                    last_quote_at=now,
                    quote_missing_confirmations=0,
                    quote_degraded=False,
                    high_watermark_bid=high,
                    trail_armed=armed,
                    trail_trigger_bid=trail_trigger,
                    trail_breach_confirmations=confirmations,
                    target_extension_active=extension_active,
                    target_hit_at=(
                        _f(state["positions"][s].get("target_hit_at")) or now
                        if extension_active else 0.0
                    ),
                    target_hit_bid=(
                        max(_f(state["positions"][s].get("target_hit_bid")), quote.bid)
                        if extension_active else 0.0
                    ),
                    target_extension_profit_floor_bid=profit_floor,
                    target_momentum_state=momentum_state,
                    target_momentum_loss_confirmations=momentum_loss_confirmations,
                    target_extension_last_momentum_at=last_momentum_at,
                    fast_momentum_state=fast_momentum_state,
                    fast_momentum_negative_confirmations=fast_negative_confirmations,
                    fast_momentum_last_observed_at=fast_last_observed_at,
                    fast_momentum_mfe_pct=mfe_pct,
                    fast_momentum_giveback_pct=giveback_pct,
                    no_followthrough_confirmations=no_followthrough_confirmations,
                    last_position_heartbeat_at=now if heartbeat_due else _f(
                        state["positions"][s].get("last_position_heartbeat_at")
                    ),
                ),
            )
            if target_new:
                self.log.info(
                    "TARGET EXTENSION %s bid=%s target=%s momentum=%s trail=%s | no SELL candidate",
                    symbol,
                    quote.bid,
                    target,
                    momentum_state,
                    trail_trigger,
                )
                self._notify(
                    f"target-extension:{symbol}:{int(now)}",
                    f"REVX v3 TARGET EXTENSION\n{symbol}\n"
                    f"Target {target} reached at bid {quote.bid}; no SELL was proposed.\n"
                    f"Fast momentum {momentum_state} | s20 {_f(latest_momentum.get('s20')):.3f}% | "
                    f"m1 {_f(latest_momentum.get('m1')):.3f}% | m5 {_f(latest_momentum.get('m5')):.3f}%.\n"
                    f"Profit protection armed at {trail_trigger}; hard stop remains first priority.",
                )
                self._append_evidence({
                    "type": "TARGET_EXTENSION_MILESTONE",
                    "ts": now,
                    "symbol": symbol,
                    "bid": quote.bid,
                    "target": target,
                    "trail_trigger": trail_trigger,
                    "profit_floor": profit_floor,
                    "momentum_state": momentum_state,
                    "momentum": latest_momentum,
                })
            if recovered:
                self.log.info("POSITION QUOTE RECOVERED %s bid=%s", symbol, quote.bid)
                self._notify(
                    f"position-quote-recovered:{symbol}:{int(now // 3600)}",
                    f"REVX v3 POSITION DATA RECOVERED\n{symbol}\n"
                    f"Fresh bid {quote.bid}. Exit monitoring resumed; no order was sent.",
                )
            if heartbeat_due:
                self.log.info(
                    "POSITION HEARTBEAT %s bid=%s pnl=%.2f%% managed=%s venueSeen=%s "
                    "stop=%s target=%s trail=%s high=%s trigger=%s extension=%s targetMomentum=%s/%d fastMomentum=%s/%d",
                    symbol,
                    quote.bid,
                    pnl_pct,
                    position.get("quantity"),
                    position.get("observed_venue_quantity"),
                    position.get("stop"),
                    position.get("target"),
                    "ARMED" if armed else "OFF",
                    high,
                    trail_trigger,
                    "ACTIVE" if extension_active else "OFF",
                    momentum_state,
                    momentum_loss_confirmations,
                    fast_momentum_state,
                    fast_negative_confirmations,
                )

            reason = ""
            if quote.bid <= _f(position.get("stop")):
                reason = "STOP_HIT"
            elif trailing_breach and confirmations >= int(self.config.get("trailing_confirmations", 2)):
                reason = "TRAIL_PROFIT"
            elif (
                extension_active
                and momentum_loss_confirmations
                >= int(self.config.get("target_extension_momentum_confirmations", 2))
            ):
                reason = "TARGET_MOMENTUM_LOSS"
            elif failed_breakout:
                reason = "FAILED_BREAKOUT"
            elif early_momentum_failure:
                reason = "EARLY_MOMENTUM_FAILURE"
            elif no_followthrough_confirmations >= int(self.config.get("ignition_exit_confirmations", 2)):
                reason = "IGNITION_NO_FOLLOW_THROUGH"
            if not reason:
                continue
            if now - _f(position.get("last_exit_alert_at")) < float(self.config.get("exit_rearm_sec", 300)):
                continue
            current = self.state.view()
            if any(row.get("symbol") == symbol and row.get("status") in self.ACTIVE_EXIT for row in current.get("exits", {}).values()):
                continue
            exit_id = "exit" + secrets.token_hex(4)
            try:
                position = self.state.view()["positions"][symbol]
                plan = await self.execution.build_sell_plan(exit_id, position, reason, "MANAGED")
            except Exception as exc:
                self.log.warning("EXIT PREFLIGHT REFUSED %s reason=%s: %s", symbol, reason, exc)
                continue

            def commit(state):
                state["exits"][exit_id] = {
                    "id": exit_id,
                    "symbol": symbol,
                    "reason": reason,
                    "status": "PENDING",
                    "created_at": time.time(),
                    "plan": asdict(plan),
                    "position_entry_signal_id": position.get("entry_signal_id"),
                    "venue_available_at_preflight": plan.venue_available,
                }
                state["positions"][symbol]["last_exit_alert_at"] = time.time()

            await self.state.apply("EXIT_CANDIDATE", commit)
            self._notify(
                f"exit:{exit_id}",
                f"REVX v3 EXIT CANDIDATE [{exit_id}]\n{symbol} | {reason}\n"
                f"Fresh bid {plan.trigger_bid} | Managed {plan.managed_quantity} | "
                f"Available {plan.venue_available}\n"
                f"PnL {pnl_pct:.3f}% | MFE {mfe_pct:.3f}% | Giveback {giveback_pct:.3f}% | "
                f"Fast momentum {fast_momentum_state}/{fast_negative_confirmations}\n"
                f"Managed limit {plan.limit_price} | managed slip {plan.estimated_slippage_pct:.4f}%\n"
                f"VWAP {plan.estimated_vwap} | Slip {plan.estimated_slippage_pct:.4f}% | Cover {plan.coverage_pct:.1f}%\n"
                f"Approval expires in {int(self.config.get('exit_approval_ttl_sec', 60))}s. "
                "Either SELL choice rebuilds authenticated quantity and depth before POST.",
                [[
                    {"text": "SELL MANAGED", "callback_data": f"V3SELLM:{exit_id}"},
                    {"text": "SELL ALL", "callback_data": f"V3SELLA:{exit_id}"},
                ], [{"text": "HOLD", "callback_data": f"V3HOLD:{exit_id}"}]],
            )
            self.log.info("LIVE EXIT CANDIDATE %s [%s] reason=%s", symbol, exit_id, reason)

    async def _expire_pending_exits(self, now: float) -> None:
        view = self.state.view()
        ttl = float(self.config.get("exit_approval_ttl_sec", 60))
        expired = [
            (exit_id, row.get("symbol"))
            for exit_id, row in view.get("exits", {}).items()
            if row.get("status") == "PENDING" and now - _f(row.get("created_at")) > ttl
        ]
        if not expired:
            return

        def commit(state):
            for exit_id, symbol in expired:
                if state["exits"].get(exit_id, {}).get("status") == "PENDING":
                    state["exits"][exit_id].update(status="EXPIRED", expired_at=now)
                if symbol in state["positions"]:
                    state["positions"][symbol]["last_exit_alert_at"] = 0

        await self.state.apply("EXIT_APPROVALS_PASSIVELY_EXPIRED", commit)
        self.log.info("EXIT APPROVAL PASSIVE EXPIRY count=%d | trigger may re-arm", len(expired))

    async def _confirm_sell(self, callback_id: str, exit_id: str, scope: str) -> None:
        async with self._execution_lock:
            view = self.state.view()
            row = view.get("exits", {}).get(exit_id)
            if not row or row.get("status") != "PENDING":
                await self.telegram.answer(callback_id, "Exit approval unavailable")
                return
            age = time.time() - _f(row.get("created_at"))
            if age > float(self.config.get("exit_approval_ttl_sec", 60)):
                await self.state.apply(
                    "EXIT_EXPIRED",
                    lambda state: (
                        state["exits"][exit_id].update(status="EXPIRED"),
                        state["positions"][row["symbol"]].update(last_exit_alert_at=0)
                        if row["symbol"] in state["positions"] else None,
                    ),
                )
                await self.telegram.answer(callback_id, "Exit expired; wait for fresh plan")
                return
            if not bool(self.config.get("execution_enabled", False)):
                await self.telegram.answer(callback_id, "Execution is not armed")
                return
            position = view.get("positions", {}).get(row["symbol"])
            if not position or position.get("status") != "OPEN":
                await self.telegram.answer(callback_id, "Position no longer open")
                return
            await self.telegram.answer(
                callback_id,
                "Final SELL ALL revalidation" if scope == "ALL_AVAILABLE" else "Final SELL MANAGED revalidation",
            )
            approved = SellPlan(**row["plan"])
            try:
                fresh = await self.execution.build_sell_plan(exit_id, position, row["reason"], scope)
                if fresh.trigger_bid < approved.trigger_bid:
                    drift = (approved.trigger_bid - fresh.trigger_bid) / approved.trigger_bid * 100
                    if drift > float(self.config.get("exit_max_adverse_drift_pct", 0.50)):
                        raise ExecutionRefused(f"adverse bid drift {drift:.3f}% requires a fresh approval")
                await self.state.apply(
                    "SELL_EXECUTING",
                    lambda state: state["exits"][exit_id].update(
                        status="SELL_EXECUTING",
                        executing_at=time.time(),
                        selected_scope=scope,
                        execution_plan=asdict(fresh),
                    ),
                )
                order = await self.execution.submit_sell(fresh)
                await self._apply_sell_truth(exit_id, fresh, order)
            except ExecutionUnknown as exc:
                await self.state.apply("SELL_EXECUTION_UNKNOWN", lambda state: state["exits"][exit_id].update(status="EXECUTION_UNKNOWN", error=str(exc)))
                self._notify(f"sell-unknown:{exit_id}", f"SELL STATUS UNKNOWN\n{row['symbol']} [{exit_id}]\n{exc}\nNo retry before venue reconciliation.")
            except Exception as exc:
                executing = self.state.view().get("exits", {}).get(exit_id, {}).get("status") == "SELL_EXECUTING"
                status = "EXECUTION_UNKNOWN" if executing else "SELL_REFUSED"
                await self.state.apply(
                    "SELL_EXECUTION_UNKNOWN" if executing else "SELL_REFUSED",
                    lambda state: (
                        state["exits"][exit_id].update(status=status, error=str(exc)),
                        state["positions"][row["symbol"]].update(last_exit_alert_at=0)
                        if not executing and row["symbol"] in state["positions"] else None,
                    ),
                )
                if executing:
                    self._notify(f"sell-unknown:{exit_id}", f"SELL STATUS UNKNOWN\n{row['symbol']} [{exit_id}]\n{exc}\nExecution had started; no retry before venue reconciliation.")
                else:
                    self._notify(f"sell-refused:{exit_id}:{time.time_ns()}", f"SELL REFUSED - NO ORDER\n{row['symbol']} [{exit_id}]\n{exc}")

    async def _apply_sell_truth(self, exit_id: str, plan: SellPlan, order: dict) -> None:
        venue_id = order_id(order)
        filled = _f(order.get("filled_quantity"))
        leaves = _f(order.get("leaves_quantity"), max(0.0, plan.quantity - filled))
        avg = _f(order.get("average_fill_price"), plan.limit_price)
        view = self.state.view()
        previous = _f(view.get("exits", {}).get(exit_id, {}).get("applied_filled_quantity"))
        delta = max(0.0, filled - previous)
        current_qty = _f(view.get("positions", {}).get(plan.symbol, {}).get("quantity"))
        remaining = max(0.0, current_qty - delta)
        venue_status = order_status(order)
        terminal = venue_status in {"cancelled", "canceled", "rejected", "expired"}
        order_complete = leaves <= max(1e-12, plan.quantity * 1e-9) or venue_status == "filled"
        if filled > 0 and order_complete:
            status = "SELL_FILLED"
        elif filled > 0 and terminal:
            status = "SELL_PARTIAL_FINAL"
        elif filled > 0:
            status = "SELL_PARTIAL"
        elif terminal:
            status = "SELL_CANCELLED"
        else:
            status = "ORDER_SUBMITTED"
        managed_cleared = remaining <= max(1e-12, plan.managed_quantity * 1e-9)
        closed = managed_cleared and (
            plan.scope == "MANAGED" or order_complete or terminal
        )
        first_close = closed and not bool(
            view.get("positions", {}).get(plan.symbol, {}).get("closed_at")
        )
        close_ts = time.time()
        entry_before = _f(
            view.get("positions", {}).get(plan.symbol, {}).get("average_entry_price")
        )
        round_trip_fee_pct = 2.0 * float(self.config.get("taker_fee_pct", 0.09))
        profitable_close = bool(
            entry_before > 0
            and avg >= entry_before * (1.0 + round_trip_fee_pct / 100.0)
        )
        profit_reset_due = bool(
            first_close
            and (
                plan.reason in PROFIT_RESET_REASONS
                or (plan.reason == "FAILED_BREAKOUT" and profitable_close)
            )
        )

        def commit(state):
            exit_row = state["exits"][exit_id]
            exit_row.update(
                status=status,
                venue_order_id=venue_id,
                client_order_id=plan.client_order_id,
                order=order,
                submitted_at=exit_row.get("submitted_at", time.time()),
                filled_quantity=filled,
                applied_filled_quantity=filled,
                leaves_quantity=leaves,
                average_fill_price=avg,
                scope=plan.scope,
                managed_quantity=plan.managed_quantity,
                venue_available_at_execution=plan.venue_available,
            )
            position = state["positions"][plan.symbol]
            position["quantity"] = remaining
            if closed:
                position.update(
                    status="CLOSED",
                    closed_at=close_ts,
                    exit_order_id=venue_id,
                    exit_price=avg,
                    exit_reason=plan.reason,
                    exit_scope=plan.scope,
                    exit_managed_quantity=plan.managed_quantity,
                    total_exit_filled_quantity=filled,
                    unmanaged_sold_quantity=max(0.0, filled - plan.managed_quantity),
                    unmanaged_remaining_estimate=(
                        max(0.0, leaves) if plan.scope == "ALL_AVAILABLE" else 0.0
                    ),
                    external_cost_basis_unknown=plan.scope == "ALL_AVAILABLE",
                )
                if profit_reset_due:
                    state.setdefault("reentry_resets", {})[plan.symbol] = {
                        "symbol": plan.symbol,
                        "status": "AWAITING_PULLBACK",
                        "created_at": close_ts,
                        "source_exit_id": exit_id,
                        "exit_reason": plan.reason,
                        "exit_price": avg,
                        "peak_price": max(
                            avg,
                            _f(position.get("high_watermark_bid")),
                            _f(position.get("target")),
                        ),
                    }
            elif managed_cleared and plan.scope == "ALL_AVAILABLE":
                position["status"] = "CLOSING_ALL"

        await self.state.apply("SELL_VENUE_TRUTH", commit)
        self._notify(
            f"sell-accepted:{exit_id}:{status}:{filled}",
            f"SELL ACCEPTED\n{plan.symbol} [{exit_id}]\nOrder {venue_id}\n"
            f"Scope {plan.scope} | Status {status} | Filled {filled} | Leaves {leaves} | Avg {avg}\n"
            f"Managed remaining {remaining}"
            + (
                f" | unmanaged remainder estimate {max(0.0, leaves)}; external cost basis remains unknown"
                if plan.scope == "ALL_AVAILABLE" and terminal and leaves > 0
                else (" | external cost basis remains unknown" if plan.scope == "ALL_AVAILABLE" else "")
            )
            + (
                " | post-profit re-entry now requires pullback + momentum reclaim"
                if profit_reset_due else ""
            ),
        )
        self.log.info("SELL ACCEPTED %s [%s] order=%s status=%s filled=%s leaves=%s", plan.symbol, exit_id, venue_id, status, filled, leaves)
        if profit_reset_due:
            reset = self.state.view().get("reentry_resets", {}).get(plan.symbol, {})
            self._append_evidence({
                "type": "POST_PROFIT_REENTRY_RESET_CREATED",
                "ts": close_ts,
                "symbol": plan.symbol,
                "exit_id": exit_id,
                "reason": plan.reason,
                "state": reset,
            })
            self.log.info(
                "POST-PROFIT REENTRY RESET CREATED %s reason=%s peak=%s",
                plan.symbol,
                plan.reason,
                reset.get("peak_price"),
            )
        if first_close:
            position = self.state.view()["positions"][plan.symbol]
            try:
                self._append_trade(position, exit_id, order)
            except Exception as exc:
                self.log.error("CLOSED TRADE LEDGER WRITE FAILED %s [%s]: %s", plan.symbol, exit_id, exc)
                self._notify(f"ledger-failed:{exit_id}", f"REVX LEDGER WRITE FAILED\n{plan.symbol} [{exit_id}]\nVenue/state show the close, but local trade-ledger append failed: {exc}")

    async def _order_watch_once(self) -> None:
        view = self.state.view()
        watchdog = float(self.config.get("order_watchdog_sec", 45))
        for sid, row in list(view.get("signals", {}).items()):
            if row.get("status") not in {"BUY_EXECUTING", "ORDER_SUBMITTED", "BUY_PARTIAL", "EXECUTION_UNKNOWN"}:
                continue
            plan_raw = row.get("execution_plan") or row.get("approved_plan")
            if not isinstance(plan_raw, dict):
                continue
            plan = BuyPlan(**plan_raw)
            order = None
            venue_id = str(row.get("venue_order_id", ""))
            if venue_id:
                payload = await self.client.order(venue_id, Priority.EXIT_WATCH)
                rows = _rows(payload)
                order = rows[0] if rows else (payload if isinstance(payload, dict) else None)
            if order is None:
                order = await self.execution.find_order(plan.symbol, plan.client_order_id, Priority.EXIT_WATCH)
            if order is None:
                continue
            if order_status(order) in {"new", "open", "partially_filled"} and time.time() - _f(row.get("submitted_at", row.get("executing_at"))) > watchdog:
                oid = order_id(order)
                if oid:
                    await self.client.cancel_order(oid, Priority.EXIT_WATCH)
                    payload = await self.client.order(oid, Priority.EXIT_WATCH)
                    checked = _rows(payload)
                    order = checked[0] if checked else (payload if isinstance(payload, dict) else order)
            await self._apply_buy_truth(sid, plan, order)

        view = self.state.view()
        for exit_id, row in list(view.get("exits", {}).items()):
            if row.get("status") not in {"SELL_EXECUTING", "ORDER_SUBMITTED", "SELL_PARTIAL", "EXECUTION_UNKNOWN"}:
                continue
            plan_raw = row.get("execution_plan") or row.get("plan")
            if not isinstance(plan_raw, dict):
                continue
            plan = SellPlan(**plan_raw)
            order = None
            venue_id = str(row.get("venue_order_id", ""))
            if venue_id:
                payload = await self.client.order(venue_id, Priority.EXIT_CRITICAL)
                rows = _rows(payload)
                order = rows[0] if rows else (payload if isinstance(payload, dict) else None)
            if order is None:
                order = await self.execution.find_order(plan.symbol, plan.client_order_id, Priority.EXIT_CRITICAL)
            if order is None:
                continue
            if order_status(order) in {"new", "open", "partially_filled"} and time.time() - _f(row.get("submitted_at", row.get("executing_at"))) > watchdog:
                oid = order_id(order)
                if oid:
                    await self.client.cancel_order(oid, Priority.EXIT_CRITICAL)
                    payload = await self.client.order(oid, Priority.EXIT_CRITICAL)
                    checked = _rows(payload)
                    order = checked[0] if checked else (payload if isinstance(payload, dict) else order)
            await self._apply_sell_truth(exit_id, plan, order)

        view = self.state.view()
        for exit_id, row in list(view.get("external_exits", {}).items()):
            if row.get("status") not in {"SELL_EXECUTING", "ORDER_SUBMITTED", "SELL_PARTIAL", "EXECUTION_UNKNOWN"}:
                continue
            plan_raw = row.get("execution_plan") or row.get("plan")
            if not isinstance(plan_raw, dict):
                continue
            plan = SellPlan(**plan_raw)
            order = None
            venue_id = str(row.get("venue_order_id", ""))
            if venue_id:
                payload = await self.client.order(venue_id, Priority.EXIT_CRITICAL)
                rows = _rows(payload)
                order = rows[0] if rows else (payload if isinstance(payload, dict) else None)
            if order is None:
                order = await self.execution.find_order(plan.symbol, plan.client_order_id, Priority.EXIT_CRITICAL)
            if order is None:
                continue
            if order_status(order) in {"new", "open", "partially_filled"} and time.time() - _f(row.get("submitted_at", row.get("executing_at"))) > watchdog:
                oid = order_id(order)
                if oid:
                    await self.client.cancel_order(oid, Priority.EXIT_CRITICAL)
                    payload = await self.client.order(oid, Priority.EXIT_CRITICAL)
                    checked = _rows(payload)
                    order = checked[0] if checked else (payload if isinstance(payload, dict) else order)
            await self._apply_external_sell_truth(exit_id, plan, order)

    async def _inventory_once(self) -> None:
        view = self.state.view()
        positions = [row for row in view.get("positions", {}).values() if row.get("status") == "OPEN"]
        balances = await self.execution.balances_map(Priority.EXIT_WATCH)
        busy = self._busy_inventory_symbols(view)
        for position in positions:
            symbol = position["symbol"]
            if symbol in busy:
                self.log.info("INVENTORY DEFERRED %s | local order/approval state active", symbol)
                continue
            asset = symbol.removesuffix("-USD")
            venue = _f(balances.get(asset, {}).get("total"))
            managed = _f(position.get("quantity"))
            tolerance = max(1e-12, managed * 1e-6)
            if venue + tolerance < managed:
                confirmations = int(position.get("downward_confirmations", 0)) + 1
                if confirmations < 2:
                    await self.state.apply(
                        "INVENTORY_REDUCTION_DETECTED",
                        lambda state: state["positions"][symbol].update(
                            downward_confirmations=confirmations, observed_venue_quantity=venue
                        ),
                    )
                    self.log.warning("INVENTORY REDUCTION DETECTED %s managed=%s venue=%s | confirming", symbol, managed, venue)
                    continue
                status = "CLOSED_EXTERNAL" if venue <= tolerance else "OPEN"
                await self.state.apply(
                    "INVENTORY_REDUCTION_RECONCILED",
                    lambda state: state["positions"][symbol].update(
                        quantity=venue,
                        status=status,
                        downward_confirmations=0,
                        observed_venue_quantity=venue,
                        externally_reduced_at=time.time(),
                    ),
                )
                self._notify(
                    f"inventory-down:{symbol}:{venue}",
                    f"REVX v3 INVENTORY RECONCILED\n{symbol}\nManaged {managed} -> venue {venue} after two authenticated snapshots.\nNo order was submitted; external realized PnL is unknown.",
                )
            elif venue > managed + tolerance:
                excess = venue - managed
                if abs(_f(position.get("unmanaged_excess")) - excess) > tolerance:
                    await self.state.apply(
                        "INVENTORY_EXCESS_QUARANTINED",
                        lambda state: state["positions"][symbol].update(
                            downward_confirmations=0,
                            observed_venue_quantity=venue,
                            unmanaged_excess=excess,
                        ),
                    )
                    self._notify(
                        f"inventory-excess:{symbol}:{round(excess, 12)}",
                        f"REVX v3 UNMANAGED INVENTORY EXCESS\n{symbol}\nVenue {venue} > v3 managed {managed}.\nExcess {excess} is quarantined and will not inherit this position's stop/target.",
                    )
                await self._ensure_inventory_review(symbol, venue, managed)
            elif position.get("downward_confirmations") or position.get("unmanaged_excess"):
                await self.state.apply(
                    "INVENTORY_ALIGNED",
                    lambda state: state["positions"][symbol].update(
                        downward_confirmations=0, observed_venue_quantity=venue, unmanaged_excess=0
                    ),
                )

        # The authenticated balance snapshot is portfolio authority. Assets
        # without an OPEN local position are no longer invisible to v3.
        view = self.state.view()
        for asset, balance in balances.items():
            asset = str(asset).upper()
            venue = _f(balance.get("total"))
            if asset == "USD" or venue <= 0:
                continue
            symbol = f"{asset}-USD"
            position = view.get("positions", {}).get(symbol)
            if position and position.get("status") == "OPEN":
                continue
            if symbol in busy:
                continue
            await self._ensure_inventory_review(symbol, venue, 0.0)

        await self._reconcile_absent_inventory_reviews(balances)

        snapshot = {
            str(asset).upper(): round(_f(row.get("total")), 12)
            for asset, row in balances.items()
            if _f(row.get("total")) > 0
        }
        if snapshot != self.state.view().get("portfolio_inventory", {}):
            await self.state.apply(
                "PORTFOLIO_INVENTORY_SNAPSHOT",
                lambda state, value=snapshot: state.update(portfolio_inventory=value),
            )
        await self._external_exit_once()

    async def _reconcile_absent_inventory_reviews(self, balances: dict) -> None:
        """Close stale manual-inventory reviews from the same authenticated snapshot.

        A review can outlive an external sell or conversion.  It must never keep
        proposing an impossible SELL from an old quantity.  This is deliberately
        local-only: no order, history query, or notification is emitted here.
        """
        active_review_ids = {
            str(row.get("review_id"))
            for row in self.state.view().get("external_exits", {}).values()
            if row.get("status") in self.ACTIVE_EXTERNAL_EXIT and row.get("review_id")
        }
        stale_statuses = {
            "ANALYZING", "READY", "OBSERVED", "UNVERIFIED", "RETRY", "POLICY_EXIT_HELD",
            "DUST_UNTRADABLE",
        }
        view = self.state.view()
        resolved: list[tuple[str, str]] = []
        for review_id, review in view.get("inventory_reviews", {}).items():
            if review.get("status") not in stale_statuses or str(review_id) in active_review_ids:
                continue
            symbol = str(review.get("symbol", "")).upper().replace("/", "-")
            asset = symbol.removesuffix("-USD")
            if not asset or _f(balances.get(asset, {}).get("total")) > 0:
                continue
            position = view.get("positions", {}).get(symbol)
            if position and position.get("status") == "OPEN":
                continue
            resolved.append((str(review_id), symbol))

        if not resolved:
            return
        now = time.time()

        def commit(state):
            for review_id, symbol in resolved:
                review = state["inventory_reviews"].get(review_id)
                if not review or review.get("status") not in stale_statuses:
                    continue
                review.update(
                    status="CLOSED_EXTERNAL",
                    reconciled_at=now,
                    reconciled_venue_quantity=0.0,
                    reconciliation_reason="AUTHENTICATED_PORTFOLIO_ABSENT",
                )
                position = state.get("positions", {}).get(symbol)
                if position and position.get("status") != "OPEN":
                    position.update(observed_venue_quantity=0.0, unmanaged_excess=0.0)

        await self.state.apply("INVENTORY_REVIEW_ABSENT_RECONCILED", commit)
        for review_id, symbol in resolved:
            self.log.info(
                "INVENTORY REVIEW RECONCILED %s [%s] venue=0 | stale manual review closed locally; no order",
                symbol,
                review_id,
            )

    def _busy_inventory_symbols(self, view: dict) -> set[str]:
        busy = {
            str(row.get("symbol"))
            for row in view.get("signals", {}).values()
            if row.get("status") in self.ACTIVE_SIGNAL
        }
        busy.update(
            str(row.get("symbol"))
            for row in view.get("exits", {}).values()
            if row.get("status") in self.ACTIVE_EXIT
        )
        busy.update(
            str(row.get("symbol"))
            for row in view.get("external_exits", {}).values()
            if row.get("status") in self.ACTIVE_EXTERNAL_EXIT
        )
        return busy

    async def _ensure_inventory_review(
        self, symbol: str, venue_quantity: float, managed_quantity: float
    ) -> None:
        symbol = symbol.upper().replace("/", "-")
        fingerprint = f"{venue_quantity:.12g}:{managed_quantity:.12g}"
        now = time.time()
        reviews = self.state.view().get("inventory_reviews", {})
        dust_rows = [
            (str(review_id), row)
            for review_id, row in reviews.items()
            if row.get("symbol") == symbol and row.get("status") == "DUST_UNTRADABLE"
        ]
        if dust_rows:
            dust_id, dust = max(dust_rows, key=lambda item: _f(item[1].get("dust_at")))
            minimum = _f(dust.get("dust_minimum_executable_quantity"))
            tolerance = max(1e-12, minimum * 1e-9)
            if minimum > 0 and venue_quantity + tolerance < minimum:
                if dust.get("fingerprint") != fingerprint:
                    await self.state.apply(
                        "PORTFOLIO_DUST_BALANCE_TRACKED",
                        lambda state, rid=dust_id: state["inventory_reviews"][rid].update(
                            fingerprint=fingerprint,
                            venue_quantity=venue_quantity,
                            managed_quantity=managed_quantity,
                            dust_last_seen_at=time.time(),
                        ),
                    )
                return
            await self.state.apply(
                "PORTFOLIO_DUST_REARMED",
                lambda state, rid=dust_id: state["inventory_reviews"][rid].update(
                    status="SUPERSEDED",
                    superseded_at=time.time(),
                    superseded_reason="BALANCE_REACHED_MINIMUM_EXECUTABLE_QUANTITY",
                ),
            )
        for row in reviews.values():
            if row.get("symbol") != symbol or row.get("fingerprint") != fingerprint:
                continue
            if row.get("status") in {
                "ANALYZING", "READY", "OBSERVED", "ADOPTED", "UNVERIFIED",
                "POLICY_EXIT_PENDING", "POLICY_EXIT_HELD", "POLICY_EXIT_EXECUTING",
                "DUST_UNTRADABLE",
            }:
                return
            if row.get("status") == "RETRY" and now < _f(row.get("retry_at")):
                return

        review_id = secrets.token_hex(5)

        def start_review(state):
            for old in state["inventory_reviews"].values():
                if old.get("symbol") == symbol and old.get("status") in {"ANALYZING", "READY", "UNVERIFIED", "DUST_UNTRADABLE"}:
                    old.update(status="SUPERSEDED", superseded_at=now)
            state["inventory_reviews"][review_id] = {
                "id": review_id,
                "symbol": symbol,
                "status": "ANALYZING",
                "fingerprint": fingerprint,
                "created_at": now,
                "venue_quantity": venue_quantity,
                "managed_quantity": managed_quantity,
                "excess_quantity": max(0.0, venue_quantity - managed_quantity),
            }

        await self.state.apply("MANUAL_INVENTORY_DETECTED", start_review)
        try:
            active = _rows(await self.client.active_orders(symbol, Priority.EXIT_WATCH))
            if active:
                await self.state.apply(
                    "MANUAL_INVENTORY_ACTIVE_ORDER_DEFERRED",
                    lambda state: state["inventory_reviews"][review_id].update(
                        status="RETRY", error="venue order still active",
                        retry_at=time.time() + 60,
                    ),
                )
                return
            history_hours = int(self.config.get("manual_inventory_history_hours", 24))
            payload = await self.client.historical_orders(
                symbol, history_hours, Priority.EXIT_WATCH
            )
            orders = _rows(payload)
            current_view = self.state.view()
            match = unique_buy_lot_match(
                orders,
                symbol,
                max(0.0, venue_quantity - managed_quantity),
                owned_order_ids(current_view),
            )
            if match.get("status") != "MATCHED":
                await self.state.apply(
                    "MANUAL_INVENTORY_UNVERIFIED",
                    lambda state: state["inventory_reviews"][review_id].update(
                        status="UNVERIFIED", match=match, checked_at=time.time()
                    ),
                )
                self._notify(
                    f"manual-unverified:{review_id}",
                    f"REVX v3 MANUAL INVENTORY UNVERIFIED [{review_id}]\n"
                    f"{symbol} | Venue {venue_quantity} | Managed {managed_quantity}\n"
                    f"Exact recent BUY-lot match: {match.get('status')}.\n"
                    "Fail-closed: no stop/target or SELL authority is attached.",
                    [[{"text": "OBSERVE ONLY", "callback_data": f"V3OBSERVE:{review_id}"}]],
                )
                return

            decision = await self.execution.fresh_decision(symbol, "STANDARD")
            spread_ratio = max(0.0, _f(decision.spread_pct)) / 100.0
            fresh_bid = _f(decision.entry) * (1.0 - spread_ratio / 2.0) / (1.0 + spread_ratio / 2.0)
            proposed_stop = _f(decision.stop)
            if fresh_bid <= 0 or proposed_stop <= 0 or proposed_stop >= fresh_bid:
                raise ExecutionRefused("fresh manual-management geometry has no valid protective stop")
            existing = current_view.get("positions", {}).get(symbol, {})
            old_cost = managed_quantity * _f(existing.get("average_entry_price"))
            average_entry = (old_cost + _f(match.get("cost_usd"))) / venue_quantity
            proposed_target = (
                _f(decision.target)
                if _f(decision.target) > max(fresh_bid, average_entry)
                else 0.0
            )
            proposal = {
                "quantity": venue_quantity,
                "average_entry_price": average_entry,
                "stop": proposed_stop,
                "target": proposed_target,
                "fresh_bid": fresh_bid,
                "assessment": decision.verdict,
                "assessment_blockers": list(decision.blockers),
                "quality": decision.quality,
            }
            await self.state.apply(
                "MANUAL_INVENTORY_REVIEW_READY",
                lambda state: state["inventory_reviews"][review_id].update(
                    status="READY",
                    checked_at=time.time(),
                    match=match,
                    proposal=proposal,
                ),
            )
            target_text = proposed_target if proposed_target > 0 else "TRAIL_ONLY"
            blockers = ",".join(decision.blockers) or "PASS"
            self._notify(
                f"manual-ready:{review_id}",
                f"REVX v3 MANUAL INVENTORY REVIEW [{review_id}]\n"
                f"{symbol} | Venue {venue_quantity} | Previously managed {managed_quantity}\n"
                f"Exact BUY lots {len(match['lots'])} | Effective entry {average_entry:.10g}\n"
                f"Fresh stop {proposed_stop:.10g} | Target {target_text}\n"
                f"Market assessment {decision.verdict}: {blockers}\n"
                "ADOPT & MANAGE changes local ownership only; it submits no order. "
                "Future SELL still requires a fresh trigger and Telegram approval.",
                [[
                    {"text": "ADOPT & MANAGE", "callback_data": f"V3ADOPT:{review_id}"},
                    {"text": "OBSERVE ONLY", "callback_data": f"V3OBSERVE:{review_id}"},
                ]],
            )
        except Exception as exc:
            await self.state.apply(
                "MANUAL_INVENTORY_REVIEW_RETRY",
                lambda state: state["inventory_reviews"][review_id].update(
                    status="RETRY", error=str(exc), retry_at=time.time() + 300
                ),
            )
            raise

    async def _external_exit_once(self) -> None:
        """Offer an explicit SELL ALL only for unmanaged inventory that fails both policies."""
        now = time.time()
        await self._expire_pending_external_exits(now)
        view = self.state.view()
        active_symbols = {
            str(row.get("symbol"))
            for row in view.get("external_exits", {}).values()
            if row.get("status") in self.ACTIVE_EXTERNAL_EXIT
        }
        for review_id, review in list(view.get("inventory_reviews", {}).items()):
            if review.get("status") not in {"READY", "UNVERIFIED", "POLICY_EXIT_HELD"}:
                continue
            if now < _f(review.get("policy_retry_at")):
                continue
            symbol = str(review.get("symbol", "")).upper().replace("/", "-")
            venue_quantity = _f(review.get("venue_quantity"))
            if not symbol or venue_quantity <= 0 or symbol in active_symbols:
                continue
            position = view.get("positions", {}).get(symbol)
            if position and position.get("status") == "OPEN":
                continue
            try:
                standard, ambitious = await self._portfolio_policy_decisions(symbol)
            except Exception as exc:
                await self.state.apply(
                    "PORTFOLIO_EXIT_POLICY_RETRY",
                    lambda state, rid=review_id, detail=str(exc): state["inventory_reviews"][rid].update(
                        policy_retry_at=time.time() + 300, policy_error=detail
                    ),
                )
                self.log.warning("PORTFOLIO EXIT ASSESSMENT DEFERRED %s: %s", symbol, exc)
                continue
            if standard.verdict == "CANDIDATE" or ambitious.verdict == "CANDIDATE":
                await self.state.apply(
                    "PORTFOLIO_EXIT_POLICY_CONFORMING",
                    lambda state, rid=review_id: state["inventory_reviews"][rid].update(
                        policy_checked_at=time.time(),
                        policy_retry_at=time.time() + float(self.config.get("external_policy_review_sec", 60)),
                        policy_standard=asdict(standard),
                        policy_ambitious=asdict(ambitious),
                    ),
                )
                continue
            held = review.get("status") == "POLICY_EXIT_HELD"
            if held:
                previous_entry = _f((review.get("policy_standard") or {}).get("entry"))
                current_entry = _f(standard.entry)
                deterioration_pct = (
                    (previous_entry - current_entry) / previous_entry * 100.0
                    if previous_entry > 0 and current_entry > 0 else 0.0
                )
                reoffer_drawdown = float(self.config.get("external_hold_reoffer_drawdown_pct", 2.5))
                reoffer_after = float(self.config.get("external_hold_reoffer_sec", 3600))
                held_age = now - _f(review.get("held_at"))
                if deterioration_pct < reoffer_drawdown and held_age < reoffer_after:
                    await self.state.apply(
                        "PORTFOLIO_EXIT_HELD_RECHECK",
                        lambda state, rid=review_id: state["inventory_reviews"][rid].update(
                            policy_checked_at=time.time(),
                            policy_retry_at=time.time() + float(self.config.get("external_policy_review_sec", 60)),
                            policy_standard=asdict(standard),
                            policy_ambitious=asdict(ambitious),
                            last_held_deterioration_pct=round(deterioration_pct, 4),
                        ),
                    )
                    continue
            exit_id = "pex" + secrets.token_hex(4)
            try:
                plan = await self.execution.build_sell_plan(
                    exit_id,
                    {"symbol": symbol, "quantity": venue_quantity},
                    "PORTFOLIO_POLICY_EXIT",
                    "ALL_AVAILABLE",
                    external=True,
                )
            except Exception as exc:
                if isinstance(exc, DustUntradable):
                    detail = str(exc)
                    await self.state.apply(
                        "PORTFOLIO_DUST_QUARANTINED",
                        lambda state, rid=review_id, reason=detail, dust=exc: state["inventory_reviews"][rid].update(
                            status="DUST_UNTRADABLE",
                            dust_at=time.time(),
                            dust_reason=reason,
                            dust_available_quantity=dust.available_quantity,
                            dust_minimum_executable_quantity=dust.minimum_executable_quantity,
                            dust_minimum_notional=dust.minimum_notional,
                            policy_retry_at=0,
                            policy_error=None,
                            policy_standard=asdict(standard),
                            policy_ambitious=asdict(ambitious),
                        ),
                    )
                    self.log.info(
                        "PORTFOLIO DUST HELD %s qty=%s | %s | no retry until authenticated balance changes",
                        symbol,
                        venue_quantity,
                        detail,
                    )
                    continue
                await self.state.apply(
                    "PORTFOLIO_EXIT_PREFLIGHT_RETRY",
                    lambda state, rid=review_id, detail=str(exc): state["inventory_reviews"][rid].update(
                        policy_retry_at=time.time() + 300, policy_error=detail
                    ),
                )
                self.log.warning("PORTFOLIO EXIT PREFLIGHT REFUSED %s: %s", symbol, exc)
                continue

            def commit(state):
                state["external_exits"][exit_id] = {
                    "id": exit_id,
                    "review_id": review_id,
                    "symbol": symbol,
                    "reason": "PORTFOLIO_POLICY_EXIT",
                    "status": "PENDING",
                    "review_prior_status": review.get("status"),
                    "reoffer_reason": (
                        "HELD_DRAWDOWN_OR_REVIEW_DUE"
                        if held else "INITIAL_POLICY_FAILURE"
                    ),
                    "created_at": time.time(),
                    "plan": asdict(plan),
                    "policy_standard": asdict(standard),
                    "policy_ambitious": asdict(ambitious),
                }
                state["inventory_reviews"][review_id].update(
                    status="POLICY_EXIT_PENDING",
                    policy_checked_at=time.time(),
                    policy_standard=asdict(standard),
                    policy_ambitious=asdict(ambitious),
                    policy_exit_id=exit_id,
                )

            await self.state.apply("PORTFOLIO_EXIT_OFFERED", commit)
            standard_blockers = ",".join(standard.blockers) or "PASS"
            ambitious_blockers = ",".join(ambitious.blockers) or "PASS"
            dominant_reason = str((standard.blockers or ambitious.blockers or ("no_current_long_plan",))[0])
            self._notify(
                f"portfolio-exit:{exit_id}",
                f"REVX v3 PORTFOLIO EXIT PROPOSAL [{exit_id}]\n"
                f"{symbol} | external/manual qty {plan.quantity}\n"
                "ASSESSMENT: agentul nu vede acum un plan LONG executabil; aceasta nu este o predicție sigură de scădere.\n"
                f"WHY NOW: {dominant_reason} | R/R {standard.structural_rr:.3f} | spread {standard.spread_pct:.3f}% | trend {standard.trend_1h_pct:.2f}%/{standard.trend_6h_pct:.2f}%\n"
                f"STANDARD {standard.verdict}: {standard_blockers}\n"
                f"AMBITIOUS {ambitious.verdict}: {ambitious_blockers}\n"
                f"EXECUTABLE SELL ALL NOW: limit {plan.limit_price} | slip {plan.estimated_slippage_pct:.4f}% | cover {plan.coverage_pct:.1f}%\n"
                f"SELL ALL submits only after final revalidation; KEEP declines this proposal. Expires in {int(self.config.get('exit_approval_ttl_sec', 60))}s.",
                [[{"text": "SELL ALL", "callback_data": f"V3XSELL:{exit_id}"}],
                 [{"text": "KEEP", "callback_data": f"V3XHOLD:{exit_id}"}]],
            )
            self.log.info(
                "PORTFOLIO EXIT OFFERED %s [%s] qty=%s%s",
                symbol,
                exit_id,
                plan.quantity,
                " after held-inventory deterioration/review" if held else "",
            )
            active_symbols.add(symbol)

    async def _expire_pending_external_exits(self, now: float) -> None:
        ttl = float(self.config.get("exit_approval_ttl_sec", 60))
        expired = [
            (exit_id, row.get("review_id"))
            for exit_id, row in self.state.view().get("external_exits", {}).items()
            if row.get("status") == "PENDING" and now - _f(row.get("created_at")) > ttl
        ]
        if not expired:
            return

        def commit(state):
            for exit_id, review_id in expired:
                row = state["external_exits"].get(exit_id)
                if not row or row.get("status") != "PENDING":
                    continue
                row.update(status="EXPIRED", expired_at=now)
                review = state["inventory_reviews"].get(str(review_id))
                if review and review.get("status") == "POLICY_EXIT_PENDING":
                    review.update(
                        status=row.get("review_prior_status", "UNVERIFIED"),
                        policy_retry_at=now + 900,
                    )

        await self.state.apply("PORTFOLIO_EXIT_PASSIVE_EXPIRY", commit)

    async def _confirm_external_sell(self, callback_id: str, exit_id: str) -> None:
        async with self._execution_lock:
            view = self.state.view()
            row = view.get("external_exits", {}).get(exit_id)
            if not row or row.get("status") != "PENDING":
                await self.telegram.answer(callback_id, "Portfolio exit unavailable")
                return
            if time.time() - _f(row.get("created_at")) > float(self.config.get("exit_approval_ttl_sec", 60)):
                await self._expire_pending_external_exits(time.time())
                await self.telegram.answer(callback_id, "Approval expired; no order")
                return
            if not bool(self.config.get("execution_enabled", False)):
                await self.telegram.answer(callback_id, "Execution is not armed")
                return
            await self.telegram.answer(callback_id, "Final SELL ALL revalidation")
            try:
                standard, ambitious = await self._portfolio_policy_decisions(row["symbol"])
                if standard.verdict == "CANDIDATE" or ambitious.verdict == "CANDIDATE":
                    raise ExecutionRefused("asset now conforms to an entry policy; fresh human decision required")
                approved = SellPlan(**row["plan"])
                fresh = await self.execution.build_sell_plan(
                    exit_id,
                    {"symbol": row["symbol"], "quantity": approved.quantity},
                    "PORTFOLIO_POLICY_EXIT",
                    "ALL_AVAILABLE",
                    external=True,
                )
                if fresh.trigger_bid < approved.trigger_bid:
                    drift = (approved.trigger_bid - fresh.trigger_bid) / approved.trigger_bid * 100
                    if drift > float(self.config.get("exit_max_adverse_drift_pct", 0.50)):
                        raise ExecutionRefused(f"adverse bid drift {drift:.3f}% requires a fresh approval")
                await self.state.apply(
                    "PORTFOLIO_EXIT_EXECUTING",
                    lambda state: state["external_exits"][exit_id].update(
                        status="SELL_EXECUTING", executing_at=time.time(), execution_plan=asdict(fresh)
                    ),
                )
                order = await self.execution.submit_sell(fresh)
                await self._apply_external_sell_truth(exit_id, fresh, order)
            except ExecutionUnknown as exc:
                await self.state.apply(
                    "PORTFOLIO_EXIT_EXECUTION_UNKNOWN",
                    lambda state: state["external_exits"][exit_id].update(status="EXECUTION_UNKNOWN", error=str(exc)),
                )
                self._notify(f"portfolio-exit-unknown:{exit_id}", f"SELL STATUS UNKNOWN\n{row['symbol']} [{exit_id}]\n{exc}\nNo retry before venue reconciliation.")
            except Exception as exc:
                executing = self.state.view().get("external_exits", {}).get(exit_id, {}).get("status") == "SELL_EXECUTING"
                status = "EXECUTION_UNKNOWN" if executing else "SELL_REFUSED"
                def refuse(state):
                    external = state["external_exits"][exit_id]
                    external.update(status=status, error=str(exc))
                    if not executing:
                        review = state["inventory_reviews"].get(str(external.get("review_id")))
                        if review and review.get("status") == "POLICY_EXIT_PENDING":
                            review.update(
                                status=external.get("review_prior_status", "UNVERIFIED"),
                                policy_retry_at=time.time() + 300,
                            )
                await self.state.apply(
                    "PORTFOLIO_EXIT_EXECUTION_UNKNOWN" if executing else "PORTFOLIO_EXIT_REFUSED",
                    refuse,
                )
                text = "SELL STATUS UNKNOWN" if executing else "SELL REFUSED - NO ORDER"
                self._notify(f"portfolio-exit-result:{exit_id}:{status}", f"{text}\n{row['symbol']} [{exit_id}]\n{exc}")

    async def _apply_external_sell_truth(self, exit_id: str, plan: SellPlan, order: dict) -> None:
        venue_id = order_id(order)
        filled = _f(order.get("filled_quantity"))
        leaves = _f(order.get("leaves_quantity"), max(0.0, plan.quantity - filled))
        avg = _f(order.get("average_fill_price"), plan.limit_price)
        venue_status = order_status(order)
        terminal = venue_status in {"cancelled", "canceled", "rejected", "expired"}
        complete = leaves <= max(1e-12, plan.quantity * 1e-9) or venue_status == "filled"
        if filled > 0 and complete:
            status = "SELL_FILLED"
        elif filled > 0 and terminal:
            status = "SELL_PARTIAL_FINAL"
        elif filled > 0:
            status = "SELL_PARTIAL"
        elif terminal:
            status = "SELL_CANCELLED"
        else:
            status = "ORDER_SUBMITTED"

        def commit(state):
            row = state["external_exits"][exit_id]
            review = state["inventory_reviews"].get(str(row.get("review_id")))
            row.update(
                status=status, venue_order_id=venue_id, client_order_id=plan.client_order_id,
                order=order, submitted_at=row.get("submitted_at", time.time()),
                filled_quantity=filled, leaves_quantity=leaves, average_fill_price=avg,
                scope="ALL_AVAILABLE", venue_available_at_execution=plan.venue_available,
            )
            if not review:
                return
            if complete:
                review.update(status="EXIT_FILLED", closed_at=time.time())
            elif terminal:
                review.update(
                    status=row.get("review_prior_status", "UNVERIFIED"),
                    policy_retry_at=time.time() + 300,
                )
            else:
                review.update(status="POLICY_EXIT_EXECUTING")

        await self.state.apply("PORTFOLIO_EXIT_VENUE_TRUTH", commit)
        self._notify(
            f"portfolio-exit-accepted:{exit_id}:{status}:{filled}",
            f"SELL ACCEPTED\n{plan.symbol} [{exit_id}]\nOrder {venue_id}\n"
            f"Scope ALL_AVAILABLE | Status {status} | Filled {filled} | Leaves {leaves} | Avg {avg}\n"
            "External cost basis/PnL remains unknown.",
        )
        self.log.info("PORTFOLIO SELL ACCEPTED %s [%s] order=%s status=%s filled=%s leaves=%s", plan.symbol, exit_id, venue_id, status, filled, leaves)

    async def _portfolio_policy_decisions(self, symbol: str):
        shared = getattr(self.execution, "fresh_decisions", None)
        if callable(shared):
            return await shared(symbol)
        return (
            await self.execution.fresh_decision(symbol, "STANDARD"),
            await self.execution.fresh_decision(symbol, "AMBITIOUS"),
        )

    async def _hold_external_exit(self, callback_id: str, exit_id: str) -> None:
        row = self.state.view().get("external_exits", {}).get(exit_id)
        if not row or row.get("status") != "PENDING":
            await self.telegram.answer(callback_id, "Portfolio exit unavailable")
            return

        def commit(state):
            state["external_exits"][exit_id].update(status="HELD", held_at=time.time())
            review = state["inventory_reviews"].get(str(row.get("review_id")))
            if review:
                review.update(status="POLICY_EXIT_HELD", held_at=time.time())

        await self.state.apply("PORTFOLIO_EXIT_HELD", commit)
        await self.telegram.answer(callback_id, "KEEP recorded; no order")

    async def _adopt_inventory(self, callback_id: str, review_id: str) -> None:
        async with self._execution_lock:
            view = self.state.view()
            review = view.get("inventory_reviews", {}).get(review_id)
            if not review or review.get("status") != "READY":
                await self.telegram.answer(callback_id, "Inventory review unavailable")
                return
            if time.time() - _f(review.get("checked_at")) > float(
                self.config.get("manual_inventory_review_ttl_sec", 600)
            ):
                await self.state.apply(
                    "MANUAL_INVENTORY_REVIEW_EXPIRED",
                    lambda state: state["inventory_reviews"][review_id].update(status="EXPIRED"),
                )
                await self.telegram.answer(callback_id, "Review expired; wait for a fresh inventory review")
                return
            symbol = review["symbol"]
            if symbol in self._busy_inventory_symbols(view):
                await self.telegram.answer(callback_id, "Local approval/order state active; adoption refused")
                return
            await self.telegram.answer(callback_id, "Revalidating venue inventory and BUY lots")
            active = _rows(await self.client.active_orders(symbol, Priority.EXIT_CRITICAL))
            if active:
                await self.telegram.answer(callback_id, "Venue order active; adoption refused")
                return
            balances = await self.execution.balances_map(Priority.EXIT_CRITICAL)
            asset = symbol.removesuffix("-USD")
            venue = _f(balances.get(asset, {}).get("total"))
            expected = _f(review.get("venue_quantity"))
            tolerance = max(1e-10, expected * 1e-6)
            position = view.get("positions", {}).get(symbol)
            managed = _f(position.get("quantity")) if position and position.get("status") == "OPEN" else 0.0
            if abs(venue - expected) > tolerance or abs(managed - _f(review.get("managed_quantity"))) > tolerance:
                await self.state.apply(
                    "MANUAL_INVENTORY_REVIEW_STALE",
                    lambda state: state["inventory_reviews"][review_id].update(status="STALE"),
                )
                await self.telegram.answer(callback_id, "Inventory changed; wait for a fresh review")
                return
            history = _rows(await self.client.historical_orders(
                symbol,
                int(self.config.get("manual_inventory_history_hours", 24)),
                Priority.EXIT_CRITICAL,
            ))
            match = unique_buy_lot_match(
                history,
                symbol,
                max(0.0, venue - managed),
                owned_order_ids(view),
            )
            expected_ids = {
                str(row.get("venue_order_id")) for row in review.get("match", {}).get("lots", [])
            }
            fresh_ids = {
                str(row.get("venue_order_id")) for row in match.get("lots", [])
            }
            if match.get("status") != "MATCHED" or fresh_ids != expected_ids:
                await self.state.apply(
                    "MANUAL_INVENTORY_REVIEW_STALE",
                    lambda state: state["inventory_reviews"][review_id].update(status="STALE"),
                )
                await self.telegram.answer(callback_id, "BUY-lot truth changed; wait for a fresh review")
                return

            proposal = review["proposal"]
            lots = list(review["match"]["lots"])
            adopted_at = time.time()

            def commit(state):
                old = state["positions"].get(symbol)
                if old and old.get("status") == "OPEN":
                    prior_lots = list(old.get("manual_lots", []))
                    old.update(
                        quantity=venue,
                        original_filled_quantity=venue,
                        average_entry_price=proposal["average_entry_price"],
                        stop=proposal["stop"],
                        target=proposal["target"],
                        observed_venue_quantity=venue,
                        unmanaged_excess=0,
                        downward_confirmations=0,
                        quantity_source="VENUE_AUTHORITY_EXACT_LOTS",
                        manual_lots=prior_lots + lots,
                        manual_adopted_at=adopted_at,
                        trail_armed=False,
                        trail_breach_confirmations=0,
                        high_watermark_bid=proposal["fresh_bid"],
                        last_exit_alert_at=0,
                    )
                else:
                    opened_ms = min((int(row.get("created_date", 0)) for row in lots), default=0)
                    state["positions"][symbol] = {
                        "status": "OPEN",
                        "symbol": symbol,
                        "quantity": venue,
                        "original_filled_quantity": venue,
                        "average_entry_price": proposal["average_entry_price"],
                        "stop": proposal["stop"],
                        "target": proposal["target"],
                        "opened_at": opened_ms / 1000 if opened_ms > 0 else adopted_at,
                        "entry_signal_id": f"manual:{review_id}",
                        "entry_order_id": lots[0]["venue_order_id"] if len(lots) == 1 else "MULTI_LOT",
                        "quantity_source": "VENUE_AUTHORITY_EXACT_LOTS",
                        "manual_lots": lots,
                        "manual_adopted_at": adopted_at,
                        "observed_venue_quantity": venue,
                        "unmanaged_excess": 0,
                        "downward_confirmations": 0,
                        "trail_armed": False,
                        "trail_breach_confirmations": 0,
                        "high_watermark_bid": proposal["fresh_bid"],
                        "last_exit_alert_at": 0,
                    }
                state["inventory_reviews"][review_id].update(
                    status="ADOPTED", adopted_at=adopted_at
                )

            await self.state.apply("MANUAL_INVENTORY_ADOPTED", commit)
            await self.telegram.answer(callback_id, "Inventory adopted; no order submitted")
            target_text = proposal["target"] if _f(proposal.get("target")) > 0 else "TRAIL_ONLY"
            self._notify(
                f"manual-adopted:{review_id}",
                f"REVX v3 MANUAL INVENTORY MANAGED [{review_id}]\n"
                f"{symbol} | Qty {venue} | Entry {proposal['average_entry_price']:.10g}\n"
                f"Stop {proposal['stop']:.10g} | Target {target_text}\n"
                "No order was submitted. Future exits remain trigger- and Telegram-gated.",
            )
            self.log.info(
                "MANUAL INVENTORY ADOPTED %s qty=%s lots=%d | NO ORDER",
                symbol, venue, len(lots),
            )

    async def _observe_inventory(self, callback_id: str, review_id: str) -> None:
        review = self.state.view().get("inventory_reviews", {}).get(review_id)
        if not review or review.get("status") not in {"READY", "UNVERIFIED"}:
            await self.telegram.answer(callback_id, "Inventory review unavailable")
            return
        await self.state.apply(
            "MANUAL_INVENTORY_OBSERVED",
            lambda state: state["inventory_reviews"][review_id].update(
                status="OBSERVED", observed_at=time.time()
            ),
        )
        await self.telegram.answer(callback_id, "Inventory left unmanaged; no order submitted")

    async def _terminal_signal(self, callback_id: str, signal_id: str, status: str, answer: str) -> None:
        row = self.state.view().get("signals", {}).get(signal_id)
        if not row or row.get("status") not in {"PENDING", "AWAITING_CONFIRM"}:
            await self.telegram.answer(callback_id, "Signal unavailable")
            return
        await self.state.apply("ENTRY_TERMINAL", lambda state: state["signals"][signal_id].update(status=status))
        await self.telegram.answer(callback_id, answer)

    async def _cancel_buy(self, callback_id: str, signal_id: str, token: str) -> None:
        row = self.state.view().get("signals", {}).get(signal_id)
        if not row or row.get("status") != "AWAITING_CONFIRM" or token != row.get("confirmation_token"):
            await self.telegram.answer(callback_id, "Confirmation unavailable")
            return
        await self.state.apply("BUY_CANCELLED", lambda state: state["signals"][signal_id].update(status="CANCELLED"))
        await self.telegram.answer(callback_id, "Cancelled; no order")

    async def _hold_exit(self, callback_id: str, exit_id: str) -> None:
        view = self.state.view()
        row = view.get("exits", {}).get(exit_id)
        if not row or row.get("status") != "PENDING":
            await self.telegram.answer(callback_id, "Exit unavailable")
            return
        await self.state.apply("EXIT_HELD", lambda state: state["exits"][exit_id].update(status="HELD", held_at=time.time()))
        await self.telegram.answer(callback_id, "HOLD recorded; no order")

    async def _deliver_outbox(self) -> None:
        delivered = await asyncio.to_thread(self.outbox.deliver_ready, self.telegram.send_sync, 10)
        if delivered:
            self.log.info("TELEGRAM OUTBOX delivered=%d", delivered)
        now = time.monotonic()
        heartbeat = float(self.config.get("outbox_heartbeat_sec", 300))
        if now - self._last_outbox_health_log >= heartbeat:
            health = await asyncio.to_thread(self.outbox.health)
            self.log.info(
                "TELEGRAM OUTBOX HEALTH pending=%d retrying=%d delivered=%d maxAttempts=%d oldestDue=%.1fs%s",
                health["pending"],
                health["retrying"],
                health["delivered"],
                health["max_attempts"],
                health["oldest_due_age_sec"],
                f" lastError={health['last_error']}" if health["last_error"] else "",
            )
            self._last_outbox_health_log = now

    def _notify(self, key: str, text: str, buttons: list | None = None) -> None:
        try:
            self.outbox.enqueue(key, text, buttons)
        except Exception as exc:
            self.log.error("TELEGRAM OUTBOX ENQUEUE FAILED key=%s: %s", key, exc)

    def _append_trade(self, position: dict, exit_id: str, order: dict) -> None:
        self.trade_ledger.parent.mkdir(parents=True, exist_ok=True)
        entry = _f(position.get("average_entry_price"))
        exit_price = _f(position.get("exit_price"))
        qty = _f(
            position.get("exit_managed_quantity"),
            _f(position.get("original_filled_quantity"), _f(order.get("filled_quantity"))),
        )
        total_filled = _f(order.get("filled_quantity"), qty)
        total_fee = _f(order.get("total_fee")) if str(order.get("fee_currency", "")).upper() == "USD" else 0.0
        fee = total_fee * min(1.0, qty / total_filled) if total_filled > 0 else 0.0
        record = {
            "closed_at": position.get("closed_at"),
            "symbol": position.get("symbol"),
            "entry_signal_id": position.get("entry_signal_id"),
            "exit_id": exit_id,
            "entry_price": entry,
            "exit_price": exit_price,
            "quantity": qty,
            "reason": position.get("exit_reason"),
            "scope": position.get("exit_scope", "MANAGED"),
            "net_pnl_usd": (exit_price - entry) * qty - fee,
            "managed_fee_usd": fee,
            "total_order_filled_quantity": total_filled,
            "unmanaged_sold_quantity": _f(position.get("unmanaged_sold_quantity")),
            "external_cost_basis_unknown": bool(position.get("external_cost_basis_unknown")),
            "exit_order_id": position.get("exit_order_id"),
        }
        with self.trade_ledger.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, separators=(",", ":"), ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
