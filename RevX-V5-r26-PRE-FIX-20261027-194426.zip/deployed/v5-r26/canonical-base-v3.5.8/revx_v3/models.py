from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Awaitable, Callable


class Priority(IntEnum):
    EXIT_CRITICAL = 0
    EXIT_WATCH = 10
    ENTRY = 20
    DISCOVERY = 30


class RequestKind(IntEnum):
    AUTH = 0
    PUBLIC = 1


@dataclass(order=True)
class RequestJob:
    priority: int
    sequence: int
    lane: Priority = field(compare=False)
    kind: RequestKind = field(compare=False)
    action: str = field(compare=False)
    operation: Callable[[], Awaitable[Any]] = field(compare=False)
    future: Any = field(compare=False)


@dataclass(frozen=True)
class Quote:
    symbol: str
    bid: float
    ask: float
    spread_pct: float
    source: str
    api_time: int | None = None

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0


@dataclass(frozen=True)
class Candidate:
    symbol: str
    score: float
    change_24h_pct: float
    quote: Quote
    momentum: dict[str, float | bool] = field(default_factory=dict)


@dataclass(frozen=True)
class Decision:
    symbol: str
    lane: str
    verdict: str
    quality: float
    risk_pct: float
    structural_rr: float
    entry: float
    stop: float
    target: float
    spread_pct: float
    trend_1h_pct: float
    trend_6h_pct: float
    volume_accel: float
    target_basis: str
    blockers: tuple[str, ...]
    observed_at: float
    trend_ladder: dict[str, float] = field(default_factory=dict)
