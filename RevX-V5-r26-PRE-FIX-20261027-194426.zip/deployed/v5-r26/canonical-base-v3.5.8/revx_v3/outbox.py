from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Callable


class DurableOutbox:
    """Delivery truth: suppression starts only after Telegram acknowledges."""

    def __init__(self, path: Path, clock=time.time):
        self.path = path
        self.clock = clock
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute(
            """CREATE TABLE IF NOT EXISTS messages (
                dedupe_key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                status TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                next_attempt REAL NOT NULL,
                delivered_at REAL,
                telegram_message_id TEXT,
                last_error TEXT
            )"""
        )
        self.db.commit()

    def enqueue(self, dedupe_key: str, text: str, buttons: list | None = None) -> bool:
        payload = json.dumps({"text": text, "buttons": buttons}, ensure_ascii=False)
        with self._lock:
            before = self.db.total_changes
            self.db.execute(
                "INSERT OR IGNORE INTO messages(dedupe_key,payload,status,next_attempt) VALUES(?,?,'PENDING',?)",
                (dedupe_key, payload, self.clock()),
            )
            self.db.commit()
            return self.db.total_changes > before

    def deliver_ready(self, sender: Callable[[str, list | None], str], limit: int = 10) -> int:
        with self._lock:
            now = self.clock()
            rows = self.db.execute(
                "SELECT dedupe_key,payload,attempts FROM messages WHERE status='PENDING' AND next_attempt<=? ORDER BY rowid LIMIT ?",
                (now, limit),
            ).fetchall()
            delivered = 0
            for key, raw, attempts in rows:
                payload = json.loads(raw)
                try:
                    message_id = str(sender(payload["text"], payload.get("buttons")))
                except Exception as exc:
                    attempts += 1
                    delay = min(300.0, 2.0 ** min(attempts, 8))
                    self.db.execute(
                        "UPDATE messages SET attempts=?,next_attempt=?,last_error=? WHERE dedupe_key=?",
                        (attempts, now + delay, str(exc)[:500], key),
                    )
                else:
                    self.db.execute(
                        "UPDATE messages SET status='DELIVERED',attempts=?,delivered_at=?,telegram_message_id=?,last_error=NULL WHERE dedupe_key=?",
                        (attempts + 1, now, message_id, key),
                    )
                    delivered += 1
            self.db.commit()
            return delivered

    def status(self, dedupe_key: str) -> str | None:
        with self._lock:
            row = self.db.execute("SELECT status FROM messages WHERE dedupe_key=?", (dedupe_key,)).fetchone()
            return row[0] if row else None

    def health(self) -> dict:
        """Cheap local delivery telemetry; never performs a network request."""
        with self._lock:
            now = self.clock()
            pending, retrying, delivered, max_attempts, oldest = self.db.execute(
                """SELECT
                    SUM(CASE WHEN status='PENDING' THEN 1 ELSE 0 END),
                    SUM(CASE WHEN status='PENDING' AND attempts>0 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN status='DELIVERED' THEN 1 ELSE 0 END),
                    MAX(CASE WHEN status='PENDING' THEN attempts ELSE 0 END),
                    MIN(CASE WHEN status='PENDING' THEN next_attempt END)
                   FROM messages"""
            ).fetchone()
            last_error = self.db.execute(
                """SELECT last_error FROM messages
                   WHERE status='PENDING' AND last_error IS NOT NULL
                   ORDER BY rowid DESC LIMIT 1"""
            ).fetchone()
            return {
                "pending": int(pending or 0),
                "retrying": int(retrying or 0),
                "delivered": int(delivered or 0),
                "max_attempts": int(max_attempts or 0),
                "oldest_due_age_sec": round(max(0.0, now - float(oldest)), 1) if oldest else 0.0,
                "last_error": str(last_error[0])[:160] if last_error else "",
            }

    def close(self) -> None:
        with self._lock:
            self.db.close()
