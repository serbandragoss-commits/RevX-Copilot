from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path


CONFIRM = "IMPORT V2 OPEN POSITIONS INTO V3"


def _f(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def import_positions(v2_path: Path, v3_path: Path, confirmation: str) -> list[dict]:
    if confirmation != CONFIRM:
        raise RuntimeError(f"exact confirmation required: {CONFIRM}")
    with v2_path.open("r", encoding="utf-8-sig") as handle:
        source = json.load(handle)
    if v3_path.exists():
        with v3_path.open("r", encoding="utf-8-sig") as handle:
            target = json.load(handle)
        if int(target.get("schema", 0)) != 3:
            raise RuntimeError("refusing non-v3 destination state")
    else:
        target = {
            "schema": 3, "mode": "LIVE_GUARDED", "signals": {}, "positions": {},
            "exits": {}, "outbox": {}, "metrics": {}, "revision": 0,
        }
    imported = []
    for signal_id, signal in (source.get("signals") or {}).items():
        if not isinstance(signal, dict) or signal.get("kind") in {"EXIT", "TEST_EXIT"}:
            continue
        position = signal.get("position")
        if not isinstance(position, dict) or str(position.get("status", "")).upper() != "OPEN":
            continue
        symbol = str(position.get("symbol") or signal.get("symbol") or "").upper().replace("/", "-")
        quantity = _f(position.get("managed_remaining_quantity"), _f(position.get("quantity")))
        entry = _f(position.get("average_entry_price"))
        stop = _f(position.get("stop"))
        target_price = _f(position.get("target"))
        if not symbol.endswith("-USD") or min(quantity, entry, stop, target_price) <= 0:
            raise RuntimeError(f"invalid OPEN v2 position cannot be imported: {signal_id}/{symbol}")
        existing = target.setdefault("positions", {}).get(symbol)
        if existing and existing.get("status") == "OPEN":
            if existing.get("imported_from_v2_signal_id") == signal_id:
                continue
            raise RuntimeError(f"v3 already has a different OPEN position for {symbol}")
        imported_id = f"v2-{signal_id}"
        target.setdefault("signals", {})[imported_id] = {
            "id": imported_id,
            "symbol": symbol,
            "lane": "IMPORTED_V2",
            "status": "BUY_FILLED",
            "created_at": time.time(),
            "source": "V2_OPEN_POSITION_IMPORT",
        }
        target["positions"][symbol] = {
            "status": "OPEN",
            "symbol": symbol,
            "quantity": quantity,
            "original_filled_quantity": _f(position.get("original_filled_quantity"), quantity),
            "average_entry_price": entry,
            "stop": stop,
            "target": target_price,
            "entry_signal_id": imported_id,
            "entry_order_id": str(position.get("entry_order_id") or ""),
            "opened_at": position.get("opened_at") or time.time(),
            "last_exit_alert_at": 0,
            "imported_from_v2_signal_id": signal_id,
            "imported_at": time.time(),
        }
        imported.append({"symbol": symbol, "quantity": quantity, "stop": stop, "target": target_price})
    target["mode"] = "LIVE_GUARDED"
    target.setdefault("migrations", []).append({
        "type": "V2_OPEN_POSITION_IMPORT", "ts": time.time(), "positions": imported,
    })
    target["revision"] = int(target.get("revision", 0)) + 1
    v3_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = v3_path.with_suffix(v3_path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(target, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, v3_path)
    return imported


def main() -> None:
    parser = argparse.ArgumentParser(description="Import exact OPEN v2 managed plans into stopped v3")
    parser.add_argument("--v2-state", required=True)
    parser.add_argument("--v3-state", required=True)
    parser.add_argument("--confirm", required=True)
    args = parser.parse_args()
    rows = import_positions(Path(args.v2_state), Path(args.v3_state), args.confirm)
    print(json.dumps({"status": "OK", "imported": rows, "no_order_performed": True}, indent=2))


if __name__ == "__main__":
    main()
