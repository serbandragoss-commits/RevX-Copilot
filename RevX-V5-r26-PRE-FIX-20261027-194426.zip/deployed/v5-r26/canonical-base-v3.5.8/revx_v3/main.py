from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path

from .broker import RequestBroker
from .client import LiveRevXClient, RevXClient
from .engine import ShadowEngine, configure_logging
from .live_engine import GuardedEngine
from .outbox import DurableOutbox
from .singleton import ProcessSingleton
from .state import StateOwner
from .telegram import TelegramTransport


def expand_path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value)))


async def async_main(args) -> None:
    config_path = expand_path(args.config)
    with config_path.open("r", encoding="utf-8-sig") as handle:
        config = json.load(handle)
    mode = str(config.get("mode", "")).upper()
    if mode not in {"SHADOW", "LIVE_GUARDED"}:
        raise SystemExit("v3 refuses modes other than SHADOW or LIVE_GUARDED")
    singleton = None
    if mode == "LIVE_GUARDED":
        if str(config.get("live_guard_ack", "")) != "I_ACCEPT_V3_LIVE_GUARDED":
            raise SystemExit("LIVE_GUARDED acknowledgement is missing")
        if not bool(config.get("execution_enabled", False)):
            raise SystemExit("LIVE_GUARDED is not armed; run Arm-RevX-v3-LiveGuarded.ps1")
    root = config_path.parent
    if mode == "LIVE_GUARDED":
        singleton = ProcessSingleton(root / "data" / "revx-v3-live.lock")
    broker = RequestBroker(
        float(config.get("auth_gap_ms", 750)) / 1000.0,
        float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client_cls = LiveRevXClient if mode == "LIVE_GUARDED" else RevXClient
    client = client_cls(
        broker,
        base_url=str(config.get("base_url", "https://revx.revolut.com")),
        api_key_file=expand_path(config["api_key_file"]),
        private_key_file=expand_path(config["private_key_file"]),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    if mode == "LIVE_GUARDED":
        state = StateOwner(root / "data" / "state-v3.live.json", root / "data" / "events-v3.live.jsonl")
        logger = configure_logging(root / "logs" / "agent-v3.live.log")
        telegram = TelegramTransport(
            expand_path(config["telegram_token_file"]),
            str(config["telegram_chat_id"]),
            poll_timeout_sec=int(config.get("telegram_poll_timeout_sec", 15)),
        )
        outbox = DurableOutbox(root / "data" / "outbox-v3.live.db")
        engine = GuardedEngine(
            config, client, state, logger, telegram, outbox, root / "logs" / "trades-v3.live.jsonl"
        )
    else:
        state = StateOwner(root / "data" / "state-v3.json", root / "data" / "events-v3.jsonl")
        logger = configure_logging(root / "logs" / "agent-v3.log")
        engine = ShadowEngine(config, client, state, logger)
    try:
        await engine.run(once=args.once)
    finally:
        await broker.close()
        if singleton:
            singleton.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="RevX v3 runtime")
    parser.add_argument("--config", required=True)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    asyncio.run(async_main(args))


if __name__ == "__main__":
    main()
