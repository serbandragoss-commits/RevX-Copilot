from __future__ import annotations

import hashlib
import math
import time
import uuid
from dataclasses import asdict, dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from typing import Any

from .client import LiveRevXClient
from .models import Candidate, Decision, Priority, Quote
from .strategy import AMBITIOUS, IGNITION, MOVER, SPECULATIVE, STANDARD, evaluate, evaluate_ignition


class ExecutionRefused(RuntimeError):
    pass


class DustUntradable(ExecutionRefused):
    def __init__(
        self,
        message: str,
        *,
        available_quantity: float,
        minimum_executable_quantity: float,
        minimum_notional: float,
    ):
        super().__init__(message)
        self.available_quantity = available_quantity
        self.minimum_executable_quantity = minimum_executable_quantity
        self.minimum_notional = minimum_notional


class ExecutionUnknown(RuntimeError):
    pass


def _d(value: Any) -> Decimal:
    return Decimal(str(value))


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _entry_momentum_negative(momentum: dict) -> bool:
    """Match the live guard's short-horizon negative classification."""
    if not isinstance(momentum, dict):
        return False
    has_m1 = momentum.get("m1") is not None
    has_s20 = momentum.get("s20") is not None
    has_accel = momentum.get("accel_5_vs_15") is not None
    m1 = _f(momentum.get("m1"))
    s20 = _f(momentum.get("s20"))
    accel = _f(momentum.get("accel_5_vs_15"))
    return bool(
        (has_m1 and m1 <= -0.12)
        or (has_s20 and has_m1 and s20 <= -0.08 and m1 <= 0.0)
        or (has_m1 and has_accel and m1 <= 0.0 and accel <= -0.10)
    )


def _validate_entry_momentum(momentum: dict | None, config: dict, lane: str = "STANDARD") -> None:
    """Fail closed when the final BUY path lacks current tape evidence."""
    if not isinstance(momentum, dict):
        raise ExecutionRefused("fresh entry momentum is unavailable")
    observed_at = _f(momentum.get("observed_at"))
    max_age = float(config.get("entry_momentum_max_age_sec", 45.0))
    age = time.time() - observed_at
    if observed_at <= 0 or age < -5.0 or age > max_age:
        raise ExecutionRefused(
            f"fresh entry momentum is stale or unavailable (age={age:.1f}s max={max_age:.1f}s)"
        )
    if _entry_momentum_negative(momentum):
        if lane.upper() == "MOVER":
            m1 = _f(momentum.get("m1")); m5 = _f(momentum.get("m5"))
            s20 = _f(momentum.get("s20")); accel = _f(momentum.get("accel_5_vs_15"))
            if not (m1 > 0 or m5 > 0 or accel > 0) or (m1 <= -0.12 and s20 <= -0.08):
                raise ExecutionRefused("fresh mover momentum is negative")
        else:
            raise ExecutionRefused("fresh entry momentum is negative")


def _validate_ignition_entry_strength(momentum: dict | None, config: dict) -> None:
    """Require current, strong continuation before an IGNITION order."""
    if not isinstance(momentum, dict):
        raise ExecutionRefused("fresh IGNITION momentum is unavailable")
    limits = (
        ("s20", "ignition_entry_min_s20_pct", 0.10),
        ("m1", "ignition_entry_min_m1_pct", 0.35),
        ("m5", "ignition_entry_min_m5_pct", 0.70),
        ("m15", "ignition_entry_min_m15_pct", 0.60),
        ("accel_5_vs_15", "ignition_entry_min_accel_pct", 0.10),
    )
    if not bool(momentum.get("ignition", False)):
        raise ExecutionRefused("fresh IGNITION confirmation is absent")
    if not bool(momentum.get("early_continuation", False)):
        raise ExecutionRefused("fresh IGNITION early continuation is absent")
    for field, config_key, fallback in limits:
        value = _f(momentum.get(field), float("-inf"))
        minimum = float(config.get(config_key, fallback))
        if value < minimum:
            raise ExecutionRefused(
                f"fresh IGNITION {field}={value:.4f} is below {minimum:.4f}"
            )


def _floor(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ExecutionRefused("invalid venue step")
    return (value / step).to_integral_value(rounding=ROUND_FLOOR) * step


def _ceil(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ExecutionRefused("invalid venue step")
    return (value / step).to_integral_value(rounding=ROUND_CEILING) * step


def _text(value: Decimal) -> str:
    return format(value, "f")


def _rows(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        # Venue order APIs use a paginated envelope.  An empty `data` list is
        # no active order; treating the envelope itself as a row fabricated an
        # UNKNOWN active order and blocked every execution path.
        for key in ("data", "items", "orders", "results"):
            if isinstance(payload.get(key), list):
                return [row for row in payload[key] if isinstance(row, dict)]
        if payload and all(isinstance(row, dict) for row in payload.values()):
            return list(payload.values())
        return [payload] if payload.get("id") or payload.get("venue_order_id") else []
    return []


def _prop(row: dict, *names: str) -> Any:
    for name in names:
        if row.get(name) is not None:
            return row[name]
    return None


def order_id(row: dict | None) -> str:
    if not isinstance(row, dict):
        return ""
    return str(_prop(row, "venue_order_id", "id") or "")


def order_status(row: dict | None) -> str:
    if not isinstance(row, dict):
        return ""
    return str(_prop(row, "status", "state") or "").lower()


def deterministic_order_id(side: str, signal_id: str, symbol: str) -> str:
    seed = f"revx-v3|{side.lower()}|{signal_id}|{symbol.upper()}"
    digest = hashlib.sha256(seed.encode("utf-8")).digest()[:16]
    return str(uuid.UUID(bytes=digest))


@dataclass(frozen=True)
class PairRules:
    symbol: str
    base: str
    quote: str
    base_step: float
    quote_step: float
    min_order_size: float
    max_order_size: float
    min_order_size_quote: float
    status: str


@dataclass(frozen=True)
class BuyPlan:
    signal_id: str
    symbol: str
    lane: str
    client_order_id: str
    created_at: float
    risk_fraction_pct: int
    requested_risk_usd: float
    actual_risk_usd: float
    quantity: float
    limit_price: float
    stop: float
    target: float
    risk_pct: float
    structural_rr: float
    net_rr: float
    quality: float
    spread_pct: float
    execution_style: str
    estimated_vwap: float
    estimated_slippage_pct: float
    coverage_pct: float
    notional_usd: float
    available_usd: float
    cash_reserve_usd: float
    capital_limit_usd: float
    capital_usage_pct: float
    sizing_mode: str
    body: dict
    requested_quantity: float = 0.0
    visible_depth_quantity: float = 0.0
    depth_scale_pct: float = 100.0


@dataclass(frozen=True)
class SellPlan:
    exit_id: str
    symbol: str
    reason: str
    scope: str
    client_order_id: str
    created_at: float
    quantity: float
    managed_quantity: float
    venue_available: float
    trigger_bid: float
    limit_price: float
    estimated_vwap: float
    estimated_slippage_pct: float
    coverage_pct: float
    body: dict


class ExecutionService:
    def __init__(self, client: LiveRevXClient, config: dict):
        self.client = client
        self.config = config
        self._rules_payload: Any = None
        self._rules_loaded_at = 0.0

    async def pair_rules(
        self, symbol: str, lane: Priority = Priority.ENTRY
    ) -> PairRules:
        if self._rules_payload is None or time.time() - self._rules_loaded_at > 3600:
            # Pair rules are required by both BUY and SELL preflight.  Loading
            # them through ENTRY allowed an entry-side 429 cooldown to block a
            # hard-stop SELL before any exit-critical request was attempted.
            self._rules_payload = await self.client.pair_configurations(lane)
            self._rules_loaded_at = time.time()
        payload = self._rules_payload
        dash = symbol.upper().replace("/", "-")
        slash = dash.replace("-", "/")
        row = None
        if isinstance(payload, dict):
            row = payload.get(slash) or payload.get(dash)
            if row is None:
                for item in payload.values():
                    if isinstance(item, dict) and str(item.get("symbol", "")).upper() in {dash, slash}:
                        row = item
                        break
        if not isinstance(row, dict):
            raise ExecutionRefused(f"pair configuration unavailable for {dash}")
        rules = PairRules(
            dash,
            str(row.get("base", dash.removesuffix("-USD"))).upper(),
            str(row.get("quote", "USD")).upper(),
            _f(row.get("base_step")),
            _f(row.get("quote_step")),
            _f(row.get("min_order_size")),
            _f(row.get("max_order_size")),
            _f(row.get("min_order_size_quote")),
            str(row.get("status", "")),
        )
        if rules.status.lower() != "active" or min(rules.base_step, rules.quote_step) <= 0:
            raise ExecutionRefused(f"pair {dash} is not active or has invalid steps")
        return rules

    async def balances_map(self, lane: Priority = Priority.EXIT_WATCH) -> dict[str, dict]:
        rows = _rows(await self.client.balances(lane))
        return {str(row.get("currency", "")).upper(): row for row in rows}

    async def fresh_decision(self, symbol: str, lane: str, momentum_context: dict | None = None) -> Decision:
        if lane.upper() == "IGNITION":
            book = await self.client.order_book(symbol, 50, Priority.ENTRY)
            quote = self._quote_from_book(symbol, book)
            candles = _rows(await self.client.candles(symbol, 15, 27))
            # The tape was created from a more frequent public batch and is
            # carried with the approval.  Book/candle truth is still rebuilt
            # fresh immediately before the order.
            return evaluate_ignition(Candidate(symbol, 0.0, 0.0, quote, dict(momentum_context or {})), candles)
        if lane.upper() in {"SPECULATIVE", "MOVER"}:
            book = await self.client.order_book(symbol, 50, Priority.ENTRY)
            quote = self._quote_from_book(symbol, book)
            candles = _rows(await self.client.candles(symbol, 15, 27))
            policy = MOVER if lane.upper() == "MOVER" else SPECULATIVE
            return evaluate(Candidate(symbol, 0.0, 0.0, quote, dict(momentum_context or {})), candles, policy)
        standard, ambitious = await self.fresh_decisions(symbol, momentum_context)
        return ambitious if lane.upper() == "AMBITIOUS" else standard

    async def fresh_decisions(
        self, symbol: str, momentum_context: dict | None = None
    ) -> tuple[Decision, Decision]:
        """Evaluate both entry policies from one fresh book/candle snapshot."""
        book = await self.client.order_book(symbol, 50, Priority.ENTRY)
        quote = self._quote_from_book(symbol, book)
        candles = await self.client.candles(symbol, 15, 27)
        rows = _rows(candles)
        candidate = Candidate(symbol, 0.0, 0.0, quote, dict(momentum_context or {}))
        return evaluate(candidate, rows, STANDARD), evaluate(candidate, rows, AMBITIOUS)

    async def build_buy_plan(
        self, signal_id: str, symbol: str, lane: str, risk_fraction_pct: int, momentum_context: dict | None = None
    ) -> BuyPlan:
        if risk_fraction_pct not in {25, 50, 75, 100}:
            raise ExecutionRefused("risk fraction must be 25/50/75/100")
        symbol = symbol.upper().replace("/", "-")
        lane = lane.upper()
        if lane == "IGNITION" and not bool(self.config.get("ignition_live_enabled", False)):
            raise ExecutionRefused("IGNITION is shadow-only because ignition_live_enabled=false")
        if lane == "IGNITION" and risk_fraction_pct != 25:
            raise ExecutionRefused("IGNITION uses one 25% starter allocation")
        _validate_entry_momentum(momentum_context, self.config, lane)
        if lane == "IGNITION":
            _validate_ignition_entry_strength(momentum_context, self.config)
        decision = await self.fresh_decision(symbol, lane, momentum_context)
        if decision.verdict != "CANDIDATE":
            raise ExecutionRefused("fresh strategy decision is not CANDIDATE: " + ",".join(decision.blockers))
        rules = await self.pair_rules(symbol)
        balances = await self.balances_map(Priority.ENTRY)
        if _f(balances.get(rules.base, {}).get("total")) > 0:
            raise ExecutionRefused(f"existing {rules.base} inventory blocks a duplicate entry")
        active = _rows(await self.client.active_orders(symbol, Priority.ENTRY))
        if any(str(row.get("side", "")).lower() == "buy" for row in active):
            raise ExecutionRefused(f"active BUY already exists for {symbol}")

        # Re-read the book after authenticated truth. Mature entries remain
        # passive maker orders. IGNITION is a fast lane: a post-only bid is a
        # structural mismatch (the move usually leaves it behind), so it uses
        # a tightly bounded marketable limit after visible ask-depth proof.
        book = await self.client.order_book(symbol, 50, Priority.ENTRY)
        quote = self._quote_from_book(symbol, book)
        quote_step = _d(rules.quote_step)
        bid, ask = _d(quote.bid), _d(quote.ask)
        if lane == "IGNITION":
            limit_price = _ceil(ask, quote_step)
            execution_style = "MARKETABLE_LIMIT_DEPTH_CAPPED"
        else:
            limit_price = _floor(bid + quote_step, quote_step)
            if limit_price >= ask:
                limit_price = _floor(bid, quote_step)
            if limit_price <= 0 or limit_price >= ask:
                raise ExecutionRefused("cannot derive a non-crossing post-only BUY price")
            execution_style = "POST_ONLY_MAKER"
        stop, target = _d(decision.stop), _d(decision.target)
        policy = (
            IGNITION if lane == "IGNITION" else
            AMBITIOUS if lane == "AMBITIOUS" else
            MOVER if lane == "MOVER" else (SPECULATIVE if lane == "SPECULATIVE" else STANDARD)
        )
        max_spread = _d(policy.max_spread_pct)
        if _d(quote.spread_pct) > max_spread:
            raise ExecutionRefused("fresh spread exceeds lane maximum")

        base_risk = _d(self.config.get(
            "ignition_risk_usd" if lane == "IGNITION" else ("ambitious_risk_usd" if lane == "AMBITIOUS" else "standard_risk_usd"),
            self.config.get("risk_usd", 3),
        ))
        requested_risk = base_risk * _d(risk_fraction_pct) / 100
        available_usd = _d(balances.get("USD", {}).get("available", 0))
        reserve = max(_d(self.config.get("cash_reserve_usd", 2)), available_usd * _d(self.config.get("cash_reserve_pct", 2)) / 100)
        reserve = min(reserve, available_usd)
        usable = max(Decimal(0), available_usd - reserve)
        # A selected 25/50/75/100 risk fraction may never consume a larger
        # fraction of cash. This is only a ceiling: the original risk budget
        # still sizes the order and can produce a much smaller notional.
        capital_limit = min(usable, available_usd * _d(risk_fraction_pct) / 100)
        if lane == "IGNITION":
            ignition_cap_pct = _d(self.config.get("ignition_max_capital_pct", 25.0))
            if ignition_cap_pct <= 0 or ignition_cap_pct > 100:
                raise ExecutionRefused("ignition_max_capital_pct must be within (0, 100]")
            capital_limit = min(usable, available_usd * ignition_cap_pct / 100)
        base_step = _d(rules.base_step)

        def size_at(
            price: Decimal, quantity_cap: Decimal | None = None
        ) -> tuple[Decimal, Decimal, Decimal, Decimal, str]:
            if price <= stop or target <= price:
                raise ExecutionRefused("fresh structural geometry no longer has executable upside")
            unit_risk = price - stop
            local_risk_pct = unit_risk / price * 100
            if local_risk_pct > _d(policy.max_risk_pct):
                raise ExecutionRefused(f"fresh risk {local_risk_pct:.3f}% exceeds {policy.max_risk_pct:.2f}%")
            local_rr = (target - price) / unit_risk
            # IGNITION's discovery geometry is defined at the best ask. A
            # depth-capped fill may be a few ticks higher; its final net-R/R
            # guard below remains authoritative. Mature lanes retain their
            # full structural threshold at the passive limit.
            if lane not in {"IGNITION", "SPECULATIVE"} and local_rr < _d(policy.min_structural_rr):
                raise ExecutionRefused("fresh structural R/R is below lane minimum")
            local_qty = _floor(requested_risk / unit_risk, base_step)
            min_qty = _ceil(max(_d(rules.min_order_size), _d(rules.min_order_size_quote) / price), base_step)
            if local_qty < min_qty:
                raise ExecutionRefused("selected fractional risk is below venue minimum; risk will not be rounded up")
            mode = "RISK_SIZED"
            if local_qty * price > capital_limit:
                local_qty = _floor(capital_limit / price, base_step)
                mode = "IGNITION_CAPITAL_CAPPED" if lane == "IGNITION" else "CAPITAL_CAPPED"
            if quantity_cap is not None and local_qty > quantity_cap:
                local_qty = _floor(quantity_cap, base_step)
                mode = (
                    "IGNITION_CAPITAL_AND_DEPTH_CAPPED"
                    if mode == "IGNITION_CAPITAL_CAPPED"
                    else "IGNITION_DEPTH_CAPPED"
                )
            if local_qty < min_qty:
                if quantity_cap is not None:
                    raise ExecutionRefused("visible ask depth is below venue minimum")
                if capital_limit < usable:
                    raise ExecutionRefused("selected capital cap is below venue minimum")
                raise ExecutionRefused("insufficient usable USD after reserve")
            if local_qty > _d(rules.max_order_size):
                raise ExecutionRefused("quantity exceeds venue maximum")
            local_actual_risk = local_qty * unit_risk
            if local_actual_risk > requested_risk + _d("0.01"):
                raise ExecutionRefused("computed risk exceeds selected risk")
            return local_qty, unit_risk, local_risk_pct, local_rr, mode

        quantity, risk_per_unit, risk_pct, structural_rr, sizing_mode = size_at(limit_price)
        requested_quantity = quantity
        visible_depth_quantity = quantity
        depth_scale_pct = Decimal(100)
        estimated_vwap = limit_price
        estimated_slippage_pct = Decimal(0)
        coverage_pct = Decimal(0)
        if lane == "IGNITION":
            slip_cap = _d(self.config.get("ignition_buy_max_slippage_pct", 0.25))
            if slip_cap < 0 or slip_cap > _d("0.75"):
                raise ExecutionRefused("ignition_buy_max_slippage_pct must be within [0, 0.75]")
            price_ceiling = ask * (Decimal(1) + slip_cap / 100)
            asks = self._levels(book, "asks")

            def walk_depth(required: Decimal, ceiling: Decimal) -> tuple[Decimal, Decimal, Decimal]:
                remaining, value, filled, last = required, Decimal(0), Decimal(0), Decimal(0)
                for price_f, qty_f in asks:
                    price, level_qty = _d(price_f), _d(qty_f)
                    if price > ceiling:
                        break
                    take = min(remaining, level_qty)
                    if take > 0:
                        value += take * price
                        filled += take
                        remaining -= take
                        last = price
                    if remaining <= 0:
                        break
                return filled, value, last

            visible, _, last_price = walk_depth(quantity, price_ceiling)
            if visible <= 0 or last_price <= 0:
                raise ExecutionRefused(
                    "no visible ask depth inside IGNITION slippage cap"
                )
            # IGNITION is allowed to scale down to executable visible depth;
            # risk/capital limits remain ceilings and venue minimums remain
            # hard floors.  This replaces the former all-or-nothing 100% book
            # coverage requirement without relaxing spread or slippage.
            depth_cap = _floor(min(visible, quantity), base_step)
            limit_price = _ceil(last_price, quote_step)
            if limit_price > price_ceiling:
                raise ExecutionRefused("IGNITION marketable limit exceeds slippage cap after tick rounding")
            quantity, risk_per_unit, risk_pct, structural_rr, sizing_mode = size_at(
                limit_price, depth_cap
            )
            visible, value, last_price = walk_depth(quantity, limit_price)
            coverage_pct = visible / quantity * 100 if quantity > 0 else Decimal(0)
            if visible < quantity or last_price <= 0:
                raise ExecutionRefused(
                    f"visible ask depth covers only {coverage_pct:.2f}% at final IGNITION limit"
                )
            estimated_vwap = value / visible
            estimated_slippage_pct = (estimated_vwap - ask) / ask * 100
            visible_depth_quantity = depth_cap
            depth_scale_pct = (
                quantity / requested_quantity * 100
                if requested_quantity > 0 else Decimal(0)
            )

        actual_risk = quantity * risk_per_unit
        notional = quantity * limit_price
        capital_usage_pct = notional / available_usd * 100 if available_usd > 0 else Decimal(0)
        taker_fee = _d(self.config.get("taker_fee_pct", 0.09)) / 100
        net_reward = (target - limit_price) * quantity - target * quantity * taker_fee
        net_risk = actual_risk + stop * quantity * taker_fee
        net_rr = net_reward / net_risk if net_risk > 0 else Decimal(0)
        net_key = {
            "IGNITION": "ignition_min_net_rr",
            "AMBITIOUS": "ambitious_min_net_rr",
            "MOVER": "mover_min_net_rr",
            "SPECULATIVE": "speculative_min_net_rr",
        }.get(lane, "standard_min_net_rr")
        # IGNITION keeps its 2.75R structural target but may admit a 25%
        # starter at a lower net multiple because its failure exit is fast.
        # Mature STANDARD and AMBITIOUS thresholds remain unchanged.
        policy_floor = _d({
            "AMBITIOUS": "2.25",
            "IGNITION": "1.5",
            "MOVER": "1.0",
            "SPECULATIVE": "1.2",
        }.get(lane, "2.0"))
        min_net = max(policy_floor, _d(self.config.get(net_key, policy_floor)))
        if net_rr < min_net:
            raise ExecutionRefused(f"net R/R {net_rr:.3f} is below {min_net}")
        # A structurally attractive target is not enough if the expected move
        # cannot pay both sides of execution cost.  This gate is deliberately
        # additive: it never weakens the existing R/R, spread, slippage or
        # depth checks.
        expected_gain_pct = (target - limit_price) / limit_price * 100
        fee_cost_pct = Decimal("2") * taker_fee * 100
        expected_entry_slippage_pct = _d(
            self.config.get("expected_entry_slippage_pct", 0.05)
        )
        expected_exit_slippage_pct = _d(
            self.config.get("expected_exit_slippage_pct", 0.05)
        )
        minimum_net_edge_pct = _d(
            self.config.get("minimum_expected_net_profit_pct", 0.05)
        )
        expected_cost_pct = (
            fee_cost_pct + expected_entry_slippage_pct
            + expected_exit_slippage_pct + minimum_net_edge_pct
        )
        if expected_gain_pct <= expected_cost_pct:
            raise ExecutionRefused(
                f"expected net edge {expected_gain_pct:.3f}% is below cost floor "
                f"{expected_cost_pct:.3f}%"
            )
        client_id = deterministic_order_id("buy", signal_id, symbol)
        body = {
            "client_order_id": client_id,
            "symbol": symbol,
            "side": "buy",
            "order_configuration": {
                "limit": {"base_size": _text(quantity), "price": _text(limit_price)}
            },
        }
        if lane != "IGNITION":
            body["order_configuration"]["limit"]["execution_instructions"] = ["post_only"]
        return BuyPlan(
            signal_id, symbol, lane.upper(), client_id, time.time(), risk_fraction_pct,
            float(requested_risk), float(actual_risk), float(quantity), float(limit_price),
            float(stop), float(target), float(risk_pct), float(structural_rr), float(net_rr),
            decision.quality, quote.spread_pct, execution_style, float(estimated_vwap),
            float(estimated_slippage_pct), float(coverage_pct), float(notional), float(available_usd),
            float(reserve), float(capital_limit), float(capital_usage_pct), sizing_mode, body,
            float(requested_quantity), float(visible_depth_quantity), float(depth_scale_pct),
        )

    async def submit_buy(self, plan: BuyPlan) -> dict:
        existing = await self.find_order(plan.symbol, plan.client_order_id, Priority.ENTRY)
        if existing:
            return existing
        try:
            result = await self.client.submit_order(plan.body, Priority.ENTRY)
        except Exception as exc:
            try:
                recovered = await self.find_order(plan.symbol, plan.client_order_id, Priority.ENTRY)
            except Exception:
                recovered = None
            if recovered:
                return recovered
            raise ExecutionUnknown(
                f"BUY execution status unknown for client_order_id {plan.client_order_id}; no retry"
            ) from exc
        row = _rows(result)
        order = row[0] if row else (result if isinstance(result, dict) else {})
        if not order_id(order):
            try:
                recovered = await self.find_order(plan.symbol, plan.client_order_id, Priority.ENTRY)
            except Exception:
                recovered = None
            if recovered:
                return recovered
            raise ExecutionUnknown(
                f"BUY POST returned no venue id for client_order_id {plan.client_order_id}; no retry"
            )
        return order

    async def build_sell_plan(
        self,
        exit_id: str,
        position: dict,
        reason: str,
        scope: str = "MANAGED",
        external: bool = False,
    ) -> SellPlan:
        symbol = str(position["symbol"]).upper().replace("/", "-")
        rules = await self.pair_rules(symbol, Priority.EXIT_CRITICAL)
        scope = scope.upper()
        if scope not in {"MANAGED", "ALL_AVAILABLE"}:
            raise ExecutionRefused("SELL scope must be MANAGED or ALL_AVAILABLE")
        balances = await self.balances_map(Priority.EXIT_CRITICAL)
        available = _d(balances.get(rules.base, {}).get("available", 0))
        if external:
            if scope != "ALL_AVAILABLE":
                raise ExecutionRefused("external SELL scope must be ALL_AVAILABLE")
            managed_quantity = _floor(available, _d(rules.base_step))
        else:
            managed_quantity = _floor(_d(position["quantity"]), _d(rules.base_step))
            if managed_quantity <= 0 or managed_quantity < _d(rules.min_order_size):
                raise ExecutionRefused("managed SELL quantity is below venue minimum")
            if available < managed_quantity:
                raise ExecutionRefused(
                    f"venue available {available} is below managed quantity {managed_quantity}; reconciliation required"
                )
        quantity = (
            _floor(available, _d(rules.base_step))
            if scope == "ALL_AVAILABLE"
            else managed_quantity
        )
        if quantity <= 0 or quantity < _d(rules.min_order_size):
            raise DustUntradable(
                "selected SELL quantity is below venue minimum",
                available_quantity=float(available),
                minimum_executable_quantity=float(rules.min_order_size),
                minimum_notional=float(rules.min_order_size_quote),
            )
        if quantity > _d(rules.max_order_size):
            raise ExecutionRefused("selected SELL quantity exceeds venue maximum")
        active = _rows(await self.client.active_orders(symbol, Priority.EXIT_CRITICAL))
        if active:
            sides = sorted({str(row.get("side", "unknown")).upper() for row in active})
            raise ExecutionRefused(
                f"active venue order already exists for {symbol} ({'/'.join(sides)}); reconciliation required"
            )
        book = await self.client.order_book(symbol, 50, Priority.EXIT_CRITICAL)
        quote = self._quote_from_book(symbol, book)
        reason = reason.upper()
        stop, target = _f(position.get("stop")), _f(position.get("target"))
        if reason == "STOP_HIT" and quote.bid > stop:
            raise ExecutionRefused("STOP_HIT is no longer true on the fresh book")
        if reason == "TARGET_HIT" and quote.bid < target:
            raise ExecutionRefused("TARGET_HIT is no longer true on the fresh book")
        if reason == "TARGET_MOMENTUM_LOSS":
            required = int(self.config.get("target_extension_momentum_confirmations", 2))
            if (
                not bool(position.get("target_extension_active"))
                or int(position.get("target_momentum_loss_confirmations", 0)) < required
            ):
                raise ExecutionRefused(
                    "TARGET_MOMENTUM_LOSS is no longer confirmed"
                )
        if reason in {"EARLY_MOMENTUM_FAILURE", "FAILED_BREAKOUT"}:
            required = int(self.config.get("early_momentum_confirmations", 2))
            last_momentum_at = _f(position.get("fast_momentum_last_observed_at"))
            max_age = float(self.config.get("early_momentum_max_age_sec", 75.0))
            if (
                str(position.get("fast_momentum_state", "")) != "NEGATIVE"
                or int(position.get("fast_momentum_negative_confirmations", 0)) < required
                or last_momentum_at <= 0
                or time.time() - last_momentum_at > max_age
            ):
                raise ExecutionRefused(f"{reason} is no longer momentum-confirmed")
            entry = _f(position.get("average_entry_price"))
            if entry <= 0:
                raise ExecutionRefused(f"{reason} has no valid entry price")
            pnl_pct = (quote.bid / entry - 1.0) * 100.0
            if reason == "EARLY_MOMENTUM_FAILURE":
                fee_floor = (
                    2.0 * float(self.config.get("taker_fee_pct", 0.09))
                    + float(self.config.get("early_momentum_fee_buffer_pct", 0.10))
                )
                loss_floor = max(
                    fee_floor,
                    float(self.config.get("early_momentum_min_loss_pct", 0.30)),
                )
                if pnl_pct > -loss_floor:
                    raise ExecutionRefused(
                        "EARLY_MOMENTUM_FAILURE recovered above its cost-adjusted loss trigger"
                    )
            else:
                high = max(entry, _f(position.get("high_watermark_bid"), entry))
                mfe_pct = (high / entry - 1.0) * 100.0
                giveback_pct = (high / quote.bid - 1.0) * 100.0 if quote.bid > 0 else 0.0
                if (
                    mfe_pct < float(self.config.get("failed_breakout_min_mfe_pct", 0.75))
                    or giveback_pct < float(self.config.get("failed_breakout_min_giveback_pct", 0.60))
                    or pnl_pct > float(self.config.get("failed_breakout_max_pnl_pct", 0.75))
                ):
                    raise ExecutionRefused("FAILED_BREAKOUT geometry is no longer true")
        if reason == "TRAIL_PROFIT":
            trigger = _f(position.get("trail_trigger_bid"))
            if not position.get("trail_armed") or trigger <= 0 or quote.bid > trigger:
                raise ExecutionRefused("TRAIL_PROFIT is no longer true on the fresh book")
        profit_exit = reason in {"TARGET_HIT", "TARGET_MOMENTUM_LOSS"}
        cap_pct = _d(self.config.get(
            "target_max_slippage_pct" if profit_exit else "stop_max_slippage_pct",
            0.3 if profit_exit else 0.6,
        ))
        bids = self._levels(book, "bids")
        floor_price = _d(quote.bid) * (Decimal(1) - cap_pct / 100)
        remaining, value = quantity, Decimal(0)
        last_price = Decimal(0)
        filled = Decimal(0)
        for price_f, qty_f in bids:
            price, level_qty = _d(price_f), _d(qty_f)
            if price < floor_price:
                break
            take = min(remaining, level_qty)
            if take > 0:
                value += take * price
                filled += take
                remaining -= take
                last_price = price
            if remaining <= 0:
                break
        coverage = filled / quantity * 100 if quantity > 0 else Decimal(0)
        if remaining > 0 or last_price <= 0:
            raise ExecutionRefused(f"visible bid depth covers only {coverage:.2f}% inside slippage cap")
        limit_price = _floor(last_price, _d(rules.quote_step))
        if quantity * limit_price < _d(rules.min_order_size_quote):
            minimum_quantity = _ceil(
                _d(rules.min_order_size_quote) / limit_price,
                _d(rules.base_step),
            )
            raise DustUntradable(
                "SELL notional is below venue quote minimum",
                available_quantity=float(available),
                minimum_executable_quantity=float(max(minimum_quantity, _d(rules.min_order_size))),
                minimum_notional=float(rules.min_order_size_quote),
            )
        vwap = value / filled
        slippage = (_d(quote.bid) - vwap) / _d(quote.bid) * 100
        client_id = deterministic_order_id(f"sell-{scope.lower()}", exit_id, symbol)
        body = {
            "client_order_id": client_id,
            "symbol": symbol,
            "side": "sell",
            "order_configuration": {
                "limit": {"base_size": _text(quantity), "price": _text(limit_price)}
            },
        }
        return SellPlan(
            exit_id, symbol, reason, scope, client_id, time.time(), float(quantity),
            float(managed_quantity), float(available), quote.bid,
            float(limit_price), float(vwap), float(slippage), float(coverage), body,
        )

    async def submit_sell(self, plan: SellPlan) -> dict:
        existing = await self.find_order(plan.symbol, plan.client_order_id, Priority.EXIT_CRITICAL)
        if existing:
            return existing
        try:
            result = await self.client.submit_order(plan.body, Priority.EXIT_CRITICAL)
        except Exception as exc:
            try:
                recovered = await self.find_order(plan.symbol, plan.client_order_id, Priority.EXIT_CRITICAL)
            except Exception:
                recovered = None
            if recovered:
                return recovered
            raise ExecutionUnknown(
                f"SELL execution status unknown for client_order_id {plan.client_order_id}; "
                f"cause={type(exc).__name__}: {str(exc)[:500]}; no retry"
            ) from exc
        rows = _rows(result)
        order = rows[0] if rows else (result if isinstance(result, dict) else {})
        if not order_id(order):
            try:
                recovered = await self.find_order(plan.symbol, plan.client_order_id, Priority.EXIT_CRITICAL)
            except Exception:
                recovered = None
            if recovered:
                return recovered
            raise ExecutionUnknown(
                f"SELL POST returned no venue id for client_order_id {plan.client_order_id}; no retry"
            )
        return order

    async def find_order(self, symbol: str, client_order_id: str, lane: Priority) -> dict | None:
        for loader in (
            lambda: self.client.active_orders(symbol, lane),
            lambda: self.client.historical_orders(symbol, 24, lane),
        ):
            payload = await loader()
            for row in _rows(payload):
                if str(row.get("client_order_id", "")) == client_order_id:
                    return row
        return None

    @staticmethod
    def plan_drift(approved: BuyPlan, fresh: BuyPlan, config: dict) -> list[str]:
        breaches = []
        def adverse_increase(a: float, b: float) -> float:
            return max(0.0, (a - b) / b * 100) if b > 0 else 0.0
        # A cheaper entry, smaller risk or smaller capital use is favorable,
        # not plan drift.  Only adverse movement needs renewed consent.
        entry = adverse_increase(fresh.limit_price, approved.limit_price)
        risk = max(0.0, fresh.risk_pct - approved.risk_pct)
        notional = adverse_increase(fresh.notional_usd, approved.notional_usd)
        rr_drop = max(0.0, approved.net_rr - fresh.net_rr)
        if entry > float(config.get("approval_max_entry_drift_pct", 0.30)):
            breaches.append(f"entry drift {entry:.3f}%")
        if risk > float(config.get("approval_max_risk_drift_pp", 0.75)):
            breaches.append(f"risk drift {risk:.3f}pp")
        if notional > float(config.get("approval_max_notional_drift_pct", 10.0)):
            breaches.append(f"notional drift {notional:.2f}%")
        if rr_drop > float(config.get("approval_max_netrr_drop", 0.35)):
            breaches.append(f"net R/R drop {rr_drop:.2f}")
        return breaches

    @staticmethod
    def _levels(payload: Any, side: str) -> list[tuple[float, float]]:
        if not isinstance(payload, dict):
            return []
        levels = []
        for row in payload.get(side) or []:
            if isinstance(row, dict):
                price = _f(_prop(row, "price", "p"))
                quantity = _f(_prop(row, "quantity", "size", "q", "base_size"))
            elif isinstance(row, (list, tuple)) and len(row) >= 2:
                price, quantity = _f(row[0]), _f(row[1])
            else:
                continue
            if price > 0 and quantity > 0:
                levels.append((price, quantity))
        return sorted(levels, key=lambda item: item[0], reverse=(side == "bids"))

    @classmethod
    def _quote_from_book(cls, symbol: str, payload: Any) -> Quote:
        bids, asks = cls._levels(payload, "bids"), cls._levels(payload, "asks")
        if not bids or not asks:
            raise ExecutionRefused("fresh order book has no usable two-sided quote")
        bid, ask = bids[0][0], asks[0][0]
        if ask < bid:
            raise ExecutionRefused("crossed fresh order book")
        mid = (bid + ask) / 2
        return Quote(symbol, bid, ask, (ask - bid) / mid * 100, "PUBLIC_V2_ORDER_BOOK")


def buy_plan_dict(plan: BuyPlan) -> dict:
    return asdict(plan)


def sell_plan_dict(plan: SellPlan) -> dict:
    return asdict(plan)
