from __future__ import annotations

import math
import time
from dataclasses import dataclass, replace
from typing import Any, Iterable

from .models import Candidate, Decision, Quote


def _number(obj: dict, *names: str, default: float = 0.0) -> float:
    for name in names:
        try:
            value = obj.get(name)
            if value is not None:
                return float(value)
        except (TypeError, ValueError, AttributeError):
            pass
    return default


def normalize_symbol(value: str) -> str:
    return str(value or "").upper().replace("/", "-")


def quote_from_ticker(row: dict) -> Quote | None:
    symbol = normalize_symbol(row.get("symbol", ""))
    bid = _number(row, "bid", "best_bid")
    ask = _number(row, "ask", "best_ask")
    if not symbol.endswith("-USD") or bid <= 0 or ask < bid:
        return None
    mid = (bid + ask) / 2.0
    return Quote(
        symbol=symbol,
        bid=bid,
        ask=ask,
        spread_pct=((ask - bid) / mid) * 100.0,
        source="PUBLIC_V1_TICKERS_BATCH",
        api_time=int(_number(row, "timestamp", "api_time", default=0)) or None,
    )


@dataclass(frozen=True)
class Policy:
    name: str
    max_risk_pct: float
    min_quality: float
    min_structural_rr: float
    max_spread_pct: float
    min_change_24h_pct: float


# v3.5.5 keeps the audited STANDARD envelope and replaces the two-point trend
# test with a closed-candle ladder.  Short structure is mandatory; slower
# horizons vote as a regime instead of one arbitrary 6h observation becoming
# an unconditional veto.
STANDARD = Policy("STANDARD", 10.0, 55.0, 1.85, 0.50, 0.5)
SPECULATIVE = Policy("SPECULATIVE", 10.0, 45.0, 1.20, 0.50, 0.5)
MOVER = Policy("MOVER", 5.0, 35.0, 0.90, 0.50, 0.5)
AMBITIOUS = Policy("AMBITIOUS", 15.0, 55.0, 2.75, 0.70, 1.0)
IGNITION = Policy("IGNITION", 5.0, 55.0, 2.75, 0.50, 0.0)

TREND_HORIZONS_HOURS = (1, 3, 6, 9, 12, 15, 18, 21, 24)
STANDARD_TREND_CONSENSUS = 0.50
IGNITION_TREND_CONSENSUS = 0.60
IGNITION_MAX_TREND_1H_PCT = 6.0
# A merely-positive tape is enough to keep observing a symbol, not enough to
# ask for an IGNITION allocation. These floors apply on every fresh decision.
IGNITION_ENTRY_MIN_QUALITY = 65.0
IGNITION_ENTRY_MIN_S20_PCT = 0.10
IGNITION_ENTRY_MIN_M1_PCT = 0.35
IGNITION_ENTRY_MIN_M5_PCT = 0.70
IGNITION_ENTRY_MIN_M15_PCT = 0.60
IGNITION_ENTRY_MIN_ACCEL_PCT = 0.10


def _trend_ladder(closes: list[float]) -> dict[str, float]:
    """Return exact closed-candle returns for 1h, 3h, then every 3h.

    Fifteen-minute candles need ``periods + 1`` closes to compare endpoints.
    Missing history is omitted rather than silently substituting a shorter
    horizon; the policy then fails closed if no slow regime vote is available.
    """
    result: dict[str, float] = {}
    for hours in TREND_HORIZONS_HOURS:
        periods = hours * 4
        if len(closes) <= periods:
            continue
        reference = closes[-(periods + 1)]
        if reference > 0:
            result[f"{hours}h"] = (closes[-1] / reference - 1.0) * 100.0
    return result


def _trend_consensus(ladder: dict[str, float]) -> tuple[float, int]:
    values = [
        ladder[f"{hours}h"]
        for hours in TREND_HORIZONS_HOURS[2:]
        if f"{hours}h" in ladder
    ]
    if not values:
        return 0.0, 0
    return sum(value > 0 for value in values) / len(values), len(values)


def _trend_blockers(
    ladder: dict[str, float], minimum_consensus: float
) -> tuple[list[str], float]:
    blockers: list[str] = []
    short_positive = ladder.get("1h", 0.0) > 0 and ladder.get("3h", 0.0) > 0
    consensus, votes = _trend_consensus(ladder)
    if not short_positive:
        blockers.append("trend_not_positive")
    if votes == 0:
        blockers.append("trend_regime_unavailable")
    elif consensus + 1e-12 < minimum_consensus:
        blockers.append(f"trend_consensus<{minimum_consensus:.2f}")
    return blockers, consensus


def rank_candidates(
    rows: Iterable[dict],
    owned: set[str],
    policy: Policy,
    limit: int | None = 15,
    live_momentum: dict[str, dict[str, float | bool]] | None = None,
) -> list[Candidate]:
    result: list[Candidate] = []
    for row in rows:
        quote = quote_from_ticker(row)
        if quote is None or quote.symbol in owned or quote.spread_pct > 2.0:
            continue
        if row.get("price_change_24h") is not None and row.get("last_price") is not None:
            last = _number(row, "last_price")
            delta = _number(row, "price_change_24h")
            previous = last - delta
            change = (quote.mid - previous) / previous * 100.0 if previous > 0 else 0.0
        else:
            change = _number(row, "change_24h_pct", "price_change_percentage_24h", "change_24h")
            if abs(change) <= 1.0 and "change_24h_pct" not in row and "price_change_percentage_24h" not in row:
                change *= 100.0
        momentum = dict((live_momentum or {}).get(quote.symbol, {}))
        # An early continuation may not have reached the old 24h floor yet.
        # Its fresh tape evidence is sufficient for WATCH, never by itself for
        # an order, and keeps the discovery net open before a move becomes a
        # headline gainer.
        if change < policy.min_change_24h_pct and not bool(momentum.get("early_continuation", False)):
            continue
        volume = max(0.0, _number(row, "quote_volume_24h", "volume_24h", "volume"))
        notional = volume if row.get("quote_volume_24h") is not None else volume * quote.mid
        if notional < 50_000:
            continue
        liquidity_bonus = min(20.0, math.log10(notional + 1.0) * 2.5)
        m1 = _number(momentum, "m1")
        m5 = _number(momentum, "m5")
        m15 = _number(momentum, "m15")
        accel = _number(momentum, "accel_5_vs_15")
        # 24h return is discovery context, not an entry command.  This lets a
        # fresh, liquid small-cap impulse outrank a coin already up 150% today.
        fresh_score = max(0.0, m1) * 9.0 + max(0.0, m5) * 15.0 + max(0.0, m15) * 5.0 + max(0.0, accel) * 12.0
        context_score = min(max(change, 0.0), 35.0) * 0.70
        late_move_penalty = max(0.0, change - 45.0) * 0.75
        score = max(0.0, fresh_score + context_score + liquidity_bonus - late_move_penalty - quote.spread_pct * 20.0)
        result.append(Candidate(quote.symbol, round(score, 2), change, quote, momentum))
    ranked = sorted(result, key=lambda item: item.score, reverse=True)
    if limit is None:
        return ranked
    return ranked[:max(0, int(limit))]


def _candle(row: dict) -> tuple[float, float, float, float, float]:
    return (
        _number(row, "open", "o"),
        _number(row, "high", "h"),
        _number(row, "low", "l"),
        _number(row, "close", "c"),
        _number(row, "volume", "v"),
    )


def evaluate(candidate: Candidate, candles: list[dict], policy: Policy) -> Decision:
    v5_short_policy = candidate.momentum.get("v5_short_trend_policy") is True
    if v5_short_policy and policy.min_quality == 55.0:
        policy = replace(policy, min_quality=45.0)
    short_confirmed = (
        v5_short_policy
        and candidate.momentum.get("five_minute_context_ready") is True
        and _number(candidate.momentum, "m1") > 0
        and _number(candidate.momentum, "m5") > 0
        and _number(candidate.momentum, "s20", default=-1.0) >= 0
    )
    parsed = [_candle(row) for row in candles]
    parsed = [row for row in parsed if row[0] > 0 and row[1] >= row[2] > 0 and row[3] > 0]
    blockers: list[str] = []
    if len(parsed) < 24:
        blockers.append("candles<24")
        return Decision(
            candidate.symbol, policy.name, "REJECT", 0, 0, 0,
            candidate.quote.ask, 0, 0, candidate.quote.spread_pct,
            0, 0, 0, "UNAVAILABLE", tuple(blockers), time.time()
        )

    closes = [row[3] for row in parsed]
    highs = [row[1] for row in parsed]
    lows = [row[2] for row in parsed]
    volumes = [row[4] for row in parsed]
    entry = candidate.quote.ask
    true_ranges = []
    for index in range(1, len(parsed)):
        true_ranges.append(max(highs[index] - lows[index], abs(highs[index] - closes[index - 1]), abs(lows[index] - closes[index - 1])))
    atr = sum(true_ranges[-14:]) / max(1, len(true_ranges[-14:]))
    support = min(lows[-12:])
    stop = min(entry - max(atr * 0.75, entry * 0.0075), support)
    if stop <= 0 or stop >= entry:
        blockers.append("invalid_stop")
        stop = max(entry * 0.99, 0.0)
    risk_pct = ((entry - stop) / entry) * 100.0 if entry else 0.0
    # Target is market structure truth, not a policy-generated multiple. Both
    # lanes evaluate the same geometry. A breakout without visible resistance
    # remains WAIT until a later depth-aware target model can prove upside.
    recent_high = max(highs[-24:])
    target = recent_high if recent_high > entry else entry
    early_continuation = bool(candidate.momentum.get("early_continuation", False))
    target_basis = "RECENT_6H_HIGH" if recent_high > entry else "NO_VISIBLE_RESISTANCE_ABOVE_ENTRY"
    structural_rr = (target - entry) / (entry - stop) if entry > stop and target > entry else 0.0

    trend_ladder = _trend_ladder(closes)
    trend_1h = trend_ladder.get("1h", 0.0)
    trend_3h = trend_ladder.get("3h", 0.0)
    trend_6h = trend_ladder.get("6h", 0.0)
    trend_blockers, trend_consensus = _trend_blockers(
        trend_ladder, STANDARD_TREND_CONSENSUS
    )
    recent_vol = sum(volumes[-4:]) / 4.0
    base_vol = sum(volumes[-24:-4]) / max(1, len(volumes[-24:-4]))
    volume_accel = recent_vol / base_vol if base_vol > 0 else 0.0
    trend_score = max(
        0.0,
        min(30.0, trend_1h * 4.0 + trend_3h * 2.0 + trend_consensus * 10.0),
    )
    volume_score = max(0.0, min(25.0, (volume_accel - 0.5) * 20.0))
    # Raw quality is policy-independent. Policies only decide whether the same
    # observation is acceptable for STANDARD or AMBITIOUS.
    spread_score = max(0.0, 20.0 * (1.0 - candidate.quote.spread_pct / 0.70))
    geometry_score = max(0.0, min(25.0, structural_rr / 2.75 * 25.0))
    quality = trend_score + volume_score + spread_score + geometry_score

    speculative = policy.name == "SPECULATIVE"
    mover = policy.name == "MOVER"
    if risk_pct > policy.max_risk_pct:
        blockers.append(f"risk>{policy.max_risk_pct:.2f}")
    epsilon = 1e-9
    if target <= entry:
        blockers.append("no_structural_upside")
    if structural_rr + epsilon < policy.min_structural_rr:
        blockers.append(f"rr<{policy.min_structural_rr:.2f}")
    if candidate.quote.spread_pct > policy.max_spread_pct:
        blockers.append(f"spread>{policy.max_spread_pct:.2f}")
    if quality < policy.min_quality:
        blockers.append(f"quality<{policy.min_quality:.0f}")
    # Fast tape is discovery evidence, never authority to reverse negative
    # 1h/3h closed structure.  The 6h..24h ladder is a regime vote: this
    # permits a genuine reversal when most slower horizons agree without
    # letting one lagging window dominate the entire decision.
    if speculative:
        m1 = float(candidate.momentum.get("m1", 0) or 0)
        m5 = float(candidate.momentum.get("m5", 0) or 0)
        accel = float(candidate.momentum.get("accel_5_vs_15", 0) or 0)
        if not (m1 > 0 and m5 > 0 and accel > 0):
            blockers.append("speculative_short_trend_required")
    elif mover:
        # The raw-mover rescue lane is allowed to enter before a full closed
        # candle reclaim, but it still needs live directional evidence and a
        # non-catastrophic reversal.  Spread, risk, book depth and slippage
        # remain hard execution gates downstream.
        m1 = _number(candidate.momentum, "m1")
        m5 = _number(candidate.momentum, "m5")
        s20 = _number(candidate.momentum, "s20")
        accel = _number(candidate.momentum, "accel_5_vs_15")
        if not (m1 > 0 or m5 > 0 or accel > 0):
            blockers.append("mover_short_trend_absent")
        if m1 <= -0.12 and s20 <= -0.08:
            blockers.append("mover_reversal_too_strong")
    else:
        blockers.extend(blocker for blocker in trend_blockers
                        if not (short_confirmed and blocker == "trend_not_positive"))

    # A positive short/medium return alone is a lagging observation: after a pump it
    # remains positive while the market is already distributing.  Only closed
    # 15m candles reach this point (the client excludes the live candle).
    #
    # The former target model used the most recent six-hour high as upside.  If
    # price is materially below a very recent peak, that is not a fresh target;
    # it is a post-pump fade.  Fail closed until a later breakout/retest model
    # can prove a new level with executable depth.
    recent_window = 8  # two hours of closed 15m structure
    recent_slice = highs[-recent_window:]
    peak_offset = max(range(len(recent_slice)), key=lambda index: recent_slice[index])
    recent_peak = recent_slice[peak_offset]
    peak_age = recent_window - 1 - peak_offset
    peak_retrace_pct = ((recent_peak - entry) / recent_peak) * 100.0 if recent_peak > 0 else 0.0
    if (
        1 <= peak_age <= recent_window - 1
        and peak_retrace_pct > 5.0
    ):
        blockers.append("post_spike_drawdown>5")

    # Do not chase a fresh book that has already run far beyond the latest
    # confirmed close.  The limit is volatility-aware, but never wider than
    # 1.25%; it protects the approval path as well as discovery.
    last_close = closes[-1]
    intrabar_extension_pct = ((entry - last_close) / last_close) * 100.0 if last_close > 0 else 0.0
    extension_ceiling = 1.25
    max_intrabar_extension_pct = min(extension_ceiling, max(0.35, (atr / last_close) * 50.0)) if last_close > 0 else 0.35
    if intrabar_extension_pct > max_intrabar_extension_pct:
        blockers.append("intrabar_chase")

    # A recovery must be visible in closed structure, not just as a flashing
    # quote.  This rejects the lower-high / rolling-over sequences seen after
    # the SWELL, PYR and NCT spikes.
    closed_reclaim = closes[-1] > closes[-2] and closes[-2] >= closes[-3]
    if not speculative and not mover and not closed_reclaim and not short_confirmed:
        blockers.append("reclaim_unconfirmed")
    # A fresh continuation without a proven resistance target is valuable
    # information but not a trade.  Keep it as a bounded WATCH observation
    # until the price offers a real pullback/reclaim geometry.
    if early_continuation and target <= entry:
        verdict = "WATCH"
        target_basis = "EARLY_CONTINUATION_WATCH"
    else:
        verdict = "CANDIDATE" if not blockers else "WAIT"
    return Decision(
        candidate.symbol,
        policy.name,
        verdict,
        round(quality, 2),
        round(risk_pct, 4),
        round(structural_rr, 3),
        entry,
        stop,
        target,
        round(candidate.quote.spread_pct, 4),
        round(trend_1h, 4),
        round(trend_6h, 4),
        round(volume_accel, 4),
        target_basis,
        tuple(blockers),
        time.time(),
        {key: round(value, 4) for key, value in trend_ladder.items()},
    )


def evaluate_ignition(candidate: Candidate, candles: list[dict]) -> Decision:
    """Evaluate a fresh breakout without pretending it is a mature reclaim.

    The normal strategy deliberately waits for closed-candle geometry.  This
    lane uses the same venue book and closed candles, but permits a small,
    confirmation-gated starter position when the local tape is persistently
    accelerating.  The target is explicitly risk-defined; it is not presented
    as a historical resistance level.
    """
    parsed = [_candle(row) for row in candles]
    parsed = [row for row in parsed if row[0] > 0 and row[1] >= row[2] > 0 and row[3] > 0]
    blockers: list[str] = []
    if len(parsed) < 24:
        return Decision(candidate.symbol, IGNITION.name, "REJECT", 0, 0, 0,
                        candidate.quote.ask, 0, 0, candidate.quote.spread_pct,
                        0, 0, 0, "UNAVAILABLE", ("candles<24",), time.time())

    closes = [row[3] for row in parsed]
    highs = [row[1] for row in parsed]
    lows = [row[2] for row in parsed]
    volumes = [row[4] for row in parsed]
    entry = candidate.quote.ask
    true_ranges = [
        max(highs[index] - lows[index], abs(highs[index] - closes[index - 1]), abs(lows[index] - closes[index - 1]))
        for index in range(1, len(parsed))
    ]
    atr = sum(true_ranges[-14:]) / max(1, len(true_ranges[-14:]))
    # A starter position needs a near invalidation.  Old code selected the
    # *lower* of ATR distance and recent support, which could turn a fast lane
    # into a very wide structural stop.  Keep the invalidation between 0.45%
    # and 4.5%, using nearby support only when it tightens that band.
    support = min(lows[-4:])
    risk_distance = min(max(atr * 0.40, entry * 0.0045), entry * 0.045)
    stop = entry - risk_distance
    if 0 < support < entry:
        stop = max(stop, min(support, entry - entry * 0.0045))
    if stop <= 0 or stop >= entry:
        blockers.append("invalid_stop")
        stop = max(entry * 0.99, 0.0)
    risk_pct = ((entry - stop) / entry) * 100.0 if entry > 0 else 0.0
    target = entry + (entry - stop) * IGNITION.min_structural_rr if entry > stop else entry
    structural_rr = (target - entry) / (entry - stop) if entry > stop else 0.0

    trend_ladder = _trend_ladder(closes)
    trend_1h = trend_ladder.get("1h", 0.0)
    trend_6h = trend_ladder.get("6h", 0.0)
    trend_blockers, _trend_consensus_value = _trend_blockers(
        trend_ladder, IGNITION_TREND_CONSENSUS
    )
    recent_vol = sum(volumes[-4:]) / 4.0
    base_vol = sum(volumes[-24:-4]) / max(1, len(volumes[-24:-4]))
    volume_accel = recent_vol / base_vol if base_vol > 0 else 0.0
    m1 = _number(candidate.momentum, "m1")
    m5 = _number(candidate.momentum, "m5")
    m15 = _number(candidate.momentum, "m15")
    s20 = _number(candidate.momentum, "s20")
    accel = _number(candidate.momentum, "accel_5_vs_15")
    signal_lease = bool(candidate.momentum.get("ignition_signal_lease", False))
    score_s20 = max(s20, _number(candidate.momentum, "ignition_validated_s20")) if signal_lease else s20
    score_m1 = max(m1, _number(candidate.momentum, "ignition_validated_m1")) if signal_lease else m1
    score_m5 = max(m5, _number(candidate.momentum, "ignition_validated_m5")) if signal_lease else m5
    persistence_score = min(
        28.0,
        max(0.0, score_s20) * 25.0
        + max(0.0, score_m1) * 10.0
        + max(0.0, score_m5) * 4.0,
    )
    volume_score = min(22.0, max(0.0, volume_accel - 0.5) * 18.0)
    spread_score = max(0.0, 25.0 * (1.0 - candidate.quote.spread_pct / IGNITION.max_spread_pct))
    geometry_score = max(0.0, min(25.0, (IGNITION.max_risk_pct - risk_pct) / IGNITION.max_risk_pct * 25.0))
    quality = persistence_score + volume_score + spread_score + geometry_score

    if not bool(candidate.momentum.get("ignition", False)) and not signal_lease:
        blockers.append("ignition_unconfirmed")
    if risk_pct > IGNITION.max_risk_pct:
        blockers.append(f"risk>{IGNITION.max_risk_pct:.2f}")
    if candidate.quote.spread_pct > IGNITION.max_spread_pct:
        blockers.append(f"spread>{IGNITION.max_spread_pct:.2f}")
    if quality < IGNITION.min_quality:
        blockers.append(f"quality<{IGNITION.min_quality:.0f}")
    if m1 <= 0 or m5 <= 0 or accel < -0.05:
        blockers.append("momentum_not_persistent")
    # A signal lease prevents notification churn; it can never convert a
    # fading current tape into a BUY. Require the whole fast stack now.
    if not bool(candidate.momentum.get("early_continuation", False)):
        blockers.append("early_continuation_unconfirmed")
    if quality < IGNITION_ENTRY_MIN_QUALITY:
        blockers.append(f"ignition_quality<{IGNITION_ENTRY_MIN_QUALITY:.0f}")
    if s20 < IGNITION_ENTRY_MIN_S20_PCT:
        blockers.append("ignition_s20_weak")
    if m1 < IGNITION_ENTRY_MIN_M1_PCT:
        blockers.append("ignition_m1_weak")
    if m5 < IGNITION_ENTRY_MIN_M5_PCT:
        blockers.append("ignition_m5_weak")
    if m15 < IGNITION_ENTRY_MIN_M15_PCT:
        blockers.append("ignition_m15_weak")
    if accel < IGNITION_ENTRY_MIN_ACCEL_PCT:
        blockers.append("ignition_acceleration_weak")
    # A move already far above the last confirmed 15m close is exactly the
    # HNT/KARRAT shape this lane must avoid.
    last_close = closes[-1]
    intrabar_extension_pct = ((entry - last_close) / last_close) * 100.0 if last_close > 0 else 0.0
    extension_cap = min(2.00, max(0.45, (atr / last_close) * 50.0)) if last_close > 0 else 0.45
    if intrabar_extension_pct > extension_cap:
        signal_entry = _number(candidate.momentum, "ignition_signal_entry")
        max_signal_drift = _number(
            candidate.momentum, "ignition_signal_max_entry_drift_pct", default=0.75
        )
        signal_drift = (
            ((entry - signal_entry) / signal_entry) * 100.0
            if signal_entry > 0 else math.inf
        )
        # The original alert already cleared the closed-candle chase gate.
        # While its live tape remains positive, use bounded alert-price drift
        # so the same move does not become a false chase on the next pulse.
        if not (
            signal_lease
            and signal_entry > 0
            and signal_drift <= max_signal_drift
        ):
            blockers.append("intrabar_chase")
    blockers.extend(trend_blockers)
    # The shadow cohort showed that the most violent one-hour pumps (MLN,
    # ZKJ, FIL) were late entries and then mean-reverted sharply.  IGNITION is
    # live again, but it may not chase an already overextended closed move.
    if trend_1h > IGNITION_MAX_TREND_1H_PCT:
        blockers.append(f"trend_1h>{IGNITION_MAX_TREND_1H_PCT:.2f}")

    return Decision(
        candidate.symbol, IGNITION.name, "CANDIDATE" if not blockers else "WAIT",
        round(quality, 2), round(risk_pct, 4), round(structural_rr, 3),
        entry, stop, target, round(candidate.quote.spread_pct, 4),
        round(trend_1h, 4), round(trend_6h, 4), round(volume_accel, 4),
        "IGNITION_RISK_MULTIPLE", tuple(blockers), time.time(),
        {key: round(value, 4) for key, value in trend_ladder.items()},
    )
