from __future__ import annotations

import time
from dataclasses import dataclass


@dataclass(frozen=True)
class Approval:
    approval_id: str
    symbol: str
    reason: str
    created_at: float
    expires_at: float


class ApprovalRegistry:
    """An expired capability immediately re-arms its symbol/reason alert."""

    def __init__(self, max_age_sec: float = 60.0, clock=time.time):
        self.max_age_sec = max_age_sec
        self.clock = clock
        self.pending: dict[str, Approval] = {}
        self.suppressed: set[tuple[str, str]] = set()

    def create(self, approval_id: str, symbol: str, reason: str) -> Approval:
        now = self.clock()
        approval = Approval(approval_id, symbol, reason, now, now + self.max_age_sec)
        self.pending[approval_id] = approval
        self.suppressed.add((symbol, reason))
        return approval

    def expire(self) -> list[Approval]:
        now = self.clock()
        expired = [item for item in self.pending.values() if item.expires_at <= now]
        for item in expired:
            self.pending.pop(item.approval_id, None)
            self.suppressed.discard((item.symbol, item.reason))
        return expired

    def alert_allowed(self, symbol: str, reason: str) -> bool:
        self.expire()
        return (symbol, reason) not in self.suppressed

