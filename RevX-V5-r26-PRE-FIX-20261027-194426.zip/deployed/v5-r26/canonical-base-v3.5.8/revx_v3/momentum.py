from __future__ import annotations

import time
from typing import Any


class MomentumTape:
    """Persisted, venue-native price tape built from the existing ticker batch.

    It adds no endpoint and no GPU work.  We sample the complete public ticker
    batch once per discovery cycle, retain a small rolling window, and derive
    short-horizon momentum from observed executable mids instead of ranking a
    coin mainly because it was already strong over the prior 24 hours.
    """

    def __init__(self, saved: Any = None, retention_sec: float = 4_800.0):
        self.retention_sec = max(900.0, float(retention_sec))
        self.samples: dict[str, list[tuple[float, float]]] = {}
        if isinstance(saved, dict):
            self._restore(saved)

    def _restore(self, saved: dict) -> None:
        cutoff = time.time() - self.retention_sec
        for symbol, values in saved.items():
            if not isinstance(values, list):
                continue
            parsed: list[tuple[float, float]] = []
            for value in values:
                if not isinstance(value, (list, tuple)) or len(value) < 2:
                    continue
                try:
                    ts, price = float(value[0]), float(value[1])
                except (TypeError, ValueError):
                    continue
                if ts >= cutoff and price > 0:
                    parsed.append((ts, price))
            if parsed:
                self.samples[str(symbol).upper()] = parsed[-90:]

    def snapshot(self) -> dict[str, list[list[float]]]:
        return {
            symbol: [[round(ts, 3), price] for ts, price in values[-90:]]
            for symbol, values in self.samples.items()
            if values
        }

    @staticmethod
    def _change(current: float, reference: float) -> float | None:
        if current <= 0 or reference <= 0:
            return None
        return (current / reference - 1.0) * 100.0

    @staticmethod
    def _reference(values: list[tuple[float, float]], target: float) -> tuple[float, float] | None:
        # Use the latest sample at or before the horizon; accepting a newer
        # point would make a 5m figure accidentally become a 90-second figure.
        eligible = [value for value in values if value[0] <= target]
        return eligible[-1] if eligible else None

    def observe(self, prices: dict[str, float], now: float | None = None) -> dict[str, dict[str, float | bool]]:
        now = time.time() if now is None else float(now)
        cutoff = now - self.retention_sec
        metrics: dict[str, dict[str, float | bool]] = {}
        for raw_symbol, raw_price in prices.items():
            symbol = str(raw_symbol).upper()
            try:
                price = float(raw_price)
            except (TypeError, ValueError):
                continue
            if price <= 0:
                continue
            values = [value for value in self.samples.get(symbol, []) if value[0] >= cutoff]
            if not values or now - values[-1][0] >= 15.0:
                values.append((now, price))
            else:
                values[-1] = (now, price)
            self.samples[symbol] = values[-90:]
            span = max(0.0, now - values[0][0]) if values else 0.0
            row: dict[str, float | bool] = {
                "price": price,
                "context_observations": float(len(values)),
                "context_span_sec": round(span, 3),
                # This is provenance/readiness telemetry only.  It does not
                # create an m5 signal early or relax any admission threshold.
                "five_minute_context_ready": bool(span >= 240.0 and len(values) >= 2),
            }
            for label, seconds in (("s20", 20.0), ("m1", 60.0), ("m5", 300.0), ("m15", 900.0), ("m60", 3600.0)):
                reference = self._reference(values, now - seconds)
                if reference is not None and now - reference[0] <= seconds + 110.0:
                    change = self._change(price, reference[1])
                    if change is not None:
                        row[label] = round(change, 6)
            m5 = float(row.get("m5", 0.0))
            m15 = float(row.get("m15", 0.0))
            m1 = float(row.get("m1", 0.0))
            s20 = float(row.get("s20", 0.0))
            row["accel_5_vs_15"] = round(m5 - m15 / 3.0, 6) if "m15" in row else 0.0
            row["early_continuation"] = bool(
                "m5" in row and "m15" in row
                and m5 >= 0.35 and m15 >= 0.60
                and m1 >= -0.12 and float(row["accel_5_vs_15"]) >= -0.10
            )
            # A separate, deliberately small entry lane.  It is not a raw
            # "top gainer" trigger: a move must be fresh, persistent across
            # three local horizons, and still accelerating.  It lets the
            # guarded engine ask for a shallow structural validation before a
            # mature 15-minute strategy can see a controlled reclaim.
            row["ignition"] = bool(
                "s20" in row and "m1" in row and "m5" in row
                and s20 >= 0.08 and m1 >= 0.18 and m5 >= 0.45
                and m1 <= 2.2 and m5 <= 8.0
                and float(row["accel_5_vs_15"]) >= -0.05
            )
            metrics[symbol] = row
        stale = [symbol for symbol, values in self.samples.items() if not values or values[-1][0] < cutoff]
        for symbol in stale:
            self.samples.pop(symbol, None)
        return metrics
