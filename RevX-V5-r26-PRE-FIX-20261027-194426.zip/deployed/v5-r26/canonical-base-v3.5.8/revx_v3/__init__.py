"""RevX v3 runtime.

Importing the package never starts workers or submits an order.  The shadow
client has no mutation surface; LIVE_GUARDED loads a separate client only after
explicit arming and still requires Telegram approvals.
"""

__version__ = "3.2.2-manual-inventory-manager"
