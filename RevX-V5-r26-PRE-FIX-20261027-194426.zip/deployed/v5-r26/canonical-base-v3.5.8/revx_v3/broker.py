from __future__ import annotations

import asyncio
import itertools
import random
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from .models import Priority, RequestJob, RequestKind


class RateLimited(RuntimeError):
    def __init__(self, message: str, retry_after: float | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class LaneCoolingDown(RuntimeError):
    """Local admission refusal; it is not a new venue HTTP 429."""

    def __init__(self, lane: Priority, remaining: float):
        super().__init__(f"lane {lane.name} cooling down for {remaining:.1f}s")
        self.lane = lane
        self.remaining = remaining


@dataclass
class BrokerMetrics:
    submitted: int = 0
    completed: int = 0
    failed: int = 0
    rate_limited: int = 0
    cooldown_deferred: int = 0
    total_queue_wait_sec: float = 0.0


class RequestBroker:
    """Single dispatch authority with strict priority between HTTP attempts."""

    def __init__(
        self,
        auth_gap_sec: float = 0.75,
        public_gap_sec: float = 1.10,
        clock=time.monotonic,
    ):
        self._queue: asyncio.PriorityQueue[RequestJob] = asyncio.PriorityQueue()
        self._seq = itertools.count()
        self._clock = clock
        self._gaps = {RequestKind.AUTH: auth_gap_sec, RequestKind.PUBLIC: public_gap_sec}
        self._last_start = defaultdict(lambda: 0.0)
        self._lane_cooldown_until = defaultdict(lambda: 0.0)
        self._lane_strikes = defaultdict(int)
        self._worker: asyncio.Task | None = None
        self._closing = False
        self.metrics = BrokerMetrics()

    async def start(self) -> None:
        if self._worker is None:
            self._worker = asyncio.create_task(self._run(), name="revx-request-broker")

    async def close(self) -> None:
        self._closing = True
        if self._worker:
            self._worker.cancel()
            try:
                await self._worker
            except asyncio.CancelledError:
                pass
            self._worker = None

    async def submit(self, lane: Priority, kind: RequestKind, action: str, operation) -> Any:
        if self._closing:
            raise RuntimeError("request broker is closing")
        await self.start()
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        queued_at = self._clock()
        job = RequestJob(int(lane), next(self._seq), lane, kind, action, operation, future)
        job.queued_at = queued_at  # runtime-only metric; deliberately not in ordering
        self.metrics.submitted += 1
        await self._queue.put(job)
        return await future

    def cooldown_remaining(self, lane: Priority) -> float:
        return max(0.0, self._lane_cooldown_until[lane] - self._clock())

    async def _run(self) -> None:
        while True:
            job = await self._queue.get()
            try:
                if job.future.cancelled():
                    continue
                remaining = self.cooldown_remaining(job.lane)
                if remaining > 0:
                    raise LaneCoolingDown(job.lane, remaining)
                gap_wait = self._gaps[job.kind] - (self._clock() - self._last_start[job.kind])
                if gap_wait > 0:
                    await asyncio.sleep(gap_wait)
                self._last_start[job.kind] = self._clock()
                self.metrics.total_queue_wait_sec += self._clock() - job.queued_at
                result = await job.operation()
                self._lane_strikes[job.lane] = 0
                self.metrics.completed += 1
                if not job.future.done():
                    job.future.set_result(result)
            except LaneCoolingDown as exc:
                # A local cooldown is only an admission decision. Registering it
                # as another HTTP 429 would move the deadline forward forever.
                self.metrics.cooldown_deferred += 1
                if not job.future.done():
                    job.future.set_exception(exc)
            except RateLimited as exc:
                self.metrics.rate_limited += 1
                self._register_429(job.lane, exc.retry_after)
                if not job.future.done():
                    job.future.set_exception(exc)
            except Exception as exc:
                self.metrics.failed += 1
                if not job.future.done():
                    job.future.set_exception(exc)
            finally:
                self._queue.task_done()

    def _register_429(self, lane: Priority, retry_after: float | None) -> None:
        self._lane_strikes[lane] += 1
        if lane == Priority.EXIT_CRITICAL:
            base, cap = 10.0, 60.0
        elif lane == Priority.EXIT_WATCH:
            base, cap = 15.0, 120.0
        else:
            base, cap = 60.0, 600.0
        calculated = min(cap, base * (2 ** (self._lane_strikes[lane] - 1)))
        duration = max(calculated, float(retry_after or 0.0))
        duration += random.uniform(0.0, min(1.0, duration * 0.05))
        self._lane_cooldown_until[lane] = self._clock() + duration
