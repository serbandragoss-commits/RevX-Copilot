from __future__ import annotations

import asyncio
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


@dataclass
class StateCommand:
    event_type: str
    mutator: Callable[[dict], Any]
    future: asyncio.Future


class StateOwner:
    """The only object allowed to mutate or persist v3 state."""

    def __init__(self, snapshot_path: Path, journal_path: Path, clock=time.time):
        self.snapshot_path = snapshot_path
        self.journal_path = journal_path
        self.clock = clock
        self.state: dict[str, Any] = {
            "schema": 3,
            "mode": "SHADOW",
            "signals": {},
            "positions": {},
            "outbox": {},
            "metrics": {},
            "revision": 0,
        }
        self._queue: asyncio.Queue[StateCommand] = asyncio.Queue()
        self._task: asyncio.Task | None = None

    def load(self) -> None:
        if not self.snapshot_path.exists():
            return
        with self.snapshot_path.open("r", encoding="utf-8-sig") as handle:
            loaded = json.load(handle)
        if int(loaded.get("schema", 0)) != 3:
            raise ValueError("refusing non-v3 state snapshot")
        self.state = loaded

    async def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="revx-state-owner")

    async def close(self) -> None:
        if self._task:
            await self._queue.join()
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def apply(self, event_type: str, mutator: Callable[[dict], Any]) -> Any:
        await self.start()
        future = asyncio.get_running_loop().create_future()
        await self._queue.put(StateCommand(event_type, mutator, future))
        return await future

    def view(self) -> dict:
        # JSON round-trip gives readers an immutable snapshot without exposing
        # mutable dictionaries owned by the state task.
        return json.loads(json.dumps(self.state, ensure_ascii=False))

    async def _run(self) -> None:
        while True:
            command = await self._queue.get()
            try:
                result = command.mutator(self.state)
                self.state["revision"] = int(self.state.get("revision", 0)) + 1
                event = {
                    "ts": self.clock(),
                    "revision": self.state["revision"],
                    "type": command.event_type,
                }
                self._append_event(event)
                self._write_snapshot()
                command.future.set_result(result)
            except Exception as exc:
                command.future.set_exception(exc)
            finally:
                self._queue.task_done()

    def _append_event(self, event: dict) -> None:
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        with self.journal_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(event, separators=(",", ":"), ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def _write_snapshot(self) -> None:
        self.snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.snapshot_path.with_suffix(self.snapshot_path.suffix + ".tmp")
        with tmp.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(self.state, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, self.snapshot_path)

