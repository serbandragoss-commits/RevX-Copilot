from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any


@dataclass
class CacheItem:
    value: Any
    expires_at: float
    generation: str | None = None


class SnapshotCache:
    """Small in-memory cache; generation keys prevent stale candle reuse."""

    def __init__(self, clock=time.time):
        self._clock = clock
        self._items: dict[str, CacheItem] = {}

    def get(self, key: str, generation: str | None = None) -> Any | None:
        item = self._items.get(key)
        if item is None or item.expires_at <= self._clock():
            self._items.pop(key, None)
            return None
        if generation is not None and item.generation != generation:
            return None
        return item.value

    def put(self, key: str, value: Any, ttl: float, generation: str | None = None) -> None:
        self._items[key] = CacheItem(value, self._clock() + max(0.0, ttl), generation)

    def invalidate(self, prefix: str = "") -> None:
        for key in list(self._items):
            if key.startswith(prefix):
                self._items.pop(key, None)


def closed_candle_generation(now: float, interval_sec: int = 900) -> str:
    """Generation changes only when another candle has fully closed."""
    if interval_sec <= 0:
        raise ValueError("interval_sec must be positive")
    return str(int(now // interval_sec) - 1)

