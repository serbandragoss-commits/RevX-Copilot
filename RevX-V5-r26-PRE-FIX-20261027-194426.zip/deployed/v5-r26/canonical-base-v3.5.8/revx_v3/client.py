from __future__ import annotations

import asyncio
import base64
import ctypes
import json
import platform
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from ctypes import wintypes
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, padding, rsa

from .broker import RateLimited, RequestBroker
from .models import Priority, RequestKind


class ApiError(RuntimeError):
    pass


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _dpapi_unprotect(encrypted_text: str) -> str:
    if platform.system() != "Windows":
        raise RuntimeError("DPAPI credentials can only be opened on Windows")
    serialized = encrypted_text.strip()
    # Windows PowerShell ConvertFrom-SecureString normally emits a hex DPAPI
    # blob.  PowerShell 7 variants may use base64, so support both explicitly.
    try:
        raw = bytes.fromhex(serialized)
    except ValueError:
        raw = base64.b64decode(serialized, validate=True)
    in_buffer = ctypes.create_string_buffer(raw, len(raw))
    in_blob = DATA_BLOB(len(raw), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_byte)))
    out_blob = DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
    )
    if not ok:
        raise ctypes.WinError()
    try:
        clear = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        # ConvertFrom-SecureString stores a UTF-16LE SecureString payload.
        return clear.decode("utf-16-le").rstrip("\x00")
    finally:
        ctypes.windll.kernel32.LocalFree(out_blob.pbData)


class RevXClient:
    """Long-lived direct HTTP client. It contains no order submission method."""

    def __init__(
        self,
        broker: RequestBroker,
        base_url: str = "https://revx.revolut.com",
        region: str = "EEA",
        api_key_file: Path | None = None,
        private_key_file: Path | None = None,
        timeout_sec: float = 20.0,
    ):
        self.broker = broker
        self.base_url = base_url.rstrip("/")
        self.region = region
        self.api_key_file = api_key_file
        self.private_key_file = private_key_file
        self.timeout_sec = timeout_sec
        self._api_key: str | None = None
        self._private_key = None

    def load_credentials(self) -> None:
        if not self.api_key_file or not self.private_key_file:
            raise RuntimeError("authenticated client paths are not configured")
        encrypted = self.api_key_file.read_text(encoding="ascii").strip()
        api_key = _dpapi_unprotect(encrypted)
        if len(api_key) != 64 or not api_key.isalnum():
            raise RuntimeError("decrypted API key has an invalid format")
        self._api_key = api_key
        self._private_key = serialization.load_pem_private_key(
            self.private_key_file.read_bytes(), password=None
        )

    async def public_get(self, path: str, query: dict[str, Any], lane: Priority, action: str):
        encoded = urllib.parse.urlencode(query)
        return await self.broker.submit(
            lane,
            RequestKind.PUBLIC,
            action,
            lambda: asyncio.to_thread(self._request, "GET", path, encoded, "", False),
        )

    async def auth_get(self, path: str, query: dict[str, Any] | None, lane: Priority, action: str):
        if self._api_key is None:
            self.load_credentials()
        encoded = urllib.parse.urlencode(query or {})
        return await self.broker.submit(
            lane,
            RequestKind.AUTH,
            action,
            lambda: asyncio.to_thread(self._request, "GET", path, encoded, "", True),
        )

    async def _auth_get_envelope(
        self, path: str, query: dict[str, Any] | None, lane: Priority, action: str
    ):
        """Authenticated GET that preserves data and pagination metadata."""
        if self._api_key is None:
            self.load_credentials()
        encoded = urllib.parse.urlencode(query or {})
        return await self.broker.submit(
            lane,
            RequestKind.AUTH,
            action,
            lambda: asyncio.to_thread(
                self._request, "GET", path, encoded, "", True, False
            ),
        )

    def _request(
        self, method: str, path: str, query: str, body: str,
        authenticated: bool, unwrap_data: bool = True,
    ):
        url = self.base_url + path + (("?" + query) if query else "")
        headers = {"Accept": "application/json", "User-Agent": "RevX-Agent-v3"}
        if authenticated:
            timestamp = str(int(time.time() * 1000))
            message = (timestamp + method.upper() + path + query + body).encode("utf-8")
            headers.update(
                {
                    "X-Revx-API-Key": self._api_key or "",
                    "X-Revx-Timestamp": timestamp,
                    "X-Revx-Signature": base64.b64encode(self._sign(message)).decode("ascii"),
                }
            )
        data = body.encode("utf-8") if body else None
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(url, data=data, method=method, headers=headers)
        attempts = 2 if method.upper() == "GET" else 1
        for attempt in range(attempts):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout_sec) as response:
                    raw = response.read()
                break
            except (TimeoutError, socket.timeout) as exc:
                if attempt + 1 < attempts:
                    time.sleep(0.5)
                    continue
                raise ApiError(f"transport error {path}: timed out") from exc
            except urllib.error.HTTPError as exc:
                retry = exc.headers.get("Retry-After")
                if exc.code == 429:
                    try:
                        # Revolut X defines Retry-After in milliseconds.  The
                        # broker cooldown clock is seconds.
                        retry_after = max(0.0, float(retry) / 1000.0) if retry else None
                    except ValueError:
                        retry_after = None
                    raise RateLimited(f"HTTP 429 action={path}", retry_after) from exc
                detail = exc.read(1000).decode("utf-8", "replace")
                raise ApiError(f"HTTP {exc.code} {path}: {detail}") from exc
            except urllib.error.URLError as exc:
                reason = str(getattr(exc, "reason", exc)).lower()
                if attempt + 1 < attempts and "timed out" in reason:
                    time.sleep(0.5)
                    continue
                raise ApiError(f"transport error {path}: {exc.reason}") from exc
        if not raw:
            return None
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise ApiError(f"invalid JSON from {path}") from exc
        if unwrap_data and isinstance(decoded, dict):
            return decoded.get("data", decoded)
        return decoded

    def _sign(self, message: bytes) -> bytes:
        key = self._private_key
        if isinstance(key, ed25519.Ed25519PrivateKey):
            return key.sign(message)
        if isinstance(key, rsa.RSAPrivateKey):
            return key.sign(message, padding.PKCS1v15(), hashes.SHA256())
        if hasattr(key, "sign"):
            return key.sign(message)
        raise RuntimeError(f"unsupported private-key type: {type(key).__name__}")

    async def tickers(self, lane: Priority = Priority.DISCOVERY):
        return await self.public_get(
            "/api/1.0/public/tickers", {"region": self.region}, lane, "tickers"
        )

    async def order_book(self, symbol: str, limit: int = 50, lane: Priority = Priority.ENTRY):
        return await self.public_get(
            f"/api/2.0/public/order-book/{symbol}",
            {"limit": limit, "region": self.region},
            lane,
            "order-book",
        )

    async def candles(self, symbol: str, interval: int = 15, hours: int = 24):
        # Never let an unfinished candle masquerade as confirmed structure.  The
        # endpoint's `until` boundary is the beginning of the live interval, so
        # every candle returned here has closed before it enters a BUY decision.
        interval_sec = max(1, int(interval)) * 60
        until = int(time.time() // interval_sec) * interval_sec * 1000
        since = until - hours * 60 * 60 * 1000
        return await self.auth_get(
            f"/api/1.0/candles/{symbol}",
            {"interval": interval, "since": since, "until": until},
            Priority.ENTRY,
            "candles",
        )

    async def balances(self, lane: Priority = Priority.EXIT_WATCH):
        return await self.auth_get("/api/1.0/balances", None, lane, "balances")

    async def pair_configurations(self, lane: Priority = Priority.ENTRY):
        return await self.public_get(
            "/api/1.0/public/configuration/pairs", {"region": self.region}, lane, "pair-config"
        )

    async def active_orders(self, symbol: str | None = None, lane: Priority = Priority.EXIT_WATCH):
        query: dict[str, Any] = {"limit": 100}
        if symbol:
            query["symbols"] = symbol
        return await self._paginated_orders(
            "/api/1.0/orders/active", query, lane, "active-orders"
        )

    async def historical_orders(
        self, symbol: str | None = None, hours: int = 24, lane: Priority = Priority.EXIT_WATCH
    ):
        end = int(time.time() * 1000)
        query: dict[str, Any] = {
            "start_date": end - hours * 60 * 60 * 1000,
            "end_date": end,
            "limit": 100,
        }
        if symbol:
            query["symbols"] = symbol
        return await self._paginated_orders(
            "/api/1.0/orders/historical", query, lane, "historical-orders"
        )

    async def _paginated_orders(
        self,
        path: str,
        query: dict[str, Any],
        lane: Priority,
        action: str,
        max_pages: int = 100,
    ) -> dict[str, Any]:
        """Return complete bounded order truth and retain every page metadata."""
        rows: list[dict[str, Any]] = []
        page_metadata: list[dict[str, Any]] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        for page_number in range(1, max_pages + 1):
            page_query = dict(query)
            if cursor:
                page_query["cursor"] = cursor
            payload = await self._auth_get_envelope(
                path, page_query, lane, f"{action}:page-{page_number}"
            )
            if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
                raise ApiError(f"invalid paginated response from {path}")
            if any(not isinstance(row, dict) for row in payload["data"]):
                raise ApiError(f"invalid order row in paginated response from {path}")
            rows.extend(payload["data"])
            metadata = payload.get("metadata")
            if not isinstance(metadata, dict):
                raise ApiError(f"invalid pagination metadata from {path}")
            page_metadata.append(dict(metadata))
            next_cursor = str(metadata.get("next_cursor") or "")
            if not next_cursor:
                return {
                    "data": rows,
                    "metadata": {
                        "pages": page_metadata,
                        "page_count": page_number,
                        "total_items": len(rows),
                        "pagination_complete": True,
                    },
                }
            if next_cursor in seen_cursors:
                raise ApiError(f"repeated pagination cursor from {path}")
            seen_cursors.add(next_cursor)
            cursor = next_cursor
        raise ApiError(f"pagination exceeded {max_pages} pages for {path}")

    async def order(self, venue_order_id: str, lane: Priority = Priority.EXIT_WATCH):
        return await self.auth_get(
            f"/api/1.0/orders/{venue_order_id}", None, lane, "order"
        )


class LiveRevXClient(RevXClient):
    """Mutation surface loaded only by the LIVE_GUARDED runtime."""

    async def _auth_mutation(
        self,
        method: str,
        path: str,
        body_obj: dict[str, Any] | None,
        lane: Priority,
        action: str,
    ):
        from revx_v5.live_gate import require_live_mutation
        require_live_mutation()
        if self._api_key is None:
            self.load_credentials()
        body = json.dumps(body_obj, separators=(",", ":"), ensure_ascii=False) if body_obj else ""
        def guarded_request():
            # Recheck after queueing, at actual dispatch: never retry a mutation.
            require_live_mutation()
            return self._request(method, path, "", body, True)
        return await self.broker.submit(
            lane,
            RequestKind.AUTH,
            action,
            lambda: asyncio.to_thread(guarded_request),
        )

    async def submit_order(self, body_obj: dict[str, Any], lane: Priority):
        return await self._auth_mutation(
            "POST", "/api/1.0/orders", body_obj, lane, "submit-order"
        )

    async def cancel_order(self, venue_order_id: str, lane: Priority):
        return await self._auth_mutation(
            "DELETE", f"/api/1.0/orders/{venue_order_id}", None, lane, "cancel-order"
        )
