from __future__ import annotations

import itertools
from typing import Any, Iterable


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _symbol(value: Any) -> str:
    return str(value or "").upper().replace("/", "-")


def _fee_asset(value: Any) -> str:
    # Revolut X may expose assets as either ENA or X:8:ENA.
    return str(value or "").upper().split(":")[-1]


def owned_order_ids(state: dict) -> set[str]:
    result: set[str] = set()
    for collection in ("signals", "positions", "exits"):
        rows = state.get(collection, {})
        if not isinstance(rows, dict):
            continue
        for row in rows.values():
            if not isinstance(row, dict):
                continue
            for key in (
                "venue_order_id", "entry_order_id", "exit_order_id", "client_order_id"
            ):
                if row.get(key):
                    result.add(str(row[key]))
            order = row.get("order")
            if isinstance(order, dict):
                for key in ("id", "venue_order_id", "client_order_id"):
                    if order.get(key):
                        result.add(str(order[key]))
            manual_lots = row.get("manual_lots")
            if isinstance(manual_lots, list):
                for lot in manual_lots:
                    if not isinstance(lot, dict):
                        continue
                    for key in ("venue_order_id", "client_order_id"):
                        if lot.get(key):
                            result.add(str(lot[key]))
    return result


def normalized_buy_lots(
    orders: Iterable[dict], symbol: str, excluded_order_ids: set[str] | None = None
) -> list[dict]:
    dash = _symbol(symbol)
    base = dash.removesuffix("-USD")
    excluded = {str(value) for value in (excluded_order_ids or set())}
    lots: list[dict] = []
    seen: set[str] = set()
    for row in orders:
        if not isinstance(row, dict):
            continue
        if _symbol(row.get("symbol")) != dash or str(row.get("side", "")).lower() != "buy":
            continue
        status = str(row.get("status", row.get("state", ""))).lower()
        if status not in {"filled", "cancelled", "canceled", "expired"}:
            continue
        venue_id = str(row.get("id", row.get("venue_order_id", "")))
        client_id = str(row.get("client_order_id", ""))
        if not venue_id or venue_id in seen or venue_id in excluded or client_id in excluded:
            continue
        gross = _f(row.get("filled_quantity"))
        average = _f(row.get("average_fill_price"), _f(row.get("price")))
        if gross <= 0 or average <= 0:
            continue
        fee = max(0.0, _f(row.get("total_fee")))
        fee_asset = _fee_asset(row.get("fee_currency"))
        net = gross - fee if fee_asset == base else gross
        if net <= 0:
            continue
        cost = _f(row.get("filled_amount"), gross * average)
        if cost <= 0:
            cost = gross * average
        if fee_asset == "USD":
            cost += fee
        lots.append(
            {
                "venue_order_id": venue_id,
                "client_order_id": client_id,
                "filled_quantity": gross,
                "net_quantity": net,
                "average_fill_price": average,
                "cost_usd": cost,
                "fee": fee,
                "fee_currency": str(row.get("fee_currency", "")),
                "created_date": int(_f(row.get("created_date"))),
            }
        )
        seen.add(venue_id)
    return sorted(lots, key=lambda row: row["created_date"], reverse=True)


def unique_buy_lot_match(
    orders: Iterable[dict],
    symbol: str,
    target_quantity: float,
    excluded_order_ids: set[str] | None = None,
    max_lots: int = 16,
) -> dict:
    """Return one exact recent BUY-lot subset; ambiguity always fails closed."""
    target = float(target_quantity)
    tolerance = max(1e-10, abs(target) * 1e-4)
    lots = normalized_buy_lots(orders, symbol, excluded_order_ids)[:max_lots]
    matches: list[tuple[dict, ...]] = []
    for count in range(1, len(lots) + 1):
        for combo in itertools.combinations(lots, count):
            if abs(sum(row["net_quantity"] for row in combo) - target) <= tolerance:
                matches.append(combo)
                if len(matches) > 1:
                    return {
                        "status": "AMBIGUOUS",
                        "target_quantity": target,
                        "tolerance": tolerance,
                        "candidate_count": len(matches),
                    }
    if not matches:
        return {
            "status": "NO_EXACT_MATCH",
            "target_quantity": target,
            "tolerance": tolerance,
            "candidate_lots": len(lots),
        }
    selected = list(matches[0])
    net = sum(row["net_quantity"] for row in selected)
    cost = sum(row["cost_usd"] for row in selected)
    return {
        "status": "MATCHED",
        "target_quantity": target,
        "matched_quantity": net,
        "cost_usd": cost,
        "effective_average_price": cost / net,
        "tolerance": tolerance,
        "lots": selected,
    }
