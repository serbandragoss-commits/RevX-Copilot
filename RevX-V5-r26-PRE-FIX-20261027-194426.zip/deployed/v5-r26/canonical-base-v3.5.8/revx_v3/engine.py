from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import asdict
from pathlib import Path

from .broker import LaneCoolingDown, RateLimited
from .cache import SnapshotCache, closed_candle_generation
from .client import RevXClient
from .momentum import MomentumTape
from .models import Candidate, Priority, Quote
from .state import StateOwner
from .strategy import AMBITIOUS, IGNITION, STANDARD, evaluate, evaluate_ignition, quote_from_ticker, rank_candidates


class ShadowEngine:
    def __init__(self, config: dict, client: RevXClient, state: StateOwner, logger: logging.Logger):
        self.config = config
        self.client = client
        self.state = state
        self.log = logger
        self.cache = SnapshotCache()
        self._stop = asyncio.Event()
        self._validation_last_seen: dict[str, float] = {}
        self._validation_rotation_epoch = 0
        self._last_validation_selection: dict[str, float | int] = {}
        self._momentum_tape = MomentumTape()
        self._latest_mids: dict[str, float] = {}
        self._latest_quotes: dict[str, dict[str, float]] = {}
        self._entry_validation_budget = 5
        self._entry_clean_cycles = 0
        self._last_universe_missing: tuple[str, ...] = ()
        self.label = "SHADOW" if str(config.get("mode", "SHADOW")).upper() == "SHADOW" else "LIVE"

    def stop(self) -> None:
        self._stop.set()

    def _shortlist_limit(self) -> int:
        """Wide discovery without weakening the ranking or entry policy."""
        return max(
            1,
            int(self.config.get("shortlist", 15))
            + max(0, int(self.config.get("breadth_shortlist_increment", 15))),
        )

    def _validation_ceiling(self) -> int:
        """Wide ticker discovery, bounded expensive validation."""
        configured = max(
            1,
            int(self.config.get("max_validations_per_cycle", 3))
            + max(0, int(self.config.get("breadth_validation_increment", 5))),
        )
        # 30 ticker candidates are local work; order-book/candle validation is
        # venue work.  Seven is a hard ceiling until the venue proves it can
        # sustain more without creating blind cooldowns.
        return min(configured, max(3, int(self.config.get("entry_validation_max", 7))))

    def _validation_floor(self) -> int:
        return min(self._validation_ceiling(), max(2, int(self.config.get("entry_validation_min", 3))))

    def _validation_limit(self) -> int:
        return max(self._validation_floor(), min(self._validation_ceiling(), self._entry_validation_budget))

    def _restore_entry_admission(self, saved: object) -> None:
        saved = saved if isinstance(saved, dict) else {}
        initial = int(self.config.get("entry_validation_initial", 5))
        budget = int(saved.get("budget", initial))
        self._entry_validation_budget = max(self._validation_floor(), min(self._validation_ceiling(), budget))
        self._entry_clean_cycles = max(0, int(saved.get("clean_cycles", 0)))

    def _entry_admission_snapshot(self) -> dict[str, int]:
        return {
            "budget": self._validation_limit(),
            "clean_cycles": self._entry_clean_cycles,
            "floor": self._validation_floor(),
            "ceiling": self._validation_ceiling(),
        }

    def _on_entry_rate_limit(self) -> None:
        previous = self._validation_limit()
        self._entry_validation_budget = max(self._validation_floor(), previous - 2)
        self._entry_clean_cycles = 0
        if self._entry_validation_budget < previous:
            self.log.warning(
                "ENTRY ADMISSION reduced validations=%d->%d after venue 429",
                previous,
                self._entry_validation_budget,
            )

    def _on_clean_entry_cycle(self) -> None:
        if self._entry_validation_budget >= self._validation_ceiling():
            self._entry_clean_cycles = 0
            return
        self._entry_clean_cycles += 1
        # Recover deliberately. A single quiet minute is not evidence that the
        # venue has accepted a higher request budget again.
        recovery_cycles = max(8, int(self.config.get("entry_validation_recovery_cycles", 12)))
        if self._entry_clean_cycles >= recovery_cycles:
            self._entry_validation_budget += 1
            self._entry_clean_cycles = 0
            self.log.info("ENTRY ADMISSION recovered validations=%d", self._entry_validation_budget)

    async def run(self, once: bool = False) -> None:
        self.state.load()
        self._momentum_tape = MomentumTape(self.state.state.get("momentum_tape"))
        self._restore_entry_admission(self.state.state.get("entry_admission"))
        saved_fairness = self.state.state.get("validation_last_seen", {})
        if isinstance(saved_fairness, dict):
            self._validation_last_seen = {
                str(symbol): float(value)
                for symbol, value in saved_fairness.items()
                if isinstance(value, (int, float))
            }
        self._validation_rotation_epoch = max(
            0, int(self.state.state.get("validation_rotation_epoch", 0))
        )
        await self.state.start()
        self.log.info(
            "RevX Agent v3.0 SHADOW.3 starting | execution surface absent | "
            "coexistence=%s scan=%ss validations=%s",
            bool(self.config.get("coexistence_mode", False)),
            self.config.get("scan_interval_sec", 60),
            self._validation_limit(),
        )
        while not self._stop.is_set():
            started = time.monotonic()
            try:
                await self.discovery_cycle()
            except LaneCoolingDown as exc:
                self.log.warning(
                    "%s CYCLE DEFERRED lane=%s remaining=%.1fs | local cooldown; no request attempted",
                    self.label,
                    exc.lane.name,
                    exc.remaining,
                )
            except RateLimited as exc:
                self.log.warning(
                    "%s VENUE RATE LIMIT retry_after=%s | cooldown begins once",
                    self.label,
                    exc.retry_after,
                )
            except Exception:
                self.log.exception("%s CYCLE ERROR", self.label)
            if once:
                break
            elapsed = time.monotonic() - started
            wait = max(0.0, float(self.config.get("scan_interval_sec", 60)) - elapsed)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=wait)
            except asyncio.TimeoutError:
                pass
        await self.state.close()

    async def discovery_cycle(self) -> list[dict]:
        started = time.monotonic()
        remaining = self.client.broker.cooldown_remaining(Priority.ENTRY)
        if remaining > 0:
            raise LaneCoolingDown(Priority.ENTRY, remaining)
        requests_before = self.client.broker.metrics.submitted
        owned = await self._owned_symbols()
        rows = await self.client.tickers(Priority.DISCOVERY)
        if isinstance(rows, dict):
            rows = list(rows.values())
        observed_prices = {}
        observed_quotes = {}
        observed_at = time.time()
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            quote = quote_from_ticker(row)
            if quote is not None:
                observed_prices[quote.symbol] = quote.mid
                observed_quotes[quote.symbol] = {
                    "bid": quote.bid,
                    "ask": quote.ask,
                    "spread_pct": quote.spread_pct,
                    "observed_at": observed_at,
                }
        live_momentum = self._momentum_tape.observe(observed_prices)
        self._latest_mids = dict(observed_prices)
        self._latest_quotes = dict(observed_quotes)
        coverage_symbols = {
            str(symbol).upper().replace("/", "-")
            for symbol in self.config.get("coverage_watch_symbols", [])
            if str(symbol).strip()
        }
        missing_coverage = tuple(sorted(symbol for symbol in coverage_symbols if symbol not in observed_prices))
        if missing_coverage != self._last_universe_missing:
            if missing_coverage:
                self.log.warning(
                    "UNIVERSE COVERAGE MISSING %s | absent from venue ticker batch; no order can be proposed",
                    ",".join(missing_coverage),
                )
            elif self._last_universe_missing:
                self.log.info("UNIVERSE COVERAGE RECOVERED %s", ",".join(self._last_universe_missing))
            self._last_universe_missing = missing_coverage
        # Ranking is cheap local work. Keep every strategy-eligible instrument
        # in the admission pool, then spend the bounded venue request budget
        # through surge priority plus fair rotation. Truncating here used to
        # make feed order an accidental discovery filter.
        standard = rank_candidates(rows or [], owned, STANDARD, None, live_momentum)
        ambitious = rank_candidates(rows or [], owned, AMBITIOUS, None, live_momentum)
        # Top gainers are one input, never the universe itself.  IGNITION uses
        # the same full batch with a zero 24h floor so a fresh token can earn a
        # deep validation before it becomes a headline gainer.
        ignition = [
            item for item in rank_candidates(rows or [], owned, IGNITION, None, live_momentum)
            if bool(item.momentum.get("ignition", False))
        ]
        merged = []
        seen = set()
        for candidate in ignition + standard + ambitious:
            if candidate.symbol not in seen:
                merged.append(candidate)
                seen.add(candidate.symbol)
        max_validations = self._validation_limit()
        decisions = []
        selected = self._select_for_validation(merged, max_validations)
        rate_limit_detail = None
        for candidate in selected:
            try:
                candidate = await self._fresh_candidate(candidate)
                if candidate is None:
                    continue
                candles = await self._candles(candidate.symbol)
                standard_decision = asdict(evaluate(candidate, candles, STANDARD))
                ambitious_decision = asdict(evaluate(candidate, candles, AMBITIOUS))
                # The tape is part of the decision evidence.  Persist it so
                # size selection and final confirmation rebuild the same lane
                # instead of silently losing the signal that opened it.
                standard_decision["momentum"] = dict(candidate.momentum)
                ambitious_decision["momentum"] = dict(candidate.momentum)
                decisions.append(standard_decision)
                decisions.append(ambitious_decision)
                if bool(candidate.momentum.get("ignition", False)):
                    ignition_decision = asdict(evaluate_ignition(candidate, candles))
                    ignition_decision["momentum"] = dict(candidate.momentum)
                    decisions.append(ignition_decision)
            except LaneCoolingDown as exc:
                rate_limit_detail = f"LOCAL_COOLDOWN remaining={exc.remaining:.1f}s"
                break
            except RateLimited as exc:
                rate_limit_detail = f"VENUE_429 retry_after={exc.retry_after}"
                self._on_entry_rate_limit()
                break

        if rate_limit_detail is None and selected:
            self._on_clean_entry_cycle()

        requests_this_cycle = self.client.broker.metrics.submitted - requests_before

        def commit(state):
            state["last_cycle"] = {
                "ts": time.time(),
                "elapsed_sec": round(time.monotonic() - started, 3),
                "owned": sorted(owned),
                "shortlist": [asdict(item) for item in merged],
                "decisions": decisions,
                "requests_this_cycle": requests_this_cycle,
                "request_metrics": asdict(self.client.broker.metrics),
                "rate_limit_detail": rate_limit_detail,
                "early_continuations": sorted(
                    symbol for symbol, metrics in live_momentum.items()
                    if bool(metrics.get("early_continuation", False))
                ),
                "ignitions": sorted(
                    symbol for symbol, metrics in live_momentum.items()
                    if bool(metrics.get("ignition", False))
                ),
                "universe_audit": {
                    "venue_ticker_rows": len(rows or []),
                    "ticker_symbols": len(observed_prices),
                    "tape_observed": len(live_momentum),
                    "strategy_eligible": len(merged),
                    "eligible_shortlist": len(merged),
                    "validation_selected": len(selected),
                    "validation_deferred_budget": max(0, len(merged) - len(selected)),
                    **dict(self._last_validation_selection),
                    "coverage_requested": sorted(coverage_symbols),
                    "coverage_missing_from_venue": list(missing_coverage),
                    "top_gainers": [
                        {"symbol": item.symbol, "change_24h_pct": item.change_24h_pct, "score": item.score}
                        for item in sorted(merged, key=lambda value: value.change_24h_pct, reverse=True)[:12]
                    ],
                },
                "entry_admission": self._entry_admission_snapshot(),
            }
            state["momentum_tape"] = self._momentum_tape.snapshot()
            state["universe_audit"] = dict(state["last_cycle"].get("universe_audit") or {})
            state["validation_last_seen"] = dict(self._validation_last_seen)
            state["validation_rotation_epoch"] = self._validation_rotation_epoch
            state["entry_admission"] = self._entry_admission_snapshot()
            state["metrics"]["cycles"] = int(state["metrics"].get("cycles", 0)) + 1

        await self.state.apply(f"{self.label}_DISCOVERY_CYCLE", commit)
        self._record_discovery_evidence(
            rows or [], merged, selected, decisions, live_momentum, requests_this_cycle
        )
        self.log.info(
            "%s CYCLE universe=%d observed=%d eligible=%d selected=%d deferred=%d validated=%d decisions=%d requests=%d validationBudget=%d rotation=%d elapsed=%.2fs",
            self.label,
            len(rows or []),
            len(observed_prices),
            len(merged),
            len(selected),
            max(0, len(merged) - len(selected)),
            len({decision["symbol"] for decision in decisions}),
            len(decisions),
            requests_this_cycle,
            self._validation_limit(),
            self._validation_rotation_epoch,
            time.monotonic() - started,
        )
        if rate_limit_detail:
            self.log.warning("%s CYCLE PARTIAL %s | cooldown deadline will not be extended locally", self.label, rate_limit_detail)
        by_symbol: dict[str, list[dict]] = {}
        for decision in decisions:
            by_symbol.setdefault(str(decision["symbol"]), []).append(decision)
        for symbol, rows in by_symbol.items():
            candidates = [row for row in rows if row.get("verdict") == "CANDIDATE"]
            if candidates:
                for decision in candidates:
                    self.log.info(
                        "%s CANDIDATE %s",
                        self.label,
                        json.dumps(decision, separators=(",", ":")),
                    )
                continue
            standard = next((row for row in rows if row.get("lane") == "STANDARD"), rows[0])
            ambitious = next((row for row in rows if row.get("lane") == "AMBITIOUS"), rows[-1])
            self.log.info(
                "%s CHECK %s q=%.2f risk=%.2f%% rr=%.3f spread=%.3f%% trend=%.2f/%.2f%% "
                "| STD=%s | AMB=%s",
                self.label,
                symbol,
                float(standard.get("quality", 0)),
                float(standard.get("risk_pct", 0)),
                float(standard.get("structural_rr", 0)),
                float(standard.get("spread_pct", 0)),
                float(standard.get("trend_1h_pct", 0)),
                float(standard.get("trend_6h_pct", 0)),
                ",".join(standard.get("blockers") or []) or "PASS",
                ",".join(ambitious.get("blockers") or []) or "PASS",
            )
        return decisions

    def _record_discovery_evidence(
        self,
        rows: list[dict],
        merged: list[Candidate],
        selected: list[Candidate],
        decisions: list[dict],
        live_momentum: dict[str, dict[str, float | bool]],
        requests_this_cycle: int,
    ) -> None:
        """LIVE_GUARDED overrides this with a local append-only journal."""
        return None

    @staticmethod
    def _surge_priority(item: Candidate) -> int:
        momentum = item.momentum
        try:
            m1 = float(momentum.get("m1", 0.0))
            m5 = float(momentum.get("m5", 0.0))
        except (TypeError, ValueError):
            return 0
        if bool(momentum.get("ignition", False)):
            return 4
        if bool(momentum.get("early_continuation", False)):
            return 3
        if m5 >= 0.45 and m1 >= -0.15:
            return 2
        if m1 >= 0.35 and m5 >= 0.10:
            return 1
        return 0

    def _select_for_validation(self, candidates: list[Candidate], limit: int) -> list[Candidate]:
        """Prioritize surges, then rotate fairly across the full eligible pool."""
        limit = max(0, limit)
        now = time.time()
        active = {item.symbol for item in candidates}
        unseen = sum(item.symbol not in self._validation_last_seen for item in candidates)
        ages = [
            max(0.0, now - self._validation_last_seen[item.symbol])
            for item in candidates
            if item.symbol in self._validation_last_seen
        ]
        epoch = self._validation_rotation_epoch
        band = max(0.25, float(self.config.get("coverage_score_band_points", 3.0)))

        def rotating_tie(symbol: str) -> str:
            return hashlib.sha256(f"{epoch}:{symbol}".encode("utf-8")).hexdigest()

        def score_band(item: Candidate) -> int:
            return int(item.score // band)

        surge = sorted(
            (item for item in candidates if self._surge_priority(item) > 0),
            key=lambda item: (
                -self._surge_priority(item),
                self._validation_last_seen.get(item.symbol, 0.0),
                -score_band(item),
                rotating_tie(item.symbol),
            ),
        )
        configured_surge_slots = max(1, int(self.config.get("coverage_surge_slots", 2)))
        surge_slots = min(len(surge), limit, max(1, min(configured_surge_slots, limit // 2)))
        selected = surge[:surge_slots]
        selected_symbols = {item.symbol for item in selected}
        fair = sorted(
            (
                item for item in candidates
                if item.symbol not in selected_symbols and self._surge_priority(item) == 0
            ),
            key=lambda item: (
                self._validation_last_seen.get(item.symbol, 0.0),
                -score_band(item),
                rotating_tie(item.symbol),
            ),
        )
        selected.extend(fair[:limit - len(selected)])
        selected_symbols = {item.symbol for item in selected}
        if len(selected) < limit:
            overflow = sorted(
                (item for item in candidates if item.symbol not in selected_symbols),
                key=lambda item: (
                    self._validation_last_seen.get(item.symbol, 0.0),
                    -score_band(item),
                    rotating_tie(item.symbol),
                ),
            )
            selected.extend(overflow[:limit - len(selected)])
        stamp = now
        for item in selected:
            self._validation_last_seen[item.symbol] = stamp
        self._validation_last_seen = {
            symbol: value
            for symbol, value in self._validation_last_seen.items()
            if symbol in active
        }
        self._validation_rotation_epoch += 1
        self._last_validation_selection = {
            "unseen_eligible_before_selection": unseen,
            "oldest_validation_age_sec": round(max(ages, default=0.0), 3),
            "rotation_epoch": epoch,
        }
        return selected

    async def _owned_symbols(self) -> set[str]:
        cached = self.cache.get("balances")
        if cached is None:
            cached = await self.client.balances(Priority.EXIT_WATCH)
            self.cache.put("balances", cached, float(self.config.get("balance_ttl_sec", 60)))
        fiat = {"USD", "EUR", "GBP", "RON"}
        owned = set()
        for row in cached or []:
            try:
                total = float(row.get("total", 0))
                asset = str(row.get("currency", "")).upper()
            except (AttributeError, TypeError, ValueError):
                continue
            if total > 0 and asset and asset not in fiat:
                owned.add(f"{asset}-USD")
        return owned

    async def _candles(self, symbol: str) -> list[dict]:
        generation = closed_candle_generation(time.time(), 900)
        key = f"candles:{symbol}:15"
        cached = self.cache.get(key, generation)
        if cached is not None:
            return cached
        # One request covers the full 1h/3h/6h..24h closed-candle ladder plus
        # enough boundary margin for an exact 24-hour endpoint comparison.
        rows = await self.client.candles(symbol, 15, 27)
        if isinstance(rows, dict):
            rows = list(rows.values())
        self.cache.put(key, rows or [], 1000, generation)
        return rows or []

    async def _fresh_candidate(self, candidate: Candidate) -> Candidate | None:
        payload = await self.client.order_book(candidate.symbol, 50, Priority.ENTRY)
        if not isinstance(payload, dict):
            return None
        bids = payload.get("bids") or []
        asks = payload.get("asks") or []

        def level(item):
            if isinstance(item, dict):
                return float(item.get("price", item.get("p", 0)))
            if isinstance(item, (list, tuple)) and item:
                return float(item[0])
            return 0.0

        bid_values = [level(item) for item in bids]
        ask_values = [level(item) for item in asks]
        bid_values = [value for value in bid_values if value > 0]
        ask_values = [value for value in ask_values if value > 0]
        if not bid_values or not ask_values:
            return None
        bid, ask = max(bid_values), min(ask_values)
        if ask < bid:
            return None
        mid = (bid + ask) / 2.0
        spread = ((ask - bid) / mid) * 100.0
        quote = Quote(candidate.symbol, bid, ask, spread, "PUBLIC_V2_ORDER_BOOK")
        # The order book replaces only executable quote truth.  Dropping the
        # tape here silently converted early momentum WATCH candidates into
        # ordinary late-entry evaluations.
        return Candidate(
            candidate.symbol,
            candidate.score,
            candidate.change_24h_pct,
            quote,
            candidate.momentum,
        )


def configure_logging(log_path: Path) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("revx-v3")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("[%(asctime)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger
