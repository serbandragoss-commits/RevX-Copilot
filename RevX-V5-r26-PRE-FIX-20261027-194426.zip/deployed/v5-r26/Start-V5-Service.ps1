[CmdletBinding()]
param(
    [string]$Config = 'C:\Users\serba\revx-agent-v3\config-v3.live.json',
    [string]$StateRoot = 'C:\Users\serba\Documents\RevX\state\v5',
    [string]$TelegramToken = "$env:LOCALAPPDATA\RevX\V5\telegram-token.dpapi",
    [string]$RollbackPath = '',
    [double]$IntervalSec = 15,
    [int]$MaxCycles = 0
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot)
$sourceRoot = Join-Path $root 'canonical-base-v3.5.8'
$tool = Join-Path $root 'v5_live_service.py'
$preflightTool = Join-Path $root 'v5_authenticated_get_preflight.py'
$recoveryTool = Join-Path $root 'v5_recovery_preflight.py'
$launchGate = Join-Path $root 'v5_launch_gate.py'
$state = [IO.Path]::GetFullPath($StateRoot)
$authority = Join-Path $state 'authority-v5.json'
$health = Join-Path $state 'runtime-health-v5.json'
$lease = Join-Path $state 'runtime-v5.lock'
$report = Join-Path $state 'runtime-terminal-v5.json'
$kill = Join-Path $state 'v5.kill'
$watchdog = Join-Path $root 'v5_local_watchdog.ps1'
$preflightReport = Join-Path $state 'launch-preflight-v5.json'
$recoveryReport = Join-Path $state 'launch-recovery-v5.json'

foreach ($required in @($Config, $TelegramToken, $authority, $tool, $preflightTool, $recoveryTool,
        $launchGate, $watchdog,
        (Join-Path $sourceRoot 'revx_v3\__init__.py'))) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
        throw "Required V5 input is absent: $required"
    }
}
if (Test-Path -LiteralPath $kill) {
    throw "V5 kill switch is present: $kill"
}
$python = (Get-Command python -ErrorAction Stop).Source
New-Item -ItemType Directory -Force -Path $state | Out-Null

$authorityState = Get-Content -LiteralPath $authority -Raw | ConvertFrom-Json
$nowEpoch = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$maxLiveDurationSeconds = 86400
$stopAtEpoch = 0.0
$hasDeadline = [double]::TryParse(
    [string]$authorityState.expires_at_epoch,
    [Globalization.NumberStyles]::Float,
    [Globalization.CultureInfo]::InvariantCulture,
    [ref]$stopAtEpoch
)
$operatorAckReady = (
    [string]$authorityState.schema -eq 'revx-v5-runtime-authority-v1' -and
    [bool]$authorityState.execution_enabled -and
    [string]$authorityState.order_placement -eq 'ON' -and
    [string]$authorityState.acknowledgement -eq 'REVX_V5_LIVE_EXECUTION_AUTHORIZED' -and
    $hasDeadline -and $stopAtEpoch -gt $nowEpoch -and $stopAtEpoch -le ($nowEpoch + $maxLiveDurationSeconds)
)
if (-not $operatorAckReady) {
    throw 'V5 launch gate refused: operator_ack_missing_or_deadline_missing'
}

$rollbackReady = $false
if ($RollbackPath) {
    $rollbackRoot = [IO.Path]::GetFullPath($RollbackPath)
    $rollbackReady = (
        (Test-Path -LiteralPath $rollbackRoot -PathType Container) -and
        (Test-Path -LiteralPath (Join-Path $rollbackRoot 'deployed\v5-r25\revx_v5\live_runtime.py') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $rollbackRoot 'deployed\v5-r25\canonical-base-v3.5.8\revx_v3\client.py') -PathType Leaf)
    )
}
if (-not $rollbackReady) {
    throw 'V5 launch gate refused: rollback_not_ready'
}

$preflightOutput = & $python $preflightTool --config $Config --source-root $sourceRoot 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "V5 launch preflight failed: $($preflightOutput -join ' ')"
}
$preflightText = $preflightOutput -join [Environment]::NewLine
$preflightState = $preflightText | ConvertFrom-Json
$preflightTemp = "$preflightReport.tmp"
[IO.File]::WriteAllText(
    $preflightTemp,
    ($preflightState | ConvertTo-Json -Depth 20),
    [Text.UTF8Encoding]::new($false)
)
Move-Item -LiteralPath $preflightTemp -Destination $preflightReport -Force

$recoveryOutput = & $python $recoveryTool --config $Config --source-root $sourceRoot --state-root $state 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "V5 fresh recovery failed: $($recoveryOutput -join ' ')"
}
$recoveryState = ($recoveryOutput -join [Environment]::NewLine) | ConvertFrom-Json
if ([string]$recoveryState.status -ne 'PASS' -or
        [string]$recoveryState.recovery_status -ne 'PASS' -or
        [int]$recoveryState.unresolved_intents -ne 0 -or
        [int]$recoveryState.ambiguous_orders -ne 0 -or
        -not [bool]$recoveryState.external_inventory_reconciled -or
        [string]$recoveryState.live_contract.status -ne 'PASS') {
    throw "V5 launch gate refused: fresh_recovery_not_pass"
}
$recoveryTemp = "$recoveryReport.tmp"
[IO.File]::WriteAllText($recoveryTemp, ($recoveryState | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $recoveryTemp -Destination $recoveryReport -Force
$preflightState | Add-Member -NotePropertyName recovery_status -NotePropertyValue $recoveryState.status -Force
$preflightState | Add-Member -NotePropertyName live_contract_status -NotePropertyValue $recoveryState.live_contract.status -Force
[IO.File]::WriteAllText($preflightReport, ($preflightState | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))

$gateOutput = & $python $launchGate --report $preflightReport --operator-ack --rollback-ready 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "V5 launch gate refused: $($gateOutput -join ' ')"
}

$watchdogPid = Join-Path $state 'watchdog.pid'
$existing = Get-Content -LiteralPath $watchdogPid -ErrorAction SilentlyContinue
$heartbeat = Join-Path $state 'watchdog-heartbeat.json'
$heartbeatFresh = $false
if (Test-Path -LiteralPath $heartbeat -PathType Leaf) {
    try {
        $hb = Get-Content -LiteralPath $heartbeat -Raw | ConvertFrom-Json
        $age = [DateTimeOffset]::Now.ToUnixTimeSeconds() - [int64]$hb.observed_at
        $heartbeatFresh = ($age -ge 0 -and $age -le 5 -and [string]$hb.status -eq 'HEALTHY')
    } catch { $heartbeatFresh = $false }
}
if (-not ($existing -and $heartbeatFresh -and
        (Get-Process -Id ([int]$existing) -ErrorAction SilentlyContinue))) {
    $watchdogArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$watchdog`" -HealthPath `"$health`" -StateRoot `"$state`" -ParentPid $PID -IntervalSec 1 -MaxAgeSec 90"
    $wp = Start-Process -FilePath 'powershell.exe' -ArgumentList $watchdogArgs -WindowStyle Hidden -PassThru
    Set-Content -LiteralPath $watchdogPid -Value ([string]$wp.Id) -Encoding ascii
}
$serviceArgs = @(
    $tool, '--config', $Config, '--source-root', $sourceRoot,
    '--state-root', $state, '--health', $health, '--lease', $lease,
    '--authority', $authority, '--telegram-token', $TelegramToken,
    '--report', $report, '--interval-sec', $IntervalSec,
    '--stop-at-epoch', ([string]$stopAtEpoch)
)
if ($MaxCycles -gt 0) {
    $serviceArgs += @('--max-cycles', $MaxCycles)
}
& $python @serviceArgs
exit $LASTEXITCODE
