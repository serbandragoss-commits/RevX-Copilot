[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory=$true)][string]$TargetRoot,
    [Parameter(Mandatory=$true)][string]$CanonicalArchive,
    [switch]$OfflineOnly
)
$ErrorActionPreference = 'Stop'
if (-not $OfflineOnly) { throw 'Refusing install without -OfflineOnly.' }

$source = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$workspace = [IO.Path]::GetFullPath((Join-Path $source '..\..'))
$target = [IO.Path]::GetFullPath($TargetRoot).TrimEnd('\')
$allowedTarget = [IO.Path]::GetFullPath(
    (Join-Path $workspace 'deployed\v5-r26')
).TrimEnd('\')
if (-not [string]::Equals($target, $allowedTarget, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing target outside exact r26 deployment path: $target"
}
if (Test-Path -LiteralPath $target -PathType Leaf) {
    throw "Refusing file target: $target"
}
if ((Test-Path -LiteralPath $target) -and
    (Get-ChildItem -LiteralPath $target -Force | Select-Object -First 1)) {
    throw "Refusing non-empty target: $target"
}

& python (Join-Path $source 'preflight_offline.py') $source
if ($LASTEXITCODE -ne 0) { throw 'Package preflight failed.' }
& python (Join-Path $source 'v5_verify_canonical_base.py') --archive ([IO.Path]::GetFullPath($CanonicalArchive))
if ($LASTEXITCODE -ne 0) { throw 'Canonical base verification failed.' }

$manifestPath = Join-Path $source 'RELEASE_MANIFEST.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$manifestHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash
$rollbackRoot = Join-Path $workspace 'rollback'
$backup = Join-Path $rollbackRoot ('v5-r26-install-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$targetPreexisted = Test-Path -LiteralPath $target

if (-not $PSCmdlet.ShouldProcess($target, 'Install manifest-bound RevX V5 r26 candidate')) {
    return
}

New-Item -ItemType Directory -Force -Path $backup | Out-Null
@{
    schema = 'revx-v5-r26-install-receipt-v1'
    target = $target
    source_manifest_sha256 = $manifestHash
    target_preexisted = [bool]$targetPreexisted
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'INSTALL_RECEIPT.json') -Encoding UTF8
Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $backup 'SOURCE_MANIFEST.json')

try {
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    foreach ($item in $manifest.files) {
        $relative = [string]$item.path
        if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)') {
            throw "Unsafe manifest path: $relative"
        }
        $sourceFile = [IO.Path]::GetFullPath((Join-Path $source $relative))
        $sourcePrefix = $source.TrimEnd('\') + '\'
        if (-not $sourceFile.StartsWith($sourcePrefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Manifest path escapes source: $relative"
        }
        $destination = Join-Path $target $relative
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
        Copy-Item -LiteralPath $sourceFile -Destination $destination
    }
    Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $target 'RELEASE_MANIFEST.json')
    & python (Join-Path $target 'preflight_offline.py') $target
    if ($LASTEXITCODE -ne 0) { throw 'Installed target verification failed.' }
} catch {
    if (Test-Path -LiteralPath $target) {
        Remove-Item -LiteralPath $target -Recurse -Force
    }
    if ($targetPreexisted) {
        New-Item -ItemType Directory -Force -Path $target | Out-Null
    }
    throw
}
Write-Output "OFFLINE_INSTALL_PASS target=$target backup=$backup manifest_sha256=$manifestHash"
