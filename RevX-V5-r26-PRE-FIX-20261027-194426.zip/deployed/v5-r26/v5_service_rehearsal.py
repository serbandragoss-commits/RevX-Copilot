"""Bounded authenticated GET-only rehearsal of the persistent V5 service."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path


class MutationDisabled:
    async def submit_order(self, *_args, **_kwargs):
        raise RuntimeError("mutation disabled in service rehearsal")


async def run(config_path: Path, source_root: Path, state_root: Path,
              health_path: Path, cycles: int, operating_mode: str) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.canonical_action_source import CanonicalSpeculativeActionSource
    from revx_v5.live_runtime import V5LiveBoundary
    from revx_v5.provider_adapter import RevXV5ProviderAdapter
    from revx_v5.runner import RuntimeAuthority, V5Runner
    from revx_v5.service import V5Service
    from revx_v5.operating_mode import AutoModeClock
    from revx_v5.state_store import DurableState
    from revx_v5.supervisor import V5Supervisor

    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    started = time.time()
    store = DurableState(state_root)
    try:
        adapter = RevXV5ProviderAdapter(client, Priority.EXIT_CRITICAL)
        boundary = V5LiveBoundary(adapter, MutationDisabled(), state_store=store)
        source = CanonicalSpeculativeActionSource.from_canonical(
            client, config, order_cap_usd=20.0, validation_limit=7,
            health_store=store,
        )
        runner = V5Runner(V5Supervisor(boundary, mode_clock=AutoModeClock()), boundary, source,
                          RuntimeAuthority())
        final = await V5Service(runner, health_path, interval_sec=1.0).run(
            max_cycles=cycles
        )
    finally:
        await broker.close()
    return {
        "schema": "revx-v5-service-rehearsal-v1",
        **final,
        "observed_at": time.time(),
        "duration_sec": round(time.time() - started, 6),
        "broker_accessed": 1,
        "live_accessed": 0,
        "mutation_client_loaded": 0,
        "order_placement": "OFF",
        "telegram_accessed": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--health", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=2)
    parser.add_argument("--operating-mode", choices=("DAY", "NIGHT"), required=True)
    args = parser.parse_args()
    result = asyncio.run(run(args.config, args.source_root, args.state_root,
                             args.health, args.cycles, args.operating_mode))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n",
                           encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] in {"HEALTHY_SILENCE", "ACTION_READY"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
