$ErrorActionPreference = 'Stop'
$root = Join-Path $env:LOCALAPPDATA 'RevX\V5'
$probe = Join-Path $root 'dpapi-probe.tmp'
New-Item -ItemType Directory -Force -Path $root | Out-Null
try {
    $secure = ConvertTo-SecureString 'revx-probe-not-a-secret' -AsPlainText -Force
    $cipher = ConvertFrom-SecureString -SecureString $secure
    [IO.File]::WriteAllText($probe, $cipher, [Text.Encoding]::UTF8)
    if (-not (Test-Path -LiteralPath $probe) -or (Get-Item -LiteralPath $probe).Length -le 0) {
        throw 'DPAPI probe file was not written'
    }
    Write-Output 'V5_DPAPI_PROBE_PASS'
} finally {
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
}
