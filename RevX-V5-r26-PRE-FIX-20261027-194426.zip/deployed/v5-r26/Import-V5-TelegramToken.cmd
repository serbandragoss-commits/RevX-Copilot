@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Import-V5-TelegramToken.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Import failed. The sanitized diagnostic was saved under the candidate reports folder.
if not "%RC%"=="0" pause
exit /b %RC%
