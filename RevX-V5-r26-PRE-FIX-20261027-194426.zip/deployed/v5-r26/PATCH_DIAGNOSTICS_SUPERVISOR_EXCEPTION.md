# V5 diagnostic patch: supervisor exception visibility

## Problem

The service persisted only `reason=supervisor_exception`. The exception type and
bounded detail were discarded, so Telegram and `runtime-health-v5.json` could
not distinguish a timeout, transport failure, state error, or coding defect.

## Change

V5 now records `error_type` and a bounded, whitespace-normalized
`error_detail` (240 characters maximum) for supervisor, entry-source, exit-source,
and execution exceptions. No credentials are added to logs, no retry/mutation
and failure thresholds remain unchanged. Transient provider/network failures in
supervisor or signal evaluation are reported as `DEGRADED` so the next cycle
retries them instead of consuming the fatal failure threshold. Non-transport
exceptions remain `FAILED`.

## Rollback

Restore the previous deployed release from the pre-patch rollback directory.
