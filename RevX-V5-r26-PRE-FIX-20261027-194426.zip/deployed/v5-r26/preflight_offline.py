"""Offline V5 package preflight; never contacts a broker or starts a process."""
from __future__ import annotations

import hashlib
import json
import pathlib
import sys


CANONICAL = {
    "archive_bytes": 39_513_479,
    "archive_sha256": "EC42995020E579DAA6B7DBE4BF0FC6091BCFF62C5A5BC279F2A38C7EE655AD22",
    "manifest_bytes": 10_092,
    "manifest_sha256": "D0CA9CE3B251689C21953229C2E2090D0030D0C6E223102C5883C3FC9A4E25D6",
    "manifested_files": 41,
}


def sha256(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main(root: str) -> int:
    base = pathlib.Path(root).resolve()
    manifest_path = base / "RELEASE_MANIFEST.json"
    if not manifest_path.is_file():
        print("FAIL missing RELEASE_MANIFEST.json")
        return 2
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if manifest.get("mode") != "OFFLINE_CANDIDATE":
        print("FAIL invalid mode")
        return 2
    if manifest.get("broker_accessed") or manifest.get("live_accessed"):
        print("FAIL boundary violation")
        return 2
    if manifest.get("order_placement") != "OFF":
        print("FAIL order placement boundary")
        return 2
    if manifest.get("canonical_base") != CANONICAL:
        print("FAIL canonical base anchors")
        return 2
    failures = []
    expected = {item["path"].replace("\\", "/") for item in manifest.get("files", [])}
    actual = {
        path.relative_to(base).as_posix()
        for path in base.rglob("*")
        if path.is_file() and path.name != "RELEASE_MANIFEST.json"
        and "__pycache__" not in path.parts
    }
    for extra in sorted(actual - expected):
        failures.append(f"unmanifested:{extra}")
    for missing in sorted(expected - actual):
        failures.append(f"missing:{missing}")
    for item in manifest.get("files", []):
        path = base / item["path"]
        if path.is_file() and sha256(path) != item["sha256"]:
            failures.append(f"hash:{item['path']}")
    if failures:
        print("FAIL " + ",".join(failures))
        return 2
    print(f"PASS files={len(manifest['files'])} canonical_files=41 broker_accessed=0 live_accessed=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
