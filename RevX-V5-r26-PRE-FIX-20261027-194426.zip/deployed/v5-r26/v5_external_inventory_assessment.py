"""Authenticated GET-only executable assessment of reconciled legacy balances."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from decimal import Decimal, InvalidOperation, ROUND_FLOOR
from pathlib import Path
from typing import Any


def number(value: Any) -> Decimal | None:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None
    return result if result.is_finite() and result >= 0 else None


def pair_rows(payload: Any) -> dict[str, dict]:
    if not isinstance(payload, dict):
        return {}
    nested = next((payload[key] for key in ("data", "items", "pairs", "results")
                   if isinstance(payload.get(key), dict)), None)
    source = nested if nested is not None else payload
    return {
        str(row.get("symbol") or key).upper().replace("/", "-"): row
        for key, row in source.items() if isinstance(row, dict)
    }


async def run(config_path: Path, source_root: Path) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.external_inventory import book_levels, executable_bid_value
    from revx_v5.reconciliation import parse_balances

    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    started = time.time()
    try:
        balances_raw = await client.balances(Priority.EXIT_CRITICAL)
        pairs_raw = await client.pair_configurations(Priority.DISCOVERY)
        balances, valid = parse_balances(balances_raw)
        positions = [row for row in balances if row["currency"] != "USD" and row["total"] > 0]
        pairs = pair_rows(pairs_raw)
        records = []
        for holding in positions:
            currency = str(holding["currency"]).upper()
            symbol = f"{currency}-USD"
            pair = pairs.get(symbol, {})
            book = await client.order_book(symbol, 50, Priority.EXIT_CRITICAL)
            bids = book_levels(book, "bids")
            asks = book_levels(book, "asks")
            best_bid = max((price for price, _ in bids), default=None)
            best_ask = min((price for price, _ in asks), default=None)
            step = number(pair.get("base_step"))
            quantity = number(holding["total"]) or Decimal("0")
            executable_quantity = ((quantity / step).to_integral_value(rounding=ROUND_FLOOR) * step
                                   if step and step > 0 else quantity)
            proceeds, covered = executable_bid_value(executable_quantity, bids)
            best_bid_value = executable_quantity * best_bid if best_bid is not None else None
            spread_bps = ((best_ask - best_bid) / ((best_ask + best_bid) / 2) * 10_000
                          if best_bid and best_ask and best_ask >= best_bid else None)
            minimum = next((number(pair.get(key)) for key in
                            ("min_order_value", "min_notional", "minimum_order_value",
                             "min_order_size_quote")
                            if number(pair.get(key)) is not None), None)
            constraint_fields = {
                str(key): value for key, value in pair.items()
                if any(marker in str(key).lower() for marker in ("min", "max", "step", "order"))
                and isinstance(value, (str, int, float, bool, type(None)))
            }
            records.append({
                "currency": currency,
                "symbol": symbol,
                "quantity": str(quantity),
                "executable_quantity": str(executable_quantity),
                "best_bid": str(best_bid) if best_bid is not None else None,
                "best_ask": str(best_ask) if best_ask is not None else None,
                "spread_bps": round(float(spread_bps), 4) if spread_bps is not None else None,
                "best_bid_value_usd": round(float(best_bid_value), 6) if best_bid_value is not None else None,
                "depth_value_usd": round(float(proceeds), 6) if proceeds is not None else None,
                "full_depth_covered": covered,
                "minimum_notional_usd": float(minimum) if minimum is not None else None,
                "minimum_notional_known": minimum is not None,
                "minimum_notional_met": (best_bid_value >= minimum
                                         if best_bid_value is not None and minimum is not None else None),
                "pair_active": str(pair.get("status") or "").lower() == "active",
                "pair_constraint_fields": constraint_fields,
            })
    finally:
        await broker.close()
    values = [row["best_bid_value_usd"] for row in records
              if row["best_bid_value_usd"] is not None]
    safe = valid and len(records) == len(positions) and all(
        row["pair_active"] and row["best_bid"] is not None and row["best_ask"] is not None
        for row in records
    )
    return {
        "schema": "revx-v5-external-inventory-assessment-v1",
        "status": "PASS" if safe else "INCOMPLETE",
        "observed_at": time.time(),
        "duration_sec": round(time.time() - started, 6),
        "positions_nonzero": len(positions),
        "best_bid_value_total_usd": round(sum(values), 6),
        "all_depth_covered": all(row["full_depth_covered"] for row in records),
        "all_minimums_known": all(row["minimum_notional_known"] for row in records),
        "records": records,
        "order_placement": "OFF",
        "broker_accessed": 1,
        "live_accessed": 0,
        "broker_mutated": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = asyncio.run(run(args.config, args.source_root))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n",
                           encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
