"""Explicit operator entrypoint. Default is dry/read-only; never auto-restarts."""
import argparse
import asyncio
import json
import os
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

from revx_v5 import live_gate
from revx_v5.authority_config import disarm, load_runtime_authority
from revx_v5.process_lease import ProcessLease
from revx_v5.serialized_session import validate_bundle, validate_preflight, consume, digest

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'one-shot'
CONFIG = ROOT.parents[1] / 'config-v3.live.json'
TOKEN = Path(os.environ.get('LOCALAPPDATA', 'C:/Users/serba/AppData/Local')) / 'RevX/V5/telegram-token.dpapi'


def write_json(path, value):
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix='session-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(value, out, indent=2, sort_keys=True)
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


async def terminal(store, before, reason):
    import sys
    sys.path.insert(0, str(live_gate.SOURCE_ROOT))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.provider_adapter import RevXV5ProviderAdapter
    from revx_v5.terminal_report import reconcile_terminal
    config = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
    broker = RequestBroker(auth_gap_sec=float(config.get('auth_gap_ms', 750))/1000,
                           public_gap_sec=float(config.get('public_gap_ms', 1100))/1000)
    client = RevXClient(broker, base_url=str(config.get('base_url') or 'https://revx.revolut.com'),
        api_key_file=Path(os.path.expandvars(str(config['api_key_file']))),
        private_key_file=Path(os.path.expandvars(str(config['private_key_file']))),
        timeout_sec=float(config.get('http_timeout_sec', 20)))
    try:
        return await reconcile_terminal(RevXV5ProviderAdapter(client, Priority.EXIT_CRITICAL),
            store, before, reason, not load_runtime_authority(live_gate.AUTHORITY).permits_mutation)
    finally:
        await broker.close()


async def execute(binding_hash, activate=False, reset_manual_stop=False):
    # No credentials are loaded until source/permit/counterpart validation passes.
    result = validate_bundle(PACKAGE, binding_hash, time.time())
    from v5_authenticated_get_preflight import run as preflight
    from revx_v5.state_store import DurableState
    from revx_v5.runner import LIVE_ACKNOWLEDGEMENT
    store = DurableState(live_gate.STATE_ROOT)
    consumed = live_gate.STATE_ROOT / ('consumed-' + result['permit_id'] + '.json')
    with ProcessLease(live_gate.LEASE) as lease:
        if consumed.exists():
            raise RuntimeError('PERMIT_ALREADY_CONSUMED')
        if load_runtime_authority(live_gate.AUTHORITY).permits_mutation:
            raise RuntimeError('AUTHORITY_NOT_OFF')
        kill = live_gate.STATE_ROOT / 'v5.kill'
        if kill.exists():
            if not (activate and reset_manual_stop and kill.read_text(encoding='utf-8-sig').strip() == 'STOP_REQUESTED'):
                raise RuntimeError('V5_KILL_SWITCH')
            # Only a new explicit manual start can clear the manual STOP marker,
            # after acquiring the lease and verifying persistent authority OFF.
            kill.unlink()
        from v5_recovery_preflight import run as recovery_preflight
        recovery = await recovery_preflight(CONFIG, live_gate.SOURCE_ROOT, live_gate.STATE_ROOT)
        if recovery.get('status') != 'PASS' or recovery.get('unresolved_intents', 0):
            raise RuntimeError('RECOVERY_OR_PENDING_INTENTS_BLOCKED')
        if store.pending_intents():
            raise RuntimeError('RECOVERY_OR_PENDING_INTENTS_BLOCKED')
        fresh = await preflight(CONFIG, live_gate.SOURCE_ROOT)
        validate_preflight(fresh, time.time())
        result = validate_bundle(PACKAGE, binding_hash, time.time())
        if not activate:
            return {'status': 'DRY_VALIDATION_PASS', 'preflight': fresh,
                    'authority_off': True, 'permit_consumed': False}
        output = live_gate.STATE_ROOT / ('session-' + result['permit_id'])
        output.mkdir(exist_ok=False)
        before = list(store.intent_records())
        write_json(output / 'preflight.json', fresh)
        write_json(output / 'manifest.json', result)
        consume(result, consumed)
        final = {'status': 'FAILED', 'service_stop_reason': 'startup_failure'}
        reconciliation = {'status': 'INCOMPLETE'}
        try:
            authority = {'schema': 'revx-v5-runtime-authority-v1', 'execution_enabled': True,
                         'order_placement': 'ON', 'acknowledgement': LIVE_ACKNOWLEDGEMENT,
                         'expires_at_epoch': result['deadline_epoch']}
            write_json(live_gate.AUTHORITY, authority)
            live_gate.bind_session(result, lease, digest(live_gate.AUTHORITY.read_bytes()))
            from v5_live_service import run
            args = SimpleNamespace(config=CONFIG, source_root=live_gate.SOURCE_ROOT,
                state_root=live_gate.STATE_ROOT, authority=live_gate.AUTHORITY, lease=live_gate.LEASE,
                telegram_token=TOKEN, health=live_gate.STATE_ROOT/'runtime-health-v5.json',
                stop_at_epoch=result['deadline_epoch'], interval_sec=15., max_cycles=None,
                defer_final_to_operator_wrapper=True)
            final = await run(args)
        except Exception as exc:
            final.update(error_type=type(exc).__name__)
        finally:
            disarm(live_gate.AUTHORITY)
            try:
                reconciliation = await asyncio.wait_for(
                    terminal(store, before, final.get('service_stop_reason', 'exception')), 90)
            except Exception as exc:
                reconciliation = {'status': 'INCOMPLETE', 'error_type': type(exc).__name__}
            record = {'runtime': final, 'terminal': reconciliation, 'authority_off': True,
                      'permit_id': result['permit_id'], 'stopped_at': time.time()}
            write_json(output / 'FINAL.json', record)
            # Exactly one wrapper FINAL, after account-wide reconciliation.
            try:
                from revx_v5.telegram import TelegramReporter
                from revx_v5.telegram_http import send_telegram
                config = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
                reporter = TelegramReporter(TOKEN, str(config.get('telegram_chat_id') or ''), sender=send_telegram)
                reporter.send('RevX V5 — FINAL\nRuntime: ' + str(final.get('status'))
                    + '\nReconciliation: ' + str(reconciliation.get('status'))
                    + '\nNet realized PnL: ' + str(reconciliation.get('realized_net_pnl_usd')
                                                   if reconciliation.get('realized_net_pnl_usd') is not None else 'UNKNOWN')
                    + '\nAuthority: OFF; no restart.')
                record['final_telegram'] = 'SENT'
            except Exception as exc:
                record['final_telegram'] = 'FAILED:' + type(exc).__name__
            record['status'] = ('PASS' if reconciliation.get('status') == 'PASS'
                                and final.get('status') not in ('FAILED', 'BLOCKED')
                                and record['final_telegram'] == 'SENT' else 'INCOMPLETE')
            write_json(output / 'FINAL.json', record)
        return record


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--binding-sha256', required=True)
    parser.add_argument('--package', type=Path, default=PACKAGE)
    parser.add_argument('--config', type=Path, default=CONFIG)
    parser.add_argument('--telegram-token', type=Path, default=TOKEN)
    parser.add_argument('--activate', action='store_true', help='Operator only: permits real orders once')
    parser.add_argument('--reset-manual-stop', action='store_true')
    cli = parser.parse_args()
    PACKAGE = cli.package.resolve()
    CONFIG = cli.config.resolve()
    TOKEN = cli.telegram_token.resolve()
    try:
        report = asyncio.run(execute(cli.binding_sha256, cli.activate, cli.reset_manual_stop))
    except Exception as exc:
        report = {'status': 'BLOCKED', 'error_type': type(exc).__name__, 'reason': str(exc)}
    print(json.dumps(report, indent=2, default=str))
    raise SystemExit(0 if report.get('status') in ('DRY_VALIDATION_PASS', 'PASS') else 2)
