param(
  [string]$TokenPath = "$env:LOCALAPPDATA\RevX\V5\telegram-token.dpapi",
  [string]$ErrorReport = (Join-Path (Split-Path -Parent $PSScriptRoot) 'reports\v5-telegram-import-error.json')
)
$ErrorActionPreference = 'Stop'
try {
  $parent = Split-Path -Parent $TokenPath
  New-Item -ItemType Directory -Force -Path $parent | Out-Null
  $secure = Read-Host 'Telegram bot token (hidden)' -AsSecureString
  if ($secure.Length -lt 20) {
    throw 'Token input is empty or too short. Expected digits:letters without quotes or spaces.'
  }
  $cipher = ConvertFrom-SecureString -SecureString $secure
  [IO.File]::WriteAllText($TokenPath, $cipher, [Text.Encoding]::UTF8)
  if (-not (Test-Path -LiteralPath $TokenPath) -or (Get-Item -LiteralPath $TokenPath).Length -le 0) {
    throw 'DPAPI token file was not written.'
  }
  Remove-Item -LiteralPath $ErrorReport -Force -ErrorAction SilentlyContinue
  Write-Output "V5 Telegram DPAPI token stored at $TokenPath for the current Windows user."
} catch {
  $report = [ordered]@{
    schema = 'revx-v5-telegram-import-error-v1'
    observed_at = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    error_type = $_.Exception.GetType().FullName
    error_message = $_.Exception.Message
    user_name = [Environment]::UserName
    user_profile = $env:USERPROFILE
    token_path = $TokenPath
  }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $ErrorReport) | Out-Null
  $report | ConvertTo-Json | Set-Content -LiteralPath $ErrorReport -Encoding utf8
  throw
}
