[CmdletBinding()]
param([string]$StateRoot = 'C:\Users\serba\Documents\RevX\state\v5')
$ErrorActionPreference = 'Stop'
$state = [IO.Path]::GetFullPath($StateRoot)
New-Item -ItemType Directory -Force -Path $state | Out-Null
$kill = Join-Path $state 'v5.kill'
[IO.File]::WriteAllText($kill, "STOP_REQUESTED`n", [Text.UTF8Encoding]::new($false))
Write-Output "V5_STOP_REQUESTED kill_file=$kill"
