"""V5 authenticated GET-only preflight.

Uses the verified v3.5.8 read client and deliberately never imports the live
mutation client. It does not require the V4 LIVE acknowledgement because this
is a read-only gate, but it still requires valid credential paths in config.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Any


def rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [x for x in value if isinstance(x, dict)]
    if isinstance(value, dict):
        for key in ("data", "items", "orders", "results"):
            if isinstance(value.get(key), list):
                return [x for x in value[key] if isinstance(x, dict)]
    return []


def count_records(value: Any) -> int:
    """Count list-shaped or symbol-keyed provider responses without logging data."""
    items = rows(value)
    if items:
        return len(items)
    if isinstance(value, dict):
        for key in ("data", "items", "pairs", "results"):
            nested = value.get(key)
            if isinstance(nested, dict):
                return len(nested)
        if value and all(isinstance(item, dict) for item in value.values()):
            return len(value)
    return 0


async def run(config_path: Path, source_root: Path) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.external_inventory import classify_external_inventory, fetch_inventory_books
    from revx_v5.reconciliation import parse_balances
    config = json.loads(config_path.read_text(encoding="utf-8"))
    required = ("api_key_file", "private_key_file")
    missing = [key for key in required if not str(config.get(key) or "").strip()]
    if missing:
        raise ValueError("missing V5 GET-only configuration: " + ",".join(missing))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    started = time.time()
    try:
        balances = await client.balances(Priority.EXIT_CRITICAL)
        active_orders = await client.active_orders(None, Priority.EXIT_CRITICAL)
        pairs = await client.pair_configurations(Priority.DISCOVERY)
        balance_rows, balances_valid = parse_balances(balances)
        positions = [row for row in balance_rows
                     if row["currency"] != "USD" and row["total"] > 0]
        books = await fetch_inventory_books(client, positions, pairs, Priority.EXIT_CRITICAL)
        historical_orders = await client.historical_orders(None, 24, Priority.EXIT_CRITICAL)
    finally:
        await broker.close()
    active = rows(active_orders)
    historical = rows(historical_orders)
    ambiguous = [
        row for row in active
        if str(row.get("status", "")).upper() in {"UNKNOWN", "PENDING", "PARTIALLY_FILLED"}
        or not str(row.get("id") or row.get("venue_order_id") or "")
    ]
    inventory = classify_external_inventory(positions, pairs, books)
    status = (
        "BLOCKED_BALANCE_SCHEMA" if not balances_valid else
        "BLOCKED_AMBIGUOUS" if ambiguous else
        "BLOCKED_ACTIVE_ORDERS" if active else
        "BLOCKED_EXTERNAL_INVENTORY" if positions and not inventory["reconciled"] else
        "PASS"
    )
    # The launch gate consumes a saved GET-only report.  These two fields
    # bind its recovery/live-contract checks to this exact fresh observation;
    # the launcher still verifies mutation authority independently.
    recovery_status = "PASS" if status == "PASS" else status
    live_contract_status = (
        "PASS" if status == "PASS" and balances_valid
        and not active and not ambiguous else "BLOCKED"
    )
    return {
        "schema": "revx-v5-authenticated-get-only-v1",
        "status": status,
        "recovery_status": recovery_status,
        "live_contract_status": live_contract_status,
        "observed_at": time.time(),
        "duration_sec": round(time.time() - started, 6),
        "authenticated_get": "PASS",
        "active_orders": len(active),
        "ambiguous_orders": len(ambiguous),
        "historical_orders_24h": len(historical),
        "historical_orders_with_fill_truth": sum(
            1 for row in historical if "filled_quantity" in row or "filled_amount" in row
        ),
        "pair_count": count_records(pairs),
        "balance_rows": len(balance_rows),
        "positions_nonzero": len(positions),
        "position_currencies": sorted({row["currency"] for row in positions}),
        "external_inventory_count": inventory["count"],
        "external_inventory_reconciled": inventory["reconciled"],
        "external_inventory_unknown": inventory["unknown_currencies"],
        "external_inventory_symbols": sorted(row["symbol"] for row in inventory["records"]),
        "runtime_mode": "NORMAL",
        "entry_enabled": 1,
        "balance_schema_valid": balances_valid,
        "order_placement": "OFF",
        "broker_accessed": 1,
        "live_accessed": 0,
        "mutation_client_loaded": 0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(asyncio.run(run(args.config, args.source_root)), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
