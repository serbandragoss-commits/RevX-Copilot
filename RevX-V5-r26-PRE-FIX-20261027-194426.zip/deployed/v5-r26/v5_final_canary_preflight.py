"""Aggregate final V5 structural/read-only evidence; never mutates externally."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"invalid report: {path.name}")
    return value


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def verify_release(root: Path) -> tuple[bool, int]:
    manifest = load(root / "RELEASE_MANIFEST.json")
    failures = 0
    for item in manifest.get("files", []):
        path = root / item["path"]
        if not path.is_file() or digest(path) != item["sha256"]:
            failures += 1
    safe = (manifest.get("mode") == "OFFLINE_CANDIDATE"
            and manifest.get("order_placement") == "OFF"
            and not manifest.get("live_accessed") and failures == 0)
    return safe, failures


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--get-report", type=Path, required=True)
    parser.add_argument("--service-report", type=Path, required=True)
    parser.add_argument("--telegram-report", type=Path, required=True)
    parser.add_argument("--structural-report", type=Path, required=True)
    parser.add_argument("--release-root", type=Path, required=True)
    parser.add_argument("--max-age-sec", type=float, default=900)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    current = time.time()
    get_report = load(args.get_report)
    service = load(args.service_report)
    telegram = load(args.telegram_report)
    structural = load(args.structural_report)
    release_ok, release_failures = verify_release(args.release_root)
    try:
        system_timezone = subprocess.run(
            ["tzutil", "/g"], check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        system_timezone = "UNKNOWN"
    age = current - float(get_report.get("observed_at", 0))
    checks = {
        "fresh_authenticated_get": (get_report.get("status") == "PASS"
                                    and get_report.get("authenticated_get") == "PASS"
                                    and -5 <= age <= args.max_age_sec),
        "no_active_or_ambiguous_orders": (int(get_report.get("active_orders", -1)) == 0
                                          and int(get_report.get("ambiguous_orders", -1)) == 0),
        "external_inventory_reconciled": bool(
            get_report.get("external_inventory_reconciled", False)
        ),
        "service_get_only_pass": (service.get("status") == "HEALTHY_SILENCE"
                                  and int(service.get("broker_mutated", -1)) == 0
                                  and service.get("order_placement") == "OFF"),
        "telegram_dpapi_pass": (telegram.get("status") == "PASS"
                                and int(telegram.get("token_exposed", -1)) == 0),
        "structural_buy_sell_flat": (structural.get("status") == "PASS"
                                     and int(structural.get("submits_simulated", 0)) == 2
                                     and int(structural.get("positions_after_exit", -1)) == 0
                                     and int(structural.get("broker_accessed", -1)) == 0),
        "release_hashes_pass": release_ok,
        "bucharest_system_timezone": system_timezone == "GTB Standard Time",
    }
    passed = all(checks.values())
    result = {
        "schema": "revx-v5-final-canary-preflight-v1",
        "status": "CANARY_READY" if passed else "BLOCKED",
        "checks": checks,
        "get_age_sec": round(age, 3),
        "runtime_mode": get_report.get("runtime_mode"),
        "entry_enabled": int(get_report.get("entry_enabled", 0)),
        "positions_nonzero": int(get_report.get("positions_nonzero", -1)),
        "release_hash_failures": release_failures,
        "system_timezone": system_timezone,
        "order_placement": "OFF",
        "broker_mutated": 0,
        "live_accessed": 0,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n",
                           encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
