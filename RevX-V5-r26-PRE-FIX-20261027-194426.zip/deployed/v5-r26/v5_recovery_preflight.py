"""V5 fresh recovery gate: authenticated GET-only; persists only local recovery truth."""
from __future__ import annotations
import argparse, asyncio, json, os, sys, time
from pathlib import Path

async def run(config_path: Path, source_root: Path, state_root: Path) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.live_contract import live_contract
    from revx_v5.live_runtime import V5LiveBoundary
    from revx_v5.provider_adapter import MutationDisabledAdapter, RevXV5ProviderAdapter
    from revx_v5.state_store import DurableState
    from revx_v5.supervisor import V5Supervisor
    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    started = time.time()
    broker = RequestBroker(auth_gap_sec=float(config.get("auth_gap_ms",750))/1000.0, public_gap_sec=float(config.get("public_gap_ms",1100))/1000.0)
    client = RevXClient(broker, base_url=str(config.get("base_url") or "https://revx.revolut.com"), api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))), private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))), timeout_sec=float(config.get("http_timeout_sec",20)))
    try:
        store = DurableState(state_root)
        boundary = V5LiveBoundary(RevXV5ProviderAdapter(client, Priority.EXIT_CRITICAL), MutationDisabledAdapter(), state_store=store, entry_order_ttl_sec=float(config.get("entry_order_ttl_sec",45.0)))
        prepared = await V5Supervisor(boundary).prepare()
    finally:
        await broker.close()
    status = "PASS" if prepared.get("status") == "PASS" else "BLOCKED"
    return {
        "schema":"revx-v5-fresh-recovery-v1", "status":status, "observed_at":time.time(),
        "duration_sec":round(time.time()-started,6), "authenticated_get":"PASS",
        "recovery_status":prepared.get("status"), "recovered_intents":int(prepared.get("recovered_intents",0) or 0),
        "unresolved_intents":int(prepared.get("unresolved_intents",0) or 0),
        "active_orders":int(prepared.get("active_orders",0) or 0), "ambiguous_orders":int(prepared.get("ambiguous_orders",0) or 0),
        "external_inventory_reconciled":prepared.get("external_inventory_reconciled") is True,
        "external_inventory_count":int(prepared.get("external_inventory_count",0) or 0),
        "live_contract":live_contract(), "order_placement":"OFF", "mutation_client_loaded":0, "live_accessed":0,
    }

def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--config",type=Path,required=True)
    parser.add_argument("--source-root",type=Path,required=True)
    parser.add_argument("--state-root",type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(asyncio.run(run(args.config,args.source_root,args.state_root)),indent=2,sort_keys=True))

if __name__ == "__main__": main()
