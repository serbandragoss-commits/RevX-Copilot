"""Run the authenticated V5 launch coordinator without starting execution."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path


class MutationDisabled:
    async def submit_order(self, *_args, **_kwargs):
        raise RuntimeError("mutation is disabled during launch preparation")


async def run(config_path: Path, source_root: Path, state_root: Path,
              token_path: Path, notification_id: str) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.launch_coordinator import V5LaunchCoordinator
    from revx_v5.live_runtime import V5LiveBoundary
    from revx_v5.provider_adapter import RevXV5ProviderAdapter
    from revx_v5.state_store import DurableState
    from revx_v5.supervisor import V5Supervisor
    from revx_v5.telegram import TelegramReporter, load_dpapi_token
    from revx_v5.telegram_http import send_telegram

    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    chat_id = str(config.get("telegram_chat_id") or "").strip()
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    store = DurableState(state_root)
    reporter = TelegramReporter(token_path, chat_id, sender=send_telegram,
                                token_loader=load_dpapi_token)
    started = time.time()
    try:
        adapter = RevXV5ProviderAdapter(client, Priority.EXIT_CRITICAL)
        boundary = V5LiveBoundary(adapter, MutationDisabled(), state_store=store)
        result = await V5LaunchCoordinator(
            V5Supervisor(boundary), store, reporter
        ).prepare(notification_id)
    finally:
        await broker.close()
    return {
        "schema": "revx-v5-launch-prepare-v1",
        "status": "PASS" if result.get("launch_status") == "GATE_PASS_RUNNER_REQUIRED" else "BLOCKED",
        "launch_status": result.get("launch_status"),
        "runtime_mode": result.get("runtime_mode", "UNKNOWN"),
        "entry_enabled": int(bool(result.get("entry_enabled"))),
        "external_inventory_count": result.get("external_inventory_count", 0),
        "external_inventory_reconciled": result.get("external_inventory_reconciled", False),
        "active_orders": result.get("active_orders", 0),
        "ambiguous_orders": result.get("ambiguous_orders", 0),
        "unresolved_intents": result.get("unresolved_intents", 0),
        "telegram": result.get("telegram"),
        "duration_sec": round(time.time() - started, 6),
        "broker_accessed": 1,
        "live_accessed": 0,
        "mutation_client_loaded": 0,
        "order_placement": "OFF",
        "process_started": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--token", type=Path, required=True)
    parser.add_argument("--notification-id", required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = asyncio.run(run(args.config, args.source_root, args.state_root,
                             args.token, args.notification_id))
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
