"""Send one explicit V5 Telegram transport test without exposing credentials."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from revx_v5.telegram import load_dpapi_token
from revx_v5.telegram_http import send_telegram


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--token", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8-sig"))
    chat_id = str(config.get("telegram_chat_id") or "").strip()
    token = load_dpapi_token(args.token)
    try:
        observed = datetime.now().astimezone().isoformat(timespec="seconds")
        send_telegram(
            token,
            chat_id,
            "RevX V5 TELEGRAM TEST — PASS\n"
            f"Observed: {observed}\n"
            "Runtime not started. Orders: 0. Broker mutation: 0.",
        )
    finally:
        token = ""
    print(json.dumps({
        "schema": "revx-v5-telegram-test-v1",
        "status": "PASS",
        "telegram_sent": 1,
        "token_exposed": 0,
        "broker_accessed": 0,
        "live_accessed": 0,
        "order_placement": "OFF",
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
