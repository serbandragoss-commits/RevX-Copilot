# Ultimate V5 — r25 candidate

> Historical release/readiness record. Current V5 operational authority:
> [V5 governor contract](../../V5_OPERATING_AUTHORITY.md). State is HOLD;
> old READY/PASS claims do not authorize launch or prove profitability.

Status: `AUDIT_AND_RELEASE_VALIDATION_IN_PROGRESS / LIVE_STOPPED`

This is the isolated r25 candidate workspace. The r24 LIVE runtime was stopped
flat before staging. Credentials and live state remain outside this package;
r24 remains intact as the operational rollback target.

## r25 — Mover Discovery and Fast Confirmed Exit

The product remains **RevX Ultimate V5**. `r25` is an internal release revision,
not a V5.1 strategy family.

Discovery still obtains the complete Revolut X ticker batch and performs at
most seven expensive validations per cycle. The seven slots are deterministic:
five best composite candidates, one distinct eligible raw 24h mover, and one
distinct positive-acceleration candidate; if no fresh candidate exists, the
oldest eligible underlying by last deep validation receives exploration. Slot
collisions fall through to the next composite candidate. USD/EUR aliases are
deduplicated by underlying, but r25 does not silently enable EUR execution: the
existing USD execution authority remains unchanged.

Every discovery cycle writes a bounded, atomic, secret-free decision journal.
Momentum tape and exploration timestamps survive restart with bounded state.

Exit evaluation remains ahead of every BUY and now ranks all owned positions by
severity: hard stop, then three-cycle degraded/missing ticker, then confirmed
downtrend. A downtrend needs two consecutive negative cycles (about 30 seconds)
and may exit while profitable, flat, or slightly negative. It uses a distinct
`CONFIRMED_DOWNTREND` reason, so the historical early-loss floor is not applied.
Every SELL still requires reconciliation, no active/ambiguous order, executable
bid, complete visible depth within the slippage cap, and a marketable limit;
there is no blind market order or blind retry.

## Objective

Build an autonomous short-horizon speculative engine:

```text
discovery -> deterministic admission -> BUY -> position management -> SELL
         -> venue reconciliation -> net outcome evidence
```

V2/V2.11 contribute discovery and challenger signals. V3.5.8 contributes the
canonical execution, state and reconciliation boundary. V4 contributes
breadth, capacity, mode separation and exit mechanisms. V5 contributes the
deterministic contract and evidence ledger.

## Current gate

The pure decision kernel, fail-closed reconciliation, single-submit execution,
durable state/outbox, and Telegram boundary are implemented and covered by
focused tests.
The operator explicitly authorized controlled liquidation of the five legacy
balances AIOZ, AKT, ARKM, AWE, and AXS. Each symbol passed the executable-book
gate and each one-shot SELL reconciled terminal `FILLED`; no blind retry was
used. A fresh authenticated GET then confirmed zero active orders, zero
ambiguous orders, zero non-USD positions, and `NORMAL / entry_enabled=1`.
No persistent LIVE runtime was running when this candidate was packaged.

The r25 staging root is the current self-verifying offline candidate. It must
pass package preflight, isolated install, post-copy verification and rollback
before controlled deployment. It is not yet the active LIVE release.

`v5_authenticated_get_preflight.py` and `v5_startup_reconcile.py` provide the
GET-only preflight and startup reconciliation gates. Their sanitized reports
must be written outside the release payload. Telegram DPAPI import and real
delivery are verified; the secret remains outside the candidate and payload.

`v5_runtime_prepare.py` exercises the actual V5 composition path and
persists the reconciled holdings in an isolated durable state without claiming
them as V5-owned positions. Its verified run also reported
`MANAGE_EXISTING_ONLY`, `entry_enabled=0`, and zero venue mutation.
The supervisor performs no-blind-retry intent recovery before that preparation;
unresolved intent truth keeps the runtime in `UNKNOWN/BLOCKED`.
Telegram DPAPI and durable launch-gate delivery are verified. The bounded
runner state machine is now implemented with an independent kill switch, exact
three-part mutation authority, exit-before-entry ordering, one action per
cycle, and a hard external-inventory BUY block. An authenticated GET-only
rehearsal returned `HEALTHY_SILENCE` in `MANAGE_EXISTING_ONLY`, with zero
mutations. Canonical v3.5.8 full-universe discovery and venue-specific BUY plan
construction are now connected behind the runner. V5 applies a hard 20 USD
notional ceiling by reducing canonical risk-sized quantity without ever
rounding it upward. A live-data rehearsal observed 384 ticker rows / 299 priced
USD symbols / 28 strategy-eligible symbols; all seven bounded deep validations
were correctly rejected by fresh structural gates, so the result was
`HEALTHY_SILENCE`. BUY and SELL fills are now adopted idempotently into a
durable V5-owned position ledger, including partial-fill deltas and restart
recovery. Venue balances are split between V5-owned quantity and residual
external inventory, so a V5 fill is not mislabeled after restart. The exit
bridge applies immediate hard stops, two-confirmation negative momentum exits,
and a three-strike persisted degraded-ticker exit, while requiring executable
book truth before any SELL. The live account rehearsal kept the five legacy
balances external and performed zero mutations in that rehearsal. The later
r24 runtime was started, then deliberately stopped flat before r25 staging.

The persistent service loop now writes atomic health, stops after bounded
consecutive failures, supports a kill switch and graceful shutdown, and sends
Telegram only for material state transitions through the durable outbox. The
validated V4 Day/Night clock is preserved: Day 07:00-22:00 with entry closing
at 21:55; Night 22:00-07:00 with entry closing at 06:55, Europe/Bucharest local
system time. Risk is enforced before planning with independent per-mode
USD 150 exposure, USD 20/order, USD 10 net session loss, and 20 Day / 10 Night
positions. Fill fees, per-mode session identity, exposure and realized net PnL
are persisted. The full suite passes and the offline BUY->SELL->flat lifecycle
canary proves the ledger with fee truth. A bounded two-cycle authenticated
service rehearsal remained `HEALTHY_SILENCE / MANAGE_EXISTING_ONLY`, with zero
mutation and no Telegram traffic.

The actual service launcher was also exercised for two bounded cycles with
the real provider adapter, Telegram available, the OS split-brain lease held,
and the packaged authority template exactly `OFF`. It completed
`HEALTHY_SILENCE`, made zero broker mutations, and wrote sanitized evidence.
The five legacy balances remain reconciled external inventory: V5 will neither
adopt nor sell them without a separate explicit operator decision.
A fresh GET-only executable assessment found about USD 29.19 total at best bid,
full visible depth coverage and venue minimums satisfied for all five; the
estimate is before fees and did not submit an order.

## Not in this candidate

- credentials, broker state or live state;
- the stopped economic canary output as source code;
- quarantined v3.5.9 release material;
- model/Ollama authority;
- automatic deployment or LIVE restart.
