"""V5 service entry point. Mutation remains impossible unless authority is exact."""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import os
import signal
import sys
import tempfile
import time
from pathlib import Path


def validate_deadline(deadline: float | None, now: float) -> None:
    from revx_v5.serialized_session import MAX_LIVE_DURATION_SECONDS
    if (isinstance(deadline, bool) or not isinstance(deadline, (int, float))
            or not math.isfinite(deadline) or not 0 < deadline - now <= MAX_LIVE_DURATION_SECONDS):
        raise ValueError("a future deadline within 86400 seconds is required")


async def run_owned_service(service, args):
    """Only the lease owner may disarm; duplicate launch must not stop its peer."""
    from revx_v5.authority_config import disarm
    from revx_v5.live_gate import service_lease

    with service_lease(args.lease):
        deadline_task = None
        try:
            validate_deadline(args.stop_at_epoch, time.time())

            async def expire():
                await asyncio.sleep(max(0, args.stop_at_epoch - time.time()))
                try:
                    disarm(args.authority)
                finally:
                    service.request_stop()

            deadline_task = asyncio.create_task(expire())
            return await service.run(max_cycles=args.max_cycles)
        finally:
            try:
                disarm(args.authority)
            finally:
                service.request_stop()
                if deadline_task is not None:
                    deadline_task.cancel()
                    try:
                        await deadline_task
                    except asyncio.CancelledError:
                        pass


def write_failure(path: Path, error: Exception) -> dict:
    result = {
        "schema": "revx-v5-runtime-health-v1",
        "status": "FAILED",
        "reason": "service_exception",
        "error_type": type(error).__name__,
        "service_stopped": True,
        "last_cycle_at": time.time(),
        "broker_mutated": 0,
        "actions_executed": 0,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="health-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(result, handle, sort_keys=True, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return result


def live_start_message(source) -> str:
    policy = source.risk_policy
    cap = source.order_cap_usd
    sizing = ('BUY sizing: dynamic risk/cash/costs/venue rules; no fixed USD/order cap'
              if cap is None else f'BUY cap: ${cap:g}/order')
    config=getattr(getattr(source,'planner',None),'config',{})
    if config.get('v5_order_max_usd') is not None:
        sizing=f"BUY value: dynamic ${config['v5_order_min_usd']}–${config['v5_order_max_usd']}; risk budget up to ${config['risk_usd']:g}/order"
    return (
        'RevX V5 LIVE — START Run\n'
        'Runtime: NORMAL, autonomous BUY/SELL\n'
        f'{sizing}\n'
        f'Limits: ${policy.exposure_usd:g} account-wide exposure (Day + Night); '
        f'${policy.session_loss_usd:g} loss/session; '
        f'{policy.day_max_positions} Day / {policy.night_max_positions} Night positions\n'
        'Current state will be reconciled from broker truth before every action.'
    )


async def run(args) -> dict:
    validate_deadline(args.stop_at_epoch, time.time())
    from revx_v5.live_gate import validate_paths, require_live_mutation
    validate_paths(args.state_root, args.authority, args.lease, args.source_root)
    require_live_mutation()
    if args.stop_at_epoch is not None and time.time() >= args.stop_at_epoch:
        raise RuntimeError("authorized deadline has expired")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(args.source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import LiveRevXClient, RevXClient
    from revx_v3.models import Priority
    from revx_v5.authority_config import load_runtime_authority
    from revx_v5.canonical_action_source import CanonicalSpeculativeActionSource
    from revx_v5.live_runtime import V5LiveBoundary
    from revx_v5.operating_mode import AutoModeClock
    from revx_v5.process_lease import ProcessLease
    from revx_v5.provider_adapter import MutationDisabledAdapter, RevXV5ProviderAdapter
    from revx_v5.runner import V5Runner
    from revx_v5.service import V5Service
    from revx_v5.state_store import DurableState
    from revx_v5.supervisor import V5Supervisor
    from revx_v5.telegram import TelegramReporter
    from revx_v5.telegram_http import send_telegram

    config = json.loads(args.config.read_text(encoding="utf-8-sig"))
    from revx_v5.policy import operator_policy, operator_config
    config = operator_config(config)
    policy = operator_policy()
    authority = load_runtime_authority(args.authority)
    store = DurableState(args.state_root)
    reporter = TelegramReporter(args.telegram_token,
                                str(config.get("telegram_chat_id") or ""),
                                sender=send_telegram)
    if not reporter.available():
        raise RuntimeError("Telegram is unavailable")
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client_kwargs = {
        "base_url": str(config.get("base_url") or "https://revx.revolut.com"),
        "api_key_file": Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        "private_key_file": Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        "timeout_sec": float(config.get("http_timeout_sec", 20)),
    }
    read_client = RevXClient(
        broker,
        **client_kwargs,
    )
    try:
        read_adapter = RevXV5ProviderAdapter(read_client, Priority.EXIT_CRITICAL)
        mutation_adapter = (
            RevXV5ProviderAdapter(LiveRevXClient(broker, **client_kwargs), Priority.EXIT_CRITICAL)
            if authority.permits_mutation else MutationDisabledAdapter()
        )
        boundary = V5LiveBoundary(
            read_adapter, mutation_adapter, state_store=store,
            entry_order_ttl_sec=float(config.get("entry_order_ttl_sec", 45.0)),
            risk_policy=policy,
        )
        source = CanonicalSpeculativeActionSource.from_canonical(
            read_client, config, validation_limit=10, allocation_mode=True, target_exits=True,
            health_store=store,
            risk_policy=policy,
        )
        kill_file = args.state_root / "v5.kill"
        runner = V5Runner(
            V5Supervisor(boundary, mode_clock=AutoModeClock()), boundary, source,
            authority, kill_switch=lambda: kill_file.exists() or (
                args.stop_at_epoch is not None and time.time() >= args.stop_at_epoch),
        )
        startup_message = None
        if authority.permits_mutation:
            startup_message = live_start_message(source)
        service = V5Service(runner, args.health, interval_sec=args.interval_sec,
                            state_store=store, telegram_send=reporter.send,
                            startup_message=startup_message)
        if getattr(args, 'defer_final_to_operator_wrapper', False):
            service._deliver_required_final = lambda final: {'deferred_to_terminal_reconciliation': True}
        for name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, name):
                signal.signal(getattr(signal, name), lambda *_: service.request_stop())
        final = await run_owned_service(service, args)
        return {
                **final,
                "run_schema": "revx-v5-live-service-run-v1",
                "authority_permits_mutation": authority.permits_mutation,
                "mutation_client_loaded": int(authority.permits_mutation),
                "order_placement": authority.order_placement,
                "broker_accessed": 1,
                "live_accessed": int(authority.permits_mutation),
            }
    finally:
        await broker.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--health", type=Path, required=True)
    parser.add_argument("--lease", type=Path, required=True)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--telegram-token", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--interval-sec", type=float, default=15.0)
    parser.add_argument("--max-cycles", type=int)
    parser.add_argument("--stop-at-epoch", type=float)
    args = parser.parse_args()
    try:
        final = asyncio.run(run(args))
    except Exception as exc:
        final = write_failure(args.health, exc)
    if args.report is not None:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(final, indent=2, sort_keys=True) + "\n",
                               encoding="utf-8")
    print(json.dumps(final, indent=2, sort_keys=True))
    return 0 if final["status"] not in {"FAILED", "BLOCKED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
