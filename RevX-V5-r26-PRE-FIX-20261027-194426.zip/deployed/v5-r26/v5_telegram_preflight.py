"""Validate a V5 DPAPI Telegram credential without exposing its value."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from revx_v5.telegram import load_dpapi_token


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--token", type=Path, required=True)
    args = parser.parse_args()
    try:
        token = load_dpapi_token(args.token)
        valid = re.fullmatch(r"[0-9]{6,15}:[A-Za-z0-9_-]{20,}", token) is not None
        result = {
            "schema": "revx-v5-telegram-preflight-v1",
            "status": "PASS" if valid else "FAIL",
            "file_exists": args.token.is_file(),
            "dpapi_decrypt": "PASS",
            "token_format": "PASS" if valid else "FAIL",
            "token_exposed": 0,
        }
    except Exception as exc:
        result = {
            "schema": "revx-v5-telegram-preflight-v1",
            "status": "FAIL",
            "file_exists": args.token.is_file(),
            "dpapi_decrypt": "FAIL",
            "token_format": "UNKNOWN",
            "token_exposed": 0,
            "error_type": type(exc).__name__,
        }
    finally:
        if "token" in locals():
            token = ""
    print(json.dumps(result, sort_keys=True))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
