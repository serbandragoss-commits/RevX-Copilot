"""Evaluate a saved GET-only report; no runtime or broker action."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from revx_v5.launch_gate import LaunchBlocked, validate_launch


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--operator-ack", action="store_true")
    parser.add_argument("--rollback-ready", action="store_true")
    args = parser.parse_args()
    try:
        result = validate_launch(json.loads(args.report.read_text(encoding="utf-8-sig")),
                                 operator_ack=args.operator_ack,
                                 rollback_ready=args.rollback_ready)
    except LaunchBlocked as exc:
        print(json.dumps({"status": "BLOCKED", "reason": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
