# V5 r25 — reconciliation visibility repair

## Defect

Restart recovery searched active and historical orders only by `client_order_id`.
After a successful submission, the durable intent already contained the venue's
authoritative order id, but that id was ignored. A fresh venue position could
therefore be reported locally as `BLOCKED | unresolved_intent_reconciliation`.

## Repair

Recovery now performs a read-only direct lookup by `venue_order_id` first. It
accepts the result only when the returned venue id matches exactly, then falls
back to the existing client-id search. No retry, cancel, or new mutation is
introduced. The resolution method is recorded as `VENUE_ORDER_ID` or
`CLIENT_ORDER_ID`.

## Validation and rollback

- regression test covers a venue-id-only recovery response;
- full staging suite: 106 passed;
- offline manifest preflight: PASS, 93 files;
- rollback: restore the previous manifest-bound r25 backup before installation;
- LIVE installation is intentionally deferred while the QI-USD external
  position remains unresolved.
