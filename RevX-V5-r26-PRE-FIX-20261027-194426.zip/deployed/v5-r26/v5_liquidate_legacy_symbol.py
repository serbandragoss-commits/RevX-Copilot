"""One-symbol, explicitly authorized, idempotent legacy-inventory liquidation."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any


ACK = "REVX_V5_EXTERNAL_LIQUIDATION_AUTHORIZED_20261003"
AUTHORIZED = {"AIOZ-USD", "AKT-USD", "ARKM-USD", "AWE-USD", "AXS-USD", "GTC-USD"}


def rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        for key in ("data", "items", "orders", "results"):
            if isinstance(value.get(key), list):
                return [row for row in value[key] if isinstance(row, dict)]
        if value.get("id") or value.get("venue_order_id"):
            return [value]
    return []


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix="liquidation-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as output:
            json.dump(value, output, indent=2, sort_keys=True)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


async def run(args) -> dict:
    if args.ack != ACK:
        raise ValueError("exact external-liquidation acknowledgement is required")
    symbol = args.symbol.upper().replace("/", "-")
    if symbol not in AUTHORIZED:
        raise ValueError("symbol is outside the authorized liquidation set")

    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(args.source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import LiveRevXClient
    from revx_v3.execution import ExecutionService, ExecutionUnknown
    from revx_v3.models import Priority
    from revx_v5.execution_truth import order_fill_state
    from revx_v5.reconciliation import parse_balances

    config = json.loads(args.config.read_text(encoding="utf-8-sig"))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = LiveRevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    service = ExecutionService(client, config)
    suffix = str(args.client_order_suffix or "").strip()
    exit_id = f"v5-authorized-external-liquidation-20261003-{symbol}"
    if suffix:
        exit_id += f"-{suffix}"
    journal = json.loads(args.journal.read_text(encoding="utf-8-sig")) if args.journal.is_file() else {
        "schema": "revx-v5-legacy-liquidation-journal-v1", "symbols": {}
    }
    previous = journal.get("symbols", {}).get(symbol, {})
    if previous.get("status") in {"SUBMITTING", "UNKNOWN", "ACTIVE", "PARTIAL"}:
        client_id = str(previous.get("client_order_id") or "")
        recovered = await service.find_order(symbol, client_id, Priority.EXIT_CRITICAL) if client_id else None
        if recovered is None:
            await broker.close()
            return {"status": "BLOCKED_UNKNOWN", "symbol": symbol,
                    "client_order_id": client_id, "broker_mutated": 0,
                    "reason": "prior_submit_not_reconciled"}
        order = recovered
        plan = None
    else:
        active = rows(await client.active_orders(None, Priority.EXIT_CRITICAL))
        if active:
            await broker.close()
            return {"status": "BLOCKED_ACTIVE_ORDERS", "symbol": symbol,
                    "active_orders": len(active), "broker_mutated": 0}
        balances, valid = parse_balances(await client.balances(Priority.EXIT_CRITICAL))
        positive = {f"{row['currency']}-USD" for row in balances
                    if row["currency"] != "USD" and row["total"] > 0}
        # This utility liquidates one explicitly authorized symbol.  Other
        # reconciled inventory is evidence, not a conflict: blocking on it
        # would prevent an authorized position exit from protecting capital.
        other_positive = sorted(positive - {symbol})
        if not valid or symbol not in positive:
            await broker.close()
            return {"status": "BLOCKED_INVENTORY", "symbol": symbol,
                    "other_positive_symbols": other_positive, "symbol_present": symbol in positive,
                    "broker_mutated": 0}
        plan = await service.build_sell_plan(
            exit_id, {"symbol": symbol}, "AUTHORIZED_EXTERNAL_LIQUIDATION",
            "ALL_AVAILABLE", external=True,
        )
        if args.dry_run:
            await broker.close()
            return {
                "schema": "revx-v5-legacy-liquidation-plan-v1",
                "status": "PLANNED",
                "symbol": symbol,
                "client_order_id": plan.client_order_id,
                "quantity": plan.quantity,
                "limit_price": plan.limit_price,
                "estimated_vwap": plan.estimated_vwap,
                "estimated_slippage_pct": plan.estimated_slippage_pct,
                "coverage_pct": plan.coverage_pct,
                "broker_mutated": 0,
                "order_placement": "OFF",
            }
        journal.setdefault("symbols", {})[symbol] = {
            "status": "SUBMITTING", "client_order_id": plan.client_order_id,
            "quantity": plan.quantity, "limit_price": plan.limit_price,
            "prepared_at": time.time(),
        }
        atomic_json(args.journal, journal)
        try:
            order = await service.submit_sell(plan)
        except ExecutionUnknown as exc:
            journal["symbols"][symbol]["status"] = "UNKNOWN"
            journal["symbols"][symbol]["updated_at"] = time.time()
            journal["symbols"][symbol]["last_error"] = str(exc)[:600]
            atomic_json(args.journal, journal)
            await broker.close()
            return {"status": "BLOCKED_UNKNOWN", "symbol": symbol,
                    "client_order_id": plan.client_order_id, "broker_mutated": 1,
                    "reason": "submit_result_ambiguous_no_retry",
                    "error": str(exc)[:600]}

    venue_id = str(order.get("id") or order.get("venue_order_id") or "")
    phase = order_fill_state(order)
    for _ in range(args.poll_count):
        if phase["phase"] in {"FILLED", "TERMINAL_UNFILLED", "TERMINAL_PARTIAL"}:
            break
        await asyncio.sleep(args.poll_interval_sec)
        payload = await client.order(venue_id, Priority.EXIT_CRITICAL)
        observed = rows(payload)
        order = observed[0] if observed else (payload if isinstance(payload, dict) else {})
        phase = order_fill_state(order)

    balances, valid = parse_balances(await client.balances(Priority.EXIT_CRITICAL))
    currency = symbol.removesuffix("-USD")
    remaining = next((str(row["total"]) for row in balances if row["currency"] == currency), "0")
    result_status = "FILLED" if phase["phase"] == "FILLED" and valid else (
        "BLOCKED_ACTIVE" if phase["phase"] in {"ACTIVE", "PARTIAL"} else "BLOCKED_RECONCILIATION"
    )
    journal.setdefault("symbols", {})[symbol] = {
        **journal.get("symbols", {}).get(symbol, {}),
        "status": result_status,
        "phase": phase["phase"],
        "venue_order_id": venue_id,
        "filled_quantity": str(phase["filled_quantity"]),
        "leaves_quantity": str(phase["leaves_quantity"]),
        "remaining_balance": remaining,
        "updated_at": time.time(),
    }
    atomic_json(args.journal, journal)
    await broker.close()
    return {
        "schema": "revx-v5-legacy-liquidation-result-v1",
        "status": result_status,
        "symbol": symbol,
        "client_order_id": journal["symbols"][symbol].get("client_order_id"),
        "venue_order_id": venue_id,
        "phase": phase["phase"],
        "filled_quantity": str(phase["filled_quantity"]),
        "leaves_quantity": str(phase["leaves_quantity"]),
        "remaining_balance": remaining,
        "planned_quantity": plan.quantity if plan is not None else None,
        "planned_limit_price": plan.limit_price if plan is not None else None,
        "broker_mutated": 1 if plan is not None else 0,
        "order_placement": "ON",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--journal", type=Path, required=True)
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--client-order-suffix", default="")
    parser.add_argument("--ack", required=True)
    parser.add_argument("--poll-count", type=int, default=10)
    parser.add_argument("--poll-interval-sec", type=float, default=2.0)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = asyncio.run(run(args))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n",
                           encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] in {"FILLED", "PLANNED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
