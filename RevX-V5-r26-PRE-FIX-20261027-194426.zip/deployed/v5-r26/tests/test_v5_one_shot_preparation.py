import importlib.util
import json
import shutil
import time
import uuid
from pathlib import Path

import pytest
from revx_v5.live_runtime import V5LiveBoundary
from revx_v5.state_store import DurableState


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("v5_prepare_one_shot", ROOT / "v5_prepare_one_shot.py")
PREPARE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(PREPARE)


def local_tmp() -> Path:
    path = ROOT / "tmp" / "v5-one-shot-tests" / uuid.uuid4().hex
    path.mkdir(parents=True, exist_ok=False)
    return path


def attestation(path: Path, *, now: float, observed_at: float, valid_until: float) -> None:
    path.write_text(json.dumps({
        "schema": "revx-v6-stop-attestation-v1",
        "status": "V6_STOPPED_DISARMED",
        "process_absent": True,
        "autostart_disabled": True,
        "authority_off": True,
        "lease_free": True,
        "observed_at_epoch": observed_at,
        "valid_until_epoch": valid_until,
        "source": "operator_assertion_test",
    }), encoding="utf-8")


def test_prepare_preserves_source_attestation_time():
    root = local_tmp()
    now = time.time()
    try:
        source = root / "attestation.json"
        attestation(source, now=now, observed_at=now - 30, valid_until=now + 86_700)

        result = PREPARE.prepare(ROOT, root / "state", source, now=now)
        counterpart = json.loads((Path(result["bundle"]) / "counterpart.json").read_text(encoding="utf-8"))

        assert counterpart["source"] == "operator_assertion_test"
        assert counterpart["observed_at_utc"] != PREPARE.datetime.fromtimestamp(now, PREPARE.UTC).isoformat().replace("+00:00", "Z")
    finally:
        shutil.rmtree(root)


def test_prepare_rejects_stale_or_overlong_attestation():
    root = local_tmp()
    now = time.time()
    try:
        source = root / "attestation.json"
        attestation(source, now=now, observed_at=now - PREPARE.MAX_ATTESTATION_AGE_SECONDS - 1,
                    valid_until=now + PREPARE.MAX_LIVE_DURATION_SECONDS)
        with pytest.raises(ValueError, match="V6_STOPPED_DISARMED"):
            PREPARE.prepare(ROOT, root / "state", source, now=now)

        attestation(source, now=now, observed_at=now - 30,
                    valid_until=now + PREPARE.MAX_ATTESTATION_VALIDITY_SECONDS + 1)
        with pytest.raises(ValueError, match="V6_STOPPED_DISARMED"):
            PREPARE.prepare(ROOT, root / "state", source, now=now)
    finally:
        shutil.rmtree(root)


def test_operator_launcher_uses_only_canonical_state_root():
    launcher = (ROOT / "Start-V5-r26-Operator.ps1").read_text(encoding="utf-8-sig")
    assert "[string]$StateRoot" not in launcher
    assert "$stateRoot = 'C:\\Users\\serba\\Documents\\RevX\\state\\v5'" in launcher
    assert "--state-root $stateRoot" in launcher


def test_absent_owned_position_uses_bounded_history_from_entry_time():
    root = local_tmp()
    try:
        store = DurableState(root)
        state = store.load()
        state["positions"] = {"ABC-USD": {
            "symbol": "ABC-USD", "quantity": "2", "average_entry_price": "1",
            "entry_filled_at": time.time() - 48 * 3600,
        }}
        store.save(state)

        class VenueExitedClient:
            def __init__(self):
                self.history_hours = []

            async def balances(self, lane=None):
                return {"USD": {"total": 100}}

            async def active_orders(self, symbol=None, lane=None):
                return []

            async def pair_configurations(self, lane=None):
                return {"ABC/USD": {"base": "ABC", "quote": "USD", "status": "active"}}

            async def order_book(self, symbol, limit=50, lane=None):
                return {"bids": [["1", "10"]], "asks": [["1.01", "10"]]}

            async def historical_orders(self, symbol=None, hours=24, lane=None):
                self.history_hours.append(hours)
                return [{"id": "exit-1", "symbol": "ABC-USD", "side": "sell",
                         "status": "filled", "filled_quantity": "2", "leaves_quantity": "0"}]

        client = VenueExitedClient()
        prepared = __import__("asyncio").run(V5LiveBoundary(client, client, state_store=store).prepare_startup())
        assert prepared["owned_positions"] == []
        assert client.history_hours == []
        assert store.load()["reconciliation_events"][-1]["event"] == "VENUE_BALANCE_CONFIRMED_ZERO"
    finally:
        shutil.rmtree(root)
