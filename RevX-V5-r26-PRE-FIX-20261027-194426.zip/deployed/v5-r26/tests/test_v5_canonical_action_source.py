import asyncio
import json
import pathlib
import shutil
import sys
import uuid
from dataclasses import dataclass

CANONICAL_ROOT = pathlib.Path(__file__).resolve().parents[1] / "canonical-base-v3.5.8"
sys.path.insert(0, str(CANONICAL_ROOT))

from revx_v5.canonical_action_source import CanonicalSpeculativeActionSource
from revx_v5.state_store import DurableState
from revx_v3.momentum import MomentumTape


@dataclass
class Quote:
    symbol: str
    mid: float


@dataclass
class Candidate:
    symbol: str
    momentum: dict
    score: float = 0.0
    change_24h_pct: float = 0.0


@dataclass
class Policy:
    name: str


@dataclass
class Rules:
    max_order_size: float = 100000.0
    base_step: float = 0.01
    min_order_size: float = 0.01
    min_order_size_quote: float = 1.0


@dataclass
class Plan:
    requested_risk_usd: float = 3.0
    available_usd: float = 100.0
    cash_reserve_usd: float = 2.0
    capital_limit_usd: float = 98.0
    client_order_id: str = "client-1"
    symbol: str = "ABC-USD"
    quantity: float = 100.0
    limit_price: float = 2.0
    stop: float = 1.9
    target: float = 2.3
    risk_pct: float = 5.0
    structural_rr: float = 3.0
    quality: float = 80.0
    spread_pct: float = 0.1
    estimated_slippage_pct: float = 0.0
    coverage_pct: float = 100.0
    body: dict = None

    def __post_init__(self):
        if self.body is None:
            self.body = {"client_order_id": self.client_order_id,
                         "symbol": self.symbol, "side": "buy",
                         "order_configuration": {"limit": {
                             "base_size": "100", "price": "2.0"}}}


class Client:
    async def tickers(self, _lane):
        return [{"symbol": "ABC-USD", "bid": 1.99, "ask": 2.01}]


class Tape:
    def observe(self, prices, now):
        return {symbol: {"m1": 0.5} for symbol in prices}


class Planner:
    config = {}
    def __init__(self, plan=None):
        self.plan = plan or Plan()
        self.calls = []

    async def build_buy_plan(self, signal_id, symbol, lane, fraction, momentum):
        self.calls.append((signal_id, symbol, lane, fraction, momentum))
        return self.plan

    async def pair_rules(self, _symbol):
        return Rules()

    async def build_sell_plan(self, exit_id, position, reason, scope, external=False):
        class Sell:
            client_order_id = "sell-client"
            quantity = float(position["quantity"])
            trigger_bid = 1.8
            body = {"client_order_id": "sell-client", "symbol": position["symbol"],
                    "side": "sell", "order_configuration": {"limit": {
                        "base_size": str(position["quantity"]), "price": "1.8"}}}
        self.calls.append((exit_id, position["symbol"], reason, scope, external))
        return Sell()


class Priority:
    DISCOVERY = "DISCOVERY"
    EXIT_WATCH = "EXIT_WATCH"
    EXIT_CRITICAL = "EXIT_CRITICAL"


def ranker(_rows, _owned, policy, _limit, momentum):
    return [Candidate("ABC-USD", momentum["ABC-USD"])] if policy.name == "STANDARD" else []


def quote_parser(row):
    return Quote(row["symbol"], (row["bid"] + row["ask"]) / 2)


def source(planner=None, **kwargs):
    clock = kwargs.pop("clock", lambda: 120.0)
    return CanonicalSpeculativeActionSource(
        Client(), planner or Planner(), Tape(), rank_candidates=ranker,
        quote_from_ticker=quote_parser, policies=(Policy("STANDARD"),),
        priority=Priority, order_cap_usd=20, clock=clock, **kwargs,
    )


def test_scan_uses_full_ticker_batch_and_stamps_momentum():
    item = source()
    rows = asyncio.run(item.scan())
    assert rows[0][0].momentum["observed_at"] == 120.0
    assert item.last_scan["ticker_rows"] == 1
    assert item.last_scan["strategy_eligible"] == 1


def test_live_context_records_full_ticker_universe_after_240_seconds_without_early_m5():
    class MultiClient(Client):
        async def tickers(self, _lane):
            return [
                {"symbol": "ABC-USD", "bid": 1.99, "ask": 2.01},
                {"symbol": "XYZ-USD", "bid": 2.99, "ask": 3.01},
            ]

    now = [1000.0]
    item = source(clock=lambda: now[0])
    item.client = MultiClient()
    item.tape = MomentumTape()
    asyncio.run(item.scan())
    now[0] += 241.0
    asyncio.run(item.scan())
    context = item.last_scan["market_context"]
    assert context["history_source"] == "REST_TICKERS_EXISTING_FETCH"
    assert context["symbols_recorded"] == 2
    assert context["symbols_span_ge_240"] == 2
    assert context["symbols_with_m5"] == 0
    assert context["max_context_span_sec"] == 241.0


def test_next_entry_caps_notional_to_twenty_dollars():
    planner = Planner()
    intent = asyncio.run(source(planner).next_entry({
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "DAY", "risk_truth_complete": True,
        "open_positions": 0, "exposure_usd": "0", "session_loss_usd": "0",
    }))
    assert intent.side == "BUY"
    assert intent.body["order_configuration"]["limit"]["base_size"] == "10"
    assert intent.metadata["notional_usd"] == 20.0
    assert planner.plan.body["order_configuration"]["limit"]["base_size"] == "100"


def test_next_entry_excludes_reconciled_external_holding_from_duplicate_buy():
    planner = Planner()
    item = source(planner)
    observed = []

    def respect_occupied(_rows, occupied, _policy, _limit, momentum):
        observed.append(set(occupied))
        return [] if "ABC-USD" in occupied else [Candidate("ABC-USD", momentum["ABC-USD"])]

    item.rank_candidates = respect_occupied
    intent = asyncio.run(item.next_entry({
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "DAY", "risk_truth_complete": True,
        "open_positions": 1, "exposure_usd": "12", "session_loss_usd": "0",
        "managed_symbols": ["ABC-USD"],
    }))
    assert intent is None
    assert observed == [{"ABC-USD"}]
    assert planner.calls == []


def test_source_does_not_scan_when_entry_gate_is_closed():
    planner = Planner()
    result = asyncio.run(source(planner).next_entry({
        "runtime_mode": "MANAGE_EXISTING_ONLY", "entry_enabled": False,
    }))
    assert result is None
    assert planner.calls == []


def test_source_blocks_entry_when_mode_risk_limit_is_reached():
    planner = Planner()
    item = source(planner)
    result = asyncio.run(item.next_entry({
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "NIGHT", "risk_truth_complete": True,
        "open_positions": 10, "exposure_usd": "0", "session_loss_usd": "0",
    }))
    assert result is None
    assert planner.calls == []
    assert item.last_scan["reason"] == "mode_limit"


def test_source_blocks_entry_when_risk_truth_is_unknown():
    planner = Planner()
    item = source(planner)
    result = asyncio.run(item.next_entry({
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "DAY", "risk_truth_complete": False,
    }))
    assert result is None
    assert planner.calls == []
    assert item.last_scan["reason"] == "risk_truth_unavailable"


def test_below_venue_minimum_is_no_action():
    class MinPlanner(Planner):
        async def pair_rules(self, _symbol):
            return Rules(min_order_size_quote=25.0)

    result = asyncio.run(source(MinPlanner()).next_entry({
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "DAY", "risk_truth_complete": True,
        "open_positions": 0, "exposure_usd": "0", "session_loss_usd": "0",
    }))
    assert result is None


def test_hard_stop_builds_sell_before_any_entry():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [{"symbol": "ABC-USD", "bid": 1.79, "ask": 1.81}]

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["1.79", "20"]], "asks": [["1.81", "20"]]}

    item = source()
    item.client = ExitClient()
    intent = asyncio.run(item.next_exit({"owned_positions": [{
        "symbol": "ABC-USD", "quantity": "2", "average_entry_price": "2",
        "stop": 1.8, "target": 2.4,
    }]}))
    assert intent.side == "SELL"
    assert intent.metadata["reason"] == "STOP_HIT"


def test_degraded_coverage_needs_strikes_and_executable_book():
    class MissingTickerClient(Client):
        async def tickers(self, _lane):
            return []

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["1.8", "20"]], "asks": [["1.82", "20"]]}

    now = [120.0]
    item = source(clock=lambda: now[0])
    item.client = MissingTickerClient()
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    assert asyncio.run(item.next_exit(context)) is None
    now[0] += 15
    assert asyncio.run(item.next_exit(context)) is None
    now[0] += 15
    intent = asyncio.run(item.next_exit(context))
    assert intent.metadata["reason"] == "DEGRADED_POSITION"


def test_reconciled_external_inventory_is_exit_eligible_without_cost_basis():
    class MissingTickerClient(Client):
        async def tickers(self, _lane):
            return []

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["1.8", "20"]], "asks": [["1.82", "20"]]}

    now = [120.0]
    item = source(clock=lambda: now[0])
    item.client = MissingTickerClient()
    external = {"symbol": "AIOZ-USD", "quantity": "2", "mark_price": "1.8",
                "cost_basis_status": "UNKNOWN", "pnl_status": "UNKNOWN",
                "exit_eligible": True}
    context = {"managed_positions": [external], "external_positions": [external]}
    assert asyncio.run(item.next_exit(context)) is None
    now[0] += 15
    assert asyncio.run(item.next_exit(context)) is None
    now[0] += 15
    intent = asyncio.run(item.next_exit(context))
    assert intent.side == "SELL"
    assert intent.metadata["reason"] == "DEGRADED_POSITION"


def test_degraded_bridge_never_sells_without_executable_truth():
    class NoBookClient(Client):
        async def tickers(self, _lane):
            return []

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [], "asks": []}

    item = source()
    item.client = NoBookClient()
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    for _ in range(4):
        assert asyncio.run(item.next_exit(context)) is None


def test_degraded_strikes_survive_restart():
    class MissingTickerClient(Client):
        async def tickers(self, _lane):
            return []

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["1.8", "20"]], "asks": [["1.82", "20"]]}

    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\health"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    now = [120.0]
    first = source(health_store=store, clock=lambda: now[0])
    first.client = MissingTickerClient()
    assert asyncio.run(first.next_exit(context)) is None
    now[0] += 15
    assert asyncio.run(first.next_exit(context)) is None
    now[0] += 15
    restarted = source(health_store=store, clock=lambda: now[0])
    restarted.client = MissingTickerClient()
    intent = asyncio.run(restarted.next_exit(context))
    assert intent.metadata["reason"] == "DEGRADED_POSITION"
    store.state_path.unlink(missing_ok=True)


def test_r25_allocates_five_composite_raw_mover_and_fresh_acceleration():
    item = source()
    policy = Policy("STANDARD")
    candidates = [
        (Candidate(f"A{index}-USD", {"accel_5_vs_15": index / 10},
                   score=100 - index, change_24h_pct=index), policy)
        for index in range(10)
    ]
    # The raw leader and strongest acceleration are deliberately outside top 5.
    selected, journal = item._allocate_validation_slots(candidates)
    assert [row[0].symbol for row in selected[:5]] == [f"A{i}-USD" for i in range(5)]
    assert selected[5][0].symbol == "A9-USD"
    assert selected[6][0].symbol == "A8-USD"
    assert [row["slot"] for row in journal] == [
        "COMPOSITE", "COMPOSITE", "COMPOSITE", "COMPOSITE", "COMPOSITE",
        "RAW_MOVER", "FRESH_ACCELERATION",
    ]


def test_discovery_10_preserves_specialty_slots_and_adds_ranked_backfill():
    item = source(validation_limit=10)
    policy = Policy("STANDARD")
    candidates = [
        (Candidate(f"A{index}-USD", {"accel_5_vs_15": index / 10},
                   score=100 - index, change_24h_pct=index), policy)
        for index in range(12)
    ]

    selected, journal = item._allocate_validation_slots(candidates)

    assert len(selected) == 10
    assert len({item._asset_key(row[0].symbol) for row in selected}) == 10
    assert [row["slot"] for row in journal[:7]] == [
        "COMPOSITE", "COMPOSITE", "COMPOSITE", "COMPOSITE", "COMPOSITE",
        "RAW_MOVER", "FRESH_ACCELERATION",
    ]
    assert journal[7]["slot"] == "EXPLORATION_ROTATION"
    assert [row["slot"] for row in journal[8:]] == [
        "COMPOSITE_FALLTHROUGH", "COMPOSITE_FALLTHROUGH",
    ]


def test_candidate_journal_retains_bounded_bid_ask_without_network_calls():
    candidate = Candidate("ABC-USD", {"m1": 0.2}, score=10, change_24h_pct=3)
    candidate.quote = type("MarketQuote", (), {
        "bid": 1.99, "ask": 2.01, "spread_pct": 1.0,
    })()

    view = source()._candidate_view((candidate, Policy("STANDARD")), "COMPOSITE")

    assert view["bid"] == 1.99
    assert view["ask"] == 2.01
    assert view["spread_pct"] == 1.0


def test_r25_underlying_dedup_and_backfill_never_validates_usd_and_eur():
    item = source()
    policy = Policy("STANDARD")
    candidates = [
        (Candidate("ABC-USD", {"accel_5_vs_15": 1}, 100, 10), policy),
        (Candidate("ABC-EUR", {"accel_5_vs_15": 2}, 99, 20), policy),
    ] + [
        (Candidate(f"U{i}-USD", {"accel_5_vs_15": i / 10}, 90 - i, i), policy)
        for i in range(8)
    ]
    selected, _journal = item._allocate_validation_slots(candidates)
    assets = [item._asset_key(row[0].symbol) for row in selected]
    assert len(selected) == 7
    assert len(assets) == len(set(assets))
    assert sum(asset == "ABC" for asset in assets) == 1


def test_r25_exploration_fallback_uses_oldest_unvalidated_asset():
    item = source()
    policy = Policy("STANDARD")
    candidates = [
        (Candidate(f"A{i}-USD", {"accel_5_vs_15": 0}, 100 - i, 20 - i), policy)
        for i in range(8)
    ]
    item._deep_validation_times = {"A6": 200.0, "A7": 100.0}
    selected, journal = item._allocate_validation_slots(candidates)
    assert selected[6][0].symbol == "A7-USD"
    assert journal[6]["slot"] == "EXPLORATION_ROTATION"


def test_r25_second_negative_cycle_keeps_profitable_position():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [{"symbol": "ABC-USD", "bid": 2.09, "ask": 2.11}]

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["2.09", "20"]], "asks": [["2.11", "20"]]}

    class NegativeTape:
        def observe(self, prices, now):
            return {symbol: {"s20": -0.10, "m1": -0.13, "accel_5_vs_15": -0.2}
                    for symbol in prices}

    planner = Planner()
    now = [120.0]
    item = source(planner, clock=lambda: now[0])
    item.client = ExitClient()
    item.tape = NegativeTape()
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    assert asyncio.run(item.next_exit(context)) is None
    now[0] += 15
    assert asyncio.run(item.next_exit(context)) is None
    assert item.last_scan["last_exit"]["status"] == "HOLD_PROFITABLE_DOWNTREND"


def test_r25_second_negative_cycle_sells_when_unprofitable():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [{"symbol": "ABC-USD", "bid": 1.89, "ask": 1.91}]

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["1.89", "20"]], "asks": [["1.91", "20"]]}

    class NegativeTape:
        def observe(self, prices, now):
            return {symbol: {"s20": -0.10, "m1": -0.13, "accel_5_vs_15": -0.2}
                    for symbol in prices}

    planner = Planner()
    now = [120.0]
    item = source(planner, clock=lambda: now[0])
    item.client = ExitClient()
    item.tape = NegativeTape()
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    assert asyncio.run(item.next_exit(context)) is None
    now[0] += 15
    intent = asyncio.run(item.next_exit(context))
    assert intent.metadata["reason"] == "CONFIRMED_DOWNTREND_UNPROFITABLE"


def test_r25_global_exit_precedence_prefers_stop_over_downttrend():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [
                {"symbol": "EARLY-USD", "bid": 2.0, "ask": 2.01},
                {"symbol": "STOP-USD", "bid": 0.9, "ask": 0.91},
            ]

        async def order_book(self, symbol, _limit, _lane):
            bid = "0.9" if symbol == "STOP-USD" else "2.0"
            return {"bids": [[bid, "20"]], "asks": [[str(float(bid) + .01), "20"]]}

    class NegativeTape:
        def observe(self, prices, now):
            return {symbol: {"m1": -0.2} for symbol in prices}

    planner = Planner()
    item = source(planner)
    item.client = ExitClient()
    item.tape = NegativeTape()
    item._negative_momentum["EARLY-USD"] = 1
    context = {"owned_positions": [
        {"symbol": "EARLY-USD", "quantity": "2", "average_entry_price": "2",
         "stop": 1.5, "target": 2.4},
        {"symbol": "STOP-USD", "quantity": "2", "average_entry_price": "1.1",
         "stop": 1.0, "target": 1.4},
    ]}
    intent = asyncio.run(item.next_exit(context))
    assert intent.symbol == "STOP-USD"
    assert intent.metadata["reason"] == "STOP_HIT"


def test_r25_positive_cycle_resets_negative_confirmation():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [{"symbol": "ABC-USD", "bid": 2.0, "ask": 2.01}]

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["2.0", "20"]], "asks": [["2.01", "20"]]}

    class SequenceTape:
        def __init__(self):
            self.values = iter((-0.2, 0.2, -0.2))

        def observe(self, prices, now):
            value = next(self.values)
            return {symbol: {"m1": value} for symbol in prices}

    item = source()
    item.client = ExitClient()
    item.tape = SequenceTape()
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    assert asyncio.run(item.next_exit(context)) is None
    assert asyncio.run(item.next_exit(context)) is None
    assert asyncio.run(item.next_exit(context)) is None
    assert item._negative_momentum["ABC-USD"] == 1


def test_r25_negative_confirmation_survives_restart():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [{"symbol": "ABC-USD", "bid": 2.0, "ask": 2.01}]

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["2.0", "20"]], "asks": [["2.01", "20"]]}

    class NegativeTape:
        def observe(self, prices, now):
            return {symbol: {"m1": -0.2} for symbol in prices}

    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\r25-negative-restart"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    now = [120.0]
    first = source(health_store=store, clock=lambda: now[0])
    first.client = ExitClient()
    first.tape = NegativeTape()
    assert asyncio.run(first.next_exit(context)) is None
    now[0] += 15
    restarted = source(health_store=store, clock=lambda: now[0])
    restarted.client = ExitClient()
    restarted.tape = NegativeTape()
    intent = asyncio.run(restarted.next_exit(context))
    assert intent.metadata["reason"] == "CONFIRMED_DOWNTREND_UNPROFITABLE"
    store.state_path.unlink(missing_ok=True)


def test_r25_stale_negative_restart_resets_before_confirming():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [{"symbol": "ABC-USD", "bid": 2.0, "ask": 2.01}]

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["2.0", "20"]], "asks": [["2.01", "20"]]}

    class NegativeTape:
        def observe(self, prices, now):
            return {symbol: {"m1": -0.2} for symbol in prices}

    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\r25-stale-negative"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    now = [120.0]
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    first = source(health_store=store, clock=lambda: now[0])
    first.client, first.tape = ExitClient(), NegativeTape()
    assert asyncio.run(first.next_exit(context)) is None
    now[0] = 300.0
    restarted = source(health_store=store, clock=lambda: now[0])
    restarted.client, restarted.tape = ExitClient(), NegativeTape()
    assert asyncio.run(restarted.next_exit(context)) is None
    assert restarted._negative_momentum["ABC-USD"] == 1
    now[0] += 15
    intent = asyncio.run(restarted.next_exit(context))
    assert intent.metadata["reason"] == "CONFIRMED_DOWNTREND_UNPROFITABLE"
    store.state_path.unlink(missing_ok=True)


def test_r25_stale_degraded_restart_requires_three_fresh_misses():
    class MissingTickerClient(Client):
        async def tickers(self, _lane):
            return []

        async def order_book(self, _symbol, _limit, _lane):
            return {"bids": [["1.8", "20"]], "asks": [["1.82", "20"]]}

    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\r25-stale-degraded"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    now = [120.0]
    context = {"owned_positions": [{"symbol": "ABC-USD", "quantity": "2",
                                     "average_entry_price": "2", "stop": 1.5,
                                     "target": 2.4}]}
    first = source(health_store=store, clock=lambda: now[0])
    first.client = MissingTickerClient()
    assert asyncio.run(first.next_exit(context)) is None
    now[0] = 300.0
    restarted = source(health_store=store, clock=lambda: now[0])
    restarted.client = MissingTickerClient()
    assert asyncio.run(restarted.next_exit(context)) is None
    assert restarted._coverage_misses["ABC-USD"] == 1
    now[0] += 15
    assert asyncio.run(restarted.next_exit(context)) is None
    now[0] += 15
    intent = asyncio.run(restarted.next_exit(context))
    assert intent.metadata["reason"] == "DEGRADED_POSITION"
    store.state_path.unlink(missing_ok=True)


def test_r25_blocked_stop_never_falls_through_to_downtrend():
    class ExitClient(Client):
        async def tickers(self, _lane):
            return [
                {"symbol": "STOP-USD", "bid": 0.9, "ask": 0.91},
                {"symbol": "DOWN-USD", "bid": 2.0, "ask": 2.01},
            ]

        async def order_book(self, symbol, _limit, _lane):
            bid = "0.9" if symbol == "STOP-USD" else "2.0"
            return {"bids": [[bid, "20"]], "asks": [[str(float(bid) + .01), "20"]]}

    class NegativeTape:
        def observe(self, prices, now):
            return {symbol: {"m1": -0.2} for symbol in prices}

    class FailStopPlanner(Planner):
        async def build_sell_plan(self, exit_id, position, reason, scope, external=False):
            self.calls.append((exit_id, position["symbol"], reason, scope, external))
            if reason == "STOP_HIT":
                raise ValueError("stop plan blocked")
            return await super().build_sell_plan(
                exit_id, position, reason, scope, external=external
            )

    now = [120.0]
    planner = FailStopPlanner()
    item = source(planner, clock=lambda: now[0])
    item.client, item.tape = ExitClient(), NegativeTape()
    item._negative_momentum["DOWN-USD"] = 1
    item._last_negative_observed_at["DOWN-USD"] = 105.0
    context = {"owned_positions": [
        {"symbol": "STOP-USD", "quantity": "2", "average_entry_price": "1.1",
         "stop": 1.0, "target": 1.4},
        {"symbol": "DOWN-USD", "quantity": "2", "average_entry_price": "2",
         "stop": 1.5, "target": 2.4},
    ]}
    assert asyncio.run(item.next_exit(context)) is None
    assert [call[2] for call in planner.calls] == ["STOP_HIT"]
    assert item.last_scan["last_exit"]["status"] == "BLOCKED_URGENT_EXIT"


def test_r25_decision_journal_retains_newest_256_records():
    root = pathlib.Path(__file__).resolve().parents[3] / "tmp" / "v5-tests" / ("r25-journal-" + uuid.uuid4().hex)
    try:
        store = DurableState(root)
        for observed_at in range(1, 271):
            store.append_decision_snapshot({"observed_at": observed_at})
        rows = [json.loads(line) for line in store.decision_journal_path.read_text(
            encoding="utf-8"
        ).splitlines()]
        assert len(rows) == 256
        assert rows[0]["observed_at"] == 15
        assert rows[-1]["observed_at"] == 270
    finally:
        shutil.rmtree(root)


def test_r25_journal_keeps_rejection_before_later_buy():
    class TwoPlanner(Planner):
        async def build_buy_plan(self, signal_id, symbol, lane, fraction, momentum):
            if symbol == "BAD-USD":
                raise ValueError("geometry rejected")
            return Plan(client_order_id="good", symbol=symbol)

    def two_ranker(_rows, _owned, policy, _limit, _momentum):
        if policy.name != "STANDARD":
            return []
        return [
            Candidate("BAD-USD", {}, 100, 10),
            Candidate("GOOD-USD", {}, 90, 9),
        ]

    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\r25-journal-entry"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    store.decision_journal_path.unlink(missing_ok=True)
    item = CanonicalSpeculativeActionSource(
        Client(), TwoPlanner(), Tape(), rank_candidates=two_ranker,
        quote_from_ticker=quote_parser, policies=(Policy("STANDARD"),),
        priority=Priority, health_store=store, clock=lambda: 120.0,
    )
    intent = asyncio.run(item.next_entry({
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "DAY", "risk_truth_complete": True,
        "open_positions": 0, "exposure_usd": "0", "session_loss_usd": "0",
    }))
    assert intent.symbol == "GOOD-USD"
    rows = [json.loads(line) for line in store.decision_journal_path.read_text(
        encoding="utf-8"
    ).splitlines()]
    assert rows[-1]["planning_rejections"][0]["symbol"] == "BAD-USD"
    store.state_path.unlink(missing_ok=True)
    store.decision_journal_path.unlink(missing_ok=True)
