import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import pytest
from revx_v5.process_lease import ProcessLease
from v5_detached_launcher import supervise

ROOT = Path(__file__).resolve().parents[1]


def setup(tmp_path):
    state = tmp_path / 'state'
    output = tmp_path / 'launch'
    state.mkdir()
    output.mkdir()
    authority = state / 'authority-v5.json'
    authority.write_text(json.dumps({'execution_enabled': True, 'order_placement': 'ON'}))
    return state, output, authority


def test_abrupt_exit_disarms_records_exit_and_never_restarts(tmp_path):
    state, output, authority = setup(tmp_path)
    code = (f'import os; from pathlib import Path; Path({str(authority)!r}).write_text('
            '\'{"execution_enabled":true,"order_placement":"ON"}\'); '
            'print("runtime evidence",flush=True); os._exit(23)')
    result = supervise([sys.executable, '-u', '-c', code], state, output, tmp_path/'missing.json')
    assert result['status'] == 'FAIL'
    assert result['exit_code'] == 23 and result['authority_off'] is True
    assert result['restart_attempted'] is False
    assert result['reason'] == 'RUNTIME_EXITED_WITHOUT_FINAL'
    assert json.loads(authority.read_text())['order_placement'] == 'OFF'
    assert 'runtime evidence' in (output/'runtime.stdout.log').read_text()


def test_existing_runtime_is_never_disarmed(tmp_path):
    state, output, authority = setup(tmp_path)
    before = authority.read_bytes()
    with ProcessLease(state/'runtime-v5.lock'):
        result = supervise([sys.executable, '-c', 'raise AssertionError()'], state, output, tmp_path/'missing')
    assert result['error_type'] == 'LeaseUnavailable'
    assert authority.read_bytes() == before
    assert 'runtime_pid' not in result


def test_second_supervisor_cannot_disarm_or_launch(tmp_path):
    state, output, authority = setup(tmp_path)
    before = authority.read_bytes()
    with ProcessLease(state/'supervisor-v5.lock'):
        result = supervise([sys.executable, '-c', 'raise AssertionError()'], state, output, tmp_path/'missing')
    assert result['error_type'] == 'LeaseUnavailable'
    assert authority.read_bytes() == before


def test_receipt_write_failure_does_not_abandon_child(tmp_path, monkeypatch):
    import v5_detached_launcher as module
    state, output, authority = setup(tmp_path)
    original = module.write_json
    def write(path, data):
        if Path(path).name == 'launch.json':
            raise PermissionError('receipt fault')
        return original(path,data)
    monkeypatch.setattr(module,'write_json',write)
    result = supervise([sys.executable,'-c','pass'], state,output,tmp_path/'missing')
    assert result['authority_off'] and result['exit_code']==0
    assert (output/'FINAL.json').is_file()


@pytest.mark.skipif(os.name != 'nt', reason='Windows console close regression')
def test_closing_original_console_keeps_supervisor_and_worker_alive(tmp_path):
    state, output, authority = setup(tmp_path)
    terminal = tmp_path/'runtime-final.json'
    stop = tmp_path/'stop'
    child = (f'import time,json; from pathlib import Path; stop=Path({str(stop)!r}); '
             f'terminal=Path({str(terminal)!r})\n'
             f'Path({str(authority)!r}).write_text(json.dumps({{"execution_enabled":True,"order_placement":"ON"}}))\n'
             'while not stop.exists(): time.sleep(.05)\n'
             'terminal.write_text(json.dumps({"status":"PASS"}))\n')
    supervisor = (f'import sys; sys.path.insert(0,{str(ROOT)!r}); '
        'from v5_detached_launcher import supervise; '
        f'supervise({[sys.executable,"-u","-c",child]!r},{str(state)!r},{str(output)!r},{str(terminal)!r})')
    parent = (f'import sys,os,ctypes,time; sys.path.insert(0,{str(ROOT)!r}); '
        'from v5_detached_launcher import detached_process; '
        f'out=open({str(output/"host.log")!r},"ab",buffering=0); '
        f'p=detached_process({[sys.executable,"-B","-c",supervisor]!r},out,out); '
        'print(str(p.pid)+" "+str(ctypes.windll.kernel32.GetConsoleWindow()),flush=True); time.sleep(30)')
    si=subprocess.STARTUPINFO()
    si.dwFlags=subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow=0
    process=subprocess.Popen([sys.executable,'-u','-c',parent],stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,text=True,creationflags=subprocess.CREATE_NEW_CONSOLE,startupinfo=si)
    try:
        supervisor_pid,hwnd=map(int,process.stdout.readline().split())
        deadline=time.monotonic()+10
        while not (output/'launch.json').exists() and time.monotonic()<deadline:
            time.sleep(.05)
        assert (output/'launch.json').exists()
        while json.loads(authority.read_text())['order_placement'] != 'ON' and time.monotonic()<deadline:
            time.sleep(.05)
        assert json.loads(authority.read_text())['order_placement']=='ON'
        assert ctypes.windll.user32.PostMessageW(ctypes.c_void_p(hwnd),0x0010,0,0)
        process.wait(timeout=10)
        assert process.returncode & 0xffffffff == 0xc000013a
        assert not (output/'FINAL.json').exists()
        # Worker must still react to this new stop request after console death.
        stop.touch()
        deadline=time.monotonic()+10
        while not (output/'FINAL.json').exists() and time.monotonic()<deadline:
            time.sleep(.05)
        result=json.loads((output/'FINAL.json').read_text())
        assert result['status']=='PASS' and result['exit_code']==0
        assert result['supervisor_pid']==supervisor_pid and result['authority_off']
    finally:
        stop.touch()
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=5)


def test_operator_launcher_routes_to_detached_manual_host():
    text=(ROOT/'Start-V5-r26-Operator.ps1').read_text(encoding='utf-8-sig')
    assert text.index("$confirmation -cne 'DA'") < text.index("'v5_detached_launcher.py'")
    assert '--operator-confirmed' in text
    assert "& $python (Join-Path $root 'v5_operator_session.py')" not in text


def test_success_waits_for_fresh_health_from_own_permit(tmp_path):
    from v5_detached_launcher import startup_result
    state,output,_=setup(tmp_path)
    (output/'launch.json').write_text(json.dumps(dict(status='CHILD_STARTED',runtime_pid=123,started_at=100)))
    assert startup_result(output,state,'permit') is None
    consumed=state/'consumed-permit.json'; consumed.write_text(json.dumps(dict(pid=123)))
    health=state/'runtime-health-v5.json'
    health.write_text(json.dumps(dict(last_cycle_at=99,cycles=10,status='HEALTHY_SILENCE')))
    assert startup_result(output,state,'permit') is None
    health.write_text(json.dumps(dict(last_cycle_at=101,cycles=1,status='HEALTHY_SILENCE')))
    assert startup_result(output,state,'permit')['status']=='RUNNING'
    consumed.write_text(json.dumps(dict(pid=456)))
    assert startup_result(output,state,'permit') is None
    consumed.write_text(json.dumps(dict(pid=123)))
    health.write_text(json.dumps(dict(last_cycle_at=101,cycles=1,status='BLOCKED',reason='risk_truth_unavailable')))
    assert startup_result(output,state,'permit')['status']=='STARTUP_NOT_HEALTHY'
