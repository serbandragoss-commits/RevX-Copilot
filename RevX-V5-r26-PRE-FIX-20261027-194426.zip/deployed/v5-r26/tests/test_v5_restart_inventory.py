import asyncio
from decimal import Decimal
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'canonical-base-v3.5.8'))
from revx_v5.canonical_action_source import CanonicalSpeculativeActionSource
from revx_v5.live_runtime import V5LiveBoundary
from revx_v5.provider_adapter import MutationDisabledAdapter
from revx_v5.state_store import DurableState
from revx_v5.supervisor import V5Supervisor
from revx_v5.runner import V5Runner
from revx_v5.execution_adapter import Intent


class Venue:
    def __init__(self, quantity='52.20569', bid=.39, missing_ticker=False):
        self.quantity, self.bid, self.missing_ticker = quantity, bid, missing_ticker
        self.mutations = 0

    async def balances(self, lane=None):
        return [dict(currency='USD',available='188.93',total='188.93',reserved='0'),
                dict(currency='SPX',available=self.quantity,total=self.quantity,reserved='0')]

    async def active_orders(self, symbol=None, lane=None):
        return []

    async def historical_orders(self, symbol=None, hours=24, lane=None):
        return []

    async def pair_configurations(self, lane=None):
        return {'SPX/USD':dict(base='SPX',quote='USD',status='active',base_step='.00001',
                               quote_step='.0001',min_order_size='.00001',
                               min_order_size_quote='1',max_order_size='100000')}

    async def order_book(self, symbol, limit=50, lane=None):
        return {'bids':[[str(self.bid),'1000']], 'asks':[[str(self.bid+.0001),'1000']]}

    async def tickers(self, lane=None):
        return [] if self.missing_ticker else [dict(symbol='SPX/USD',bid=self.bid,ask=self.bid+.0001)]

    async def submit_order(self,*args):
        self.mutations += 1
        raise AssertionError('No real or simulated submit during restart validation')


def setup_restart(tmp_path, *, venue=None, owned=True):
    venue = venue or Venue()
    store = DurableState(tmp_path)
    state = store.load()
    if owned:
        state['positions']['SPX-USD'] = dict(symbol='SPX-USD',quantity='52.20569',
            average_entry_price='.3831',stop=.3757,target=.401,entry_fee_usd='0',
            entry_fee_truth='KNOWN',entry_intent_id='existing-buy',source='V5_OWNED',
            operating_mode='NIGHT',session_key='prior-session')
    store.save(state)
    boundary = V5LiveBoundary(venue,MutationDisabledAdapter(),state_store=store)
    supervisor = V5Supervisor(boundary,operating_mode='NIGHT')
    source = CanonicalSpeculativeActionSource.from_canonical(venue,{},health_store=store)
    return store,venue,boundary,supervisor,source


def test_restart_reconciles_owned_position_and_evaluates_hold_then_allows_other_buy(tmp_path):
    store,venue,boundary,supervisor,source = setup_restart(tmp_path)
    calls=[]
    async def other_buy(context):
        calls.append(context)
        assert context['managed_symbols'] == ['SPX-USD']
        assert context['exposure_usd'] == '19.999999839'
        assert context['entry_enabled'] is True
        return Intent('other','OTHER-USD','BUY',{})
    source.next_entry = other_buy
    result = asyncio.run(V5Runner(supervisor,boundary,source).cycle())
    assert result['status'] == 'ACTION_READY' and result['action'] == 'BUY'
    assert result['symbol'] == 'OTHER-USD' and len(calls)==1
    assert venue.mutations == 0
    assert store.load()['positions']['SPX-USD']['entry_intent_id'] == 'existing-buy'


def test_restart_stop_hit_reaches_native_sell_planner_before_entries(tmp_path):
    store,venue,boundary,supervisor,source = setup_restart(tmp_path,venue=Venue(bid=.37))
    async def entry_must_not_run(context):
        raise AssertionError('SELL must have priority')
    source.next_entry = entry_must_not_run
    result = asyncio.run(V5Runner(supervisor,boundary,source).cycle())
    assert result['status'] == 'ACTION_READY' and result['action']=='SELL'
    assert result['symbol']=='SPX-USD' and venue.mutations==0
    assert store.load()['positions']['SPX-USD']['quantity']=='52.20569'


def test_external_position_reaches_real_sell_planner_with_bounded_quantity(tmp_path):
    store,venue,boundary,supervisor,source = setup_restart(tmp_path,venue=Venue(quantity='3',missing_ticker=True),owned=False)
    now=[1000.0]
    source.clock=lambda:now[0]
    source.planner.clock=source.clock
    context=asyncio.run(supervisor.prepare())
    assert context['runtime_mode']=='NORMAL' and context['entry_enabled']
    for _ in range(2):
        assert asyncio.run(source.next_exit(context)) is None
        now[0]+=15
    intent=asyncio.run(source.next_exit(context))
    assert intent is not None and intent.side=='SELL'
    assert intent.metadata['inventory_origin']=='EXTERNAL_INVENTORY'
    assert Decimal(intent.body['order_configuration']['limit']['base_size'])==3
    assert store.load()['positions']=={} and venue.mutations==0


def test_external_residual_sell_never_sweeps_owned_lot(tmp_path):
    store,venue,boundary,supervisor,source = setup_restart(tmp_path,venue=Venue(quantity='55.20569'),owned=True)
    context=asyncio.run(supervisor.prepare())
    external=context['external_positions'][0]
    assert Decimal(external['quantity'])==3
    external.update(inventory_origin='EXTERNAL_INVENTORY',coverage_missing_confirmations=3,
                    coverage_last_missing_at=source.clock())
    plan=asyncio.run(source.planner.build_sell_plan('external-exit',external,'DEGRADED_POSITION','MANAGED',external=True))
    assert Decimal(str(plan.quantity))==3
    assert store.load()['positions']['SPX-USD']['quantity']=='52.20569'


def test_external_fill_is_idempotent_and_preserves_owned_quantity_and_risk(tmp_path):
    store,venue,boundary,supervisor,source=setup_restart(tmp_path,venue=Venue(quantity='55.20569'))
    asyncio.run(supervisor.prepare())
    before=store.load()
    intent=dict(intent_id='external-exit',symbol='SPX-USD',side='SELL',
                metadata=dict(inventory_origin='EXTERNAL_INVENTORY'))
    order=dict(id='external-venue-id',filled_quantity='1',average_fill_price='.39')
    assert store.apply_execution_fill(intent,order)['adopted_delta']=='1'
    assert store.apply_execution_fill(intent,order)['adopted_delta']=='0'
    assert store.load()['external_inventory']['SPX-USD']['quantity']=='2.00000'
    store.apply_execution_fill(intent,dict(order,filled_quantity='3'))
    after=store.load()
    assert after['positions']==before['positions'] and after['risk']==before['risk']
    assert after['external_inventory']=={}
    assert after['external_exit_ledger'][0]['net_pnl_usd'] is None


def test_invalid_balance_does_not_remove_owned_position(tmp_path):
    class Broken(Venue):
        async def balances(self,lane=None):
            return {'unexpected':'not balances'}
    store,venue,boundary,supervisor,source=setup_restart(tmp_path,venue=Broken())
    with pytest.raises(RuntimeError):
        asyncio.run(supervisor.prepare())
    assert 'SPX-USD' in store.load()['positions']


def test_owned_stop_is_not_misclassified_when_external_residual_shares_symbol(tmp_path):
    store,venue,boundary,supervisor,source=setup_restart(tmp_path,venue=Venue(quantity='55.20569',bid=.37))
    context=asyncio.run(supervisor.prepare())
    intent=asyncio.run(source.next_exit(context))
    assert intent.metadata['inventory_origin']=='V5_OWNED'
    assert Decimal(intent.body['order_configuration']['limit']['base_size'])==Decimal('52.20569')


def test_external_hold_allows_other_buy_and_excess_fill_cannot_erase_owned_lot(tmp_path):
    store,venue,boundary,supervisor,source=setup_restart(tmp_path,venue=Venue(quantity='3'),owned=False)
    async def other_buy(context):
        assert context['entry_enabled'] and context['managed_symbols']==['SPX-USD']
        return Intent('other','OTHER-USD','BUY',{})
    source.next_entry=other_buy
    result=asyncio.run(V5Runner(supervisor,boundary,source).cycle())
    assert result['action']=='BUY' and result['status']=='ACTION_READY'
    before=store.state_path.read_bytes()
    with pytest.raises(ValueError,match='exceeds reconciled external lot'):
        store.apply_execution_fill(dict(intent_id='bad',symbol='SPX-USD',side='SELL',
            metadata=dict(inventory_origin='EXTERNAL_INVENTORY')),
            dict(id='bad',filled_quantity='4',average_fill_price='.39'))
    assert store.state_path.read_bytes()==before


def test_owned_and_external_exits_in_same_minute_have_distinct_intent_ids(tmp_path):
    store,venue,boundary,supervisor,source=setup_restart(tmp_path,venue=Venue(quantity='55.20569',missing_ticker=True))
    source.clock=lambda:1000.0
    source.planner.clock=source.clock
    source._coverage_misses['SPX-USD']=3
    source._last_coverage_miss_observed_at['SPX-USD']=1000.0
    context=asyncio.run(supervisor.prepare())
    owned_exit=asyncio.run(source.next_exit(context))
    external_exit=asyncio.run(source.next_exit({**context,'managed_positions':context['external_positions']}))
    assert owned_exit.metadata['inventory_origin']=='V5_OWNED'
    assert external_exit.metadata['inventory_origin']=='EXTERNAL_INVENTORY'
    assert owned_exit.intent_id != external_exit.intent_id
