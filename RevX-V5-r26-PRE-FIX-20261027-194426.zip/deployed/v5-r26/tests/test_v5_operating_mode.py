from datetime import datetime, timedelta, timezone

from revx_v5.operating_mode import AutoModeClock


ZONE = timezone(timedelta(hours=3))


def timestamp(hour, minute=0, day=3):
    return datetime(2026, 10, day, hour, minute, tzinfo=ZONE).timestamp()


def test_day_and_night_windows_preserve_validated_schedule():
    day = AutoModeClock(ZONE, clock=lambda: timestamp(7)).current()
    late_day = AutoModeClock(ZONE, clock=lambda: timestamp(21, 56)).current()
    night = AutoModeClock(ZONE, clock=lambda: timestamp(22)).current()
    late_night = AutoModeClock(ZONE, clock=lambda: timestamp(6, 56, day=4)).current()
    assert (day.mode, day.entry_open, day.session_key) == ("DAY", True, "2026-10-03")
    assert (late_day.mode, late_day.entry_open) == ("DAY", False)
    assert (night.mode, night.entry_open, night.session_key) == ("NIGHT", True, "2026-10-03")
    assert (late_night.mode, late_night.entry_open, late_night.session_key) == (
        "NIGHT", False, "2026-10-03"
    )
