import asyncio
from decimal import Decimal
from types import SimpleNamespace
import pytest
import subprocess
import os
from pathlib import Path
from revx_v5.execution_evidence import normalize_fills
from revx_v5.execution_truth import order_fill_state
from revx_v5.state_store import DurableState
from revx_v5.policy import operator_config, operator_policy
from revx_v5.sizing import size_buy
from test_v5_canonical_action_source import Plan,Rules,source
from test_v5_runner import Supervisor,Boundary,Source,live_authority,run
from revx_v5.runner import V5Runner
from revx_v5.execution_adapter import Intent


def intent(key,symbol,side):
    return dict(intent_id=key,symbol=symbol,side=side,metadata=dict(
        operating_mode='NIGHT',session_key='2026-10-20',stop=1,target=200))


def test_raw_api_fills_override_rounded_average_not_settled_cash():
    order=dict(id='order',symbol='NEON/USD',side='buy',filled_quantity='1048.1895',
               average_fill_price='.0058',filled_amount='6.08')
    fills=[dict(tid='trade',p='.005792',q='1048.1895',qc='NEON',pc='USD')]
    result=normalize_fills(order,{'data':fills})
    assert Decimal(result['average_fill_price'])==Decimal('.005792')
    assert result['reported_average_fill_price']=='.0058'
    assert result['executed_quote_amount']=='6.08'
    for bad in [[],fills+fills,[{**fills[0],'q':'1048'}],[{**fills[0],'qc':'OTHER'}]]:
        with pytest.raises(ValueError): normalize_fills(order,bad)


def test_partial_cumulative_prices_use_quote_delta_on_both_sides(tmp_path):
    store=DurableState(tmp_path)
    buy=intent('buy','A-USD','BUY'); sell=intent('sell','A-USD','SELL')
    for q,p in [('1','100'),('2','110')]:
        store.apply_execution_fill(buy,dict(filled_quantity=q,average_price=p,total_fee='0',fee_currency='USD'))
    assert Decimal(store.load()['positions']['A-USD']['average_entry_price'])==110
    for q,p in [('1','120'),('2','130')]:
        store.apply_execution_fill(sell,dict(filled_quantity=q,average_price=p,total_fee='0',fee_currency='USD'))
    assert Decimal(store.load()['economic_ledger'][0]['net_pnl_usd'])==40
    assert store.apply_execution_fill(sell,dict(filled_quantity='2',average_price='130',total_fee='0',fee_currency='USD'))['adopted_delta']=='0'


def test_overnight_cash_replay_including_aero_base_fee_keeps_risk_complete(tmp_path):
    store=DurableState(tmp_path)
    orders=[]
    intents={}
    # Broker settlement amounts from the 2026-10-21 run, not rounded summary VWAP.
    cases=[('COMP','4.140192','26.256','108.71','108.66','.1','0'),
           ('PEPE','4617290','.0000045404','20.97','20.91','.02','0'),
           ('NEON','1048.1895','.005792','6.08','6.06','.01','0'),
           ('COMP','4.781594','26.184','125.21','124.54','.12','0'),
           ('AERO','28.1292','.8813','24.80','24.79','.03','.0254'),
           ('PENGU','15669.749','.00799','125.21','125.20','.12','0')]
    for index,(symbol,q,p,paid,received,fee,basefee) in enumerate(cases):
        buy=intent(f'b{index}',symbol+'-USD','BUY');sell=intent(f's{index}',symbol+'-USD','SELL')
        buy_order=dict(id=f'b{index}',client_order_id=buy['intent_id'],created_date=index*2,
            execution_price_source='INDIVIDUAL_FILLS',filled_quantity=q,average_fill_price=p,
            executed_quote_amount=paid,total_fee=basefee,fee_currency=symbol if Decimal(basefee) else 'USD')
        store.apply_execution_fill(buy,buy_order)
        netq=Decimal(q)-Decimal(basefee)
        sell_order=dict(id=f's{index}',client_order_id=sell['intent_id'],created_date=index*2+1,
            execution_price_source='INDIVIDUAL_FILLS',filled_quantity=str(netq),average_fill_price=str(Decimal(received)/netq),
            executed_quote_amount=received,total_fee=fee,fee_currency='USD')
        store.apply_execution_fill(sell,sell_order)
        orders.extend([buy_order,sell_order]); intents.update({buy['intent_id']:buy,sell['intent_id']:sell})
        assert store.load()['risk']['NIGHT']['sessions']['2026-10-20']['complete'] is True
    state=store.load()
    assert not state['positions']
    assert sum(Decimal(r['net_pnl_usd']) for r in state['economic_ledger'])==pytest.approx(Decimal('-1.22'))
    assert all(r['fee_truth']=='KNOWN' for r in state['economic_ledger'])
    from revx_v5.ledger_repair import replay_flat_run
    state['economic_ledger'][4]['fee_truth']='UNKNOWN'
    state['economic_ledger'][4]['net_pnl_usd']=None
    state['risk']['NIGHT']['sessions']['2026-10-20']['complete']=False
    repaired,summary=replay_flat_run(state,intents,orders)
    assert summary['trades']==6 and Decimal(summary['realized_net_pnl_usd'])==pytest.approx(Decimal('-1.22'))
    assert repaired['risk']['NIGHT']['sessions']['2026-10-20']['complete'] is True
    assert repaired['intents']['b4']['fee_truth']=='KNOWN'
    assert state['risk']['NIGHT']['sessions']['2026-10-20']['complete'] is False


def test_unknown_fee_remains_unknown(tmp_path):
    store=DurableState(tmp_path)
    store.apply_execution_fill(intent('b','A-USD','BUY'),dict(filled_quantity=1,price=2))
    assert store.load()['positions']['A-USD']['entry_fee_truth']=='UNKNOWN'


def test_blocked_entry_is_visible_but_never_prevents_valid_exit():
    class BlockedSource(Source):
        async def next_entry(self,context):
            self.last_scan={'admission':'BLOCKED','reason':'risk_truth_unavailable'}
            return None
    action_source=BlockedSource()
    result=run(V5Runner(Supervisor(),Boundary(),action_source,live_authority()))
    assert result['status']=='BLOCKED' and result['reason']=='risk_truth_unavailable'
    action_source.exit_intent=Intent('sell','A-USD','SELL',{})
    result=run(V5Runner(Supervisor(),Boundary(),action_source,live_authority()))
    assert result['status']=='ACTION_SUBMITTED' and result['action']=='SELL'


def test_operator_band_and_usd_exposure_are_enforced():
    config=operator_config({})
    policy=operator_policy()
    assert policy.exposure_usd==200 and policy.session_loss_usd==20
    assert (policy.day_max_positions,policy.night_max_positions)==(40,20)
    for headroom in ('30','25','20'):
        q,meta=size_buy(Plan(requested_risk_usd=6),Rules(),headroom,config)
        assert Decimal(meta['notional_usd'])==Decimal(headroom)
    with pytest.raises(ValueError):size_buy(Plan(),Rules(),'19.99',config)
    assert not policy.allows('NIGHT',0,0,30.01,0)
    assert not policy.allows('NIGHT',0,0,20,-20)


def test_cancelled_partial_is_terminal_without_discarding_fill():
    result=order_fill_state(dict(status='partially_filled',reject_reason='cancelled',
        filled_quantity='1',quantity='3',leaves_quantity='2'))
    assert result['phase']=='TERMINAL_PARTIAL' and result['filled_quantity']==1


def test_unexecutable_urgent_exit_cannot_fall_through_to_buy():
    class UrgentSource(Source):
        async def next_exit(self,context):
            self.last_scan={'last_exit':{'status':'BLOCKED_URGENT_EXIT'}}
            return None
    action_source=UrgentSource(entry_intent=Intent('buy','B-USD','BUY',{}))
    result=run(V5Runner(Supervisor(),Boundary(),action_source,live_authority()))
    assert result['status']=='BLOCKED' and result['reason']=='urgent_exit_not_executable'
    assert action_source.entry_calls==0


def test_downtrend_real_reason_requires_fresh_confirmation_and_unprofitable_bid():
    from revx_v5.canonical_action_source import V5ExitPlanner
    class Delegate:
        async def build_sell_plan(self,*args,**kwargs): return SimpleNamespace(trigger_bid=101)
    planner=V5ExitPlanner(Delegate(),{},clock=lambda:100)
    position=dict(average_entry_price=100,fast_momentum_state='NEGATIVE',
                  fast_momentum_negative_confirmations=2,fast_momentum_last_observed_at=99)
    with pytest.raises(ValueError,match='recovered'):
        asyncio.run(planner.build_sell_plan('x',position,'CONFIRMED_DOWNTREND_UNPROFITABLE'))
    position['fast_momentum_last_observed_at']=1
    with pytest.raises(ValueError,match='fresh'):
        asyncio.run(planner.build_sell_plan('x',position,'CONFIRMED_DOWNTREND_UNPROFITABLE'))


@pytest.mark.skipif(os.name!='nt',reason='CMD launcher behavior')
@pytest.mark.parametrize('name',['Start-V5-r26','Stop-V5-r26'])
@pytest.mark.parametrize('exit_code',[0,7])
def test_cmd_closes_only_on_success(tmp_path,name,exit_code):
    root=Path(__file__).resolve().parents[3]
    source=root/'tools/v5-r26-desktop'/f'{name}.cmd'
    (tmp_path/f'{name}.cmd').write_bytes(source.read_bytes())
    (tmp_path/f'{name}.ps1').write_text(f'param([string]$V6Attestation)\nexit {exit_code}\n')
    result=subprocess.run(['cmd.exe','/d','/c',str(tmp_path/f'{name}.cmd')],
                          stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=15)
    assert result.returncode==exit_code
    assert ('Press any key' in result.stdout)==(exit_code!=0)


def test_ack_is_durable_before_failing_fill_get():
    from revx_v5.live_runtime import V5LiveBoundary
    events=[]
    class Store:
        def append_intent(self,row):events.append(dict(row))
    class Client:
        calls=0
        async def active_orders(self,*args):return []
        async def historical_orders(self,*args):return []
        async def submit_order(self,*args):
            self.calls+=1
            return {'id':'known-venue-id'}
        async def enrich_order(self,*args):raise TimeoutError('read-only fill lookup timed out')
    client=Client(); boundary=V5LiveBoundary(client,client,state_store=Store())
    async def prepared():return {'state':SimpleNamespace(ambiguous=False)}
    boundary.prepare_startup=prepared
    with pytest.raises(TimeoutError):
        asyncio.run(boundary.execute_intent(Intent('same-client-id','A-USD','BUY',{})))
    assert client.calls==1
    assert events[-1]['venue_order_id']=='known-venue-id' and events[-1]['status']=='SUBMITTED'
