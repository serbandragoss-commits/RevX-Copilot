import asyncio

from revx_v5.provider_adapter import MutationDisabledAdapter, RevXV5ProviderAdapter


class Client:
    async def balances(self, lane):
        return {"lane": lane}

    async def active_orders(self, symbol, lane):
        return {"symbol": symbol, "lane": lane}

    async def historical_orders(self, symbol, hours, lane):
        return {"symbol": symbol, "hours": hours, "lane": lane}

    async def submit_order(self, body, lane):
        return {"body": body, "lane": lane}

    async def pair_configurations(self, lane):
        return {"lane": lane}

    async def order_book(self, symbol, limit, lane):
        return {"symbol": symbol, "limit": limit, "lane": lane}

    async def tickers(self, lane):
        return {"lane": lane}

    async def candles(self, symbol, interval, hours):
        return {"symbol": symbol, "interval": interval, "hours": hours}


def test_provider_adapter_keeps_v5_lane_explicit():
    adapter = RevXV5ProviderAdapter(Client(), lane="EXIT_WATCH")
    assert asyncio.run(adapter.balances()) == {"lane": "EXIT_WATCH"}
    assert asyncio.run(adapter.active_orders("ABC"))["symbol"] == "ABC"
    assert asyncio.run(adapter.historical_orders("ABC", 6))["hours"] == 6
    assert asyncio.run(adapter.submit_order({"side": "BUY"}))["lane"] == "EXIT_WATCH"
    assert asyncio.run(adapter.pair_configurations())["lane"] == "EXIT_WATCH"
    assert asyncio.run(adapter.order_book("ABC", 10))["limit"] == 10
    assert asyncio.run(adapter.tickers())["lane"] == "EXIT_WATCH"
    assert asyncio.run(adapter.candles("ABC", 15, 27))["hours"] == 27


def test_mutation_adapter_is_absent_when_authority_is_off():
    try:
        asyncio.run(MutationDisabledAdapter().submit_order({"side": "BUY"}))
    except RuntimeError as exc:
        assert str(exc) == "V5 mutation client is not loaded"
    else:
        raise AssertionError("disabled mutation adapter accepted an order")
