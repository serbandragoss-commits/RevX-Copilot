import asyncio

from revx_v5.launch_coordinator import V5LaunchCoordinator
from revx_v5.state_store import DurableState


class Supervisor:
    async def prepare(self):
        return {"status": "PASS", "runtime_mode": "MANAGE_EXISTING_ONLY",
                "entry_enabled": False, "external_inventory_count": 5,
                "process_started": 0, "broker_mutated": 0}


class Reporter:
    def __init__(self, available=True):
        self._available = available
        self.messages = []

    def available(self):
        return self._available

    def send(self, message):
        self.messages.append(message)


def test_launch_coordinator_delivers_gate_and_never_starts_process():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\coordinator"
    store = DurableState(root)
    store.notifications_path.unlink(missing_ok=True)
    reporter = Reporter()
    result = asyncio.run(V5LaunchCoordinator(Supervisor(), store, reporter).prepare("gate-1"))
    assert result["launch_status"] == "GATE_PASS_RUNNER_REQUIRED"
    assert result["process_started"] == 0
    assert result["broker_mutated"] == 0
    assert "New BUY enabled: NO" in reporter.messages[0]
    store.notifications_path.unlink(missing_ok=True)


def test_launch_coordinator_blocks_when_telegram_is_unavailable():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\coordinator-offline"
    store = DurableState(root)
    store.notifications_path.unlink(missing_ok=True)
    result = asyncio.run(V5LaunchCoordinator(
        Supervisor(), store, Reporter(False)
    ).prepare("gate-2"))
    assert result["launch_status"] == "BLOCKED_TELEGRAM"
    assert store.pending_notifications()[0]["notification_id"] == "gate-2"
    store.notifications_path.unlink(missing_ok=True)
