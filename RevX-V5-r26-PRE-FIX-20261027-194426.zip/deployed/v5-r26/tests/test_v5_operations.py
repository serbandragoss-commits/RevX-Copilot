import shutil
from pathlib import Path

import pytest
import json

from revx_v5.policy import RiskPolicy
from revx_v5.state_store import DurableState
from revx_v5.telegram import TelegramReporter, TelegramUnavailable, load_dpapi_token
from revx_v5.notification_outbox import deliver_pending


def test_policy_separates_day_and_night_position_caps():
    p = RiskPolicy()
    assert p.max_positions("DAY") == 20
    assert p.max_positions("NIGHT") == 10
    assert p.allows("DAY", 19, 120, 20, 0)
    assert not p.allows("DAY", 20, 120, 20, 0)
    assert p.allows("NIGHT", 9, 120, 20, 0)
    assert not p.allows("NIGHT", 10, 120, 20, 0)
    assert not p.allows("DAY", 0, 140, 20, 0)
    assert not p.allows("DAY", 0, 0, 20, -10)


def _local_tmp():
    root = Path(r"C:\Users\serba\Documents\RevX\tmp\v5-tests")
    root.mkdir(parents=True, exist_ok=True)
    return root


def test_state_and_outbox_survive_reload():
    tmp_path = _local_tmp()
    try:
        store = DurableState(tmp_path)
        data = store.load()
        data["mode"] = "DAY"
        data["positions"] = {"ABC": {"quantity": "1"}}
        store.save(data)
        store.append_intent({"intent_id": "i-1", "symbol": "ABC", "side": "BUY"})
        reloaded = DurableState(tmp_path)
        assert reloaded.load()["positions"]["ABC"]["quantity"] == "1"
        assert reloaded.pending_intents()[0]["intent_id"] == "i-1"
    finally:
        for name in ("state.json", "outbox.jsonl", "notifications.jsonl", "token.dpapi"):
            (tmp_path / name).unlink(missing_ok=True)


def test_fill_adoption_uses_only_new_quantity_delta():
    tmp_path = _local_tmp()
    store = DurableState(tmp_path)
    store.state_path.unlink(missing_ok=True)
    intent = {"intent_id": "fill-1", "symbol": "ABC-USD", "side": "BUY",
              "metadata": {"stop": 9, "target": 12, "lane": "STANDARD",
                           "operating_mode": "DAY", "session_key": "2026-10-03"}}
    first = store.apply_execution_fill(intent, {"filled_quantity": "1",
                                                 "average_price": "10", "fee": "0"})
    second = store.apply_execution_fill(intent, {"filled_quantity": "1",
                                                  "average_price": "10", "fee": "0"})
    assert first["adopted_delta"] == "1"
    assert second["adopted_delta"] == "0"
    assert store.load()["positions"]["ABC-USD"]["quantity"] == "1"
    store.state_path.unlink(missing_ok=True)


def test_sell_fill_updates_net_session_pnl_and_mode_exposure():
    tmp_path = _local_tmp()
    store = DurableState(tmp_path)
    store.state_path.unlink(missing_ok=True)
    buy = {"intent_id": "buy-ledger", "symbol": "ABC-USD", "side": "BUY",
           "metadata": {"operating_mode": "DAY", "session_key": "2026-10-03",
                        "lane": "STANDARD"}}
    sell = {"intent_id": "sell-ledger", "symbol": "ABC-USD", "side": "SELL",
            "metadata": {}}
    store.apply_execution_fill(buy, {"filled_quantity": "2", "average_price": "10",
                                     "fee": "0.20", "fee_currency": "USD"})
    before = store.admission_snapshot("DAY", "2026-10-03")
    store.apply_execution_fill(sell, {"filled_quantity": "2", "average_price": "11",
                                      "fee": "0.22", "fee_currency": "USD"})
    after = store.admission_snapshot("DAY", "2026-10-03")
    assert before["open_positions"] == 1
    assert before["exposure_usd"] == "20"
    assert after["open_positions"] == 0
    assert float(after["exposure_usd"]) == 0
    assert after["session_loss_usd"] == "1.58"
    ledger = store.load()["economic_ledger"]
    assert ledger[-1]["gross_pnl_usd"] == "2"
    assert ledger[-1]["entry_fee_usd"] == "0.20"
    assert ledger[-1]["exit_fee_usd"] == "0.22"
    assert ledger[-1]["net_pnl_usd"] == "1.58"
    assert ledger[-1]["fill_provenance"] == "VENUE"
    store.state_path.unlink(missing_ok=True)


def test_missing_fee_reconciles_position_but_marks_economics_unknown():
    tmp_path = _local_tmp()
    store = DurableState(tmp_path)
    try:
        buy = {"intent_id": "buy-missing-fee", "symbol": "ABC-USD", "side": "BUY",
               "metadata": {"operating_mode": "DAY", "session_key": "2026-10-04",
                            "lane": "STANDARD"}}
        sell = {"intent_id": "sell-missing-fee", "symbol": "ABC-USD", "side": "SELL",
                "metadata": {}}
        store.apply_execution_fill(buy, {"filled_quantity": "2", "price": "10",
                                         "fee_currency": "ABC"})
        position = store.load()["positions"]["ABC-USD"]
        assert position["entry_fee_truth"] == "UNKNOWN"
        store.apply_execution_fill(sell, {"filled_quantity": "2", "price": "11",
                                          "fee_currency": "ABC"})
        state = store.load()
        assert state["positions"] == {}
        assert state["economic_ledger"][-1]["gross_pnl_usd"] == "2"
        assert state["economic_ledger"][-1]["net_pnl_usd"] is None
        assert state["economic_ledger"][-1]["fee_truth"] == "UNKNOWN"
        assert state["economic_ledger"][-1]["fill_provenance"] == "VENUE"
        assert state["risk"]["DAY"]["sessions"]["2026-10-04"]["complete"] is False
    finally:
        store.state_path.unlink(missing_ok=True)


def test_buy_fee_in_base_asset_tracks_net_received_quantity_and_cost_basis():
    store, root = _fresh_store("base-asset-fee")
    try:
        buy = _intent("buy-honey", "HONEY-USD", "BUY")
        first = store.apply_execution_fill(
            buy, {"filled_quantity": "50", "average_fill_price": "10",
                  "total_fee": "0.5", "fee_currency": "HONEY"}
        )
        second = store.apply_execution_fill(
            buy, {"filled_quantity": "100", "average_fill_price": "10",
                  "total_fee": "1", "fee_currency": "HONEY"}
        )
        repeated = store.apply_execution_fill(
            buy, {"filled_quantity": "100", "average_fill_price": "10",
                  "total_fee": "1", "fee_currency": "HONEY"}
        )
        position = store.load()["positions"]["HONEY-USD"]
        assert first["adopted_delta"] == "50"
        assert second["adopted_delta"] == "50"
        assert repeated["adopted_delta"] == "0"
        assert position["quantity"] == "99.0"
        assert position["gross_filled_quantity"] == "100"
        assert position["entry_base_fee_quantity"] == "1.0"
        assert position["entry_base_fee_currency"] == "HONEY"
        assert position["average_entry_price"] == "10.10101010101010101010101010"
        assert position["entry_fee_truth"] == "KNOWN"
        assert position['entry_base_fee_in_cost_basis'] is True
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_positive_fee_without_currency_fails_closed():
    store, root = _fresh_store("ambiguous-fee-currency")
    try:
        with pytest.raises(ValueError, match="fee requires currency"):
            store.apply_execution_fill(_intent("buy-ambiguous", "ABC-USD", "BUY"),
                                       {"filled_quantity": "1", "price": "10", "fee": "0.1"})
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_late_base_fee_correction_reconciles_legacy_gross_position():
    store, root = _fresh_store("late-base-fee-correction")
    try:
        intent = _intent("buy-honey-legacy", "HONEY-USD", "BUY")
        store.apply_execution_fill(intent, {"filled_quantity": "6250", "price": "0.0032"})
        corrected = store.apply_execution_fill(
            intent, {"filled_quantity": "6250", "price": "0.0032",
                     "total_fee": "5.625", "fee_currency": "HONEY"}
        )
        position = store.load()["positions"]["HONEY-USD"]
        assert corrected["adopted_delta"] == "0"
        assert position["quantity"] == "6244.375"
        assert position["gross_filled_quantity"] == "6250"
        assert position["entry_base_fee_quantity"] == "5.625"
        assert position["entry_fee_truth"] == "KNOWN"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _fresh_store(name):
    root = _local_tmp() / name
    shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True, exist_ok=True)
    return DurableState(root), root


def _intent(intent_id, symbol, side):
    return {"intent_id": intent_id, "symbol": symbol, "side": side,
            "metadata": {"operating_mode": "DAY", "session_key": "2026-10-04",
                         "lane": "STANDARD"}}


def test_later_known_trade_does_not_complete_session_with_prior_unknown_fee():
    store, root = _fresh_store("risk-incomplete-sticky")
    try:
        store.apply_execution_fill(_intent("buy-a", "AAA-USD", "BUY"),
                                   {"filled_quantity": "1", "price": "10", "fee": "0.1", "fee_currency": "USD"})
        store.apply_execution_fill(_intent("sell-a", "AAA-USD", "SELL"),
                                   {"filled_quantity": "1", "price": "11",
                                    "fee_currency": "AAA"})
        store.apply_execution_fill(_intent("buy-b", "BBB-USD", "BUY"),
                                   {"filled_quantity": "1", "price": "10", "fee": "0.1", "fee_currency": "USD"})
        store.apply_execution_fill(_intent("sell-b", "BBB-USD", "SELL"),
                                   {"filled_quantity": "1", "price": "11", "fee": "0.1", "fee_currency": "USD"})
        risk = store.load()["risk"]["DAY"]["sessions"]["2026-10-04"]
        assert risk["complete"] is False
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_same_fill_late_fee_correction_updates_ledger_and_risk():
    store, root = _fresh_store("same-fill-fee-correction")
    try:
        store.apply_execution_fill(_intent("buy-c", "CCC-USD", "BUY"),
                                   {"filled_quantity": "2", "price": "10", "fee": "0.20", "fee_currency": "USD"})
        sell = _intent("sell-c", "CCC-USD", "SELL")
        store.apply_execution_fill(sell, {"filled_quantity": "2", "price": "11",
                                          "fee_currency": "CCC"})
        correction = store.apply_execution_fill(
            sell, {"filled_quantity": "2", "price": "11", "fee": "0.22",
                   "fee_currency": "USD"}
        )
        state = store.load()
        row = state["economic_ledger"][-1]
        assert correction["economic_correction"] is True
        assert row["fee_truth"] == "KNOWN"
        assert row["net_pnl_usd"] == "1.58"
        assert state["risk"]["DAY"]["sessions"]["2026-10-04"]["complete"] is True
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_partial_unknown_then_known_cumulative_fee_is_not_double_allocated():
    store, root = _fresh_store("partial-cumulative-fee")
    try:
        store.apply_execution_fill(_intent("buy-d", "DDD-USD", "BUY"),
                                   {"filled_quantity": "2", "price": "10", "fee": "0.20", "fee_currency": "USD"})
        sell = _intent("sell-d", "DDD-USD", "SELL")
        store.apply_execution_fill(sell, {"filled_quantity": "1", "price": "11",
                                          "fee_currency": "DDD"})
        store.apply_execution_fill(sell, {"filled_quantity": "2", "price": "11",
                                          "fee": "0.22", "fee_currency": "USD"})
        state = store.load()
        rows = [row for row in state["economic_ledger"]
                if row["sell_intent_id"] == "sell-d"]
        assert len(rows) == 1
        assert rows[0]["quantity"] == "2"
        assert rows[0]["exit_fee_usd"] == "0.22"
        assert float(rows[0]["net_pnl_usd"]) == 1.58
        assert state["risk"]["DAY"]["sessions"]["2026-10-04"]["complete"] is True
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_telegram_fails_closed_until_credential_exists():
    tmp_path = _local_tmp()
    try:
        reporter = TelegramReporter(tmp_path / "missing.dpapi", "chat", sender=lambda *_: None)
        assert reporter.available() is False
        with pytest.raises(TelegramUnavailable):
            reporter.send("health")
    finally:
        (tmp_path / "token.dpapi").unlink(missing_ok=True)


def test_telegram_uses_loader_without_exposing_token():
    tmp_path = _local_tmp()
    try:
        token = tmp_path / "token.dpapi"
        token.write_text("cipher", encoding="utf-8")
        seen = []
        reporter = TelegramReporter(token, "chat", sender=lambda t, c, m: seen.append((t, c, m)),
                                    token_loader=lambda _: "decrypted")
        reporter.send("PASS")
        assert seen == [("decrypted", "chat", "PASS")]
    finally:
        (tmp_path / "token.dpapi").unlink(missing_ok=True)


def test_dpapi_loader_accepts_powershell_utf8_bom(monkeypatch):
    tmp_path = _local_tmp()
    token = tmp_path / "token.dpapi"
    token.write_text("00", encoding="utf-8-sig")
    seen = {}

    def fake_unprotect(incoming, description, entropy, reserved, prompt, flags, output):
        seen["called"] = True
        return 0

    monkeypatch.setattr("revx_v5.telegram.ctypes.windll.crypt32.CryptUnprotectData",
                        fake_unprotect)
    try:
        load_dpapi_token(token)
    except OSError:
        pass
    assert seen["called"] is True
    token.unlink(missing_ok=True)


def test_notification_outbox_deduplicates_and_retries():
    tmp_path = _local_tmp()
    try:
        store = DurableState(tmp_path)
        store.notifications_path.unlink(missing_ok=True)
        store.append_notification({"notification_id": "n-1", "message": "PASS"})
        store.append_notification({"notification_id": "n-1", "message": "duplicate"})
        calls = []
        result = deliver_pending(store, lambda message: calls.append(message))
        assert result == {"sent": 1, "failed": 0, "deferred": 0}
        assert calls == ["PASS"]
        assert store.pending_notifications() == []
    finally:
        for name in ("notifications.jsonl",):
            (tmp_path / name).unlink(missing_ok=True)


def test_notification_retry_preserves_message_after_status_record():
    tmp_path = _local_tmp()
    try:
        store = DurableState(tmp_path)
        store.notifications_path.unlink(missing_ok=True)
        store.append_notification({"notification_id": "n-retry", "message": "RETRY ME"})
        first = deliver_pending(store, lambda _: (_ for _ in ()).throw(RuntimeError("offline")))
        seen = []
        second = deliver_pending(store, seen.append)
        assert first["failed"] == 1
        assert second["sent"] == 1
        assert seen == ["RETRY ME"]
    finally:
        store.notifications_path.unlink(missing_ok=True)


def test_r25_decision_journal_is_bounded_atomic_and_reloadable():
    root = _local_tmp() / "r25-journal"
    store = DurableState(root)
    store.decision_journal_path.unlink(missing_ok=True)
    for index in range(40):
        store.append_decision_snapshot({
            "observed_at": float(index + 1),
            "event": "DISCOVERY_SELECTION",
            "selected": [{"symbol": f"A{index}-USD", "slot": "COMPOSITE"}],
        }, limit=16)
    rows = [json.loads(line) for line in store.decision_journal_path.read_text(
        encoding="utf-8"
    ).splitlines()]
    assert len(rows) == 16
    assert rows[0]["observed_at"] == 25.0
    assert rows[-1]["observed_at"] == 40.0
    assert DurableState(root).decision_journal_path.read_text(encoding="utf-8")
    store.decision_journal_path.unlink(missing_ok=True)


def test_r25_momentum_and_exploration_state_survive_reload():
    root = _local_tmp() / "r25-continuity"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    store.record_market_tape({"ABC-USD": [[float(i), 1.0 + i / 100]
                                            for i in range(80)]})
    store.record_deep_validation("ABC", 123.0)
    reloaded = DurableState(root)
    assert len(reloaded.market_tape()["ABC-USD"]) == 64
    assert reloaded.deep_validation_times()["ABC"] == 123.0
    store.state_path.unlink(missing_ok=True)
