import asyncio

from revx_v5.supervisor import V5Supervisor


class Boundary:
    def __init__(self, recovered=None, positions=0):
        self.recovered = recovered or []
        self.positions = positions

    async def recover_pending(self):
        return self.recovered

    async def prepare_startup(self):
        mode = "MANAGE_EXISTING_ONLY" if self.positions else "NORMAL"
        state = type("State", (), {"active_orders": (), "ambiguous": False})()
        return {"runtime_mode": mode, "entry_enabled": not self.positions,
                "inventory": {"count": self.positions, "reconciled": True,
                              "records": [{"symbol": f"X{i}-USD"}
                                          for i in range(self.positions)]},
                "state": state}


def test_supervisor_blocks_unresolved_intent_before_startup():
    result = asyncio.run(V5Supervisor(
        Boundary([{"intent_id": "i-1", "status": "UNCONFIRMED"}])
    ).prepare())
    assert result["status"] == "BLOCKED"
    assert result["runtime_mode"] == "UNKNOWN"
    assert result["entry_enabled"] is False


def test_supervisor_reports_active_and_ambiguous_recovery_counts():
    result = asyncio.run(V5Supervisor(
        Boundary([{"intent_id": "i-active", "status": "ACTIVE"},
                  {"intent_id": "i-unknown", "status": "UNCONFIRMED"}])
    ).prepare())
    assert result["active_orders"] == 1
    assert result["ambiguous_orders"] == 1


def test_known_active_intent_does_not_globally_block_startup():
    result = asyncio.run(V5Supervisor(
        Boundary([{"intent_id": "i-active", "status": "ACTIVE",
                   "order": {"symbol": "NEAR/USD"}}])
    ).prepare())
    assert result["status"] == "PASS"
    assert result["runtime_mode"] == "NORMAL"
    assert result["entry_enabled"] is True
    assert result["pending_intent_symbols"] == ["NEAR-USD"]


def test_supervisor_prepares_manage_existing_mode():
    result = asyncio.run(V5Supervisor(Boundary(positions=2)).prepare())
    assert result["status"] == "PASS"
    assert result["runtime_mode"] == "MANAGE_EXISTING_ONLY"
    assert result["entry_enabled"] is False


def test_supervisor_includes_external_inventory_in_admission_exposure_and_conflict_set():
    class Store:
        def admission_snapshot(self, mode, session_key):
            assert (mode, session_key) == ("DAY", "day-1")
            return {"open_positions": 1, "exposure_usd": "2",
                    "session_loss_usd": "0"}

    class AccountWideBoundary:
        state_store = Store()

        async def recover_pending(self):
            return []

        async def prepare_startup(self):
            state = type("State", (), {"active_orders": (), "ambiguous": False})()
            return {
                "runtime_mode": "NORMAL", "entry_enabled": True, "state": state,
                "owned_positions": [{"symbol": "OWN-USD"}],
                "inventory": {"count": 1, "reconciled": True, "records": [{
                    "symbol": "EXT-USD", "quantity": "4", "mark_price": "3",
                }]},
            }

    window = type("Window", (), {"mode": "DAY", "session_key": "day-1", "entry_open": True})()
    clock = type("Clock", (), {"current": lambda self: window})()
    result = asyncio.run(V5Supervisor(AccountWideBoundary(), mode_clock=clock).prepare())
    assert result["managed_symbols"] == ["EXT-USD", "OWN-USD"]
    assert result["external_position_count"] == 1
    assert result["external_exposure_usd"] == "12"
    assert result["open_positions"] == 2
    assert result["exposure_usd"] == "14"
