import asyncio
from decimal import Decimal

from revx_v5.execution_truth import net_pnl, summarize_fills, order_fill_state
from revx_v5.recovery import resolve_intent


def test_fill_summary_accounts_for_partial_fill_fees_and_slippage():
    entry = summarize_fills([
        {"filled_quantity": "2", "average_price": "10", "fee": "0.20"},
    ])
    exit = summarize_fills([
        {"filled_quantity": "1", "average_price": "11", "fee": "0.11"},
        {"filled_quantity": "1", "average_price": "11", "fee": "0.11"},
    ], expected_price="11.10")
    assert entry.quantity == Decimal("2")
    assert exit.quantity == Decimal("2")
    assert exit.slippage_value == Decimal("-0.20")
    assert net_pnl(entry, exit) == Decimal("1.98")


def test_provider_fill_aliases_are_supported_and_non_usd_fee_fails_closed():
    summary = summarize_fills([{
        "filled_quantity": "2", "average_fill_price": "10",
        "total_fee": "0.20", "fee_currency": "USD",
        "filled_amount": "20",
    }])
    assert summary.gross_value == Decimal("20")
    converted = summarize_fills([{
        "filled_quantity": "1", "average_fill_price": "10",
        "total_fee": "0.1", "fee_currency": "X:8:ENA", "fee_usd": "0.12",
    }])
    assert converted.fees == Decimal("0.12")
    marked = summarize_fills([{
        "filled_quantity": "1", "average_fill_price": "10",
        "total_fee": "0.1", "fee_currency": "X:8:ENA", "fee_price_usd": "1.25",
    }])
    assert marked.fees == Decimal("0.125")
    try:
        summarize_fills([{"filled_quantity": "1", "average_fill_price": "10",
                          "total_fee": "0.1", "fee_currency": "X:8:ENA"}])
    except ValueError as exc:
        assert "fee truth" in str(exc)
    else:
        raise AssertionError("non-USD fee was not blocked")


def test_partial_order_is_not_treated_as_filled():
    partial = order_fill_state({"id": "v-1", "status": "partially_filled",
                                "quantity": "10", "filled_quantity": "4",
                                "leaves_quantity": "6"})
    complete = order_fill_state({"id": "v-2", "status": "filled",
                                 "quantity": "10", "filled_quantity": "10"})
    assert partial["phase"] == "PARTIAL"
    assert complete["phase"] == "FILLED"


class RecoveryClient:
    def __init__(self, rows):
        self.rows = rows

    async def active_orders(self, symbol=None, lane=None):
        return self.rows

    async def historical_orders(self, symbol=None, hours=24, lane=None):
        return []


class VenueRecoveryClient(RecoveryClient):
    async def order(self, venue_order_id, lane=None):
        return {"id": venue_order_id, "status": "filled",
                "filled_quantity": "1", "quantity": "1"}


def test_recovery_confirms_and_never_retries_unknown():
    confirmed = asyncio.run(resolve_intent(
        RecoveryClient([{"client_order_id": "i-1", "id": "v-1"}]), "i-1"))
    unknown = asyncio.run(resolve_intent(RecoveryClient([]), "i-2"))
    assert confirmed["status"] == "CONFIRMED"
    assert unknown["status"] == "UNCONFIRMED"


def test_recovery_prefers_authoritative_venue_order_id():
    result = asyncio.run(resolve_intent(
        VenueRecoveryClient([]), "client-id", "venue-id"))
    assert result["status"] == "CONFIRMED"
    assert result["resolution"] == "VENUE_ORDER_ID"
    assert result["order"]["id"] == "venue-id"
