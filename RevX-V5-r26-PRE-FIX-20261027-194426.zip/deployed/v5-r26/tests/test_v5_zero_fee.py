import copy
from decimal import Decimal
import pytest
from revx_v5.execution_truth import fee_in_usd, summarize_fills
from revx_v5.execution_metrics import observation
from revx_v5.state_store import DurableState


@pytest.mark.parametrize('currency',['USD','INJ','BTC','UNKNOWN'])
def test_reported_zero_fee_is_zero_in_any_currency(currency):
    order={'total_fee':'0','fee_currency':currency,'fee':None}
    assert fee_in_usd(order)==0
    assert summarize_fills([{**order,'filled_quantity':'1','average_price':'9'}]).fees==0
    metric=observation({},dict(intent_id='s',symbol='INJ-USD',side='SELL'),
        {**order,'filled_quantity':'1','average_price':'9'},'RECOVERY_OBSERVED',1)
    assert metric['fee_usd']==0


def test_missing_fee_and_positive_unconverted_fee_stay_unknown():
    assert fee_in_usd({'fee_currency':'INJ'}) is None
    assert fee_in_usd({'total_fee':'.1','fee_currency':'INJ'}) is None
    assert fee_in_usd({'total_fee':'.1','fee_currency':'INJ','fee_price_usd':'10'})==1
    with pytest.raises(ValueError):fee_in_usd({'total_fee':'-1','fee_currency':'INJ'})


def memory():
    data={};store=object.__new__(DurableState);store.load=lambda:copy.deepcopy(data)
    def save(value):
        data.clear();data.update(copy.deepcopy(value))
    store.save=save
    return store,data


@pytest.mark.parametrize('currency',['USD','INJ','BTC'])
def test_zero_sell_fee_keeps_ledger_and_risk_complete(currency):
    store,data=memory()
    buy=dict(intent_id='b',symbol='INJ-USD',side='BUY',metadata=dict(operating_mode='NIGHT',session_key='test'))
    sell={**buy,'intent_id':'s','side':'SELL'}
    store.apply_execution_fill(buy,dict(filled_quantity='1',average_price='10',total_fee='0',fee_currency='USD'))
    order=dict(filled_quantity='1',average_price='9',total_fee='0',fee_currency=currency)
    store.apply_execution_fill(sell,order)
    row=data['economic_ledger'][0]
    assert row['exit_fee_usd']=='0' and row['fee_truth']=='KNOWN'
    assert Decimal(row['net_pnl_usd'])==-1
    assert data['risk']['NIGHT']['sessions']['test']['complete'] is True
    assert store.apply_execution_fill(sell,order)['adopted_delta']=='0'


def test_late_zero_fee_repairs_closed_sell_without_touching_quantity():
    store,data=memory()
    buy=dict(intent_id='b',symbol='INJ-USD',side='BUY',metadata=dict(operating_mode='NIGHT',session_key='test'))
    sell={**buy,'intent_id':'s','side':'SELL'}
    store.apply_execution_fill(buy,dict(filled_quantity='1',average_price='10',total_fee='0',fee_currency='USD'))
    order=dict(filled_quantity='1',average_price='9',fee_currency='INJ')
    store.apply_execution_fill(sell,order)
    assert data['risk']['NIGHT']['sessions']['test']['complete'] is False
    correction=store.apply_execution_fill(sell,{**order,'total_fee':'0'})
    assert correction['economic_correction'] is True and correction['adopted_delta']=='0'
    assert data['positions']=={} and data['economic_ledger'][0]['quantity']=='1'
    assert data['risk']['NIGHT']['sessions']['test']['complete'] is True
