from decimal import Decimal

from revx_v5.external_inventory import book_levels, executable_bid_value


def test_level_parsing_and_full_depth_liquidation_value():
    book = {"bids": [{"price": "10", "quantity": "1"}, ["9", "2"]]}
    parsed = book_levels(book, "bids")
    proceeds, covered = executable_bid_value(Decimal("2"), parsed)
    assert proceeds == Decimal("19")
    assert covered is True


def test_missing_level_quantity_keeps_depth_unknown():
    proceeds, covered = executable_bid_value(
        Decimal("1"), book_levels({"bids": [{"price": "10"}]}, "bids")
    )
    assert proceeds is None
    assert covered is False
