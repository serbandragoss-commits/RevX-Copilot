import pytest

from revx_v5.launch_gate import LaunchBlocked, validate_launch


def report(**updates):
    value = {"status": "PASS", "active_orders": 0,
             "ambiguous_orders": 0, "positions_nonzero": 0, "recovery_status": "PASS", "live_contract_status": "PASS"}
    value.update(updates)
    return value


def test_launch_gate_requires_ack_and_rollback():
    with pytest.raises(LaunchBlocked, match="operator_ack_missing"):
        validate_launch(report(), operator_ack=False, rollback_ready=True)
    assert validate_launch(report(), operator_ack=True, rollback_ready=True)["status"] == "READY_TO_LAUNCH"


def test_launch_gate_refuses_nonpass_preflight():
    with pytest.raises(LaunchBlocked, match="preflight_not_pass"):
        validate_launch(report(status="BLOCKED"), operator_ack=True,
                        rollback_ready=True)


def test_launch_gate_refuses_missing_rollback():
    with pytest.raises(LaunchBlocked, match="rollback_not_ready"):
        validate_launch(report(), operator_ack=True, rollback_ready=False)


def test_launch_gate_refuses_unknown_external_inventory():
    with pytest.raises(LaunchBlocked, match="external_inventory_unknown"):
        validate_launch(report(positions_nonzero=1), operator_ack=True, rollback_ready=True)


def test_launch_gate_allows_reconciled_inventory_with_unrelated_entries():
    result = validate_launch(report(positions_nonzero=2,
                                    external_inventory_count=2,
                                    external_inventory_reconciled=True),
                             operator_ack=True, rollback_ready=True)
    assert result["runtime_mode"] == "NORMAL"
    assert result["entry_enabled"] == 1


def test_launch_gate_refuses_external_inventory_count_mismatch():
    with pytest.raises(LaunchBlocked, match="external_inventory_count_mismatch"):
        validate_launch(report(positions_nonzero=2,
                               external_inventory_count=1,
                               external_inventory_reconciled=True),
                        operator_ack=True, rollback_ready=True)

