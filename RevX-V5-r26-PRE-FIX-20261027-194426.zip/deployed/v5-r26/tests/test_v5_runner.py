import asyncio

from revx_v5.execution_adapter import Intent
from revx_v5.runner import (
    LIVE_ACKNOWLEDGEMENT,
    NullActionSource,
    RuntimeAuthority,
    V5Runner,
)


class Supervisor:
    def __init__(self, mode="NORMAL", status="PASS", symbols=None, owned=None):
        self.mode = mode
        self.status = status
        self.symbols = symbols or []
        self.owned = owned or []

    async def prepare(self):
        return {
            "status": self.status,
            "reason": "unresolved" if self.status != "PASS" else None,
            "runtime_mode": self.mode,
            "entry_enabled": self.mode == "NORMAL",
            "external_inventory_symbols": self.symbols,
            "owned_symbols": self.owned,
        }


class Boundary:
    def __init__(self):
        self.intents = []

    async def execute_intent(self, intent):
        self.intents.append(intent)
        return {"id": "venue-1"}


class CancelRaceBoundary(Boundary):
    async def cancel_stale_entry_orders(self):
        return [{"outcome": "RACE_RECONCILIATION_REQUIRED"}]


class Source:
    def __init__(self, exit_intent=None, entry_intent=None):
        self.exit_intent = exit_intent
        self.entry_intent = entry_intent
        self.entry_calls = 0

    async def next_exit(self, _context):
        return self.exit_intent

    async def next_entry(self, _context):
        self.entry_calls += 1
        return self.entry_intent


def run(runner):
    return asyncio.run(runner.cycle())


def live_authority():
    return RuntimeAuthority(True, "ON", LIVE_ACKNOWLEDGEMENT)


def test_null_source_reports_healthy_silence_without_mutation():
    boundary = Boundary()
    result = run(V5Runner(Supervisor(), boundary, NullActionSource()))
    assert result["status"] == "HEALTHY_SILENCE"
    assert result["broker_mutated"] == 0
    assert boundary.intents == []


def test_cancel_race_blocks_new_entry_until_reconciliation():
    source = Source(entry_intent=Intent("buy-race", "DOGE-USD", "BUY", {}))
    result = run(V5Runner(Supervisor(), CancelRaceBoundary(), source, live_authority()))
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "stale_entry_cancel_race_reconciliation_pending"
    assert source.entry_calls == 0


def test_runner_preserves_operational_truth_for_health_monitoring():
    prepared = {
        "runtime_mode": "NORMAL", "entry_enabled": True,
        "operating_mode": "DAY", "session_key": "2026-10-03",
        "open_positions": 2, "owned_position_count": 2,
        "exposure_usd": "39.50", "session_loss_usd": "-1.25",
        "active_orders": 0, "ambiguous_orders": 0,
        "external_inventory_count": 0,
    }
    result = V5Runner._result("HEALTHY_SILENCE", prepared)
    assert result["operating_mode"] == "DAY"
    assert result["open_positions"] == 2
    assert result["exposure_usd"] == "39.50"
    assert result["session_loss_usd"] == "-1.25"


def test_external_inventory_does_not_disable_entry_source():
    source = Source(entry_intent=Intent("buy-1", "DOGE-USD", "BUY", {}))
    result = run(V5Runner(Supervisor("NORMAL", symbols=["AIOZ-USD"]),
                          Boundary(), source, live_authority()))
    assert result["status"] == "ACTION_SUBMITTED"
    assert source.entry_calls == 1


def test_external_inventory_buy_is_not_blocked_by_inventory_presence():
    source = Source(entry_intent=Intent("buy-1", "AIOZ-USD", "BUY", {}))
    boundary = Boundary()
    result = run(V5Runner(Supervisor("NORMAL", symbols=["AIOZ-USD"]),
                          boundary, source, live_authority()))
    assert result["status"] == "ACTION_SUBMITTED"
    assert [row.intent_id for row in boundary.intents] == ["buy-1"]


def test_external_inventory_sell_is_not_blocked_by_inventory_presence():
    source = Source(exit_intent=Intent("sell-1", "DOGE-USD", "SELL", {}))
    result = run(V5Runner(Supervisor("MANAGE_EXISTING_ONLY", symbols=["AIOZ-USD"]),
                          Boundary(), source, live_authority()))
    assert result["status"] == "ACTION_SUBMITTED"


def test_external_inventory_sell_can_be_submitted():
    source = Source(exit_intent=Intent("sell-external", "AIOZ-USD", "SELL", {}))
    boundary = Boundary()
    result = run(V5Runner(
        Supervisor("MANAGE_EXISTING_ONLY", symbols=["AIOZ-USD"]),
        boundary, source, live_authority()
    ))
    assert result["status"] == "ACTION_SUBMITTED"
    assert [row.intent_id for row in boundary.intents] == ["sell-external"]


def test_manage_existing_still_allows_v5_owned_exit():
    boundary = Boundary()
    source = Source(exit_intent=Intent("sell-owned", "DOGE-USD", "SELL", {}))
    result = run(V5Runner(
        Supervisor("MANAGE_EXISTING_ONLY", symbols=["AIOZ-USD"], owned=["DOGE-USD"]),
        boundary, source, live_authority()
    ))
    assert result["status"] == "ACTION_SUBMITTED"
    assert [row.intent_id for row in boundary.intents] == ["sell-owned"]


def test_authority_off_returns_action_ready_without_mutation():
    boundary = Boundary()
    source = Source(exit_intent=Intent("sell-2", "AIOZ-USD", "SELL", {}))
    result = run(V5Runner(Supervisor("MANAGE_EXISTING_ONLY", symbols=["AIOZ-USD"]),
                          boundary, source))
    assert result["status"] == "ACTION_READY"
    assert result["reason"] == "mutation_authority_off"
    assert result["broker_mutated"] == 0
    assert boundary.intents == []


def test_exact_three_part_authority_required():
    intent = Intent("buy-2", "DOGE-USD", "BUY", {})
    for authority in (
        RuntimeAuthority(True, "OFF", LIVE_ACKNOWLEDGEMENT),
        RuntimeAuthority(True, "ON", "wrong"),
        RuntimeAuthority(False, "ON", LIVE_ACKNOWLEDGEMENT),
    ):
        boundary = Boundary()
        result = run(V5Runner(Supervisor(), boundary,
                              Source(entry_intent=intent), authority))
        assert result["status"] == "ACTION_READY"
        assert boundary.intents == []


def test_live_authority_submits_at_most_one_exit_before_entry():
    boundary = Boundary()
    source = Source(
        exit_intent=Intent("sell-3", "ABC-USD", "SELL", {}),
        entry_intent=Intent("buy-3", "DOGE-USD", "BUY", {}),
    )
    result = run(V5Runner(Supervisor(), boundary, source, live_authority()))
    assert result["status"] == "ACTION_SUBMITTED"
    assert result["actions_executed"] == 1
    assert [x.intent_id for x in boundary.intents] == ["sell-3"]
    assert source.entry_calls == 0


def test_blocked_supervisor_and_kill_switch_fail_closed():
    blocked = run(V5Runner(Supervisor(status="BLOCKED"), Boundary(), NullActionSource()))
    killed = run(V5Runner(Supervisor(), Boundary(), NullActionSource(),
                          kill_switch=lambda: True))
    assert blocked["status"] == "BLOCKED"
    assert killed["status"] == "PAUSED"


def test_invalid_source_side_is_blocked():
    bad_exit = run(V5Runner(Supervisor(), Boundary(),
                            Source(exit_intent=Intent("x", "ABC", "BUY", {})),
                            live_authority()))
    bad_entry = run(V5Runner(Supervisor(), Boundary(),
                             Source(entry_intent=Intent("y", "ABC", "SELL", {})),
                             live_authority()))
    assert bad_exit["reason"] == "exit_source_returned_non_sell"
    assert bad_entry["reason"] == "entry_source_returned_non_buy"


def test_component_exception_is_reported_without_mutation():
    class BrokenSource(Source):
        async def next_exit(self, _context):
            raise ValueError("do not leak details")

    boundary = Boundary()
    result = run(V5Runner(Supervisor(), boundary, BrokenSource(), live_authority()))
    assert result["status"] == "FAILED"
    assert result["reason"] == "exit_source_exception"
    assert result["error_type"] == "ValueError"
    assert result["error_detail"] == "do not leak details"
    assert boundary.intents == []


def test_transient_exit_transport_is_degraded_and_retryable():
    class BrokenSource(Source):
        async def next_exit(self, _context):
            raise RuntimeError("transport error /api/1.0/public/tickers: timed out")

    boundary = Boundary()
    observed = run(V5Runner(Supervisor(), boundary, BrokenSource(), live_authority()))
    assert observed["status"] == "DEGRADED"
    assert observed["reason"] == "exit_source_transport_degraded"
    assert observed["error_type"] == "RuntimeError"
    assert boundary.intents == []
