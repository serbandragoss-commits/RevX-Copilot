import asyncio
from decimal import Decimal
from types import SimpleNamespace
import pytest
from revx_v5.allocation import allocate_targets
from revx_v5.execution_adapter import Intent
from revx_v5.execution_metrics import observation,markouts
from test_v5_canonical_action_source import source,Planner,Plan,Candidate,Policy,Quote
from test_v5_restart_inventory import setup_restart,Venue


def alternative(symbol,target):
    return Intent(symbol,symbol,'BUY',{},dict(quantity=100,entry=2,target=target,
        sizing=dict(estimated_stop_loss_with_costs_usd='1',entry_cost_allowance_usd='.01',
                    cost_assumptions_pct=dict(fee_each_side='.09',exit_slippage='.05'))))


def test_allocation_sums_to_budget_and_scores_net_scenarios():
    result=allocate_targets([alternative('A',2.3),alternative('B',2.5)],'130')
    assert abs(sum(Decimal(x['allocation_usd']) for x in result.values())-130)<Decimal('1e-20')
    assert Decimal(result['B']['allocation_usd'])>Decimal(result['A']['allocation_usd'])
    assert Decimal(allocate_targets([alternative('C',1.9)],'130')['C']['allocation_usd'])==0


def test_execution_metrics_are_observations_not_fills_or_fees_invented():
    intent=dict(intent_id='i',symbol='A-USD',side='BUY',metadata=dict(decision_at=99,decision_mid=2))
    first=observation({},intent,{},'SUBMIT_REQUESTED',100)
    assert 'first_fill_observed_at' not in first
    filled=observation(first,intent,dict(filled_quantity='3',average_fill_price='2.01',total_fee='0',fee_currency='USD'),'RECOVERY_OBSERVED',103)
    assert filled['fill_observation_latency_sec']==3
    assert filled['shortfall_vs_decision_mid_bps']==pytest.approx(50)
    assert filled['fee_usd']==0
    refreshed=observation(filled,intent,dict(filled_quantity='3'),'RECOVERY_OBSERVED',104)
    assert refreshed['fee_usd']==0 and refreshed['average_fill_price']==2.01
    rows={'i':refreshed}
    assert not markouts(rows,{'A-USD':2.02},162)
    assert markouts(rows,{'A-USD':2.02},163)
    assert rows['i']['markout_60s']['status']=='OBSERVED'
    assert markouts(rows,{'A-USD':2.03},600)
    assert rows['i']['markout_300s']['status']=='MISSED_WINDOW'
    assert rows['i']['markout_300s']['signed_bps'] is None


def test_target_exit_uses_saved_target_and_native_planner(tmp_path):
    store,venue,boundary,supervisor,item=setup_restart(tmp_path,venue=Venue(bid=.402))
    item.target_exits=True
    context=asyncio.run(supervisor.prepare())
    intent=asyncio.run(item.next_exit(context))
    assert intent is not None and intent.side=='SELL'
    assert intent.metadata['reason']=='TARGET_HIT'
    assert Decimal(intent.body['order_configuration']['limit']['base_size'])==Decimal('52.20569')
    assert venue.mutations==0


def test_allocation_replans_chosen_candidate_and_body_matches_final_budget():
    class MultiPlanner(Planner):
        config={}
        async def build_buy_plan(self,signal_id,symbol,lane,fraction,momentum):
            self.calls.append(symbol)
            return Plan(symbol=symbol,client_order_id=symbol,quantity=100,limit_price=2,
                        stop=1.9,target=2.5 if symbol=='B-USD' else 2.3)
        async def pair_rules(self,symbol):
            return SimpleNamespace(base_step='.01',min_order_size='.01',min_order_size_quote='1',max_order_size='1000')
    planner=MultiPlanner()
    item=source(planner)
    item.order_cap_usd=None
    item.allocation_mode=True
    class Client:
        async def tickers(self,lane):
            return [dict(symbol=s,bid=1.99,ask=2.01) for s in ('A-USD','B-USD')]
    item.client=Client()
    def rank(rows,owned,policy,limit,momentum):
        return [Candidate(s,dict(momentum[s]),score=10) for s in ('A-USD','B-USD')]
    item.rank_candidates=rank
    context=dict(runtime_mode='NORMAL',entry_enabled=True,operating_mode='NIGHT',
                 risk_truth_complete=True,open_positions=1,exposure_usd='20',session_loss_usd='0')
    intent=asyncio.run(item.next_entry(context))
    assert intent is not None and intent.symbol=='B-USD'
    assert planner.calls==['A-USD','B-USD','B-USD']
    qty=Decimal(intent.body['order_configuration']['limit']['base_size'])
    assert qty*2<=Decimal(intent.metadata['allocation']['allocation_usd'])
    assert float(qty)==intent.metadata['quantity']
    assert intent.metadata['decision_mid']==2


def test_allocation_redistributes_unusable_share_and_does_not_overallocate():
    a=alternative('A',2.5)
    b=alternative('B',2.3)
    a.metadata['quantity']=2
    result=allocate_targets([a,b],130)
    assert Decimal(result['A']['allocation_usd'])<=4
    assert sum(Decimal(row['allocation_usd']) for row in result.values())==130
    assert Decimal(result['B']['allocation_usd'])==126


@pytest.mark.parametrize('exposure,cash,error', [('140','100','ACCOUNT'),('0','1','CASH')])
def test_account_change_blocks_stale_allocated_buy_before_submit(exposure,cash,error):
    from revx_v5.live_runtime import V5LiveBoundary
    class Store:
        def admission_snapshot(self,*args):
            return dict(exposure_usd=exposure,open_positions=0,risk_truth_complete=True,session_loss_usd='0')
        def append_intent(self,*args):
            raise AssertionError('must not submit or persist stale intention')
    boundary=V5LiveBoundary(None,None,state_store=Store())
    async def prepared():
        return dict(state=SimpleNamespace(ambiguous=False,active_orders=[],balances=[dict(currency='USD',total=cash,available=cash)]),
                    inventory=dict(records=[]),owned_positions=[])
    boundary.prepare_startup=prepared
    intent=Intent('stale','ABC-USD','BUY',dict(order_configuration=dict(limit=dict(base_size='10',price='2'))),
                  dict(operating_mode='NIGHT',session_key='test',sizing=dict(entry_cost_allowance_usd='.1')))
    with pytest.raises(RuntimeError,match='BUY_'+error+'_CHANGED_BEFORE_SUBMIT'):
        asyncio.run(boundary.execute_intent(intent))


def test_minimum_aware_allocation_keeps_a_feasible_subset():
    candidates=[alternative(f'{i:02}',2.5) for i in range(10)]
    for candidate in candidates:
        candidate.metadata['sizing']['minimum_notional_usd']='5'
    result=allocate_targets(candidates,20)
    amounts=[Decimal(row['allocation_usd']) for row in result.values()]
    assert sum(amounts)==20
    assert sum(x>0 for x in amounts)==4
    assert all(x==0 or x>=5 for x in amounts)
    assert result==allocate_targets(list(reversed(candidates)),20)
    assert all(Decimal(row['allocation_usd'])==0
               for row in allocate_targets(candidates,4).values())


def test_entry_no_longer_starves_ten_candidates_below_venue_minimum():
    symbols=[f'A{i}-USD' for i in range(10)]
    class MultiPlanner(Planner):
        async def build_buy_plan(self,signal_id,symbol,*args):
            return Plan(symbol=symbol,client_order_id=symbol)
        async def pair_rules(self,symbol):
            return SimpleNamespace(base_step='.01',min_order_size='.01',min_order_size_quote='5',max_order_size='1000')
    class Client:
        async def tickers(self,lane):
            return [dict(symbol=s,bid=1.99,ask=2.01) for s in symbols]
    item=source(MultiPlanner(),validation_limit=10)
    item.order_cap_usd=None
    item.allocation_mode=True
    item.client=Client()
    item.rank_candidates=lambda rows,owned,policy,limit,momentum: [Candidate(s,momentum[s],score=10) for s in symbols]
    intent=asyncio.run(item.next_entry(dict(runtime_mode='NORMAL',entry_enabled=True,
        operating_mode='DAY',risk_truth_complete=True,open_positions=1,exposure_usd='130',session_loss_usd='0')))
    assert intent is not None
    assert 5<=Decimal(intent.metadata['sizing']['notional_usd'])<=20
    assert not item.last_scan['planning_rejections']


def test_minimum_notional_includes_base_step_rounding():
    from revx_v5.sizing import size_buy
    rules=SimpleNamespace(base_step='3',min_order_size='1',min_order_size_quote='5',max_order_size='100')
    _,sizing=size_buy(Plan(),rules,20,{})
    assert Decimal(sizing['minimum_notional_usd'])==6


@pytest.mark.parametrize('price,fee', [(None,None),('101',None),(None,'0.3'),('101','0.3')])
def test_growing_fill_never_reuses_partial_cumulative_price_or_fee(price,fee):
    intent=dict(intent_id='i',symbol='A-USD',side='BUY',metadata=dict(decision_mid=100))
    first=observation({},intent,dict(filled_quantity=1,average_price=100,fee_usd='.1'),'RESPONSE_OBSERVED',100)
    second=observation(first,intent,dict(filled_quantity=2,average_price=price,fee_usd=fee),'RECOVERY_OBSERVED',101)
    assert second['average_fill_price']==(float(price) if price else None)
    assert second['fee_usd']==(float(fee) if fee else None)
    assert (second['shortfall_vs_decision_mid_bps'] is None)==(price is None)
    assert first['average_fill_price']==100 and first['fee_usd']==.1


def telemetry_boundary(failure=None,filled=False):
    from revx_v5.live_runtime import V5LiveBoundary
    events=[]
    result=dict(id='venue-1',client_order_id='i',status='filled' if filled else 'open',
                quantity=1,filled_quantity=1 if filled else 0,average_price=2)
    class Store:
        def append_intent(self,event):
            events.append(event['status'])
            if failure==event['status']:
                raise PermissionError('economic persistence failure')
        def record_execution_observation(self,intent,order,phase):
            events.append(phase)
            if failure in (phase,'ALL_TELEMETRY'):
                raise PermissionError('telemetry failure')
        def apply_execution_fill(self,*args):
            events.append('APPLY_FILL')
            if failure=='APPLY_FILL':
                raise PermissionError('economic persistence failure')
        def pending_intents(self):
            return [dict(intent_id='i',symbol='A-USD',side='BUY')]
    class Client:
        calls=0
        recovering=False
        async def active_orders(self,*args):
            return [result] if self.recovering else []
        async def historical_orders(self,*args):
            return []
        async def submit_order(self,*args):
            self.calls+=1
            events.append('POST')
            if failure=='TIMEOUT':
                raise TimeoutError('ambiguous submit')
            return result
    client=Client()
    boundary=V5LiveBoundary(client,client,state_store=Store())
    async def prepared():
        return dict(state=SimpleNamespace(ambiguous=False))
    boundary.prepare_startup=prepared
    return boundary,client,events


@pytest.mark.parametrize('failure',['SUBMIT_REQUESTED','RESPONSE_OBSERVED','ALL_TELEMETRY'])
@pytest.mark.parametrize('filled',[False,True])
def test_optional_telemetry_failure_does_not_interrupt_submission(failure,filled,caplog):
    boundary,client,events=telemetry_boundary(failure,filled)
    result=asyncio.run(boundary.execute_intent(Intent('i','A-USD','BUY',{})))
    assert result['id']=='venue-1' and client.calls==1
    terminal='FILLED' if filled else 'SUBMITTED'
    assert events.index(terminal)<events.index('RESPONSE_OBSERVED')
    assert 'EXECUTION_TELEMETRY_UNAVAILABLE' in caplog.text


def test_optional_telemetry_failure_does_not_interrupt_recovery():
    boundary,client,events=telemetry_boundary('ALL_TELEMETRY',True)
    client.recovering=True
    result=asyncio.run(boundary.recover_pending())
    assert result[0]['status']=='FILLED' and client.calls==0
    assert events.index('APPLY_FILL')<events.index('FILLED')<events.index('RECOVERY_OBSERVED')


@pytest.mark.parametrize('failure,calls',[('PENDING',0),('APPLY_FILL',1),('FILLED',1),('TIMEOUT',1)])
def test_financial_persistence_and_submit_failures_still_propagate(failure,calls):
    boundary,client,events=telemetry_boundary(failure,True)
    with pytest.raises((PermissionError,TimeoutError)):
        asyncio.run(boundary.execute_intent(Intent('i','A-USD','BUY',{})))
    assert client.calls==calls
    assert 'RESPONSE_OBSERVED' not in events


def test_start_message_uses_effective_policy():
    from v5_live_service import live_start_message
    from revx_v5.policy import RiskPolicy
    item=source()
    item.order_cap_usd=None
    message=live_start_message(item)
    assert 'dynamic risk/cash/costs/venue rules' in message
    assert '$150 account-wide exposure (Day + Night)' in message
    assert '$20/order' not in message and 'separately' not in message
    item.risk_policy=RiskPolicy(exposure_usd=123,session_loss_usd=7,day_max_positions=9,night_max_positions=4)
    item.order_cap_usd=Decimal('17')
    message=live_start_message(item)
    assert '$17/order' in message and '$123 account-wide' in message
    assert '$7 loss/session; 9 Day / 4 Night' in message
