from revx_v5.decision import Candidate, Position, Quote, evaluate_entry, evaluate_exit


def quote(**overrides):
    data = dict(bid=1.0, ask=1.001, spread_pct=0.1, age_s=2.0,
                executable=True, depth_usd=100.0, volume_usd=300_000.0)
    data.update(overrides)
    return Quote(**data)


def candidate(**overrides):
    data = dict(symbol="ABC", quote=quote(), episode_age_s=10.0,
                geometry_ok=True, reversal=False,
                signal_families=frozenset({"price_momentum", "flow_liquidity"}))
    data.update(overrides)
    return Candidate(**data)


def test_buy_requires_two_independent_families():
    d = evaluate_entry(candidate(signal_families=frozenset({"price_momentum"})),
                       mode="DAY", open_positions=0, max_positions=10,
                       exposure_usd=0, max_exposure_usd=150,
                       order_usd=20, max_order_usd=20)
    assert d.action == "NO_ACTION"
    assert d.reason == "two_independent_signal_families_required"


def test_entry_passes_only_after_all_admission_gates():
    d = evaluate_entry(candidate(), mode="DAY", open_positions=0, max_positions=10,
                       exposure_usd=0, max_exposure_usd=150,
                       order_usd=20, max_order_usd=20)
    assert d.action == "BUY"


def test_degraded_bridge_waits_without_executable_truth():
    p = Position("ABC", 1, 0.9, 1.2, 10, degraded=True)
    d = evaluate_exit(p, quote(bid=None, ask=None, executable=False), reconciled=True,
                      ambiguous_order=False)
    assert d.action == "DEGRADED"


def test_degraded_bridge_sells_on_first_fresh_executable_truth():
    p = Position("ABC", 1, 0.9, 1.2, 10, degraded=True)
    d = evaluate_exit(p, quote(), reconciled=True, ambiguous_order=False)
    assert d.action == "SELL"
    assert d.reason == "degraded_position_executable_truth"


def test_ambiguity_blocks_even_a_stop():
    p = Position("ABC", 1, 0.9, 1.2, 10)
    d = evaluate_exit(p, quote(bid=0.8), reconciled=False, ambiguous_order=True)
    assert d.action == "UNKNOWN"
