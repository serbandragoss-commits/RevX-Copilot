import asyncio
import time

from revx_v5.execution_adapter import ExecutionBlocked, Intent, submit_once
from revx_v5.live_runtime import V5LiveBoundary
from revx_v5.reconciliation import parse_balances, reconcile
from revx_v5.state_store import DurableState


class FakeClient:
    def __init__(self, order=None, submit_result=None):
        self.order = order
        self.submit_result = submit_result or {"id": "venue-1"}
        self.submits = 0
        self.cancels = []

    async def balances(self, lane=None):
        return {"USD": {"total": 100}, "ABC": {"total": 2}}

    async def active_orders(self, symbol=None, lane=None):
        return [self.order] if self.order else []

    async def historical_orders(self, symbol=None, hours=24, lane=None):
        return []

    async def submit_order(self, body_obj, lane=None):
        self.submits += 1
        return self.submit_result

    async def cancel_order(self, venue_order_id, lane=None):
        self.cancels.append(venue_order_id)
        return {"id": venue_order_id, "status": "cancelled"}

    async def pair_configurations(self, lane=None):
        return {"ABC/USD": {"base": "ABC", "quote": "USD", "status": "active",
                            "base_step": "0.01", "quote_step": "0.001"}}

    async def order_book(self, symbol, limit=50, lane=None):
        return {"bids": [["1", "10"]], "asks": [["1.01", "10"]]}


class IntentStore:
    def __init__(self, records=None):
        self.records = records or {}
        self.events = []

    def intent_records(self):
        return self.records

    def append_intent(self, event):
        self.events.append(event)


def test_reconciliation_is_read_only_and_marks_ambiguous_orders():
    state = asyncio.run(reconcile(FakeClient({"status": "PENDING"})))
    assert state.ambiguous is True
    assert state.positions[0]["symbol"] == "ABC"
    assert state.balances_valid is True


def test_reconciliation_parses_live_list_shape_and_never_calls_it_flat():
    class ListBalanceClient(FakeClient):
        async def balances(self, lane=None):
            return [
                {"currency": "USD", "available": "20", "reserved": "0", "total": "20"},
                {"currency": "ABC", "available": "1.2", "reserved": "0", "total": "1.2"},
            ]

    state = asyncio.run(reconcile(ListBalanceClient()))
    assert state.balances_valid is True
    assert [row["symbol"] for row in state.positions] == ["ABC"]


def test_reconciliation_fails_closed_on_unknown_balance_shape():
    rows, valid = parse_balances({"unexpected": "shape"})
    assert rows == ()
    assert valid is False


def test_live_boundary_blocks_unreadable_balance_state():
    class BadBalanceClient(FakeClient):
        async def balances(self, lane=None):
            return {"unexpected": "shape"}

    client = BadBalanceClient()
    try:
        asyncio.run(V5LiveBoundary(client, client).startup_reconcile())
    except RuntimeError as exc:
        assert "balance" in str(exc)
    else:
        raise AssertionError("unreadable balance state was not blocked")


def test_submit_once_deduplicates_existing_intent():
    client = FakeClient({"client_order_id": "i-1", "id": "venue-1"})
    result = asyncio.run(submit_once(client, Intent("i-1", "ABC", "SELL", {})))
    assert result["id"] == "venue-1"
    assert client.submits == 0


def test_submit_once_blocks_ambiguous_response_without_retry():
    client = FakeClient(submit_result={"status": "PENDING"})
    try:
        asyncio.run(submit_once(client, Intent("i-2", "ABC", "BUY", {})))
    except ExecutionBlocked as exc:
        assert "no retry" in str(exc)
    else:
        raise AssertionError("ambiguous response was not blocked")
    assert client.submits == 1


def test_live_boundary_reconciles_before_mutation():
    class FlatClient(FakeClient):
        async def balances(self, lane=None):
            return {"USD": {"total": 100}}
    client = FlatClient()
    result = asyncio.run(V5LiveBoundary(client, client).execute_intent(
        Intent("i-3", "ABC", "BUY", {"client_order_id": "i-3"})
    ))
    assert result["id"] == "venue-1"
    assert client.submits == 1


def test_external_inventory_does_not_block_unrelated_mutation():
    client = FakeClient()
    boundary = V5LiveBoundary(client, client)
    result = asyncio.run(boundary.execute_intent(Intent("i-buy", "ABC", "BUY", {})))
    assert result["id"] == "venue-1"
    assert client.submits == 1
    result = asyncio.run(boundary.execute_intent(Intent("i-sell", "ABC", "SELL", {})))
    assert result["id"] == "venue-1"
    assert client.submits == 2


def test_live_boundary_records_outbox_before_and_after_submit():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests"
    store = DurableState(root)
    store.outbox_path.unlink(missing_ok=True)
    class FlatClient(FakeClient):
        async def balances(self, lane=None):
            return {"USD": {"total": 100}}
    client = FlatClient()
    result = asyncio.run(V5LiveBoundary(client, client, state_store=store).execute_intent(
        Intent("i-outbox", "ABC", "BUY", {"client_order_id": "i-outbox"})
    ))
    assert result["id"] == "venue-1"
    assert store.pending_intents()[0]["status"] == "SUBMITTED"


def test_immediate_buy_fill_is_adopted_idempotently():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\filled"
    store = DurableState(root)
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)

    class FilledClient(FakeClient):
        async def balances(self, lane=None):
            return {"USD": {"total": 100}}

        async def submit_order(self, body_obj, lane=None):
            return {"id": "venue-filled", "status": "filled",
                    "quantity": "2", "filled_quantity": "2",
                    "leaves_quantity": "0", "average_price": "5",
                    "fee": "0", "fee_currency": "USD"}

    client = FilledClient()
    intent = Intent("buy-filled", "ABC-USD", "BUY",
                    {"client_order_id": "buy-filled"},
                    {"stop": 4.5, "target": 6.0, "lane": "STANDARD",
                     "operating_mode": "DAY", "session_key": "2026-10-03"})
    asyncio.run(V5LiveBoundary(client, client, state_store=store).execute_intent(intent))
    saved = store.load()
    assert saved["positions"]["ABC-USD"]["quantity"] == "2"
    assert saved["positions"]["ABC-USD"]["source"] == "V5_OWNED"
    assert store.pending_intents() == []


def test_prepare_startup_separates_v5_owned_from_external_inventory():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\owned"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    state = store.load()
    state["positions"] = {"ABC-USD": {"symbol": "ABC-USD", "quantity": "2",
                                        "average_entry_price": "1", "stop": 0.9,
                                        "target": 1.2, "source": "V5_OWNED"}}
    store.save(state)
    prepared = asyncio.run(V5LiveBoundary(FakeClient(), FakeClient(),
                                           state_store=store).prepare_startup())
    assert prepared["runtime_mode"] == "NORMAL"
    assert prepared["entry_enabled"] is True
    assert prepared["inventory"]["count"] == 0
    assert prepared["owned_positions"][0]["symbol"] == "ABC-USD"


def test_prepare_startup_persists_external_inventory_without_claiming_position():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)


def test_prepare_startup_reconciles_base_fee_for_any_owned_symbol():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\accountwide-base-fee"
    store = DurableState(root)
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)
    state = store.load()
    state["positions"] = {"HONEY-USD": {
        "symbol": "HONEY-USD", "quantity": "6250", "average_entry_price": "0.0032",
        "entry_intent_id": "i-honey", "entry_fee_usd": "0", "entry_fee_truth": "UNKNOWN",
        "operating_mode": "NIGHT", "session_key": "2026-10-08", "source": "V5_OWNED",
    }}
    state["intents"] = {"i-honey": {"adopted_quantity": "6250", "fee_truth": "UNKNOWN"}}
    store.save(state)

    class AccountWideHoneyClient(FakeClient):
        async def balances(self, lane=None):
            return {"USD": {"total": 100}, "HONEY": {"total": "6244.375"}}

        async def pair_configurations(self, lane=None):
            return {"HONEY/USD": {"base": "HONEY", "quote": "USD", "status": "active",
                                   "base_step": "0.001", "quote_step": "0.0001"}}

        async def order_book(self, symbol, limit=50, lane=None):
            return {"bids": [["0.0028", "10000"]], "asks": [["0.0029", "10000"]]}

        async def historical_orders(self, symbol=None, hours=24, lane=None):
            if symbol is not None:
                return []
            return [{"id": "venue-honey", "client_order_id": "i-honey",
                     "symbol": "HONEY/USD", "side": "BUY", "status": "filled",
                     "filled_quantity": "6250", "leaves_quantity": "0",
                     "average_fill_price": "0.0032", "total_fee": "5.625",
                     "fee_currency": "HONEY"}]

    client = AccountWideHoneyClient()
    prepared = asyncio.run(V5LiveBoundary(client, client, state_store=store).prepare_startup())
    assert prepared["owned_positions"][0]["quantity"] == "6244.375"
    assert prepared["runtime_mode"] == "NORMAL"
    assert store.load()["positions"]["HONEY-USD"]["quantity"] == "6244.375"
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)


def test_prepare_startup_terminalizes_owned_position_absent_by_venue_balance():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\terminal-owned-exit"
    store = DurableState(root)
    store.state_path.unlink(missing_ok=True)
    state = store.load()
    state["positions"] = {"ABC-USD": {"symbol": "ABC-USD", "quantity": "2",
                                         "average_entry_price": "1", "source": "V5_OWNED"}}
    store.save(state)

    class VenueExitedClient(FakeClient):
        async def balances(self, lane=None):
            return {"USD": {"total": 100}}

        async def historical_orders(self, symbol=None, hours=24, lane=None):
            return [{"id": "exit-1", "symbol": "ABC-USD", "side": "sell",
                     "status": "filled", "filled_quantity": "2", "leaves_quantity": "0"}]

    prepared = asyncio.run(V5LiveBoundary(VenueExitedClient(), VenueExitedClient(),
                                           state_store=store).prepare_startup())
    assert prepared["owned_positions"] == []
    assert store.load()["positions"] == {}
    assert store.load()["reconciliation_events"][-1]["event"] == "VENUE_BALANCE_CONFIRMED_ZERO"
    assert store.load()["reconciliation_events"][-1]["economic_truth"] == "UNKNOWN"
    store.state_path.unlink(missing_ok=True)
    client = FakeClient()
    prepared = asyncio.run(V5LiveBoundary(client, client, state_store=store).prepare_startup())
    saved = store.load()
    assert prepared["runtime_mode"] == "NORMAL"
    assert prepared["entry_enabled"] is True
    assert saved["external_inventory"]["ABC-USD"]["quantity"] == "2"


def test_prepare_startup_attributes_absent_position_only_to_linked_v5_sell():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\terminal-owned-linked-exit"
    store = DurableState(root)
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)
    state = store.load()
    state["positions"] = {"ABC-USD": {"symbol": "ABC-USD", "quantity": "2",
                                          "average_entry_price": "1", "source": "V5_OWNED",
                                          "entry_filled_at": time.time() - 48 * 3600}}
    store.save(state)
    store.append_intent({"intent_id": "v5-exit", "symbol": "ABC-USD", "side": "SELL",
                         "status": "FILLED"})

    class LinkedVenueExitedClient(FakeClient):
        def __init__(self):
            super().__init__()
            self.history_hours = []

        async def balances(self, lane=None):
            return {"USD": {"total": 100}}

        async def historical_orders(self, symbol=None, hours=24, lane=None):
            self.history_hours.append(hours)
            return [{"id": "exit-1", "client_order_id": "v5-exit", "symbol": "ABC-USD",
                     "side": "sell", "status": "filled", "filled_quantity": "2",
                     "leaves_quantity": "0"}]

    client = LinkedVenueExitedClient()
    prepared = asyncio.run(V5LiveBoundary(client, client, state_store=store).prepare_startup())
    assert prepared["owned_positions"] == []
    assert client.history_hours and client.history_hours[0] >= 72
    assert store.load()["reconciliation_events"][-1]["event"] == "VENUE_CONFIRMED_OWNED_EXIT"
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)


def test_restart_recovery_marks_pending_without_resubmitting():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests"
    store = DurableState(root)
    store.outbox_path.unlink(missing_ok=True)


def test_restart_recovery_terminalizes_unpriced_venue_sell_without_resubmission():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\unpriced-venue-sell"
    store = DurableState(root)
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)


def test_restart_recovery_adopts_terminal_losing_sell_without_reconciliation_block():
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\losing-venue-sell"
    store = DurableState(root)
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)
    state = store.load()
    state["positions"] = {"ABC-USD": {
        "symbol": "ABC-USD", "quantity": "2", "average_entry_price": "2",
        "entry_fee_usd": "0", "entry_fee_truth": "KNOWN", "operating_mode": "DAY",
        "session_key": "2026-10-08", "source": "V5_OWNED",
    }}
    store.save(state)
    store.append_intent({"intent_id": "i-losing-sell", "symbol": "ABC-USD",
                         "side": "SELL", "venue_order_id": "venue-losing",
                         "status": "SUBMITTED"})

    class LosingSellClient(FakeClient):
        async def historical_orders(self, symbol=None, hours=24, lane=None):
            return [{"id": "venue-losing", "client_order_id": "i-losing-sell",
                     "symbol": "ABC/USD", "side": "SELL", "status": "filled",
                     "filled_quantity": "2", "leaves_quantity": "0",
                     "average_fill_price": "1", "total_fee": "0.02", "fee_currency": "USD"}]

    client = LosingSellClient()
    result = asyncio.run(V5LiveBoundary(client, client, state_store=store).recover_pending())
    assert result[0]["status"] == "FILLED"
    assert store.pending_intents() == []
    assert store.load()["positions"] == {}
    assert store.load()["economic_ledger"][-1]["gross_pnl_usd"] == "-2"
    assert client.submits == 0
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)
    state = store.load()
    state["positions"] = {"ABC-USD": {
        "symbol": "ABC-USD", "quantity": "2", "average_entry_price": "1",
        "operating_mode": "DAY", "session_key": "2026-10-08", "source": "V5_OWNED",
    }}
    store.save(state)
    store.append_intent({"intent_id": "i-unpriced-sell", "symbol": "ABC-USD",
                         "side": "SELL", "venue_order_id": "venue-sell",
                         "status": "SUBMITTED"})

    class UnpricedSellClient(FakeClient):
        async def historical_orders(self, symbol=None, hours=24, lane=None):
            return [{"id": "venue-sell", "client_order_id": "i-unpriced-sell",
                     "symbol": "ABC/USD", "side": "SELL", "status": "filled",
                     "filled_quantity": "2", "leaves_quantity": "0"}]

    client = UnpricedSellClient()
    result = asyncio.run(V5LiveBoundary(client, client, state_store=store).recover_pending())
    assert result[0]["status"] == "TERMINAL_UNPRICED"
    assert store.pending_intents() == []
    assert store.load()["positions"]["ABC-USD"]["quantity"] == "2"
    assert client.submits == 0
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)
    store.append_intent({"intent_id": "i-recover", "symbol": "ABC",
                         "side": "BUY", "status": "PENDING"})
    client = FakeClient()
    result = asyncio.run(V5LiveBoundary(client, client, state_store=store).recover_pending())
    assert result[0]["status"] == "UNCONFIRMED"
    assert store.pending_intents()[0]["status"] == "UNCONFIRMED"
    assert client.submits == 0
    store.outbox_path.unlink(missing_ok=True)


def test_restart_recovery_adopts_buy_base_fee_as_net_venue_quantity():
    """A restart must recover the quantity credited by the venue, not gross fill."""
    root = r"C:\Users\serba\Documents\RevX\tmp\v5-tests\honey-base-fee-recovery"
    store = DurableState(root)
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)
    store.append_intent({
        "intent_id": "i-honey-buy", "symbol": "HONEY-USD", "side": "BUY",
        "venue_order_id": "venue-honey", "status": "SUBMITTED",
        "metadata": {"operating_mode": "NIGHT", "session_key": "2026-10-08"},
    })

    class HoneyFillClient(FakeClient):
        async def historical_orders(self, symbol=None, hours=24, lane=None):
            return [{"id": "venue-honey", "client_order_id": "i-honey-buy",
                     "symbol": "HONEY/USD", "side": "BUY", "status": "filled",
                     "filled_quantity": "6250", "leaves_quantity": "0",
                     "average_fill_price": "0.0032", "total_fee": "5.625",
                     "fee_currency": "HONEY"}]

    client = HoneyFillClient()
    result = asyncio.run(V5LiveBoundary(client, client, state_store=store).recover_pending())
    position = store.load()["positions"]["HONEY-USD"]
    assert result[0]["status"] == "FILLED"
    assert store.pending_intents() == []
    assert position["quantity"] == "6244.375"
    assert position["gross_filled_quantity"] == "6250"
    assert position["entry_base_fee_quantity"] == "5.625"
    assert position["entry_fee_truth"] == "KNOWN"
    assert position['entry_base_fee_in_cost_basis'] is True
    assert client.submits == 0
    for path in (store.state_path, store.outbox_path):
        path.unlink(missing_ok=True)


def test_live_boundary_blocks_ambiguous_startup():
    client = FakeClient({"status": "PENDING", "id": "venue-pending"})
    try:
        asyncio.run(V5LiveBoundary(client, client).startup_reconcile())
    except RuntimeError as exc:
        assert "ambiguous" in str(exc)
    else:
        raise AssertionError("ambiguous startup was not blocked")


def test_stale_v5_owned_buy_is_cancelled_but_sell_is_never_touched():
    import time
    client = FakeClient()
    stale = {"id": "old-buy", "client_order_id": "intent-old-buy",
             "symbol": "ABC-USD", "side": "buy",
             "created_at": time.time() - 60}
    sell = {"id": "old-sell", "symbol": "ABC-USD", "side": "sell",
            "created_at": time.time() - 60}
    client.order = stale
    original = client.active_orders
    async def active_orders(symbol=None, lane=None):
        return [stale, sell]
    client.active_orders = active_orders
    store = IntentStore({"intent-old-buy": {
        "intent_id": "intent-old-buy", "venue_order_id": "old-buy",
        "symbol": "ABC-USD", "side": "BUY",
        "submitted_at": time.time() - 60, "status": "ACTIVE",
    }})
    result = asyncio.run(V5LiveBoundary(
        client, client, state_store=store, entry_order_ttl_sec=45)
                         .cancel_stale_entry_orders())
    assert [row["venue_order_id"] for row in result] == ["old-buy"]
    assert client.cancels == ["old-buy"]


def test_stale_buy_inactive_cancel_race_requires_reconciliation_not_failure():
    import time

    class InactiveCancelClient(FakeClient):
        async def cancel_order(self, venue_order_id, lane=None):
            self.cancels.append(venue_order_id)
            raise RuntimeError("HTTP 409 Can't cancel order in inactive state")

    stale = {"id": "old-buy", "client_order_id": "intent-old-buy",
             "symbol": "ABC-USD", "side": "buy",
             "created_at": time.time() - 60}
    store = IntentStore({"intent-old-buy": {
        "intent_id": "intent-old-buy", "venue_order_id": "old-buy",
        "symbol": "ABC-USD", "side": "BUY",
        "submitted_at": time.time() - 60, "status": "ACTIVE",
    }})
    client = InactiveCancelClient(stale)
    result = asyncio.run(V5LiveBoundary(
        client, client, state_store=store, entry_order_ttl_sec=45
    ).cancel_stale_entry_orders())
    assert result[0]["outcome"] == "RACE_RECONCILIATION_REQUIRED"
    assert store.events[-1]["status"] == "SUBMITTED"


def test_stale_external_buy_is_never_cancelled():
    import time
    client = FakeClient()
    stale = {"id": "manual-buy", "client_order_id": "manual-intent",
             "symbol": "ABC-USD", "side": "buy",
             "created_at": time.time() - 600}
    client.order = stale
    result = asyncio.run(V5LiveBoundary(
        client, client, state_store=IntentStore(), entry_order_ttl_sec=45)
                         .cancel_stale_entry_orders())
    assert result == []
    assert client.cancels == []


def test_stale_buy_with_conflicting_venue_identity_is_never_cancelled():
    import time
    client = FakeClient()
    stale = {"id": "unexpected-order", "client_order_id": "intent-old-buy",
             "symbol": "ABC-USD", "side": "buy",
             "created_at": time.time() - 600}
    client.order = stale
    store = IntentStore({"intent-old-buy": {
        "intent_id": "intent-old-buy", "venue_order_id": "expected-order",
        "symbol": "ABC-USD", "side": "BUY",
        "submitted_at": time.time() - 600, "status": "ACTIVE",
    }})
    result = asyncio.run(V5LiveBoundary(
        client, client, state_store=store, entry_order_ttl_sec=45)
                         .cancel_stale_entry_orders())
    assert result == []
    assert client.cancels == []
