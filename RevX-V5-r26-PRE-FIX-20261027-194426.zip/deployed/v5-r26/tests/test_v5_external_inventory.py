import asyncio

from revx_v5.external_inventory import (
    active_usd_pairs, classify_external_inventory, executable_book, fetch_inventory_books,
)


PAIRS = {
    "ABC/USD": {"base": "ABC", "quote": "USD", "status": "active",
                "base_step": "0.01", "quote_step": "0.001"},
    "OFF/USD": {"base": "OFF", "quote": "USD", "status": "inactive",
                "base_step": "0.01", "quote_step": "0.001"},
}


def test_pair_and_book_require_real_executable_shape():
    assert active_usd_pairs(PAIRS) == {"ABC-USD"}
    assert executable_book({"bids": [["1", "2"]], "asks": [["1.1", "2"]]})
    assert not executable_book({"bids": [["1.2", "2"]], "asks": [["1.1", "2"]]})


def test_inventory_is_reconciled_only_when_every_symbol_is_observable():
    positions = [{"currency": "ABC", "total": "2"}]
    result = classify_external_inventory(
        positions, PAIRS,
        {"ABC-USD": {"bids": [{"price": "1"}], "asks": [{"price": "1.1"}]}}
    )
    assert result["reconciled"] is True
    assert result["records"][0]["classification"] == "EXTERNAL_INVENTORY"
    assert result["records"][0]["exit_eligible"] is True
    assert result["records"][0]["cost_basis_status"] == "UNKNOWN"
    assert result["records"][0]["pnl_status"] == "UNKNOWN"
    assert result["records"][0]["mark_price"] == "1"


def test_unknown_pair_fails_closed():
    result = classify_external_inventory([{"currency": "XYZ", "total": "2"}], PAIRS, {})
    assert result["reconciled"] is False
    assert result["unknown_currencies"] == ["XYZ"]


def test_inventory_book_retry_exhaustion_remains_unknown_and_fail_closed():
    class UnavailableBook:
        def __init__(self):
            self.calls = 0

        async def order_book(self, symbol, depth, lane):
            self.calls += 1
            raise TimeoutError("temporary public book timeout")

    client = UnavailableBook()
    positions = [{"currency": "ABC", "total": "2"}]
    books = asyncio.run(fetch_inventory_books(client, positions, PAIRS, attempts=3))
    result = classify_external_inventory(positions, PAIRS, books)

    assert client.calls == 3
    assert books == {}
    assert result["reconciled"] is False
    assert result["unknown_currencies"] == ["ABC"]
