from revx_v5.decision import Candidate, Quote, evaluate_entry_with_policy
from revx_v5.policy import RiskPolicy


def candidate():
    return Candidate("ABC", Quote(1, 1.001, 0.1, 1, True, 100, 300000),
                     10, True, False,
                     frozenset({"price_momentum", "flow_liquidity"}))


def test_policy_wrapper_binds_day_and_night_caps():
    p = RiskPolicy()
    assert evaluate_entry_with_policy(candidate(), mode="DAY", open_positions=19,
                                      exposure_usd=0, session_loss_usd=0, order_usd=20,
                                      policy=p).action == "BUY"
    assert evaluate_entry_with_policy(candidate(), mode="DAY", open_positions=20,
                                      exposure_usd=0, session_loss_usd=0,
                                      policy=p).action == "NO_ACTION"
    assert evaluate_entry_with_policy(candidate(), mode="NIGHT", open_positions=10,
                                      exposure_usd=0, session_loss_usd=0,
                                      policy=p).action == "NO_ACTION"


def test_policy_wrapper_blocks_loss_before_signal_evaluation():
    d = evaluate_entry_with_policy(candidate(), mode="DAY", open_positions=0,
                                   exposure_usd=0, session_loss_usd=-10)
    assert d.reason == "mode_limit"
