import asyncio
import json
import shutil
import uuid
from pathlib import Path

from revx_v5.service import V5Service
from revx_v5.state_store import DurableState


class SequenceRunner:
    def __init__(self, rows):
        self.rows = list(rows)
        self.index = 0

    async def cycle(self):
        row = self.rows[min(self.index, len(self.rows) - 1)]
        self.index += 1
        return dict(row)


def result(status="HEALTHY_SILENCE", **extra):
    return {"status": status, "runtime_mode": "NORMAL", "entry_enabled": True,
            "broker_mutated": 0, "actions_executed": 0,
            "reason": "no_qualifying_action", **extra}


def run(service, cycles):
    return asyncio.run(service.run(max_cycles=cycles))


def local_tmp():
    path = Path(r"C:\Users\serba\Documents\RevX\tmp\v5-service-tests") / uuid.uuid4().hex
    path.mkdir(parents=True, exist_ok=False)
    return path


def test_service_writes_atomic_health_for_bounded_rehearsal():
    tmp_path = local_tmp()
    health = tmp_path / "health.json"
    try:
        final = run(V5Service(SequenceRunner([result()]), health, interval_sec=0), 2)
        observed = json.loads(health.read_text(encoding="utf-8"))
        assert final == observed
        assert observed["status"] == "HEALTHY_SILENCE"
        assert observed["cycles"] == 2
        assert observed["broker_mutated"] == 0
        assert observed["service_stop_reason"] == "bounded_rehearsal_complete"
    finally:
        shutil.rmtree(tmp_path)


def test_service_stops_after_consecutive_failures():
    tmp_path = local_tmp()
    failed = result("FAILED", reason="provider_unavailable")
    try:
        final = run(V5Service(SequenceRunner([failed]), tmp_path / "health.json",
                              interval_sec=0, failure_limit=3), 10)
        assert final["cycles"] == 3
        assert final["consecutive_failures"] == 3
        assert final["service_stop_reason"] == "failure_threshold"
    finally:
        shutil.rmtree(tmp_path)


def test_service_stops_after_consecutive_transport_degradation():
    tmp_path = local_tmp()
    degraded = result("DEGRADED", reason="exit_source_transport_degraded")
    try:
        final = run(V5Service(SequenceRunner([degraded]), tmp_path / "health.json",
                              interval_sec=0, failure_limit=3), 10)
        assert final["cycles"] == 3
        assert final["consecutive_failures"] == 3
        assert final["service_stop_reason"] == "failure_threshold"
    finally:
        shutil.rmtree(tmp_path)


def test_service_persists_bounded_failure_diagnostics():
    tmp_path = local_tmp()
    failed = result("FAILED", reason="supervisor_exception",
                    error_type="TimeoutError", error_detail="read timed out")
    try:
        final = run(V5Service(SequenceRunner([failed]), tmp_path / "health.json",
                              interval_sec=0, failure_limit=1), 1)
        observed = json.loads((tmp_path / "health.json").read_text(encoding="utf-8"))
        assert final["error_type"] == "TimeoutError"
        assert observed["error_detail"] == "read timed out"
    finally:
        shutil.rmtree(tmp_path)


def test_material_transition_is_deduplicated_and_delivered():
    tmp_path = local_tmp()
    store = DurableState(tmp_path / "state")
    sent = []
    rows = [result("BLOCKED", reason="startup_gate"),
            result("BLOCKED", reason="startup_gate")]
    try:
        final = run(V5Service(SequenceRunner(rows), tmp_path / "health.json",
                              interval_sec=0, state_store=store,
                              telegram_send=sent.append), 2)
        assert len(sent) == 1
        assert "BLOCKED" in sent[0]
        assert final["notification"]["sent"] == 0
        assert store.pending_notifications() == []
    finally:
        shutil.rmtree(tmp_path)


def test_required_startup_message_is_sent_before_first_cycle():
    tmp_path = local_tmp()
    store = DurableState(tmp_path / "state")
    sent = []
    try:
        final = run(V5Service(
            SequenceRunner([result(), result()]), tmp_path / "health.json",
            interval_sec=0, state_store=store, telegram_send=sent.append,
            startup_message="RevX V5 LIVE — STARTED",
        ), 2)
        assert final["status"] == "HEALTHY_SILENCE"
        assert len(sent) == 2
        assert sent[0] == "RevX V5 LIVE — STARTED"
        assert sent[1].startswith("RevX V5 LIVE — FINAL Run")
        assert store.pending_notifications() == []
    finally:
        shutil.rmtree(tmp_path)


def test_notification_failure_remains_durable():
    tmp_path = local_tmp()
    store = DurableState(tmp_path / "state")
    service = V5Service(SequenceRunner([result("ACTION_READY")]),
                        tmp_path / "health.json", interval_sec=0,
                        state_store=store,
                        telegram_send=lambda _: (_ for _ in ()).throw(RuntimeError()))
    try:
        final = run(service, 1)
        assert final["notification"]["failed"] == 1
        assert len(store.pending_notifications()) == 1
    finally:
        shutil.rmtree(tmp_path)


def test_action_submitted_notification_identifies_action_and_symbol():
    tmp_path = local_tmp()
    store = DurableState(tmp_path / "state")
    sent = []
    try:
        final = run(V5Service(
            SequenceRunner([result("ACTION_SUBMITTED", reason=None,
                                   action="BUY", symbol="QNT-USD",
                                   intent_id="intent-123456789")]),
            tmp_path / "health.json", interval_sec=0,
            state_store=store, telegram_send=sent.append), 1)
        assert final["status"] == "ACTION_SUBMITTED"
        assert sent == ["RevX V5 | ACTION_SUBMITTED | BUY QNT-USD | intent=intent-12345"]
    finally:
        shutil.rmtree(tmp_path)


def test_stop_event_prevents_next_cycle():
    tmp_path = local_tmp()
    service = V5Service(SequenceRunner([result()]), tmp_path / "health.json",
                        interval_sec=0)

    async def scenario():
        service.request_stop()
        return await service.run(max_cycles=2)

    try:
        observed = asyncio.run(scenario())
        assert observed["status"] == "PAUSED"
        assert observed["cycles"] == 0
        assert observed["service_stop_reason"] == "stop_requested"
    finally:
        shutil.rmtree(tmp_path)


def test_required_start_failure_prevents_runner_cycle():
    tmp_path = local_tmp()
    runner = SequenceRunner([result()])
    sent = []

    def fail_start(message):
        sent.append(message)
        raise RuntimeError("telegram unavailable")

    try:
        final = run(V5Service(
            runner, tmp_path / "health.json", interval_sec=0,
            telegram_send=fail_start, startup_message="START Run",
        ), 1)
        assert final["status"] == "FAILED"
        assert final["reason"] == "telegram_start_delivery_failed"
        assert final["cycles"] == 0
        assert runner.index == 0
        assert final["final_notification"]["failed"] == 1
    finally:
        shutil.rmtree(tmp_path)
