import asyncio

try:
    from tools.v5_structural_canary import run
except ModuleNotFoundError:  # offline release flattens operator tools
    from v5_structural_canary import run


from pathlib import Path


def test_structural_canary_is_offline_and_passes():
    root = Path(r"C:\Users\serba\Documents\RevX\tmp\v5-tests\canary")
    root.mkdir(parents=True, exist_ok=True)
    (root / "state.json").unlink(missing_ok=True)
    (root / "outbox.jsonl").unlink(missing_ok=True)
    report = asyncio.run(run(root))
    assert report["status"] == "PASS"
    assert report["broker_accessed"] == 0
    assert report["live_accessed"] == 0
    assert report["pending_after_restart"] == 0
    assert report["submits_simulated"] == 2
    assert report["positions_after_exit"] == 0
    assert report["realized_net_pnl_usd"] == "0.79"
