import asyncio
from pathlib import Path
import sys
import urllib.error

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "canonical-base-v3.5.8"))

from revx_v3.broker import RateLimited
from revx_v3.client import ApiError, RevXClient
from revx_v3.models import Priority


class PaginatedClient(RevXClient):
    def __init__(self, pages):
        self.pages = pages
        self.queries = []

    async def _auth_get_envelope(self, path, query, lane, action):
        self.queries.append((path, dict(query), lane, action))
        cursor = query.get("cursor")
        return self.pages[cursor]


def test_active_orders_exhausts_cursor_and_preserves_page_metadata():
    client = PaginatedClient({
        None: {"data": [{"id": "one"}],
               "metadata": {"timestamp": 1, "next_cursor": "page-2"}},
        "page-2": {"data": [{"id": "two"}],
                   "metadata": {"timestamp": 2}},
    })
    result = asyncio.run(client.active_orders("ABC-USD", Priority.EXIT_WATCH))
    assert [row["id"] for row in result["data"]] == ["one", "two"]
    assert result["metadata"]["pagination_complete"] is True
    assert result["metadata"]["page_count"] == 2
    assert result["metadata"]["pages"][0]["next_cursor"] == "page-2"
    assert client.queries[1][1]["cursor"] == "page-2"


def test_historical_orders_rejects_repeated_cursor():
    client = PaginatedClient({
        None: {"data": [], "metadata": {"next_cursor": "same"}},
        "same": {"data": [], "metadata": {"next_cursor": "same"}},
    })
    with pytest.raises(ApiError, match="repeated pagination cursor"):
        asyncio.run(client.historical_orders())


def test_active_orders_rejects_malformed_order_row():
    client = PaginatedClient({
        None: {"data": [{"id": "one"}, None], "metadata": {}},
    })
    with pytest.raises(ApiError, match="invalid order row"):
        asyncio.run(client.active_orders())


@pytest.mark.parametrize("metadata", [None, [], "terminal"])
def test_active_orders_rejects_missing_or_malformed_metadata(metadata):
    payload = {"data": []}
    if metadata is not None:
        payload["metadata"] = metadata
    client = PaginatedClient({None: payload})
    with pytest.raises(ApiError, match="invalid pagination metadata"):
        asyncio.run(client.active_orders())


def test_retry_after_milliseconds_are_converted_to_seconds(monkeypatch):
    client = RevXClient(broker=None)

    def rate_limited(*args, **kwargs):
        raise urllib.error.HTTPError(
            "https://revx.revolut.com/api/1.0/orders/active",
            429,
            "rate limited",
            {"Retry-After": "1000"},
            None,
        )

    monkeypatch.setattr("urllib.request.urlopen", rate_limited)
    with pytest.raises(RateLimited) as error:
        client._request("GET", "/api/1.0/orders/active", "", "", False)
    assert error.value.retry_after == 1.0
