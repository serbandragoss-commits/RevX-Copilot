import json
import shutil
import uuid
import time
from pathlib import Path

import pytest

from revx_v5.authority_config import load_runtime_authority
from revx_v5.process_lease import LeaseUnavailable, ProcessLease
from revx_v5.runner import LIVE_ACKNOWLEDGEMENT


def local_tmp():
    path = Path(r"C:\Users\serba\Documents\RevX\tmp\v5-authority-tests") / uuid.uuid4().hex
    path.mkdir(parents=True, exist_ok=False)
    return path


def test_authority_file_defaults_fail_closed_and_rejects_partial_arm():
    root = local_tmp()
    try:
        path = root / "authority.json"
        path.write_text(json.dumps({"schema": "revx-v5-runtime-authority-v1",
                                    "execution_enabled": False,
                                    "order_placement": "OFF",
                                    "acknowledgement": ""}), encoding="utf-8")
        assert load_runtime_authority(path).permits_mutation is False
        path.write_text(json.dumps({"schema": "revx-v5-runtime-authority-v1",
                                    "execution_enabled": True,
                                    "order_placement": "ON",
                                    "acknowledgement": "wrong"}), encoding="utf-8")
        with pytest.raises(ValueError):
            load_runtime_authority(path)
    finally:
        shutil.rmtree(root)


def test_exact_authority_and_single_process_lease():
    root = local_tmp()
    try:
        path = root / "authority.json"
        path.write_text(json.dumps({"schema": "revx-v5-runtime-authority-v1",
                                    "execution_enabled": True,
                                    "order_placement": "ON",
                                    "acknowledgement": LIVE_ACKNOWLEDGEMENT,
                                    "expires_at_epoch": time.time() + 60}),
                        encoding="utf-8")
        assert load_runtime_authority(path).permits_mutation is True
        with ProcessLease(root / "runtime.lock"):
            with pytest.raises(LeaseUnavailable):
                with ProcessLease(root / "runtime.lock"):
                    pass
        with ProcessLease(root / "runtime.lock"):
            pass
    finally:
        shutil.rmtree(root)


def test_packaged_authority_template_is_fail_closed():
    path = Path(__file__).resolve().parents[1] / "authority-v5.off.json"
    authority = load_runtime_authority(path)
    assert authority.execution_enabled is False
    assert authority.order_placement == "OFF"
    assert authority.acknowledgement == ""
    assert authority.permits_mutation is False
