import asyncio
from decimal import Decimal
from types import SimpleNamespace
import pytest

from revx_v5.sizing import size_buy, pending_buy_commitment
from revx_v5.policy import RiskPolicy
from revx_v5.decision import evaluate_entry_with_policy
from test_v5_canonical_action_source import source, Planner, Plan
from test_v5_policy_binding import candidate


def inputs(**changes):
    fields = dict(quantity='400', limit_price='0.3831', stop='0.3757',
                  requested_risk_usd='3', available_usd='188.93',
                  cash_reserve_usd='3.7786', capital_limit_usd='185.1514')
    fields.update(changes)
    return (SimpleNamespace(**fields), SimpleNamespace(base_step='0.00001',
            min_order_size='0.00001', min_order_size_quote='1', max_order_size='100000'))


def test_dynamic_quantity_exceeds_twenty_and_respects_costed_risk():
    plan, rules = inputs()
    q, info = size_buy(plan, rules, '130', {})
    assert Decimal(info['notional_usd']) > 20
    assert Decimal(info['notional_usd']) <= 130
    assert Decimal(info['estimated_stop_loss_with_costs_usd']) <= 3
    assert q == size_buy(plan, rules, '130', {})[0]
    assert q % Decimal(rules.base_step) == 0


def test_tighter_stop_is_not_flat_twenty_and_budget_is_accounted():
    p1, rules = inputs(stop='0.37')
    p2, _ = inputs(stop='0.38')
    q1, _ = size_buy(p1, rules, '150', {})
    q2, _ = size_buy(p2, rules, '150', {})
    assert q1 < q2


def test_costlier_execution_does_not_increase_size():
    plan, rules = inputs()
    q1, _ = size_buy(plan, rules, '150', {'taker_fee_pct': 0})
    q2, _ = size_buy(plan, rules, '150', {'taker_fee_pct': 0.9})
    assert q2 < q1


def test_cash_and_planner_depth_bound_are_never_exceeded():
    plan, rules = inputs(available_usd='5', cash_reserve_usd='2', capital_limit_usd='3')
    q, info = size_buy(plan, rules, '150', {})
    assert q * Decimal(plan.limit_price) + Decimal(info['entry_cost_allowance_usd']) <= 3
    plan, rules = inputs(quantity='10')
    assert size_buy(plan, rules, '150', {})[0] <= 10


@pytest.mark.parametrize('changes', [dict(stop='0.3831'), dict(quantity='NaN'),
                                   dict(available_usd='Infinity'), dict(requested_risk_usd='-1')])
def test_invalid_inputs_refused(changes):
    plan, rules = inputs(**changes)
    with pytest.raises(ValueError):
        size_buy(plan, rules, '150', {})


def test_venue_minimum_never_rounded_up():
    plan, rules = inputs()
    with pytest.raises(ValueError, match='below venue minimum'):
        size_buy(plan, rules, '.99', {})


def test_partial_order_counts_only_remaining_quantity_and_sell_does_not_release_cash():
    rows = [dict(id='1',side='buy',symbol='ABC/USD',quantity='10',filled_quantity='4',
                 leaves_quantity='6',price='2'), dict(id='2',side='sell')]
    total, symbols = pending_buy_commitment(rows)
    assert total == 12 and symbols == {'ABC-USD'}
    with pytest.raises(ValueError):
        pending_buy_commitment([rows[0], rows[0]])
    with pytest.raises(ValueError):
        pending_buy_commitment([dict(rows[0], leaves_quantity='7')])


def test_policy_checks_actual_size_instead_of_twenty():
    policy = RiskPolicy()
    assert policy.can_open('NIGHT', 7, 135, 0)
    assert policy.allows('NIGHT', 7, 135, 10, 0)
    assert not policy.allows('NIGHT', 7, 135, 20, 0)
    assert policy.allows('NIGHT', 1, 20, 100, 0)
    assert not policy.allows('NIGHT', 1, 20, 131, 0)
    assert evaluate_entry_with_policy(candidate(), mode='DAY', open_positions=0,
                                      exposure_usd=0, session_loss_usd=0).reason == 'calculated_size_required'


def test_dynamic_source_emits_sized_body_and_preserves_planner_body():
    plan = Plan(quantity=100, limit_price=2, stop=1.9)
    plan.requested_risk_usd = 3
    plan.available_usd = 100
    plan.cash_reserve_usd = 2
    plan.capital_limit_usd = 98
    class DynamicPlanner(Planner):
        config = {}
        async def pair_rules(self, symbol):
            return SimpleNamespace(base_step='.01',min_order_size='.01',
                                   min_order_size_quote='1',max_order_size='1000')
    item = source(DynamicPlanner(plan))
    item.order_cap_usd = None
    ctx = dict(runtime_mode='NORMAL',entry_enabled=True,operating_mode='NIGHT',
               risk_truth_complete=True,open_positions=7,exposure_usd='135',session_loss_usd='0')
    intent = asyncio.run(item.next_entry(ctx))
    assert intent is not None
    assert Decimal(intent.body['order_configuration']['limit']['base_size']) == Decimal('7.5')
    assert intent.metadata['notional_usd'] == 15
    assert intent.metadata['sizing']['binding'] == 'portfolio_headroom'
    assert plan.body['order_configuration']['limit']['base_size'] == '100'
    ctx['exposure_usd'] = '0'
    intent = asyncio.run(item.next_entry(ctx))
    assert intent.metadata['notional_usd'] > 20


def test_supervisor_reserves_unfilled_buy_exposure():
    from revx_v5.supervisor import V5Supervisor
    class Store:
        def admission_snapshot(self, mode, key):
            return dict(open_positions=1, exposure_usd='20', session_loss_usd='0',risk_truth_complete=True)
    class Boundary:
        state_store = Store()
        async def recover_pending(self):
            return []
        async def prepare_startup(self):
            order = dict(id='buy-2',side='BUY',symbol='NEW-USD',quantity='10',
                         filled_quantity='0',leaves_quantity='10',price='3')
            return dict(runtime_mode='NORMAL',entry_enabled=True,
                        owned_positions=[dict(symbol='SPX-USD')],
                        inventory=dict(count=0,reconciled=True,records=[]),
                        state=SimpleNamespace(active_orders=(order,),ambiguous=False))
    result = asyncio.run(V5Supervisor(Boundary(),operating_mode='NIGHT').prepare())
    assert result['exposure_usd'] == '50'
    assert result['pending_buy_exposure_usd'] == '30'
    assert result['open_positions'] == 2


def test_day_night_transition_retains_account_exposure(tmp_path):
    from revx_v5.state_store import DurableState
    store = DurableState(tmp_path)
    state = store.load()
    state['positions'] = {'NIGHT-USD':dict(operating_mode='NIGHT',quantity='5',average_entry_price='2')}
    store.save(state)
    view = store.admission_snapshot('DAY', 'test')
    assert view['exposure_usd'] == '10'
    assert view['open_positions'] == 1


@pytest.mark.parametrize('activate,reset,marker,passes_stop', [
    (False,False,'STOP_REQUESTED',False), (False,True,'STOP_REQUESTED',False),
    (True,False,'STOP_REQUESTED',False), (True,True,'EMERGENCY',False),
    (True,True,'STOP_REQUESTED',True)])
def test_manual_stop_clear_requires_explicit_live_start(monkeypatch,tmp_path,activate,reset,marker,passes_stop):
    import v5_operator_session as op
    import v5_recovery_preflight as recovery
    kill = tmp_path / 'v5.kill'
    kill.write_text(marker)
    monkeypatch.setattr(op.live_gate, 'STATE_ROOT', tmp_path)
    monkeypatch.setattr(op.live_gate, 'LEASE', tmp_path / 'lease')
    monkeypatch.setattr(op, 'validate_bundle', lambda *args:dict(permit_id='test'))
    monkeypatch.setattr(op, 'load_runtime_authority', lambda *args:SimpleNamespace(permits_mutation=False))
    async def offline_recovery(*args):
        raise RuntimeError('OFFLINE_PREFLIGHT_BOUNDARY')
    monkeypatch.setattr(recovery, 'run', offline_recovery)
    with pytest.raises(RuntimeError, match='OFFLINE_PREFLIGHT_BOUNDARY' if passes_stop else 'V5_KILL_SWITCH'):
        asyncio.run(op.execute('test',activate,reset))
    assert kill.exists() is not passes_stop


def test_state_replace_retries_windows_race_but_propagates_persistent_failure(monkeypatch):
    import revx_v5.state_store as module
    if module.os.name != 'nt':
        pytest.skip('Windows-specific race')
    calls = []
    delays = []
    def replacement(src, dst):
        calls.append((src,dst))
        if len(calls) < 3:
            error = PermissionError('sharing race')
            error.winerror = 5
            raise error
    monkeypatch.setattr(module.os, 'replace', replacement)
    monkeypatch.setattr(module.time, 'sleep', delays.append)
    module.replace_state_file('source', 'target')
    assert len(calls) == 3 and delays == [.01,.02]
    def denied(*args):
        error = PermissionError('persistent')
        error.winerror = 5
        raise error
    monkeypatch.setattr(module.os, 'replace', denied)
    with pytest.raises(PermissionError):
        module.replace_state_file('source','target')
    assert sum(delays[2:]) < .32
