import json
from unittest.mock import patch

from revx_v5.telegram_http import send_telegram


class Response:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return json.dumps({"ok": True}).encode()


def test_telegram_http_transport_posts_without_exposing_token():
    with patch("urllib.request.urlopen", return_value=Response()) as open_url:
        send_telegram("token", "chat", "PASS")
    request = open_url.call_args.args[0]
    assert request.full_url == "https://api.telegram.org/bottoken/sendMessage"
    assert b"PASS" in request.data
