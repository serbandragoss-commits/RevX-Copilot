from revx_v5.live_contract import live_contract
from revx_v5.launch_gate import LaunchBlocked, validate_launch

def report(**updates):
    value={"status":"PASS","active_orders":0,"ambiguous_orders":0,"positions_nonzero":0,"recovery_status":"PASS","live_contract_status":"PASS"}
    value.update(updates); return value

def test_contract_matches_v5_native_limits():
    contract=live_contract()
    assert contract["order_usd"] == 30
    assert contract["sizing"] == "DYNAMIC_RISK_CASH_COSTS"
    assert contract["exposure_usd"] == 200
    assert contract["session_loss_usd"] == 20.0
    assert (contract["day_max_positions"], contract["night_max_positions"], contract["validation_limit"]) == (40,20,10)

def test_launch_gate_requires_fresh_recovery_and_contract():
    for key in ("recovery_status","live_contract_status"):
        try:
            validate_launch(report(**{key:"BLOCKED"}),operator_ack=True,rollback_ready=True)
            assert False, key
        except LaunchBlocked as exc:
            assert key.replace("_status","_not_pass") in str(exc)
