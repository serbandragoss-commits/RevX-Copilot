from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_launcher_gates_before_watchdog_and_service():
    text = (ROOT / "Start-V5-Service.ps1").read_text(encoding="utf-8-sig")
    kill_check = text.index("Test-Path -LiteralPath $kill")
    preflight = text.index("$preflightOutput = & $python $preflightTool")
    gate = text.index("$gateOutput = & $python $launchGate")
    watchdog = text.index("$wp = Start-Process")
    service = text.index("& $python @serviceArgs")
    assert kill_check < preflight < gate < watchdog < service


def test_launcher_requires_exact_ack_and_verified_rollback():
    text = (ROOT / "Start-V5-Service.ps1").read_text(encoding="utf-8-sig")
    assert "REVX_V5_LIVE_EXECUTION_AUTHORIZED" in text
    assert "operator_ack_missing" in text
    assert "rollback_not_ready" in text
    assert "live_runtime.py" in text
    assert "client.py" in text


def test_launcher_forwards_optional_bounded_cycle_limit():
    text = (ROOT / "Start-V5-Service.ps1").read_text(encoding="utf-8-sig")
    assert "[int]$MaxCycles = 0" in text
    assert "--max-cycles" in text


def test_launcher_requires_and_forwards_authority_deadline():
    text = (ROOT / "Start-V5-Service.ps1").read_text(encoding="utf-8-sig")
    assert "expires_at_epoch" in text
    assert "$maxLiveDurationSeconds = 86400" in text
    assert "operator_ack_missing_or_deadline_missing" in text
    assert "--stop-at-epoch" in text


def test_authenticated_preflight_emits_launch_gate_contract_fields():
    text = (ROOT / "v5_authenticated_get_preflight.py").read_text(encoding="utf-8-sig")
    assert '"recovery_status": recovery_status' in text
    assert '"live_contract_status": live_contract_status' in text
