import time

import pytest

from revx_v5.serialized_session import MAX_LIVE_DURATION_SECONDS
from v5_live_service import validate_deadline


def test_live_duration_is_exactly_24_hours():
    now = time.time()
    assert MAX_LIVE_DURATION_SECONDS == 86_400
    validate_deadline(now + MAX_LIVE_DURATION_SECONDS, now)
    with pytest.raises(ValueError):
        validate_deadline(now + MAX_LIVE_DURATION_SECONDS + 1, now)
    with pytest.raises(ValueError):
        validate_deadline(None, now)
