import copy
from decimal import Decimal

import pytest

from revx_v5.execution_truth import ledger_row_complete, recompute_session_risk
from revx_v5.ledger_repair import replay_flat_run
from revx_v5.state_store import DurableState


def memory():
    data = {}
    store = object.__new__(DurableState)
    store.load = lambda: copy.deepcopy(data)
    def save(value):
        data.clear()
        data.update(copy.deepcopy(value))
    store.save = save
    return store, data


def intent(key, side):
    return dict(intent_id=key, symbol='A-USD', side=side,
                metadata=dict(operating_mode='NIGHT', session_key='legacy'))


def order(q, price, cash=None):
    row = dict(filled_quantity=str(q), average_price=str(price), total_fee='0', fee_currency='USD')
    if cash is not None:
        row.update(executed_quote_amount=str(cash), execution_price_source='INDIVIDUAL_FILLS')
    return row


@pytest.mark.parametrize('new_quantity,cash', [('1','10'), ('1.00001','10.0001'), ('2','20')])
def test_legacy_buy_reconciles_basis_without_duplicate_units(new_quantity, cash):
    store, data = memory()
    buy = intent('buy', 'BUY')
    store.apply_execution_fill(buy, order(1, '10.01'))
    data['intents']['buy'].pop('adopted_quote_amount')
    result = store.apply_execution_fill(buy, order(new_quantity, 10, cash))
    position = data['positions']['A-USD']
    assert Decimal(position['quantity']) == Decimal(new_quantity)
    assert Decimal(position['average_entry_price']) == 10
    assert Decimal(result['adopted_delta']) == Decimal(new_quantity)-1
    assert Decimal(data['intents']['buy']['adopted_quote_amount']) == Decimal(cash)
    repeat = store.apply_execution_fill(buy, order(new_quantity, 10, cash))
    assert repeat['adopted_delta'] == '0' and repeat['position_changed'] is False


@pytest.mark.parametrize('quantity,cash,pnl,remaining', [('1','12','2','1'), ('2','26','6','0')])
def test_legacy_sell_corrects_existing_ledger_once(quantity, cash, pnl, remaining):
    store, data = memory()
    store.apply_execution_fill(intent('buy','BUY'), order(2, 10))
    sell = intent('sell', 'SELL')
    store.apply_execution_fill(sell, order(1, '12.01'))
    data['intents']['sell'].pop('adopted_quote_amount')
    store.apply_execution_fill(sell, order(quantity, Decimal(cash)/Decimal(quantity), cash))
    assert Decimal(data['economic_ledger'][0]['net_pnl_usd']) == Decimal(pnl)
    assert Decimal(data.get('positions',{}).get('A-USD',{}).get('quantity','0')) == Decimal(remaining)
    before = copy.deepcopy(data)
    store.apply_execution_fill(sell, order(quantity, Decimal(cash)/Decimal(quantity), cash))
    assert data == before


def test_modern_quote_regression_and_legacy_quantity_regression_still_fail():
    store, data = memory()
    buy = intent('buy', 'BUY')
    store.apply_execution_fill(buy, order(1, 10, 10))
    with pytest.raises(ValueError, match='quote regressed'):
        store.apply_execution_fill(buy, order(1, 9, 9))
    data['intents']['buy'].pop('adopted_quote_amount')
    with pytest.raises(ValueError, match='filled quantity regressed'):
        store.apply_execution_fill(buy, order('.9',10,9))


def test_legacy_buy_migration_requires_full_matching_owned_position():
    store, data = memory()
    buy = intent('buy', 'BUY')
    store.apply_execution_fill(buy, order(1, '10.01'))
    data['intents']['buy'].pop('adopted_quote_amount')
    data['positions']['A-USD']['quantity'] = '.5'
    with pytest.raises(ValueError, match='uniquely owned'):
        store.apply_execution_fill(buy, order(1,10,10))


def test_ledger_repair_uses_same_legacy_completeness_rule():
    store, data = memory()
    buy, sell = intent('buy','BUY'), intent('sell','SELL')
    data['economic_ledger'] = [dict(operating_mode='NIGHT',session_key='legacy',
        entry_fee_usd='.1',exit_fee_usd='.1',net_pnl_usd='1')]
    orders = []
    for i, price in [(buy,10),(sell,11)]:
        row = {**order(1,price,price), 'id':i['intent_id'], 'client_order_id':i['intent_id'],
               'created_date':len(orders)}
        orders.append(row)
        store.apply_execution_fill(i,row)
    assert data['risk']['NIGHT']['sessions']['legacy']['complete'] is True
    fixed,_ = replay_flat_run(data,{'buy':buy,'sell':sell},orders)
    assert fixed['risk']['NIGHT']['sessions']['legacy'] == data['risk']['NIGHT']['sessions']['legacy']
    unknown = dict(entry_fee_usd='0',exit_fee_usd='0',net_pnl_usd='1',fee_truth='UNKNOWN')
    assert ledger_row_complete(unknown) is False
    fixed['economic_ledger'].append({**unknown,'operating_mode':'NIGHT','session_key':'legacy'})
    assert recompute_session_risk(fixed,'NIGHT','legacy')['complete'] is False


@pytest.mark.parametrize('value',['not-a-number','NaN'])
def test_shared_risk_rejects_invalid_economic_value(value):
    state={'economic_ledger':[dict(operating_mode='NIGHT',session_key='legacy',net_pnl_usd=value)]}
    with pytest.raises(ValueError,match='invalid economic value'):
        recompute_session_risk(state,'NIGHT','legacy')
