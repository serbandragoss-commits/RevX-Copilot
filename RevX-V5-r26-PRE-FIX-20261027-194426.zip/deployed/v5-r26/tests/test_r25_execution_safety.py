import asyncio
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "canonical-base-v3.5.8"))

from revx_v3.execution import ExecutionRefused, ExecutionService, PairRules, _validate_entry_momentum
from revx_v5.canonical_action_source import V5ExitPlanner


class Client:
    def __init__(self, *, active=None, bids=None):
        self.active = active or []
        self.bids = bids or [["2.09", "10"]]

    async def active_orders(self, symbol, lane):
        return self.active

    async def order_book(self, symbol, limit, lane):
        return {"bids": self.bids, "asks": [["2.11", "10"]]}


class Service(ExecutionService):
    async def pair_rules(self, symbol, lane=None):
        return PairRules(symbol, "ABC", "USD", 0.01, 0.01, 0.01,
                         100000.0, 1.0, "ACTIVE")

    async def balances_map(self, lane=None):
        return {"ABC": {"available": "2"}}


def position(**overrides):
    value = {
        "symbol": "ABC-USD", "quantity": "2", "stop": 1.5,
        "target": 2.5, "fast_momentum_state": "NEGATIVE",
        "fast_momentum_negative_confirmations": 2,
        "fast_momentum_last_observed_at": 120.0,
    }
    value.update(overrides)
    return value


def planner(client=None, clock=lambda: 120.0):
    return V5ExitPlanner(Service(client or Client(), {}), {}, clock=clock)


def test_r25_mover_lane_allows_recovery_but_rejects_full_reversal():
    base = {"observed_at": time.time(), "m1": -0.03, "m5": 0.12,
            "s20": 0.05, "accel_5_vs_15": 0.02}
    _validate_entry_momentum(base, {}, "MOVER")
    with pytest.raises(ExecutionRefused, match="fresh mover momentum is negative"):
        _validate_entry_momentum({**base, "m1": -0.20, "m5": -0.10,
                                  "s20": -0.10, "accel_5_vs_15": -0.20},
                                 {}, "MOVER")


def test_r25_confirmed_downtrend_has_no_entry_or_loss_floor_veto():
    plan = asyncio.run(planner().build_sell_plan(
        "exit-1", position(), "CONFIRMED_DOWNTREND"
    ))
    assert plan.reason == "CONFIRMED_DOWNTREND"
    assert plan.coverage_pct == 100.0
    assert plan.body["order_configuration"]["limit"]["price"] == "2.09"


@pytest.mark.parametrize("patch", [
    {"fast_momentum_state": "POSITIVE"},
    {"fast_momentum_negative_confirmations": 1},
    {"fast_momentum_last_observed_at": 0},
])
def test_r25_confirmed_downtrend_rejects_unconfirmed_state(patch):
    with pytest.raises(ValueError, match="not fresh and confirmed"):
        asyncio.run(planner().build_sell_plan(
            "exit-unconfirmed", position(**patch), "CONFIRMED_DOWNTREND"
        ))


def test_r25_confirmed_downtrend_rejects_stale_or_future_evidence():
    with pytest.raises(ValueError, match="not fresh and confirmed"):
        asyncio.run(planner(clock=lambda: 300.0).build_sell_plan(
            "exit-stale", position(), "CONFIRMED_DOWNTREND"
        ))
    with pytest.raises(ValueError, match="not fresh and confirmed"):
        asyncio.run(planner(clock=lambda: 100.0).build_sell_plan(
            "exit-future", position(), "CONFIRMED_DOWNTREND"
        ))


def test_r25_confirmed_downtrend_requires_full_depth_inside_slippage_cap():
    client = Client(bids=[["2.09", "1"], ["1.00", "10"]])
    with pytest.raises(ExecutionRefused, match="visible bid depth"):
        asyncio.run(planner(client).build_sell_plan(
            "exit-2", position(), "CONFIRMED_DOWNTREND"
        ))


def test_r25_confirmed_downtrend_still_refuses_active_order():
    with pytest.raises(ExecutionRefused, match="active venue order"):
        asyncio.run(planner(Client(active=[{"side": "sell"}])).build_sell_plan(
            "exit-3", position(), "CONFIRMED_DOWNTREND"
        ))


def test_r25_degraded_position_requires_fresh_three_strike_evidence():
    confirmed = position(
        coverage_missing_confirmations=3,
        coverage_last_missing_at=120.0,
    )
    plan = asyncio.run(planner().build_sell_plan(
        "exit-degraded", confirmed, "DEGRADED_POSITION"
    ))
    assert plan.reason == "DEGRADED_POSITION"
    with pytest.raises(ValueError, match="not fresh and confirmed"):
        asyncio.run(planner().build_sell_plan(
            "exit-degraded-low", position(
                coverage_missing_confirmations=2,
                coverage_last_missing_at=120.0,
            ), "DEGRADED_POSITION"
        ))
    with pytest.raises(ValueError, match="not fresh and confirmed"):
        asyncio.run(planner(clock=lambda: 300.0).build_sell_plan(
            "exit-degraded-stale", confirmed, "DEGRADED_POSITION"
        ))
