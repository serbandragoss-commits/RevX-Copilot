"""One authenticated GET-only V5 runner cycle with mutation disabled."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path


class MutationDisabled:
    async def submit_order(self, *_args, **_kwargs):
        raise RuntimeError("mutation disabled in runner rehearsal")


async def run(config_path: Path, source_root: Path, state_root: Path) -> dict:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(source_root))
    from revx_v3.broker import RequestBroker
    from revx_v3.client import RevXClient
    from revx_v3.models import Priority
    from revx_v5.live_runtime import V5LiveBoundary
    from revx_v5.provider_adapter import RevXV5ProviderAdapter
    from revx_v5.runner import NullActionSource, V5Runner
    from revx_v5.state_store import DurableState
    from revx_v5.supervisor import V5Supervisor

    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    broker = RequestBroker(
        auth_gap_sec=float(config.get("auth_gap_ms", 750)) / 1000.0,
        public_gap_sec=float(config.get("public_gap_ms", 1100)) / 1000.0,
    )
    client = RevXClient(
        broker,
        base_url=str(config.get("base_url") or "https://revx.revolut.com"),
        api_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["api_key_file"])))),
        private_key_file=Path(os.path.expandvars(os.path.expanduser(str(config["private_key_file"])))),
        timeout_sec=float(config.get("http_timeout_sec", 20)),
    )
    started = time.time()
    try:
        adapter = RevXV5ProviderAdapter(client, Priority.EXIT_CRITICAL)
        boundary = V5LiveBoundary(adapter, MutationDisabled(),
                                  state_store=DurableState(state_root))
        result = await V5Runner(V5Supervisor(boundary), boundary,
                                NullActionSource()).cycle()
    finally:
        await broker.close()
    return {
        "schema": "revx-v5-runner-rehearsal-v1",
        **result,
        "observed_at": time.time(),
        "duration_sec": round(time.time() - started, 6),
        "broker_accessed": 1,
        "live_accessed": 0,
        "mutation_client_loaded": 0,
        "order_placement": "OFF",
        "process_started": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = asyncio.run(run(args.config, args.source_root, args.state_root))
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if result["status"] in {"HEALTHY_SILENCE", "ACTION_READY"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
