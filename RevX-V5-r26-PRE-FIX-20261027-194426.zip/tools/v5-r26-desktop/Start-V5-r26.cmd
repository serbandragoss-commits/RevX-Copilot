@echo off
setlocal
set "ATTESTATION=C:\Users\serba\Documents\RevX\state\v5\v6-counterpart-attestation.json"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-V5-r26.ps1" -V6Attestation "%ATTESTATION%"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo V5 r26 launcher exit code: %EXIT_CODE%
if "%EXIT_CODE%"=="0" exit /b 0
pause
exit /b %EXIT_CODE%
