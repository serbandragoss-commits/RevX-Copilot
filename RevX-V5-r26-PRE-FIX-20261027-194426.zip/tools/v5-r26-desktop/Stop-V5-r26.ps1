[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$candidate = 'C:\Users\serba\Documents\RevX\deployed\v5-r26'

& (Join-Path $candidate 'Stop-V5-Service.ps1')
