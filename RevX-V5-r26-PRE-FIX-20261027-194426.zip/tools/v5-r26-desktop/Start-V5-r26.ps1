[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$V6Attestation
)

$ErrorActionPreference = 'Stop'
$candidate = 'C:\Users\serba\Documents\RevX\deployed\v5-r26'
$config = 'C:\Users\serba\Documents\RevX\config-v3.live.json'

& (Join-Path $candidate 'Start-V5-r26-Operator.ps1') -V6Attestation $V6Attestation -Config $config
exit $LASTEXITCODE
