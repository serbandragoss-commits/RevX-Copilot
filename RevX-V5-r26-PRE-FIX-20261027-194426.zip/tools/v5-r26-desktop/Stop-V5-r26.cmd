@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Stop-V5-r26.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo V5 r26 stop exit code: %EXIT_CODE%
if "%EXIT_CODE%"=="0" exit /b 0
pause
exit /b %EXIT_CODE%
